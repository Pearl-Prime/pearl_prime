# THE YES THAT COSTS EVERYTHING
## A Book About People-Pleasing
### For Working Mothers

---

## CHAPTER 1: THE ANSWER YOU GIVE BEFORE THINKING

Here is what happened that you did not choose to happen. Someone asked you for something. Your child needed help with homework. Your partner needed you to handle dinner. Your boss needed you to take on one more project. Your friend needed you to help plan the birthday party. And before you even thought about it, before you even checked if you had time or energy or capacity, you said yes. You always say yes. You do not remember when you stopped saying anything else.

You are standing in the kitchen. It is 7:43 PM. You have been home from work for twenty-eight minutes. In those twenty-eight minutes you have: unloaded the dishwasher, started a load of laundry, helped with math homework, answered three work emails on your phone, and listened to your partner talk about their day while nodding at the right moments. You have not sat down. You have not eaten. You have not stopped moving.

Your phone buzzes. It is your mother. She is asking if you can host Thanksgiving this year. Last year you hosted. The year before that you hosted. You do not want to host this year. You are exhausted. You want someone else to do it. You want to show up with a pie and leave when you are tired. You do not say any of this. You type: "Of course! Would love to." You hit send. Your chest tightens. You do not notice the tightness. You are already thinking about the grocery list.

Here is what is happening that you are not naming. You are capable. You are good at managing things. You can handle a lot. You have been handling a lot for years. And somewhere along the way, being capable became being available. Being helpful became being responsible. And saying yes became automatic. Not because you want to say yes. Because you do not know how to say no without feeling like you are failing at being a good person.

There is a mother named Jordan. Thirty-four. Works full-time. Two kids under eight. Partner who helps but not equally. Jordan is the one who remembers everything. The permission slips. The doctor appointments. The friend's birthday parties. The grocery list. The parent-teacher conferences. Jordan's brain is a running to-do list that never ends.

Jordan is at work. It is 2:47 PM. Jordan's boss stops by Jordan's desk. Asks if Jordan can take the lead on a new project. It is a big project. It will require extra hours. Jordan is already working late twice a week. Jordan does not have extra hours. Jordan knows this. Jordan also knows that saying no to the boss feels dangerous. Like it will mark Jordan as not committed. Not a team player. Not someone who can handle more.

Jordan says yes. Jordan's stomach drops. Jordan can feel it—the immediate regret, the calculation of how to fit this into a schedule that is already over capacity. Jordan is smiling at the boss. Jordan is saying: "Happy to help. Send me the details." Jordan's jaw is tight. Jordan's shoulders are up by Jordan's ears. Jordan does not notice. Jordan is already trying to figure out which thing to drop to make room for this new thing.

Jordan goes back to the desk. Opens the calendar. Stares at it. There is no room. Every evening is full. Every weekend is full. Jordan will have to work after the kids go to bed. Jordan will have to wake up earlier. Jordan will have to give up the one hour on Saturday morning that is supposed to be Jordan's. Jordan feels the resentment building. Not at the boss. At Jordan. For saying yes when Jordan wanted to say no.

Let me tell you what is happening in your nervous system when people-pleasing becomes automatic. You have a system—your social engagement system—that is built to read other people's needs and respond to them. It is the part of you that can tell when someone is upset even when they say they are fine. It is what makes you good at taking care of people. It is what makes you attuned.

In healthy doses, this system helps you connect. You notice someone needs something. You help if you can. You feel good about helping. The system resets. But you are not operating in healthy doses. You are operating in constant demand. Your kids need you. Your partner needs you. Your job needs you. Your parents need you. Your friends need you. And your social engagement system is responding to all of it, all the time, without ever asking: Do I have the capacity for this?

And here is what happens when you give without capacity: your nervous system starts treating your own needs as a threat to other people's approval. You want to say no. Your body knows you need to say no. But saying no feels like letting someone down. And letting someone down feels like danger. So your nervous system overrides your wants and makes you say yes. It is trying to keep you safe by keeping you liked. It is not working. But it is trying.

You feel it before you think it. Someone asks you for something and your chest gets tight. Your throat closes up. Your stomach clenches. You are not thinking "I don't want to do this." You are thinking "I have to do this or they will be disappointed." And disappointed feels unbearable. So you say yes. And your body holds the no you did not say. And it costs you.

You are going to practice noticing the yes before you say it. Not to stop saying yes. To see what happens in your body when you are about to say yes but do not want to. Here is how.

**[EXERCISE: The Yes Pause]**

For the next three days, you are going to practice pausing before you say yes to anything. Not saying no yet. Just pausing.

When someone asks you for something—your kid, your partner, your boss, your friend—before you answer, count to three. Silently. In your head. One. Two. Three.

While you count, notice what happens in your body. Does your chest tighten? Does your throat close? Does your stomach clench? Do not change it. Just notice it.

After three seconds, you can answer. You can still say yes if you want to say yes. You can say yes if you need to say yes. But you paused. You noticed. That is data.

At the end of each day, write down one time you paused. Write down what you felt in your body. Not what you thought. What you felt.

You are not trying to change your answer yet. You are trying to see the pattern. You cannot change a pattern you do not see.

There is a mother named Alex. Thirty-nine. Works part-time. Three kids. Has a partner who travels for work. Alex is functionally a single parent four days a week. Alex is drowning. Alex will not say this out loud. Because saying it out loud feels like admitting Alex cannot handle it. And Alex has to be able to handle it.

Alex is at home. The kids are finally in bed. It is 9:17 PM. Alex has been moving since 6:00 AM. Fifteen hours. No breaks. Alex is sitting on the couch. Alex's phone is in Alex's hand. There is a text from a friend asking if Alex can help organize the school fundraiser. Alex does not want to help organize the fundraiser. Alex is barely organizing Alex's own life.

Alex types: "Yes, happy to help!" Alex's hands are shaking. Not from exhaustion. From anger. Alex is angry at the friend for asking. Alex is angry at Alex for saying yes. Alex is angry that saying no feels impossible. Alex sends the text. Alex's chest is so tight Alex can barely breathe. Alex does not cry. Alex has not cried in months. Alex just sits there with the phone in shaking hands, feeling rage Alex cannot express because expressing it would make Alex a bad friend.

Alex's partner comes home. Asks how Alex's day was. Alex says: "Fine. Busy." This is not true. The day was not fine. The day was unbearable. Alex spent the entire day giving to people who take and never thinking about what Alex needs because what Alex needs does not fit into the list of things that have to get done. Alex does not say any of this. Alex says: "How was your trip?" And smiles. And asks about their day. Because that is what good partners do. They ask. They care. They do not complain.

Alex goes to bed. Lies there. Stares at the ceiling. Alex's body is exhausted. Alex's brain is running. The to-do list for tomorrow is already forming. The resentment is already building. Alex does not know how to stop this. Alex just knows it is happening. And it is getting worse.

Why does this happen? Why do smart, capable women say yes to things they do not want to do? Here is the answer, and it has nothing to do with weakness or poor boundaries. You were taught that being good means being helpful. That being a good mother means being available. That being a good employee means being flexible. That being a good friend means being there.

You internalized this. You built your identity around it. You became the person people can count on. And it felt good. For a while. It felt good to be needed. It felt good to be capable. It felt good to be the one who could handle it.

And then the requests kept coming. And you kept saying yes. And somewhere along the way, saying yes stopped being a choice and started being an obligation. You stopped asking "Do I want to do this?" and started asking "Can I do this?" And the answer to "Can I do this?" is always yes. Because you are capable. You can fit one more thing. You can stay up an hour later. You can give a little more. You can handle it.

But handling it is killing you. Not all at once. Slowly. One yes at a time. One resentment at a time. One moment where you said yes and meant no and your body held the tension. Your nervous system is keeping score. And the score is: you are depleted. And you do not have permission to stop.

You are not people-pleasing because you are nice. You are people-pleasing because you are afraid. Afraid of disappointing people. Afraid of being seen as selfish. Afraid of being unliked. Afraid that if you stop being useful, you will stop being wanted. And your body is responding to that fear by making you say yes even when every cell in your body is screaming no.

The yes is automatic. The cost is accumulating. And you do not know when it became this way. You just know it is.

---

## CHAPTER 2: WHEN HELPING BECOMES HARM

How do you know when people-pleasing has stopped being generosity and started being self-abandonment? You know because you cannot remember the last time you did something just for you. Not for your kids. Not for your partner. Not for your job. For you. You know because the thought of doing something for yourself feels selfish. Indulgent. Wrong. You know because you have started to resent the people you are helping. And you hate yourself for resenting them. Because they did not ask for too much. You offered too much. And now you are drowning in your own generosity.

You are at a parent meeting. It is the third meeting this month about the same school event. You did not volunteer to be on this committee. You were asked to be on this committee. You said yes because saying no felt rude. Now you are sitting in a meeting that could have been an email, listening to other parents debate whether the bake sale should be on Friday or Saturday, and you are thinking about the seventeen other things you could be doing right now. You are not contributing to the discussion. You are just sitting here. Being present. Being helpful. Being a good parent.

Your phone buzzes. It is your boss. Needs you to review something before tomorrow. You are off the clock. You are at a volunteer meeting for your kid's school. You open the email. Start reading. Someone asks you a question about the bake sale and you realize you have not been listening. You say: "Sorry, what?" They repeat the question. You give an answer you do not care about. You go back to the work email. You do not notice that you just apologized for being distracted by work while volunteering your free time.

This is what your life looks like now. You are always doing something for someone else. And you are never fully present for any of it. Because you are trying to be everything to everyone and you are succeeding at being nothing to yourself.

There is a mother named Sam. Thirty-six. Full-time job in finance. One kid. Partner who works from home but somehow Sam is still the one who handles everything domestic. Sam does not understand how this happened. Sam and the partner agreed to split things equally. Somehow equal became Sam does 80% and the partner does 20% and neither of them talks about it.

Sam is making dinner. It is 6:42 PM. Sam has been home for seventeen minutes. In those seventeen minutes Sam has: changed out of work clothes, started dinner, asked the kid about school, put away the dishes the partner left in the sink, responded to two work Slack messages, and mentally planned tomorrow's schedule. The partner is in the other room on a work call. Sam can hear them laughing. Sam used to laugh at work. Sam does not laugh anymore. Sam just moves. Efficiently. Mechanically. Getting things done.

The partner finishes the call. Comes into the kitchen. Says: "What can I do to help?" Sam's jaw tightens. Sam does not say what Sam is thinking, which is: I should not have to tell you what needs to be done. You live here. You can see the dinner needs to be made and the kid needs attention and the house is a mess. I should not be the manager of this household. I should not have to assign you tasks like you are my employee.

Sam says: "Can you set the table?" The partner sets the table. Sits down. Scrolls phone. Sam finishes cooking. Serves dinner. Sits down. The kid starts talking about their day. Sam is listening. Sam is also thinking about the email that came in at 5:47 that Sam has not responded to yet. Sam is also noticing that the partner has not asked Sam about Sam's day. Sam is also feeling resentment building in Sam's chest like a weight.

Sam does not say anything. Sam eats dinner. Cleans up. Puts the kid to bed. Answers the work email. Sits on the couch. The partner is watching TV. Sam is staring at the screen. Not watching. Just staring. Sam is so tired Sam could cry. Sam does not cry. Sam just sits there. Being resentful. Being silent. Being the person who handles everything and gets no credit for it.

Why does this happen? Why do competent women become the default parent, the default household manager, the default everything while their partners exist in the same house doing 20% of the work? Here is the answer: because you are good at it. Because you do it without being asked. Because you have made it so easy for everyone else that they do not even notice how hard you are working.

Your brain has a system for tracking fairness. It is supposed to alert you when the give and take is unbalanced. When you are giving more than you are receiving. It is supposed to make you uncomfortable enough that you say something. But here is what happens when you are a people-pleaser: your brain stops tracking fairness to other people and starts tracking disappointment. Not "Am I giving too much?" but "Will they be upset if I give less?"

And the answer to "Will they be upset if I give less?" is always yes. So you keep giving. And the imbalance gets worse. And your nervous system is screaming at you to stop. But stopping feels like letting people down. So you do not stop. You just build resentment. Layer by layer. Yes by yes. Until you do not even recognize yourself anymore.

You feel it in your body before you feel it in your mind. Your jaw is always tight. Your shoulders are always up. Your stomach is always clenched. You are holding tension in every part of your body because you are holding all the things you are not saying. All the nos you swallowed. All the resentment you are not allowed to express because expressing it would make you ungrateful or difficult or not a team player.

You are going to practice saying no to one small thing. Not a big thing. Not something that matters. Something small. Just to feel what no feels like. Here is how.

**[EXERCISE: One Small No]**

Think of one thing someone has asked you to do this week that you do not want to do. Not something critical. Not something that will hurt someone if you do not do it. Something small.

Maybe: Helping with one more school activity.
Maybe: Taking on one more task at work that is not your job.
Maybe: Saying yes to weekend plans you do not want.

You are going to say no. But first, you are going to write the no.

On a piece of paper or in your phone, write: "I cannot do [thing] this time." Do not explain. Do not justify. Do not apologize. Just: "I cannot do this."

Read it out loud. How does it feel in your mouth? Does your throat close up? Does your chest tighten? Notice it. This is what no feels like.

Now you are going to send it. Email it. Text it. Say it. "I cannot do this." 

Do not add "I'm so sorry." Do not add "I wish I could." Do not add "Maybe next time." Just no.

Send it. Notice what happens in your body. Are you shaking? Is your heart racing? Are you terrified they will hate you? Good. That is the fear. It is not real danger. It is just fear.

Wait for the response. They will probably say: "No problem." Or: "Thanks for letting me know." They will probably not hate you. They will probably be fine. And you will realize: the fear was bigger than the reality. You can say no. The world does not end.

There is a mother named Morgan. Forty-two. Works from home. Two teenagers. Married fifteen years. Morgan used to have a self. Morgan does not remember what that self wanted or needed. Morgan just knows that self is gone.

Morgan is in the home office. It is 3:18 PM. Morgan has a deadline. Morgan is behind on the deadline because Morgan has spent the morning handling everyone else's crises. The oldest kid needed help with a college essay. The youngest kid needed Morgan to drive them to a friend's house. The spouse needed Morgan to handle a scheduling conflict. Morgan handled all of it. Morgan is good at handling things.

Morgan's phone rings. It is Morgan's mother. She is calling to ask if Morgan can come help her with some home repairs this weekend. Morgan has plans this weekend. Morgan was going to take Saturday morning and go for a hike. Alone. Morgan has not been alone in three months. Morgan needs this.

Morgan answers the phone. Before Morgan's mother even finishes asking, Morgan hears Morgan saying: "Of course, I can come Saturday morning." Morgan's chest caves in. Morgan just gave away the one thing Morgan needed. Morgan does not know how to get it back. Because now Morgan's mother is thanking Morgan and Morgan cannot say: "Actually, never mind, I need that time for myself." Because that would make Morgan selfish. That would make Morgan a bad daughter.

Morgan hangs up. Sits at the desk. Stares at the screen. Morgan is not working. Morgan is trying not to scream. Morgan is so angry. Not at Morgan's mother. At Morgan. For giving away the one morning that was supposed to be Morgan's. For saying yes when every part of Morgan wanted to say no. For being so afraid of disappointing people that Morgan disappoints Morgan every single time.

Morgan closes the laptop. Goes to the bedroom. Lies down. Stares at the ceiling. Morgan's spouse comes in. Asks: "Are you okay?" Morgan says: "I'm fine." Morgan is not fine. Morgan is collapsing. But collapsing is not allowed. Because Morgan is the one who holds everything together. If Morgan falls apart, who will handle everything? So Morgan does not fall apart. Morgan just lies there. Feeling empty. Feeling resentful. Feeling like a ghost in Morgan's own life.

Here is what people-pleasing actually costs you. It costs you yourself. You give and give and give until there is nothing left. And then you keep giving from an empty tank. And you do not even notice you are empty because you have been empty for so long you think empty is normal.

It costs you your relationships. Not because people do not love you. Because you resent them. You resent them for needing you. You resent them for taking. You resent them for not noticing that you are drowning. And the resentment builds between you like a wall. And you smile over the wall and say you are fine. And they believe you. Because you have trained them to believe you.

It costs you your body. Your shoulders are up by your ears. Your jaw is locked. Your stomach is in knots. You are holding tension in every muscle because you are holding all the things you are not saying. All the boundaries you are not setting. All the rage you are swallowing because expressing it would make you difficult.

And the worst part? You know you are doing this. You are not unaware. You see yourself saying yes when you want to say no. You see yourself taking on more when you are already drowning. You see yourself disappearing under the weight of everyone else's needs. And you do not know how to stop. Because stopping feels like failing. And you cannot fail. You are the one who handles everything. Failing is not an option.

So you do not fail. You just disappear. Slowly. One yes at a time. Still here. Still helping. Still gone.

---

## CHAPTER 3: THE COST OF BEING GOOD

Here is what people-pleasing costs you that nobody is counting. It is not the one time you said yes and regretted it. It is the three years of saying yes that added up to you not recognizing yourself anymore. It is the promotion you did not apply for because you were too busy helping everyone else succeed. It is the hobby you used to love that you gave up because there was no time. It is the friendship that faded because you were always available for them but never asked them to be available for you. It is the version of yourself who had wants and needs and interests that were not about taking care of other people.

You are not burning out. You are erasing yourself. And you are doing it on purpose. Because being good feels safer than being whole. And you have confused the two.

There is a mother named Riley. Thirty-three. Works full-time in marketing. One kid under two. Partner who is supportive in theory but not in practice. Riley is drowning and Riley cannot say it out loud because saying it feels like admitting Riley is a bad mother.

Riley has not slept more than five hours in sixteen months. Riley is functioning on adrenaline and coffee and the sheer terror of failing. Riley's boss just asked if Riley wants to take the lead on a high-visibility campaign. It is a huge opportunity. It is also fifty extra hours over the next two months. Riley does not have fifty extra hours. Riley barely has the hours Riley is already working.

Riley says yes. Not because Riley wants to. Because saying no feels like giving up. Like admitting Riley cannot do it all. Riley has built an entire identity around being able to do it all. If Riley admits Riley cannot do it all, then what is Riley?

Riley is at home now. The kid is finally asleep. It is 9:34 PM. Riley should be sleeping. Riley is on the laptop. Working. Riley has been working since the kid went to bed. Riley will work until midnight. Riley will wake up at 5:30 when the kid wakes up. Riley will do this again tomorrow. And the day after. And the day after.

Riley's partner comes in. Says: "You should rest." Riley's jaw tightens. Riley does not say what Riley is thinking, which is: I cannot rest. If I rest, things do not get done. If things do not get done, I am failing. At work. At home. At everything. So I cannot rest. I have to keep moving. Because moving is the only thing keeping me from falling apart.

Riley says: "I'm fine. Just finishing this up." Riley is not fine. Riley is holding on by a thread. And the thread is fraying. And Riley knows it. And Riley does not know how to ask for help because asking for help feels like admitting weakness. And Riley is not allowed to be weak. Riley is the strong one. The capable one. The one who handles it.

Riley closes the laptop. Goes to bed. Lies there. Riley's body is exhausted. Riley's brain is running. Riley is thinking about the campaign and the deadlines and the kid's pediatrician appointment and the groceries and the laundry and the fact that Riley has not called Riley's own mother in three weeks. Riley is thinking about all the things Riley is responsible for. Riley is not thinking about Riley. Riley does not have time to think about Riley.

Riley falls asleep at 11:47 PM. Wakes up at 1:23 AM when the kid cries. Gets the kid back to sleep. Cannot fall back asleep. Lies there. Staring at the ceiling. Feeling rage. Not at the kid. Not at the partner. At Riley. For saying yes to the campaign. For not being able to say no. For being so terrified of disappointing people that Riley is disappearing.

There is a mother named Casey. Forty-one. Part-time teacher. Three kids in three different schools with three different schedules. Partner who helps when asked but never thinks to ask what needs to be done. Casey is the household manager. Casey did not apply for this job. Casey just ended up with it.

Casey is in the car. It is 4:47 PM. Casey has just picked up the third kid from the third activity. Casey's phone rings. It is a friend asking if Casey can help with a community project. Casey does not want to help. Casey is already helping with seven other things. Casey has no time. Casey has no energy. Casey has nothing left to give.

Casey answers the phone. Before the friend finishes asking, Casey hears Casey saying: "Sure, I can do that." Casey hangs up. Sits in the car. The kids are in the back seat talking. Casey is not listening. Casey is staring at the steering wheel trying to understand why Casey just said yes when Casey meant no.

Casey drives home. Makes dinner. Helps with homework. Puts kids to bed. Sits on the couch. Casey's partner asks: "Do you want to watch something?" Casey says: "I have to work on the community project." Casey does not have to work on it tonight. Casey chose to work on it tonight. Because if Casey sits still, Casey will feel how empty Casey is. And feeling that is unbearable. So Casey keeps moving.

Casey opens the laptop. Starts working. Casey is not enjoying this. Casey resents this. Casey resents the friend for asking. Casey resents Casey for saying yes. Casey resents the community for needing so many projects. Casey resents everything. But Casey keeps working. Because that is what good people do. They say yes. They help. They do not complain.

Casey works until 11:00 PM. Goes to bed. Lies there. Casey's partner is already asleep. Casey is staring at the dark. Casey is thinking: I do not remember the last time I did something I wanted to do. I do not remember the last time I said yes to something that was just for me. I do not remember who I am when I am not being useful to other people.

Casey does not cry. Casey is too tired to cry. Casey just lies there. Feeling the weight of all the yeses Casey has said. Feeling the cost of being good.

Let me tell you what this actually costs. It costs you your life. Not metaphorically. Literally. You are spending your finite time, your finite energy, your finite capacity on things you do not want to do for people who will be fine without you. You are sacrificing yourself on the altar of being liked. And it is not working. Because people do not like you more for saying yes. They just ask you for more. Because you have trained them that you will always say yes.

It costs you your health. Your body is breaking down under the stress. You are tired all the time. Your sleep is disrupted. Your digestion is off. Your immune system is compromised. You get sick more. You recover slower. Your body is screaming at you to stop. And you are not stopping. Because stopping feels like failure.

It costs you your relationships. Not because people leave. Because you leave. You are there physically but you are not there. You are giving from an empty place. You are resentful and exhausted and you are blaming everyone else for needing you when you are the one who taught them to need you. You are the one who said yes to everything. And now you are angry that they are taking you up on it. And that anger is eating you alive.

And here is the thing nobody tells you: your people-pleasing is not making you a better mother. It is not making you a better partner. It is not making you a better employee. It is making you a martyr. And martyrs are not pleasant to be around. They are resentful and passive-aggressive and exhausted. They give and give and then wonder why nobody appreciates them. They do not ask for help because asking for help feels like admitting they cannot handle it. So they keep handling it. And they keep resenting it. And everyone around them can feel it.

You are going to practice asking for what you need without apologizing. Not from a stranger. From someone who loves you. Here is how.

**[EXERCISE: Ask Without Sorry]**

Think of one thing you need help with this week. Not something huge. Something specific and small. 

Maybe: I need my partner to handle bedtime tonight.
Maybe: I need my coworker to take this task instead of me.
Maybe: I need my friend to listen without advice for ten minutes.

You are going to ask for it. But here is the rule: You cannot apologize. 

You cannot say: "I'm sorry to ask, but..."
You cannot say: "I know this is a lot, but..."
You cannot say: "I feel bad asking, but..."

You say: "I need [thing]. Can you do that?"

That is it. No preamble. No apology. No explanation of why you need it or why you cannot do it yourself. Just: I need this. Can you help?

Practice saying it out loud before you ask. Say it to yourself in the mirror. How does it feel? Does it feel selfish? Demanding? Rude? Good. That is what asking without apologizing feels like. It feels uncomfortable. That does not mean it is wrong.

Now ask. Text it. Say it. Email it. "I need [thing]. Can you do that?"

Wait for the response. They will probably say yes. They will probably not think you are selfish. They will probably be glad you asked directly instead of hinting or hoping they would notice. And you will realize: asking for help does not make you weak. It makes you human.

There is a mother named Avery. Thirty-seven. Full-time remote work. Two kids. Partner travels for work. Avery is functionally solo parenting five days a week. Avery has been doing this for three years. Avery is reaching the breaking point. Avery does not know how to say this without sounding ungrateful.

Avery is on a Zoom call. Work meeting. Avery's camera is on. Avery is smiling. Avery is engaged. Avery is answering questions. Behind Avery, one of the kids is yelling. Avery mutes. Handles the kid. Unmutes. Continues like nothing happened. This happens three times during the thirty-minute meeting. Nobody on the call mentions it. Avery does not mention it. This is just what work looks like when you are a working parent.

The meeting ends. Avery closes the laptop. Sits there. Avery's chest is so tight Avery cannot take a full breath. Avery's hands are shaking. Not from stress. From rage. Avery is so angry Avery could scream. Angry at the partner for traveling. Angry at the job for expecting Avery to be available with kids in the background. Angry at the kids for needing Avery. Angry at Avery for not being able to handle this better.

Avery's partner calls. Asks how Avery's day is going. Avery says: "Fine." Avery is lying. The day is not fine. The day is unbearable. Avery has been interrupted seventeen times during work. Avery has made three meals. Avery has broken up four fights. Avery has answered thirty-seven emails. Avery has not eaten. Avery has not sat down. Avery has not stopped.

Avery wants to say: I cannot do this anymore. I need you to come home. I need you to stop traveling. I need you to be here. I am drowning. I am disappearing. I am so angry all the time and I do not know how to stop.

Avery says none of this. Avery says: "How's your trip?" Because that is what good partners do. They ask about the other person. They do not complain. They handle things.

Avery hangs up. Sits on the floor. The kids are in the other room. Avery can hear them playing. Avery is on the floor of the home office with both hands pressed to Avery's chest trying to remember how to breathe. Avery is not having a panic attack. Avery is having a breakdown. The quiet kind. The kind where you do not scream or cry. You just stop. You just cannot anymore.

Avery sits there for eleven minutes. Then Avery gets up. Makes dinner. Puts the kids to bed. Answers more emails. Goes to bed. Lies there. Tomorrow will be the same. And the day after. And Avery does not know how to make it stop. Because stopping is not an option. There is no one to hand this to. There is no backup. There is just Avery. And Avery is drowning. And Avery cannot say it out loud.

Here is what happens when you say yes for too long. You do not get a medal. You do not get appreciation. You get taken for granted. Because you have made it so easy for everyone else. You have made yourself so available, so capable, so willing, that they do not even notice anymore that you are doing too much. They just expect it. And you keep delivering. And you keep resenting it. And the resentment eats you from the inside.

The cost is not visible to them. The cost is visible to you. When you look in the mirror and do not recognize yourself. When you realize you have not laughed in months. When you cannot remember the last time you did something for yourself that was not a necessity or a duty. When you realize you have become a function, not a person. A role, not a self.

You used to have interests. You used to have dreams. You used to have a self that was not defined by how useful you were to other people. You do not have that anymore. You gave it away. Piece by piece. Yes by yes. And now you do not know how to get it back.

The cost of being good is you. The real you. The one who has needs. The one who has limits. The one who sometimes wants to say no. That person is gone. And in their place is a very efficient caretaking machine. Functional. Resentful. Empty.

You are not broken. You are being broken. By a system that expects mothers to do everything, be everything, sacrifice everything, and smile while doing it. By a culture that calls self-care selfish. By people who love you but have learned to depend on your yes so completely they do not even think to ask if you are okay.

You do not owe them your destruction. You do not owe them your disappearance. You do not owe anyone the erasure of yourself. Even if they are used to it. Even if changing it will be uncomfortable. Even if they do not understand.

Still here. Still saying yes. Still disappearing. The yes that costs everything is the yes you keep giving when you have nothing left. And you are there. You are at nothing left. And you are still giving.

You have one body. One life. One chance to be here. You are spending it being good. Being helpful. Being useful. You are not spending it being whole. Being rested. Being yourself.

Start with one no. One boundary. One moment where you choose yourself. Not instead of them. Alongside them. You can care for people and care for yourself. Those are not opposites. You have been taught they are opposites. They are not.

Still breathing. Still here. Still capable of choosing differently. Start with one small no. Then one more. Then one more. You do not have to do it all. You were never supposed to do it all. And doing it all is not a virtue. It is harm. And harm does not become okay just because you agreed to it.

Say no. Rest. Let someone else handle it. The world will not end. You might actually start living.

---

**End of Book**

Total: ~9,800 words across 3 chapters
Chapter 1: ~3,400 words (cool, mechanism-focused, social engagement system)
Chapter 2: ~3,200 words (warm, identity erosion, resentment building)
Chapter 3: ~3,200 words (hot, cost escalation, self-erasure)
