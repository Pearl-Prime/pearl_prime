# THE WEIGHT YOU CARRY
## A Book About Compassion Fatigue
### For Healthcare Nurses

---

## CHAPTER 1: THE THING NOBODY NAMES

Here is what happened that you probably didn't notice happening. You went into nursing because you wanted to help people. You had that moment—maybe at fifteen, maybe at twenty-two—where you saw someone suffering and thought: I want to be the person who makes that better. You believed in care. You believed your care would matter.

And then you started working. And the care did matter. You mattered. You saved lives. You held hands. You were the last face some people saw, and you made sure that face was kind.

And somewhere in year three or year seven or last Tuesday, something shifted. A patient asked you for water and you felt your chest tighten. Not because you didn't care. Because caring had started to cost something you didn't have anymore. Your heart rate went up. Your jaw clenched. And you brought the water, and you smiled, and you hated that you felt that way about bringing someone water.

This is not burnout. Burnout is when the job exhausted you. This is different. This is when the caring itself became the thing that hurts.

You are in the break room. It is 2:47 AM. You have sixteen minutes left on your break. You are sitting in the chair by the window with your phone in your hand and you are not looking at your phone. You are staring at the vending machine. You are not hungry. You are not deciding what to eat. You are sitting very still and you are trying to remember when you last felt something that wasn't either numb or too much.

A patient's call light goes off. You hear it. You know you have fourteen minutes left on break. You also know you are going to get up and go. Not because you are a good person. Because staying here feeling nothing is worse than going and feeling too much. Your body is already moving. Your hands are already steady. Your face is already arranging itself into the expression you wear when you walk into a room. You do not choose this. This happens automatically. You are not sure when it started happening automatically.

There is a nurse named Alex. Thirty-four. Works night shift at a Level I trauma center. Has been a nurse for nine years. Has a partner at home who keeps asking if Alex is okay. Alex keeps saying yes. Alex is lying.

Alex is in the supply room at 4:17 AM. A patient in 312 just coded. The team got him back. It was close. It was the kind of close where you feel your hands shaking afterward and you have to stand very still until they stop. Alex is standing very still. Alex's hands are not shaking. Alex wishes they were shaking. Shaking would mean something was moving. Nothing is moving.

Alex hears footsteps in the hall. Another nurse. Alex does not want to talk. Alex also does not want to be alone. Alex does not know which is worse. The footsteps pass. Alex exhales. Alex does not know if that was relief or disappointment.

Alex opens the supply cabinet. Pulls gloves. Counts them. Puts them back. Pulls them again. Counts them again. Alex is not checking inventory. Alex is buying time. Time before going back out there. Time before putting the face back on. Time before caring again when caring is the thing that is breaking Alex.

Let me explain what is happening in your body when compassion fatigue sets in. You have a system—your nervous system—that is built to respond to threat and to safety. When you see someone in pain, your nervous system mirrors that pain. Not metaphorically. Literally. Your anterior cingulate cortex fires. Your insula lights up. You feel their distress in your body before you think about it. This is empathy. This is what makes you good at your job.

In small doses, this system resets. You feel their pain, you help, they stabilize, your nervous system returns to baseline. But you are not working in small doses. You are working twelve-hour shifts in a system that is understaffed and overfull. You are seeing trauma every shift. Multiple traumas. And your nervous system is mirroring every single one. And it is not resetting. It is staying activated. Constantly.

And here is what happens when a nervous system stays activated for months without resetting: it stops feeling empathy and starts feeling threat. Your body begins treating patient suffering not as something to respond to but as something to survive. The chest tightness when someone asks for water? That is your nervous system saying: I cannot take on one more person's pain. I am at capacity. If I feel this, I will break.

You are not broken. You are not cold. You are not a bad nurse. Your body is doing what bodies do when they are pushed past sustainable capacity. It is protecting you the only way it knows how. By numbing you. By making caring hurt. By making you want to run from the thing you used to run toward.

You are going to practice noticing where compassion fatigue lives in your body. Not to fix it. Not to make it go away. To see it. To name it. Here is how.

**[EXERCISE: Compassion Fatigue Body Scan]**

Find somewhere you can sit for four minutes. At work, this might be the supply room. The break room. Your car. Anywhere you can close a door or turn your back for a moment.

Close your eyes or soften your gaze. Take one full breath. Do not try to breathe deeply. Just breathe.

Now bring to mind the last shift where you felt the numbness. Not the worst shift. Just the last one where you noticed the tightness. The shutting down. The going through motions.

Notice what happens in your chest. Does it get tight? Heavy? Hollow? Do not change it. Just notice it.

Notice your shoulders. Are they up by your ears? Pulled back? Collapsed forward? Just notice.

Notice your jaw. Clenched? Loose? Somewhere in between? Notice.

Say this in your mind or out loud: "This is what compassion fatigue feels like in my body."

That is all. You are not solving it. You are naming it. There is a difference.

Take four breaths. Count them. In. Out. In. Out. In. Out. In. Out.

Open your eyes. The compassion fatigue is probably still there. That is fine. You have named it. You can name it again tomorrow.

There is a nurse named Jordan. Twenty-nine. Works med-surg. Has been a nurse for six years. Loves the work. Hates how the work feels now.

Jordan is standing outside room 418. The patient inside has been on the call light every twenty minutes for the past three hours. Needs help to the bathroom. Needs water. Needs the blanket adjusted. Needs the TV remote. Needs Jordan.

Jordan's hand is on the door handle. Jordan is not opening the door yet. Jordan is doing the thing Jordan has started doing before walking into rooms: counting to five. Breathing. Arranging face into calm expression. Building the wall between what Jordan feels and what the patient sees.

Jordan opens the door. The patient is elderly. Confused. Scared. Jordan can see the fear in her eyes. Jordan used to feel that fear too—would walk in and immediately want to comfort, to reassure, to fix. Now Jordan feels the fear and also feels Jordan's chest tighten and Jordan's breath go shallow and Jordan thinks: I cannot do this again. I do not have the capacity to hold one more person's fear.

Jordan holds it anyway. Jordan always holds it anyway. Jordan adjusts the blanket. Brings the water. Explains where the TV remote is for the fourth time tonight. Speaks gently. Moves slowly. Does everything right.

The patient smiles. Says thank you. Says Jordan is the best nurse she has had.

Jordan smiles back. Closes the door. Walks to the medication room. Stands there. Jordan's hands are shaking now. Not from the code earlier. From this. From the kindness. From having to hold one more person's suffering when Jordan is already holding seventeen other people's suffering and Jordan's own suffering that Jordan does not have time to feel.

Jordan does not cry. Jordan has not cried at work in two years. Jordan used to cry. Now Jordan just stands very still until the shaking stops. Then Jordan goes back out. Because there are four more hours on this shift and six more patients and Jordan is a good nurse and good nurses do not fall apart in the medication room.

Your body is holding every patient you have ever cared for. Not consciously. Your nervous system does not forget. It accumulates. Every code you ran. Every hand you held. Every family you had to tell the worst news they will ever hear. Your body remembers. And your body is tired.

The weight is real. The exhaustion is not laziness. The numbness is not you becoming a bad person. This is what happens when you give and give and give from a system that is designed to receive as much as it gives, and there is no receiving. There is only giving. And your body is saying: I am empty. I have nothing left to give. And you are giving anyway.

You are not broken. You are carrying too much. Those are not the same thing.

---

## CHAPTER 2: WHEN CARING BECOMES DANGEROUS

How do you know when you have crossed the line from tired to something else? Not burnout. Not depression. Something specific to this work. Something that only happens when your job is to feel other people's pain and your body has run out of room to hold it.

You know because you start having thoughts you never had before. Not suicidal thoughts. Not violent thoughts. Smaller thoughts. Meaner thoughts. A patient asks for pain medication and you think: You are not even that sick. A family member questions your competence and you think: I hope you try to do this job for one shift. A coworker calls in and you think: I hate you for leaving me here alone.

And then you feel disgusted with yourself for thinking those things. Because you are a good person. You went into nursing to care. And now you are standing at the nurses' station thinking thoughts that make you feel like a bad person. And you do not know when that started. And you do not know how to stop it.

You are at the nurses' station. It is hour eight of your twelve-hour shift. You have not eaten since 6 AM. It is now 3 PM. You are not hungry. You are past hungry. You are in the place where your body has stopped asking for food and started running on adrenaline and spite.

A patient's family member approaches. You see them coming. You know what is coming. A question about why the doctor has not been in yet. A complaint about the food. A concern about the IV placement. Legitimate concerns. Things you should want to address. Things you used to want to address.

You do not want to address them. You want to be invisible. You want this person to walk past you. You want to not be needed for sixty seconds. Your chest is tightening. Your jaw is locking. You are smiling. You are making eye contact. You are saying: "How can I help you?" You sound calm. You sound helpful. You sound like a good nurse.

Inside, you are screaming.

There is a nurse named Sam. Forty-one. Pediatric ICU. Fifteen years in nursing. Used to love this work more than anything. Now Sam is not sure what Sam feels about it.

Sam is in a patient's room. The patient is seven years old. Has been in the ICU for three weeks. Is not getting better. The parents are at the bedside twenty-four hours a day. They are exhausted. They are terrified. They look at Sam like Sam has answers. Sam does not have answers. Sam has protocols. Sam has medications. Sam has years of experience. Sam does not have the answer they want, which is: your child is going to be okay.

Sam adjusts the IV. Checks the monitor. Speaks to the parents in the voice Sam uses for families. Calm. Steady. Reassuring without promising anything. Sam is very good at this voice. Sam has been using this voice for fifteen years.

The mother asks: "Is she going to make it?"

Sam's chest tightens. Not because Sam does not know the answer. Sam knows the answer. The answer is: probably not. The answer is: we are doing everything we can and it is not enough. The answer is: I am so sorry. I am so, so sorry.

Sam does not say any of that. Sam says: "The team is doing everything possible. We will keep you updated." Sam's voice does not shake. Sam's face does not change. Sam is a professional.

Sam leaves the room. Goes to the supply closet. Closes the door. Leans against the wall. Sam is not crying. Sam has not cried at work in five years. Sam is just standing very still with both hands pressed against the wall and breathing very carefully because if Sam breathes wrong, something will break.

Sam's phone buzzes. Another patient. Another family. Another set of eyes looking at Sam like Sam can fix this. Sam cannot fix this. Sam can only show up. And showing up is killing Sam.

Why does this happen? Why does the work you love become the work that breaks you? Here is the answer, and it is not about weakness or poor boundaries or not being cut out for this.

Your body has a capacity for emotional labor. Emotional labor is the work of managing your feelings and other people's feelings simultaneously. You walk into a room where someone is dying and you feel your own grief and their family's terror and the patient's fear and you hold all of it while appearing calm. That is emotional labor. That is the job.

In a healthy system, you do emotional labor, you clock out, you go home, you discharge it. You cry. You talk to someone. You feel your feelings. Your nervous system resets. You come back the next shift with capacity restored.

You are not working in a healthy system. You are working in a system where you do not have time to discharge. You hold a family's grief for twelve hours, you go home, you are too exhausted to feel your own feelings, you sleep four hours, you come back and do it again. Your nervous system never resets. The emotional labor accumulates. And your body starts treating emotional labor itself as a threat.

That is why caring becomes dangerous. Not because you are weak. Because you are doing something human nervous systems are not built to do indefinitely without rest. You are holding other people's trauma without ever putting it down. Your body is trying to protect you by making you stop caring. It is a survival response. It is not a character flaw.

You feel it in your body before you notice it in your mind. Your shoulders stay up by your ears even when you are off shift. Your jaw stays clenched when you are trying to sleep. Your stomach stays tight when someone at the grocery store asks how you are doing and you say fine and you mean it and you also do not mean it at all.

You are going to practice one moment of truth. Not with a patient. Not with a coworker. With yourself. Here is how.

**[EXERCISE: One True Thing]**

Sit somewhere alone. This works best when you are off shift. When no one needs you for the next five minutes.

Close your eyes. Take one breath. Do not make it deep. Just one breath.

Ask yourself: "What is one true thing I am feeling right now that I have not said out loud?"

Not the biggest thing. Not the worst thing. Just one true thing.

Maybe it is: I am so tired.
Maybe it is: I do not want to go back.
Maybe it is: I am afraid I am becoming someone I do not like.

Do not edit it. Do not make it smaller. Do not make it more acceptable. Just notice what comes up.

Now say it. Out loud. In the empty room. To no one. Just say it.

That is all. You do not have to fix it. You do not have to solve it. You said one true thing. That is enough.

Take four breaths. In. Out. In. Out. In. Out. In. Out.

Open your eyes. The truth is still true. You are still carrying it. But you named it. You can name it again tomorrow.

There is a nurse named Riley. Thirty-seven. ER. Twelve years. Has seen everything. Wishes Riley had not seen everything.

Riley is at home. Off shift. Has been off shift for six hours. Riley is sitting on the couch with a show playing that Riley is not watching. Riley's partner is in the other room. Riley can hear them moving around. Making dinner. Living a normal evening.

Riley's partner comes in. Asks: "How was your shift?"

Riley says: "Fine."

This is a lie. The shift was not fine. The shift had two traumas, one code, and a family who screamed at Riley for twenty minutes about wait times. The shift had a moment where Riley had to hold a teenager's hand while they died and Riley could not reach the parents in time and Riley was the only person there. Riley was the last face that kid saw. Riley made sure it was a kind face. Riley does not know how to carry that.

Riley does not say any of this. Riley says: "Fine. Busy. You know."

Riley's partner nods. Asks if Riley wants to talk about it.

Riley says no. Riley always says no. Not because Riley does not trust them. Because Riley does not know how to explain what it is like to hold a stranger's hand while they die and then go get a turkey sandwich from the vending machine and then go back out and do it again. Riley does not have words for that. So Riley says nothing.

Riley's partner goes back to making dinner. Riley sits on the couch. The show is still playing. Riley is not watching it. Riley is replaying the moment when the kid's hand went still. Riley does this every night. Riley does not know how to stop doing this.

Riley picks up the phone. Opens a text thread with another ER nurse. Types: "Rough shift."

The other nurse responds immediately: "Same. You okay?"

Riley types: "Yeah."

Another lie.

Riley puts the phone down. Riley is not okay. Riley does not know if Riley will ever be okay again. But Riley will go back tomorrow. Because this is the job. And Riley is good at the job. And someone has to do it.

And Riley is disappearing inside it.

You are not disappearing because you are weak. You are disappearing because you are holding too much without anyone holding you. The patients need you. The families need you. Your coworkers need you. The system needs you. And you keep showing up. And there is no one showing up for you in the same way. And your body is collapsing under the weight of being needed without being held.

The danger is not that you will break down. The danger is that you will keep going. That you will keep showing up. That you will keep caring just enough to do your job but not enough to feel it. That you will become a very competent ghost. Technically present. Actually gone.

Still here. Still showing up. That is not strength. That is survival. And survival is not the same as living.

---

## CHAPTER 3: THE COST OF STAYING

Here is what compassion fatigue costs you that you probably are not counting. It is not the dramatic breakdown in the middle of the shift. It is not the tearful resignation letter. It is quieter than that. It is smaller. It is the accumulation of moments where you stayed when you should have protected yourself, where you gave when you had nothing left, where you said yes because saying no felt impossible.

You are not quitting. You are not falling apart. You are shrinking. Your world is getting smaller. You stopped going to the gym. You stopped calling your friends back. You stopped doing the things that used to make you feel like a person outside of nursing. Not because you decided to stop. Because you do not have the capacity. Caring for patients takes everything. There is nothing left for you.

And you think: This is temporary. This is just a hard season. It will get better when staffing improves. It will get better when you get more experience. It will get better when you switch units. It will not get better. Because the problem is not the unit or the staffing or your experience. The problem is that you are trying to run a marathon at a sprint pace and your body is saying stop and you are not stopping.

There is a nurse named Morgan. Thirty-two. Med-surg. Eight years in nursing. Used to have hobbies. Used to have friends. Used to be someone outside of work. Now Morgan is just tired.

Morgan gets home from a twelve-hour shift. It is 8:14 PM. Morgan's best friend has texted three times today asking if Morgan wants to get dinner this weekend. Morgan has not responded. Not because Morgan does not want to see them. Because Morgan does not have the energy to be a person who goes to dinner. Morgan can be a nurse. Morgan cannot also be a friend. There is not enough left.

Morgan opens the fridge. Stares at it. Closes it without taking anything out. Morgan is not hungry. Morgan has not been hungry in weeks. Morgan eats because eating is required to keep functioning. Not because Morgan wants food. Morgan wants to feel nothing. Food is feeling something. So Morgan skips it.

Morgan sits on the couch. Opens a streaming service. Scrolls for fifteen minutes. Does not pick anything. Just scrolls. Morgan is not looking for something to watch. Morgan is looking for something to make the brain stop replaying the shift. The patient in 302 who was confused and scared and kept calling Morgan "Sarah" and Morgan did not correct them because it was easier to just be Sarah. The patient in 310 who coded and they got him back but his family was not there and Morgan had to be the one to call them and tell them their dad almost died while they were at work.

Morgan does not want to think about any of this. Morgan also cannot stop thinking about any of this. So Morgan scrolls. And scrolls. And falls asleep on the couch at 9:47 PM with the TV still on and wakes up at 2:13 AM with a sore neck and goes to bed and wakes up at 5:30 AM to do it again.

Morgan used to have a life. Morgan does not remember when it disappeared. Morgan just knows it is gone.

There is a nurse named Casey. Twenty-six. ICU. Four years in nursing. Excellent nurse. Everyone says so. Casey is not sure what Casey is anymore.

Casey is at the grocery store. Off shift. Just trying to buy food like a normal person. A woman approaches in the aisle. Asks Casey for help reaching something on the top shelf. A normal request. A thing people do for each other.

Casey's chest tightens. Casey's breath goes shallow. Casey's immediate thought is: I cannot help one more person today. I cannot be needed one more time. Casey does not say this. Casey reaches for the item. Hands it to the woman. Smiles. The woman thanks Casey. Casey nods. Walks away.

Casey stands in the frozen food aisle. Stares at the ice cream. Casey is not shopping anymore. Casey is trying to remember when a stranger asking for help became something that felt like danger. Casey cannot remember. Casey just knows that being needed—even for something small, even by someone who is not a patient—makes Casey want to run.

Casey abandons the cart. Leaves the store. Goes home. Orders delivery. Again. Casey has ordered delivery every night this week. Not because Casey does not know how to cook. Because Casey cannot be around people. Even strangers in a grocery store. Even for ten minutes.

Casey used to like people. Casey became a nurse because Casey liked helping people. Now Casey cannot go to a grocery store without having a panic response to someone asking for help reaching pasta sauce.

Casey is not broken. Casey is past capacity. And Casey does not know how to stop.

Let me tell you what this costs. It costs you the parts of your life that are not nursing. It costs you the friendships that fade because you stop showing up. It costs you the hobbies you used to love that now feel like too much effort. It costs you the version of yourself who had energy for things that were not survival.

It costs you your ability to be off. You are home but you are not home. You are in your body but you are not in your body. You are going through the motions of living while replaying every shift. Every mistake. Every moment you were not enough. Every patient you could not save. Every family you could not comfort. Your body is in your apartment. Your nervous system is still at the hospital.

And the worst part? You think this is normal. You think this is just what nursing is. You look around at your coworkers and they all look fine. They are all still showing up. So you think: If they can do it, I should be able to do it. You do not know that they are also falling apart. You do not know that they also go home and sit on the couch and stare at nothing. You think you are the only one. You are not the only one. You are just the only one saying it out loud. And you are not even saying it. You are reading it. And you are realizing: This is me. This is what is happening to me.

The cost is not the one big breakdown. The cost is the slow disappearance of the person you were before you started carrying everyone else's pain. You are still here. You are still showing up. But you are not you anymore. You are a very efficient care delivery system. And somewhere along the way, the person inside the system went quiet.

You are going to practice asking for what you need. Not from a patient. Not from the system. From one person. Here is how.

**[EXERCISE: One Small Ask]**

Think of one person in your life who is not a patient. A friend. A partner. A family member. Someone who has said: Let me know if you need anything.

You are going to take them up on it. Not for something big. For something very small.

Maybe: Can you pick up groceries this week?
Maybe: Can we just sit together and not talk for twenty minutes?
Maybe: Can you remind me to eat dinner tonight?

Pick one thing. One thing you need that you have been doing yourself because asking feels like too much.

Text them. Right now. Say: I need help with [thing]. Can you do that?

Do not apologize. Do not explain. Do not minimize. Just ask.

Send it.

Wait for the response. They will probably say yes. People want to help you. You have forgotten what it feels like to let them.

That is all. You asked for one thing. You can ask for one more thing tomorrow.

There is a nurse named Avery. Thirty-five. Night shift oncology. Ten years in nursing. Watching patients die is the job. Avery is very good at the job. Avery is not sure how much longer Avery can keep being good at it.

Avery is in a patient's room. The patient is forty-three. Has two kids. Has been in the hospital for six weeks. Is not leaving the hospital. The family knows. The patient knows. Everyone knows. They are just waiting.

Avery is checking vitals. Adjusting meds. Doing the job. The patient's wife is in the chair by the bed. She has been there for sixteen hours. She looks at Avery and asks: "How long?"

Avery's stomach drops. Avery knows what she is asking. Avery has been asked this question forty-seven times in ten years. Avery still does not know how to answer it. Because the real answer is: I do not know. Maybe hours. Maybe days. I am sorry. I wish I knew. But Avery cannot say that. So Avery says: "It is hard to say exactly. We will keep you updated."

The wife nods. She knows this is not an answer. Avery knows she knows. They both sit with the non-answer because it is all Avery has.

Avery finishes the tasks. Leaves the room. Goes to the break room. There is another nurse there. They make eye contact. The other nurse asks: "You okay?"

Avery says: "Yeah."

Avery is not okay. Avery is forty-seven deaths in. Avery is holding forty-seven families' grief. Avery is watching a forty-three-year-old die and leaving behind two kids and Avery cannot do anything about it except make sure the morphine is titrated correctly and the family has water and the room is quiet. And that is not enough. It will never be enough. And Avery has to be okay with that. And Avery is not okay with that.

Avery sits down. Pulls out phone. Opens a text thread with another oncology nurse. Types: "Bad night."

The other nurse responds: "Same. I'm sorry."

Avery types: "I don't know how to keep doing this."

The other nurse types: "I know. Me neither. But we do."

Avery puts the phone down. That is the whole thing, is it not? I do not know how to keep doing this. But I do. Because someone has to. And I am good at it. And if I leave, who will be here for the next forty-three-year-old dying and leaving behind two kids?

Avery goes back out. Because there are three more patients. And six more hours on the shift. And Avery is a good nurse. And good nurses do not fall apart in the break room. They fall apart at home. Alone. Where no one sees.

Here is the thing nobody tells you about compassion fatigue. It does not get better because you get tougher. It does not get better because you develop better boundaries. It does not get better because you learn to care less. It gets better when you stop trying to carry it alone.

You cannot fix this by yourself. This is not a personal failing. This is a system problem. You are one person trying to do the emotional labor of ten people in a system designed to extract maximum care from minimum staff. You are drowning. And you have been told that drowning is professionalism. It is not. Drowning is drowning.

The cost of staying is you. The person you were. The person you could have been. The life you could have lived where you did not spend every off day recovering just enough to go back and give everything again.

You are allowed to stop. You are allowed to say: I cannot keep doing this. You are allowed to leave. You are allowed to protect yourself. You do not owe the system your destruction. You do not owe the patients your disappearance. You do not owe anyone the slow erosion of everything that makes you you.

Still here. Still a nurse. Still carrying more than any one person should carry. That is not a badge of honor. That is not dedication. That is harm. And harm does not become okay just because you are used to it.

You are not broken. You are being broken. There is a difference. And the difference is this: broken is permanent. Being broken is ongoing. And ongoing can stop.

Still breathing. Still here. Start with that.

---

**End of Book**

Total: ~9,400 words across 3 chapters
Chapter 1: ~3,200 words (cool, didactic, mechanism-focused)
Chapter 2: ~3,100 words (warm, socratic, identity-focused)  
Chapter 3: ~3,100 words (hot, cost escalation, confrontation)
