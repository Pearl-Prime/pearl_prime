# The Feeling You Can't Name
## A Therapeutic Audiobook for Gen Z
### Written by Claude for SpiritualTech Systems

---

## OPENING [3 minutes]

There's a feeling in your chest right now.

Maybe it's been there for hours. Maybe days. Maybe so long you don't even notice it anymore.

It's not quite anxiety. Not quite sadness. Not quite anything you can point to and say "that's what this is."

It's just... there. A weight. A tightness. A heaviness you carry everywhere.

And when someone asks "How are you?" you say "I'm fine" because you don't have words for what you're actually feeling.

This book is about that gap. Between what you're feeling and what you can say about it.

I'm not going to tell you to journal your feelings or name your emotions or practice mindfulness. Those might help someone, but that's not what we're doing here.

We're going to look at why you can't name what you're feeling. Why emotions feel dangerous. Why you've been running from your inner experience for so long that you've forgotten how to be with it.

And why that running is making everything harder.

Because you can't heal what you can't feel. You can't process what you won't acknowledge. You can't move through what you keep avoiding.

So let's stop avoiding.

---

## CHAPTER 1: THE NUMBNESS [12 minutes]

### The Flatline

Someone asks how you're feeling and your mind goes blank.

Not because nothing's happening. Because everything's happening and you can't sort through it.

So you land on "fine" or "tired" or "stressed" because those are the default options. The ones that don't require actually feeling anything.

This is emotional alexithymia. The inability to identify and describe your own emotional states.

And you've gotten really good at it.

### What's Actually Happening

Your emotional system has been suppressed for so long it's gone offline.

Not because you're broken. Because at some point, feeling was too dangerous.

Maybe your emotions weren't allowed. Maybe they were punished. Maybe nobody could hold them so you learned to not have them.

Maybe you learned that anger is bad, sadness is weakness, fear is embarrassing, joy is naive.

So you shut it down. All of it.

And now you're left with a narrowed emotional range:
- Fine
- Stressed
- Tired
- Anxious (but only in the vague sense)
- Overwhelmed (which isn't actually an emotion, it's emotional flooding you can't parse)

Everything else got compressed into those five words. And you lost access to the nuance of your inner life.

### The Pattern

Here's how it happens:

1. Emotion arises (body signals something)
2. Mind doesn't recognize it (no practice identifying)
3. Feeling gets labeled as "something's wrong"
4. Discomfort increases (because it's unidentified)
5. Seek distraction to escape discomfort
6. Emotion gets suppressed
7. Never learn what that feeling was
8. Pattern reinforces
9. Emotional vocabulary shrinks
10. Loop intensifies

You're not emotionless. You're emotionally illiterate.

And illiteracy isn't stupidity—it's just lack of practice.

### Why It Won't Stop

Because feeling is uncomfortable.

It's easier to stay numb. Easier to scroll. Easier to distract. Easier to stay busy than to sit with what's actually happening inside you.

And nobody taught you how to do this. Nobody modeled it. Nobody said "here's how you identify what you're feeling and sit with it without it destroying you."

So you're winging it. And mostly what you're doing is avoiding it.

### The Interrupt

You're not going to suddenly become emotionally fluent. But you can start building vocabulary.

Try this: Next time you feel something but can't name it, locate it in your body.

Where is this feeling? Chest? Stomach? Throat? Shoulders?

You don't need to name the emotion yet. Just notice the physical sensation.

"There's tightness in my chest."

That's step one. Feeling lives in your body, not your mind.

Start there.

### The Practice

Right now, scan your body.

What sensations are present? Tension? Lightness? Heaviness? Temperature?

Don't interpret. Don't fix. Just notice.

"Right now my jaw is clenched."

"Right now my shoulders are tight."

"Right now there's pressure in my chest."

That's data. That's feeling. Even if you don't have words for it yet.

---

## CHAPTER 2: THE SADNESS YOU WON'T FEEL [11 minutes]

### The Push-Down

Something sad happens. Or you remember something sad. Or you just feel sad for no reason you can identify.

And immediately your brain says: "Don't go there. Keep moving. You're fine."

So you don't cry. You don't sit with it. You don't let it move through you.

You just push it down and keep going.

And it stays down there. Waiting. Getting heavier.

### What's Actually Happening

You're storing grief in your body.

Every time you suppress sadness, it doesn't disappear. It gets filed away. Compressed. Added to the collection of unfelt feelings living in your nervous system.

And here's the thing about grief: it doesn't have an expiration date.

That thing from three years ago you never processed? Still there.

That loss you moved on from without ever feeling it? Still there.

That disappointment you shrugged off? Still there.

It all accumulates. Until you're carrying years of unfelt sadness and wondering why you feel heavy for no reason.

### The Pattern

Here's the cycle:

1. Sad thing happens
2. Sadness arises
3. Judge sadness as weak/pointless/indulgent
4. Suppress the feeling
5. Distract or dissociate
6. Sadness goes underground
7. Resurfaces later (usually at inconvenient times)
8. Suppress again
9. Accumulation increases
10. Loop intensifies

You think you're being strong by not crying. You think you're moving on by not dwelling.

But suppression isn't strength. It's storage.

And eventually, your storage is full.

### Why It Won't Stop

Because you learned that sadness is dangerous.

Maybe because when you cried as a kid, you got told to stop. Maybe because showing sadness meant being vulnerable and vulnerable meant being hurt.

Maybe because there was too much sadness around you and you decided you wouldn't add to it.

So you learned: don't cry. Keep it together. Be strong. Move on.

And now you can't access sadness even when you need to. Even when it would help. Even when crying would actually release the pressure.

### The Interrupt

You're not going to force yourself to cry. But you can stop running from sadness when it shows up.

Try this: Next time you feel sad, don't immediately distract.

Just sit with it for two minutes.

Not "thinking about why you're sad" (that's analysis, not feeling).

Just feeling the sadness in your body.

Where is it? What does it feel like? Heavy? Hollow? Aching?

Let it be there without fixing it.

Sadness isn't an emergency. It's just information about loss.

### The Practice

Right now, think of something you've been avoiding feeling sad about.

Could be big. Could be small. Could be from yesterday or years ago.

Just notice: What would happen if you let yourself feel sad about it?

You don't have to do it right now. Just notice what comes up when you consider it.

That resistance? That's the suppression mechanism.

It's trying to protect you from something that can't actually hurt you.

---

## CHAPTER 3: THE ANGER YOU'RE NOT ALLOWED [13 minutes]

### The Swallow

Someone crosses a boundary. Or disrespects you. Or does something that's actually not okay.

And you feel it—that flash of heat, that surge in your chest.

Anger.

And immediately you suppress it. Because anger is bad. Anger is ugly. Anger makes you the problem.

So you swallow it. Smile. Say "it's fine."

And the anger doesn't go away. It just turns inward.

### What's Actually Happening

You're directing your anger at the wrong target.

Anger is designed to signal boundary violations. It's your nervous system saying "that's not okay."

But you were taught that expressing anger is unacceptable. That it makes you difficult, aggressive, too much.

So instead of directing anger outward (where it belongs), you direct it inward.

At yourself. For feeling angry. For being sensitive. For caring about things that "shouldn't" matter.

And this creates a toxic cycle: you're angry, you suppress the anger, you feel ashamed for being angry, and then you're angry at yourself for being ashamed.

It compounds.

### The Pattern

Here's the cycle:

1. Boundary gets violated
2. Anger arises (healthy response)
3. Judge anger as bad/wrong/dangerous
4. Suppress expression of anger
5. Anger turns inward (self-criticism, shame)
6. Feel powerless (because anger is meant to mobilize action)
7. Resent yourself for being powerless
8. More anger directed inward
9. Loop intensifies

You end up carrying rage that has nowhere to go. And it leaks out sideways—in passive aggression, in irritability, in chronic frustration, in depression.

### Why It Won't Stop

Because you think anger will destroy your relationships.

You think if you express anger, people will leave. They'll think you're too much. They'll reject you.

And maybe some people will. The ones who need you to stay small. The ones who can't handle your boundaries.

But here's what nobody tells you: unexpressed anger destroys relationships anyway.

It comes out as resentment. As withdrawal. As criticism. As that wall you build between yourself and the people you supposedly care about.

You can't have intimacy without honesty. And you can't have honesty without anger sometimes.

### The Interrupt

You're not going to start yelling at people. But you can start acknowledging when you're angry.

Try this: Next time you feel that flash of anger, instead of immediately suppressing it, name it.

"I'm angry right now."

Not to the other person necessarily. Just to yourself.

Acknowledge that the anger is there. That it's information. That it's telling you something about what you need or what boundary got crossed.

You don't have to act on it immediately. You just have to stop pretending it's not there.

### The Practice

Right now, think of something you're angry about but haven't let yourself fully feel.

Could be recent. Could be old. Could be "silly" or "legitimate"—anger doesn't care about your judgment.

Notice: Where is the anger in your body? Jaw? Fists? Chest? Stomach?

What does it want to do? Scream? Push? Break something?

You don't have to do those things. Just notice the impulse.

That's your anger trying to mobilize you.

It's not the enemy. It's information about what needs to change.

---

## CHAPTER 4: THE FEAR YOU WON'T ADMIT [10 minutes]

### The Mask

You're terrified. About something real or something imagined or something you can't quite name.

But you don't say "I'm scared." You say "I'm stressed" or "I'm overwhelmed" or "I'm fine, just tired."

Because admitting fear feels like admitting weakness.

And you're not allowed to be weak.

### What's Actually Happening

You're repackaging fear into something more socially acceptable.

Fear sounds childish. Like you can't handle things. Like you need help.

So you translate it into stress (more acceptable), anxiety (more clinical), or exhaustion (more relatable).

But fear and stress aren't the same thing.

Stress is about demands exceeding resources.

Fear is about perceived threat.

And when you mislabel fear as stress, you treat it wrong.

You try to solve it with productivity, time management, rest. None of which address the actual fear underneath.

### The Pattern

Here's the cycle:

1. Fear arises (threat detected)
2. Judge fear as weakness/overreaction
3. Relabel as stress/anxiety/overwhelm
4. Try to "fix" it through control/productivity
5. Fixing doesn't work (because it's fear, not stress)
6. Feel more afraid (now of the fear itself)
7. More relabeling
8. More ineffective coping
9. Loop intensifies

You're running from your fear instead of toward what it's trying to tell you.

### Why It Won't Stop

Because admitting fear feels dangerous.

If you say "I'm scared," people might think you can't handle it. They might lose confidence in you. They might leave.

Or worse: you might realize the fear is rational. That the thing you're afraid of might actually happen. That you might not be able to control it.

So you keep calling it stress. Keep pushing through. Keep pretending you're fine.

And the fear gets louder.

### The Interrupt

You're not going to eliminate fear. But you can stop running from it.

Try this: Next time you feel afraid, say it out loud.

"I'm scared."

Not "I'm stressed about this." Not "This is making me anxious."

"I'm scared of [specific thing]."

Name the fear. Let it be fear.

It doesn't make you weak. It makes you honest.

### The Practice

Right now, what are you actually afraid of?

Not stressed about. Not worried about.

Afraid of.

Say it: "I'm afraid that..."

Notice how your body responds to naming it directly.

Fear loses some of its power when you stop hiding it.

---

## CHAPTER 5: THE LONELINESS YOU CAN'T SAY [12 minutes]

### The Silence

You're surrounded by people. You have friends, followers, group chats, plans.

And you're desperately lonely.

Not because you're physically alone. Because nobody actually knows you.

And you can't say that. Because admitting loneliness sounds pathetic.

### What's Actually Happening

You're confusing connection with presence.

You're around people. You're talking to people. You're doing things with people.

But you're not actually letting anyone in.

Because letting people in requires vulnerability. And vulnerability requires trust. And trust requires risk.

So you perform. You present the curated version. The one that's easy to like.

And everyone likes that version. But that version isn't you.

So you're lonely even in a room full of people who think they know you.

### The Pattern

Here's the cycle:

1. Feel lonely
2. Reach out to people
3. Present curated self (to stay safe)
4. Get surface connection
5. Feel relieved temporarily
6. Relief fades (wasn't real intimacy)
7. Feel more lonely (confirmed that nobody knows you)
8. Assume you're uniquely unlovable
9. Protect yourself more
10. Loop intensifies

You're creating the isolation you're trying to escape.

### Why It Won't Stop

Because being known feels too risky.

What if you show them the real you—messy, uncertain, struggling—and they decide you're too much? Too broken? Not worth the effort?

So you keep it surface. Keep it light. Keep it safe.

And stay lonely.

### The Interrupt

You're not going to suddenly become vulnerable with everyone. But you can start with one person.

Try this: Tell someone something true.

Not "I had a hard day" (surface).

"I'm lonely even though I'm surrounded by people."

"I don't know what I'm doing and I'm scared to admit it."

"I feel like nobody actually knows me."

Pick someone safe. Someone who's earned it.

And risk being known.

### The Practice

Right now, think of one person who might be able to hold your truth.

What would you tell them if you weren't protecting yourself?

You don't have to tell them yet. Just know what you'd say.

That's your loneliness looking for connection.

It's not weakness. It's need.

And need is allowed.

---

## CHAPTER 6: THE GRIEF THAT WON'T END [11 minutes]

### The Weight

Something ended. Someone left. Something changed that can't be unchanged.

And you're supposed to be over it by now.

Except you're not. And you don't know why it still hurts.

So you feel broken. Like you're doing grief wrong. Like you should have moved on already.

### What's Actually Happening

Grief doesn't have a timeline.

And grief isn't just about death. It's about loss of any kind.

Loss of a person. Loss of a relationship. Loss of a version of yourself. Loss of what you thought your life would be. Loss of innocence. Loss of safety. Loss of possibility.

And every loss leaves a mark. Some losses you process and integrate. Some stay with you forever in different forms.

There's no "over it." There's just "learning to live with it."

### The Pattern

Here's the cycle:

1. Loss happens
2. Grief arises
3. Society says "give it time, you'll be fine"
4. Time passes
5. Still grieving
6. Judge yourself for still grieving
7. Suppress grief to appear "over it"
8. Grief resurfaces
9. Feel broken/weak/stuck
10. Loop intensifies

You're grieving the loss AND judging yourself for grieving. Double pain.

### Why It Won't Stop

Because you think grief should end.

You think there's a finish line where you stop feeling it. Where you "heal." Where you're okay again.

But some grief doesn't end. It just changes shape.

And the more you fight it, the more it holds you.

### The Interrupt

You're not going to "get over" some things. But you can stop fighting the grief.

Try this: Instead of "I should be over this by now," try "This still matters to me."

Not because you're stuck. Because you loved something and losing it left a mark.

That's not weakness. That's the cost of caring.

And it's allowed to still hurt.

### The Practice

Right now, what loss are you still carrying that you think you should be over?

Notice: What if you never "get over it"?

What if this grief is just part of you now?

Can you let it be there without making it mean something's wrong with you?

Grief doesn't mean you're broken. It means you're human.

---

## CHAPTER 7: THE SHAME OF FEELING [12 minutes]

### The Meta-Loop

You're feeling something—sadness, anger, fear, whatever.

And immediately a second feeling arrives: shame.

Shame that you're feeling this at all. Shame that you're "too sensitive." Shame that you can't just get over it.

This is the most insidious pattern: feeling bad about feeling bad.

### What's Actually Happening

You've internalized the message that emotions are problems.

That feeling things means you're weak, dramatic, too much, broken.

So every time an emotion arises, you don't just feel the emotion—you feel shame about having the emotion.

And shame compounds everything. Because now you're not just dealing with the original feeling, you're dealing with self-attack on top of it.

### The Pattern

Here's the cycle:

1. Emotion arises (normal human experience)
2. Judge the emotion as bad/wrong/excessive
3. Feel shame for having the emotion
4. Try to suppress both the emotion and the shame
5. Emotions intensify (suppression doesn't work)
6. More shame for not being able to control your feelings
7. Self-criticism increases
8. Emotional capacity decreases
9. Loop intensifies

You're at war with your own inner experience. And you can't win.

### Why It Won't Stop

Because you learned that feelings are burdens.

Maybe your caregivers couldn't handle your emotions so you learned to not have them.

Maybe you got punished for crying or yelled at for being angry or mocked for being scared.

Maybe you learned that other people's comfort was more important than your emotional truth.

So now you police your own feelings before anyone else can. You shame yourself first.

And that shame makes the original feeling worse.

### The Interrupt

You're not going to stop having feelings. But you can stop shaming yourself for them.

Try this: Next time you feel something, notice if shame shows up.

"I'm sad. And I'm judging myself for being sad."

Name both. Acknowledge both.

Then try this radical move: "It's okay that I'm feeling this."

Not "I should feel this" (that's justification).

Not "This feeling is valid" (that's still evaluating).

Just: "It's okay that this is here."

Feelings don't need permission. But they do need acceptance.

### The Practice

Right now, what feeling are you most ashamed of having?

What emotion makes you think "I shouldn't feel this"?

Notice the shame. Notice how it sits on top of the original feeling.

Now ask: "What would happen if I let this feeling just be here without judging it?"

You don't have to like the feeling. You just have to stop attacking yourself for having it.

Feelings aren't failures. They're data.

---

## CHAPTER 8: THE EMOTION YOU'RE ALWAYS RUNNING FROM [10 minutes]

### The Chase

You scroll. You work. You plan. You distract. You stay busy. You optimize. You consume. You produce.

Anything to not feel what's underneath all of it.

Because underneath all of it is the feeling you can't name. The one you've been running from for so long you don't even remember what it is anymore.

You just know that if you stop moving, it will catch up.

### What's Actually Happening

You're using busyness as an avoidance strategy.

Not because you're lazy (you're the opposite of lazy). Because you're afraid of what you'll discover if you sit still long enough to feel.

Maybe it's grief you never processed. Maybe it's rage you never expressed. Maybe it's loneliness you never admitted. Maybe it's fear you never faced.

Whatever it is, it's waiting. And running doesn't make it go away.

It just makes you tired.

### The Pattern

Here's the cycle:

1. Uncomfortable emotion starts to surface
2. Immediately seek distraction/activity
3. Temporary relief (feeling is suppressed)
4. Relief fades
5. Emotion resurfaces
6. More distraction
7. Build entire life around not feeling
8. Exhaustion increases
9. Emotion gets stronger (because it hasn't been processed)
10. Loop intensifies

You're spending your entire life running from something that can't actually hurt you.

### Why It Won't Stop

Because you think if you feel it fully, it will destroy you.

You think the emotion is too big. Too overwhelming. Too much to hold.

So you keep it at bay. Keep moving. Keep busy. Keep running.

But here's the truth: feelings can't actually destroy you.

They're uncomfortable. They're intense. They're scary sometimes.

But they're just sensations in your body. They arise. They peak. They pass.

The running is what's destroying you. Not the feeling.

### The Interrupt

You're not going to stop running tomorrow. But you can stop for five minutes today.

Try this: Sit somewhere quiet. Set a timer for five minutes.

Don't meditate. Don't breathe deeply. Don't try to calm down.

Just sit. And let whatever feeling is there be there.

Don't analyze it. Don't fix it. Don't make it go away.

Just feel it. Notice where it is in your body. Notice what it wants to do.

Let it move through you instead of around you.

Five minutes. That's all.

See what you've been running from.

### The Practice

Right now, if you stopped moving—stopped scrolling, stopped working, stopped distracting—what feeling would be there?

You don't have to name it. You don't have to understand it.

Just notice: it's there. Waiting.

And it won't destroy you.

It just wants to be felt.

---

## CLOSING: THE FEELING YOU CAN FINALLY NAME [7 minutes]

### What We've Covered

We've looked at eight ways you avoid feeling:

The numbness. The suppressed sadness. The swallowed anger. The hidden fear. The unspoken loneliness. The endless grief. The shame of feeling. The emotion you run from.

These aren't separate problems. They're all the same thing:

You learned that feelings are dangerous. And you've been protecting yourself from them ever since.

### The Truth

Here's what nobody told you:

Feelings aren't dangerous. They're just information.

Sadness is information about loss.

Anger is information about boundaries.

Fear is information about threat.

Loneliness is information about need.

Grief is information about love.

They're not problems to solve. They're signals to listen to.

And you can't live fully without them.

### The Permission

You don't have to be good at feelings.

You don't have to process them perfectly. You don't have to understand them completely. You don't have to express them eloquently.

You just have to stop running from them.

Because the running is what's exhausting you. The running is what's keeping you numb. The running is what's making you feel like something's fundamentally wrong with you.

Nothing is wrong with you.

You just never learned that feelings are safe.

So let me tell you now: Feelings are safe.

They're uncomfortable. They're intense. They're inconvenient sometimes.

But they can't actually hurt you.

And when you stop fighting them, they stop fighting you.

### What Happens Next

You're not going to become emotionally fluent overnight.

You're going to numb out. You're going to suppress. You're going to run.

But every time you notice—every time you catch yourself mid-avoidance and pause—you're building capacity.

For feeling. For being with yourself. For living in your actual experience instead of running from it.

That's the work.

Not feeling perfectly. Just feeling at all.

### Final Practice

Right now, notice: What are you feeling?

Not what you think you should be feeling. Not what makes sense to feel.

What's actually here, in your body, right now?

You might not have words for it. That's okay.

You might not understand it. That's okay too.

Just notice it's there.

"Right now, I'm feeling [something]."

Even if [something] is "I don't know."

That's still data. That's still true.

And truth is where healing starts.

---

## PRODUCTION NOTES

**Total Runtime:** Approximately 89 minutes

**Tone:** Gentle but direct, compassionate without being patronizing. Speaks to people who've been cut off from their emotional experience and are just starting to realize it. Normalizes difficulty while offering practical entry points.

**TTS Guidance:** Slower pacing than Books 1-2. This material is tender—give it space. Pause after key concepts. Should feel like someone sitting with you in the difficult stuff, not rushing you through it.

**Music/Sound:** More ambient than previous books. Gentle texture during practices. This content is emotionally activating—sound design should create safety, not stimulation.

**Target Audience:** Gen Z (18-27) who've been emotionally suppressed, raised in achievement culture, taught to optimize instead of feel, and are beginning to realize that numbness isn't actually protection.

**Therapeutic Framework:** Combines emotional literacy education, somatic awareness, self-compassion practices, and grief/loss processing. Based on research in affective neuroscience, attachment theory, somatic experiencing, and emotion-focused therapy. Addresses alexithymia and emotional avoidance patterns common in high-achieving, digitally-native populations.

---

**END OF SCRIPT**
