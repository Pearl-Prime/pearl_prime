# Phoenix Omega V4.5 — Embodiment Upgrade
## Final Specification

**Version:** V4.5  
**Date:** February 2026  
**Status:** Canonical  
**Supersedes:** V4.4 (all previous versions)

---

## Executive Summary

V4.5 addresses the editorial feedback that V4.4 books are "conceptually excellent but emotionally flat."

**The diagnosis:** V4.4 optimizes for mechanism clarity but not somatic embodiment. Books run at one emotional register (analytical) with cognitive-dominant REFLECTIONs, no visible action scenes, and abstract closings.

**The solution:** Six surgical writing standard additions + two metadata fields. No architectural changes. No new section types. No therapeutic position changes.

**V4.5 = V4.4 + embodiment discipline + emotional variance enforcement.**

---

## Part 0 — What Changes (and What Doesn't)

### ✅ CHANGES

**Seven additions to V4.4:**

1. **emotional_register** field added to STORY atoms (4 values: analytical, embodied, active, frozen)
2. **emotional_intensity** field added to STORY atoms (5 levels: 1-5)
3. **action_despite_pattern** role added to STORY atoms (≥2 per book required)
4. **Sensory anchor requirement** for REFLECTION atoms (20-40 words somatic language)
5. **Body-present closing requirement** for INTEGRATION atoms (final sentence references body/breath/presence)
6. **Narrative bridge requirement** for EXERCISE atoms (30-50 word author-voice transition)
7. **Sticky sentence guideline** for REFLECTION atoms (≥1 quotable 8-15 word moment, quality-checked not formula-enforced)

### ❌ DOES NOT CHANGE

- 6 section types (HOOK, SCENE, STORY, REFLECTION, EXERCISE, INTEGRATION)
- Beat map architecture (12 full + 8 micro beat maps)
- Emotional temperature curve (cool/warm/hot)
- Cost chapter system (cost_confrontation beat map)
- Therapeutic position (no resolution, no breakthrough, coexistence not cure)
- Plan compiler logic (deterministic selection)
- K-tables (pool depth requirements)
- Approval workflow
- CI gate framework (gates 1-68 remain valid)

**Architecture is sound. Standards are upgraded.**

---

## Part 1 — New Metadata Fields

### 1.1 STORY: emotional_register

**Purpose:** Distribute emotional variety across characters to prevent monotone.

**Schema addition:**

```yaml
emotional_register: analytical | embodied | active | frozen
```

**Definitions:**

| Register | Description | Character state | Example |
|----------|-------------|-----------------|---------|
| **analytical** | Stuck in head, running scenarios, overthinking | Thinking, calculating | Jordan paralyzed texting Maya |
| **embodied** | Noticing physical sensations, aware of body responses | Feeling, sensing | Alex noticing pulse on subway |
| **active** | Acting despite pattern still running (requires action_despite_pattern role) | Moving, doing | Jordan hitting send while loop runs |
| **frozen** | Completely paralyzed, pattern has locked them up | Shutdown, immobile | Zara unable to submit essay |

**Plan compiler rules:**

- **Distribution requirement:** Maximum 60% of stories in any single register
- **Coverage requirement (8+ chapter books):** All four registers must appear at least once
- **Coverage requirement (3-chapter books):** Minimum three registers must appear
- **Active register placement:** All action_despite_pattern stories must be tagged `active`

**Why this matters:**

Prevents seven analytical characters in a row. Creates emotional texture variety without requiring collapse/breakthrough scenes. Maintains therapeutic position while increasing dynamic range.

---

### 1.2 STORY: emotional_intensity

**Purpose:** Enforce variance across emotional voltage levels to prevent all-medium flatness.

**Schema addition:**

```yaml
emotional_intensity: 1 | 2 | 3 | 4 | 5
```

**Intensity scale definitions:**

| Level | Description | Pattern visibility | Stakes | Example |
|-------|-------------|-------------------|--------|---------|
| **1** | Calm observation, pattern barely visible | Subtle | Low | Character notices slight hesitation before speaking |
| **2** | Mild tension, pattern noticeable | Moderate | Medium-low | Character rehearses what to say three times |
| **3** | Clear tension, pattern actively running | High | Medium | Character paralyzed by decision for hours |
| **4** | High tension, pattern causing visible cost | Very high | Medium-high | Character misses opportunity due to overthinking |
| **5** | Maximum tension, pattern at breaking point (but NOT breaking) | Extreme | High | Character's world visibly smaller due to pattern |

**Critical distinction:**

Level 5 is maximum tension while maintaining coexistence. It is NOT:
- Breakdown
- Collapse  
- Cathartic release
- Breakthrough

Level 5 shows the pattern at its most intense AND the character still functioning within it. Example: Malik realizing he's been uninvited from the group chat entirely (consequence visible, pattern still running, no resolution).

**Plan compiler rules:**

- **Distribution requirement:** Maximum 60% of stories at any single intensity level
- **Range requirement (8+ chapter books):** Must span at least 3 intensity levels; must include at least one level-5 story
- **Range requirement (3-chapter books):** Must span at least 3 intensity levels
- **Escalation guidance:** Higher-intensity stories should cluster in hot-temperature chapters (6-8 for 8-chapter books, 3 for 3-chapter books)

**Why this matters:**

Prevents emotional monotone. "The Loop That Runs" had 7 stories all at level 3 (clear tension, pattern running). No level-1 subtle moments. No level-5 maximum-cost moments. Result: flatness. V4.5 enforces voltage variance.

---

## Part 2 — New STORY Role

### 2.1 action_despite_pattern

**Purpose:** Show characters ACTING while the pattern is still running. Proves "act anyway" cinematically instead of theoretically.

**Role definition:**

```yaml
role: action_despite_pattern
emotional_register: active  # required
emotional_intensity: 3 | 4 | 5  # typically high-intensity
word_count: 60-150
```

**Writing requirements:**

Character must:

1. **Perform a visible, specific action**
   - Text sent
   - Hand raised
   - Word spoken
   - Boundary stated
   - Invitation accepted
   - Question asked
   - Observable, concrete, completed

2. **Pattern explicitly still running during action**
   - Loop continues
   - Anxiety present
   - What-ifs active
   - Overthinking ongoing
   - Must be stated, not implied

3. **NO resolution language** (forbidden lexemes apply)
   - Not "feels better"
   - Not "relieved"
   - Not "lighter"
   - Not "free"
   - Not "healed"
   - Character is not transformed by the action

4. **Action is small and specific**
   - Not "Jordan becomes confident"
   - Yes: "Jordan hits send"
   - Micro-moment, not life change

5. **Ends with: action completed + pattern still present**
   - "Jordan hits send. The loop does not stop."
   - "Alex raises hand. Heart still racing."
   - Coexistence shown, not resolution achieved

**Example (118 words):**

> Jordan is sitting on the bed. It is 11:58 PM. Maya's text from 9:14 is still open. Jordan has typed eight versions. The loop is running — what if it sounds desperate, what if she thinks Jordan doesn't care, what if the tone is wrong, what if what if what if.
>
> Jordan types: "yeah saturday works."
>
> The cursor blinks. Jordan's thumb hovers over send. The scenarios are still stacking. The loop has not stopped. Jordan can feel it — the seventeen versions of how this could go wrong, the calculations running faster than thought. Jordan's heart is doing something uneven in Jordan's chest.
>
> Jordan hits send.
>
> The message delivers. The loop is still running. The what-ifs are still there. Jordan's shoulders are still tight. Jordan acted anyway.

**Plan compiler requirements:**

- **Quantity (8+ chapter books):** Minimum 2 action_despite_pattern stories required
- **Quantity (3-chapter books):** Minimum 2 action_despite_pattern stories required
- **Placement (8-chapter books):** First action in chapters 5-6, second action in chapters 7-8
- **Placement (3-chapter books):** First action in chapter 2, second action in chapter 3
- **Escalation:** If using 2 actions, second should be higher intensity than first (e.g., first is level-3, second is level-4)

**Why ≥2, not ≥1:**

One action scene makes "act anyway" feel anecdotal. Two proves it's a pattern. The listener sees: this is replicable, this is learnable, this happens more than once.

**QA gate 75:**
- Every compiled plan must include ≥2 action_despite_pattern stories
- Stories must be positioned in final 1/3 to 1/2 of book (not all front-loaded)
- Stories must have emotional_register: active
- Stories must not contain resolution lexemes

---

## Part 3 — Updated Writing Standards

### 3.1 REFLECTION: Sensory Anchor Requirement

**Current gap:** REFLECTIONs explain mechanisms cognitively but don't consistently anchor them somatically. Result: all head, no body.

**New requirement:**

Every REFLECTION atom (200-500 words full, 60-150 words micro) must include at least ONE sensory/somatic anchor:

- **Length:** 20-40 words (full atoms), 10-20 words (micro atoms)
- **Content:** Description of what the mechanism feels like in the body, not just what it does in the brain
- **Placement:** Can appear anywhere in the REFLECTION (beginning, middle, or end)
- **Voice:** Second-person present tense, sensory-specific

**Sensory vocabulary (non-exhaustive):**

Body parts: jaw, shoulders, breath, chest, stomach, throat, hands, pulse, heart, spine, neck, face
Sensations: tight, tense, heavy, hot, cold, hollow, clenched, shallow, racing, frozen, numb, electric, weighted, compressed, expanded
Actions: holds, grips, clenches, rises, drops, tightens, releases, catches, stalls, speeds, slows

**Before (cognitive only, 467 words):**

> Why does this happen? Why do you lose track of who you are when you are trying to be what other people need you to be? Here is the answer, and it has nothing to do with being fake or insecure.
>
> Your brain has a system called the social prediction network. It is active whenever you are around other people. Its job is to predict how other people are perceiving you so you can adjust your behavior in real-time to get the social outcome you want. In small doses, this is useful. It is how you learn to read a room. It is how you know when someone is upset even if they say they are fine.
>
> In overdrive, this system does something different. It does not just predict how you are being perceived. It creates versions of you optimized for each context, and it runs all of them simultaneously, and it does not tell you which one is the baseline...

**After (cognitive + somatic, 502 words):**

> Why does this happen? Why do you lose track of who you are when you are trying to be what other people need you to be? Here is the answer, and it has nothing to do with being fake or insecure.
>
> Your brain has a system called the social prediction network. It is active whenever you are around other people. Its job is to predict how other people are perceiving you so you can adjust your behavior in real-time to get the social outcome you want. In small doses, this is useful. It is how you learn to read a room. It is how you know when someone is upset even if they say they are fine.
>
> **You feel it before you think it. Your jaw tightens when you walk into a room. Your breath gets shallow when someone asks you a question. Your shoulders rise half an inch and stay there. This is not anxiety. This is your body calculating.** *(35 words added)*
>
> In overdrive, this system does something different. It does not just predict how you are being perceived. It creates versions of you optimized for each context, and it runs all of them simultaneously, and it does not tell you which one is the baseline...

**What changed:**
- Added 4 sentences (35 words) between mechanism intro and deep explanation
- Jaw, breath, shoulders — specific body parts
- Tightens, shallow, rise — specific sensations
- "You feel it before you think it" — anchors cognition in soma
- Passes QA gate 76

**QA gate 76:**
- Scan REFLECTION body text for sensory vocabulary
- Flag REFLECTIONs with zero body/sensation words
- Human review required for flagged atoms
- Not auto-reject (some REFLECTIONs may validly lack somatic anchors if mechanism is purely cognitive, e.g., explaining memory formation)
- Review confirms: Does a somatic moment exist, OR is this a valid exception?

---

### 3.2 INTEGRATION: Body-Present Closing Requirement

**Current gap:** Some INTEGRATIONs end in abstract philosophy without grounding in present-moment body awareness. Result: floating endings.

**New requirement:**

The final sentence (or final two sentences) of every INTEGRATION atom must reference the body, breath, or physical presence.

- **No pure philosophy:** Don't end with abstract truth statements only
- **No future promises:** Don't end with "you will heal" or outcome language
- **Present-tense body observation:** Anchor in NOW, in the body, in what's physically real

**Acceptable body/breath/presence vocabulary:**

- Body: body, breath, breathing, chest, heart, pulse, hands, feet, ground, weight, sitting, standing
- Presence: here, now, present, this moment, still, right now
- Sensations: feeling, noticing, aware, sense

**Before (abstract philosophy only, 186 words):**

> You are not one person pretending to be many. You are many versions trying to figure out which one is you. The versions are real. The self underneath them is also real. You have not lost it. You have buried it under performance. Knowing this does not make the performance stop. Knowing this makes it possible to notice when you are performing and ask: Is this what I want, or is this what this version of me is supposed to want?

**After (philosophy + body-present closing, 197 words):**

> You are not one person pretending to be many. You are many versions trying to figure out which one is you. The versions are real. The self underneath them is also real. You have not lost it. You have buried it under performance. Knowing this does not make the performance stop. Knowing this makes it possible to notice when you are performing and ask: Is this what I want, or is this what this version of me is supposed to want?
>
> **You are still breathing. You are still here. Start with that.** *(11 words added)*

**What changed:**
- Added 3 sentences (11 words) as final closing
- "Still breathing. Still here." — body and presence
- "Start with that." — grounds in NOW, not future or past
- Same philosophy, but LANDED in body instead of floating in abstraction
- Passes QA gate 77

**QA gate 77:**
- Check final sentence of every INTEGRATION atom
- Must contain at least one body/breath/presence word
- Flag abstract-only closings
- Human review required
- Not auto-reject (some INTEGRATIONs may validly end philosophically if they're returning to core thesis, but rare)

---

### 3.3 EXERCISE: Narrative Bridge Requirement

**Current gap:** Exercise placeholders break narrative flow. In audiobook, feels like system notes in a draft.

**New requirement:**

Every EXERCISE atom must include a `narrative_bridge_in` field:

```yaml
narrative_bridge_in: |
  30-50 word first-person author voice transition that moves from preceding REFLECTION/STORY content into the exercise practice
```

**Bridge requirements:**

- **Length:** 30-50 words (full atoms), 20-30 words (micro atoms)
- **Voice:** First-person author ("you are going to practice..." not "the reader should...")
- **Function:** Transition statement, not instruction yet
- **Tone:** Conversational, warm, directive
- **Content:** Names what the exercise will do, why now, and signals the shift

**Before (placeholder breaks flow):**

> The prefrontal cortex asks a question: "What will happen if I do X?" Then it generates possible answers. In a non-overthinking brain, it generates two or three answers, picks one, moves on. In an overthinking brain, it generates seven answers, then generates sub-answers for each of those, then evaluates the sub-answers, then circles back to the original question because none of the answers felt certain enough.
>
> [EXERCISE PLACEHOLDER: 3-5 minute grounding exercise - body-based loop interrupt, naming the spiral, returning to present sensory input without resolving the question]

**After (with narrative bridge + full exercise, 364 total words):**

> The prefrontal cortex asks a question: "What will happen if I do X?" Then it generates possible answers. In a non-overthinking brain, it generates two or three answers, picks one, moves on. In an overthinking brain, it generates seven answers, then generates sub-answers for each of those, then evaluates the sub-answers, then circles back to the original question because none of the answers felt certain enough.
>
> **You are going to practice stopping the loop. Not by solving the question. By interrupting the machinery. Here is how.** *(20 words — narrative bridge)*
>
> **[FULL EXERCISE: Loop Interrupt Practice — 180 words]**
>
> Close your eyes or soften your gaze. Notice your breath without changing it. Just notice.
>
> Now bring to mind something you have been overthinking. Not the biggest thing. Something ordinary. A text you have not sent. A decision you have been circling. A conversation you keep replaying.
>
> Feel where the loop lives in your body. Is it tightness in your chest? Tension in your jaw? A knot in your stomach? Just notice it. Do not try to fix it.
>
> Say this out loud or in your mind: "The loop is running."
>
> That is all. You are not solving the problem. You are naming the machinery. The loop is running. You notice. You breathe.
>
> Count four breaths. In. Out. In. Out. In. Out. In. Out.
>
> Open your eyes. The loop is probably still there. That is fine. You interrupted it for four breaths. You can do it again.

**What changed:**
- Narrative bridge (20 words) transitions smoothly from REFLECTION into practice
- Full exercise written (not placeholder): 180 words, step-by-step, guided timing, return-to-present cue
- First-person author voice throughout
- Flow maintained — no mechanical break
- Passes QA gate 78

**QA gate 78:**
- Every EXERCISE must have narrative_bridge_in field populated
- Bridge must be 30-50 words (full) or 20-30 words (micro)
- Bridge must be first-person author voice
- Flag exercises with empty or placeholder bridges
- Human review required

---

### 3.4 REFLECTION: Sticky Sentence Guideline

**Current gap:** Few quotable moments. Most sentences 15-25 words, similar complexity. No rhythm variation.

**New guideline (quality-checked, not formula-enforced):**

Every REFLECTION atom should include at least ONE sentence that:

- **Length:** 8-15 words
- **Function:** Can be quoted standalone, crystallizes core insight
- **Structure:** Uses parallel structure, reversal, contrast, or sharp simplicity
- **Placement:** Anywhere in the REFLECTION (often mid-paragraph or closing)

**Examples of sticky sentences:**

- "The loop is real. The threat is not." *(8 words, reversal)*
- "You are not fake. You are flexible to the point of disappearing." *(12 words, reframe)*
- "The loop runs. You notice. You act anyway." *(8 words, parallel structure)*
- "Your company will survive if you take a break. You might not survive if you don't." *(15 words, contrast)*
- "You do not lose your mind. You lose your life." *(10 words, reversal)*
- "The overthinking does not predict the future. The overthinking writes the future." *(11 words, reversal)*

**Non-examples (too long, too complex, not quotable):**

- "Your brain is treating the text message as if it carries the same threat level as a physical predator approaching you in an open field." *(25 words, loses punch)*
- "The version problem is not about being authentic but about your brain losing the difference between adapting to context and disappearing into context." *(24 words, conceptually good but not sticky)*

**Before (no sticky moments, 467 words):**

> And here is the part that makes it unbearable: your brain starts treating the versions as equally real. You are not a person with flexible social behavior. You are five different people wearing the same face, and you have no idea which one you are supposed to be when no one is watching.
>
> This is why being alone feels both like relief and like panic. Relief because you can stop performing. Panic because without an audience, you do not know which version to be, and the question "who am I actually?" does not have a clear answer anymore.

**After (with sticky sentence, 480 words):**

> And here is the part that makes it unbearable: your brain starts treating the versions as equally real. **You are not fake. You are flexible to the point of disappearing.** *(13 words added)* You are not a person with flexible social behavior. You are five different people wearing the same face, and you have no idea which one you are supposed to be when no one is watching.
>
> This is why being alone feels both like relief and like panic. Relief because you can stop performing. Panic because without an audience, you do not know which version to be, and the question "who am I actually?" does not have a clear answer anymore.

**What changed:**
- Added 2 sentences (13 words total) mid-paragraph
- "You are not fake. You are flexible to the point of disappearing." — 12 words, quotable, uses reversal
- Crystallizes the core insight (version-switching as disappearance, not deception)
- Passes QA gate 79 (but see note below on enforcement)

**QA gate 79 (SOFT enforcement):**
- Scan REFLECTION body for sentences under 20 words
- Flag atoms with NO sentences under 20 words (likely all long complex sentences)
- Human review required: Does a sticky/quotable moment exist?
- **NOT auto-reject** — this is a quality check, not a formula
- Reviewer confirms: Is there at least one moment that crystallizes insight, OR is this a valid exception (e.g., extremely technical REFLECTION where sticky sentences would feel forced)?

**Critical note on enforcement:**

This is the ONLY V4.5 requirement that is guideline-based rather than rule-based. The goal is quality, not compliance. Over-enforcing this can make prose feel engineered. Use human judgment.

If a REFLECTION has all 18-word sentences but one of them is brilliantly clear and quotable, that's fine. If a REFLECTION has three 10-word sentences but none of them crystallize anything, flag it.

**Sticky sentences are about craft, not counting.**

---

## Part 4 — Updated Plan Compiler Rules

### 4.1 STORY Selection with emotional_register and emotional_intensity

**New selection criteria:**

When filling a STORY slot, the plan compiler must:

1. **Check existing distribution:**
   - Count how many stories in the current plan have each emotional_register value
   - Count how many stories in the current plan have each emotional_intensity value

2. **Apply distribution caps:**
   - Reject candidates if selecting them would exceed 60% in any register
   - Reject candidates if selecting them would exceed 60% in any intensity level

3. **Apply coverage requirements:**
   - For 8+ chapter books: Flag if final plan doesn't include all four registers
   - For 8+ chapter books: Flag if final plan doesn't span at least 3 intensity levels
   - For 8+ chapter books: Flag if final plan doesn't include at least one level-5 story

4. **Score remaining candidates:**
   - Bonus for under-represented registers
   - Bonus for under-represented intensity levels
   - Bonus for fitting chapter's emotional_temperature (warm chapters prefer intensity 3-4, hot chapters prefer 4-5)

5. **Select deterministically:**
   - Use existing scoring function (persona_fit, topic_fit, novelty, arc_coherence, duplication_penalty, overuse_penalty)
   - Add register_variety_bonus and intensity_variety_bonus
   - Tiebreak with seed-based deterministic selection

**Compiled plan output (updated):**

```yaml
chapters:
  - chapter_number: 3
    emotional_temperature: hot
    slots:
      - slot_id: "ch3_slot03"
        slot_type: "story"
        atom_id: "story_nyc_genalpha_overthinking_consequence_001"
        role: "consequence"
        emotional_register: "analytical"
        emotional_intensity: 5
        note: "High-intensity cost story, analytical register"
```

---

### 4.2 action_despite_pattern Placement Rules

**Requirement:**

- Every compiled plan (all formats, all tiers with ≥3 chapters) must include ≥2 action_despite_pattern stories
- These stories must be positioned strategically (not all front-loaded)

**Placement logic:**

For 8-chapter books:
- First action_despite_pattern: chapters 5-6
- Second action_despite_pattern: chapters 7-8

For 3-chapter books:
- First action_despite_pattern: chapter 2
- Second action_despite_pattern: chapter 3

**Escalation logic:**

If using exactly 2 action stories:
- Second should be higher emotional_intensity than first (e.g., first is level-3, second is level-4 or 5)
- This shows progression: small action → bigger action (while pattern still runs in both)

If using 3+ action stories:
- Distribute across final half of book
- Escalate intensity across the sequence

**Compiler behavior:**

During chapter planning:
1. Mark slots in chapters 5-8 (or 2-3 for short books) as eligible for action_despite_pattern
2. When selecting atoms for STORY slots in those positions, prioritize action_despite_pattern role if quota not yet met
3. Ensure ≥2 are selected before plan is finalized
4. Ensure intensity escalates if using exactly 2

**Failure mode:**

If pool lacks sufficient action_despite_pattern atoms:
- STRICT MODE: Fail compilation with error "Insufficient action_despite_pattern atoms in pool (need 2, have X)"
- RELAXED MODE: Compile with warning, flag in build manifest

---

## Part 5 — Updated QA Gates

### New gates (75-79):

**Gate 75: action_despite_pattern presence**
- Check: Every compiled plan includes ≥2 action_despite_pattern stories
- Check: Stories are positioned in final 1/3 to 1/2 of book
- Check: All action_despite_pattern stories have emotional_register: active
- Check: No resolution lexemes in action_despite_pattern story bodies
- Severity: CRITICAL (blocks release)

**Gate 76: REFLECTION sensory vocabulary**
- Check: Scan REFLECTION body for sensory words (jaw, breath, shoulders, pulse, stomach, chest, throat, hands, tight, tense, shallow, heavy, etc.)
- Action: Flag REFLECTIONs with zero sensory vocabulary
- Severity: WARNING (requires human review, not auto-reject)
- Review question: Does a somatic anchor exist, OR is this a valid exception?

**Gate 77: INTEGRATION body-present closing**
- Check: Extract final sentence of every INTEGRATION atom
- Check: Final sentence contains at least one body/breath/presence word
- Action: Flag abstract-only closings
- Severity: WARNING (requires human review, not auto-reject)
- Review question: Is the closing grounded in body/presence, OR is this a valid philosophical exception?

**Gate 78: EXERCISE narrative bridge presence**
- Check: Every EXERCISE atom has narrative_bridge_in field populated
- Check: Bridge is 30-50 words (full) or 20-30 words (micro)
- Check: Bridge is first-person author voice
- Action: Flag exercises with empty or placeholder bridges
- Severity: WARNING (requires human review before approval)

**Gate 79: Sticky sentence check (SOFT)**
- Check: Scan REFLECTION body for sentences under 20 words
- Action: Flag REFLECTIONs with NO short sentences
- Severity: INFO (quality check, not enforcement)
- Review question: Does at least one sentence crystallize insight in a quotable way?
- Note: This is craft review, not formula compliance

**Gate 80: emotional_register distribution**
- Check: No more than 60% of stories in plan share the same emotional_register
- Check (8+ chapters): All four registers appear at least once
- Check (3 chapters): At least three registers appear
- Severity: CRITICAL (blocks compilation)

**Gate 81: emotional_intensity distribution**
- Check: No more than 60% of stories in plan share the same emotional_intensity level
- Check (8+ chapters): Plan spans at least 3 intensity levels
- Check (8+ chapters): Plan includes at least one level-5 story
- Check (3 chapters): Plan spans at least 3 intensity levels
- Severity: CRITICAL (blocks compilation)

---

## Part 6 — Migration and Rollout

### 6.1 Existing Approved Atoms

**Grandfather in.** Do not invalidate V4.4 atoms.

Atoms approved under V4.4 remain valid. They represent prior standards. Over time, as pool diversity increases and new V4.5 atoms are written, plan compiler can prefer V4.5-compliant atoms when available (e.g., prefer STORY atoms with emotional_register and emotional_intensity metadata).

**Retroactive tagging (optional):**

Existing STORY atoms can be retroactively tagged with emotional_register and emotional_intensity by human reviewers:
- Review existing atom
- Assess: Which register? (analytical/embodied/active/frozen)
- Assess: Which intensity level? (1-5)
- Add metadata fields
- Re-approve

This is NOT required for migration but improves pool usability.

### 6.2 New Atom Production

**All new atoms written after V4.5 adoption must follow V4.5 standards:**

STORY atoms:
- Must include emotional_register field
- Must include emotional_intensity field
- action_despite_pattern stories must meet all 5 writing requirements

REFLECTION atoms:
- Must include ≥1 sensory anchor (20-40 words body sensation)
- Should include ≥1 sticky sentence (8-15 words, quotable)

INTEGRATION atoms:
- Final sentence must reference body/breath/presence

EXERCISE atoms:
- Must include narrative_bridge_in field (30-50 words, first-person author voice)

### 6.3 Writer Training

**Timeline:** 2-3 hours onboarding for V4.5 standards

**Topics:**

1. **Four emotional registers** (30 min)
   - Definitions with examples
   - How to write analytical vs embodied vs active vs frozen
   - Practice: Rewrite one story across all four registers

2. **Five intensity levels** (30 min)
   - Definitions with examples (level 1 subtle → level 5 maximum tension)
   - How to calibrate intensity without adding drama/collapse
   - Practice: Rewrite one story at three intensity levels

3. **action_despite_pattern role** (45 min)
   - Definition and 5 requirements
   - Examples of correct vs incorrect executions
   - Critical distinction: action-while-pattern-runs vs action-as-resolution
   - Practice: Write one action_despite_pattern story (100 words)

4. **Sensory anchors** (20 min)
   - What counts as sensory vocabulary
   - Where to place anchors in REFLECTIONs
   - Practice: Add 30-word sensory anchor to existing REFLECTION

5. **Body-present closings** (15 min)
   - What counts as body/breath/presence vocabulary
   - Examples of good vs bad INTEGRATION closings
   - Practice: Rewrite one abstract closing to be body-present

6. **Narrative bridges** (15 min)
   - What makes a good bridge (30-50 words, author voice, transition)
   - Examples
   - Practice: Write bridge for existing exercise

7. **Sticky sentences** (15 min)
   - What makes a sentence quotable (8-15 words, parallel/reversal/contrast)
   - Examples
   - Practice: Craft 3 sticky sentences for given insights

**Deliverable:** Writer completes practice exercises, receives feedback, then writes first V4.5-compliant atoms under supervision.

### 6.4 Dev Implementation Timeline

**Phase 1 (Day 1):** Schema changes
- Add emotional_register enum to STORY atom schema
- Add emotional_intensity enum to STORY atom schema
- Add action_despite_pattern to STORY role enum
- Add narrative_bridge_in text field to EXERCISE atom schema

**Phase 2 (Day 1-2):** Plan compiler updates
- Implement emotional_register distribution logic
- Implement emotional_intensity distribution logic
- Implement action_despite_pattern placement rules
- Update compiled plan YAML output to include new metadata

**Phase 3 (Day 2):** QA gates
- Implement gates 75-81
- Wire gates into CI pipeline
- Configure severity levels (CRITICAL vs WARNING vs INFO)

**Phase 4 (Day 2):** Documentation updates
- Update STORY writing spec
- Update REFLECTION writing spec
- Update INTEGRATION writing spec
- Update EXERCISE writing spec
- Update plan compiler reference doc

**Total timeline:** 2 days for full V4.5 implementation

---

## Part 7 — Rewriting "The Loop That Runs" to V4.5

**Current state:** V4.4 book, emotionally flat

**V4.5 upgrades needed:**

### 7.1 Add 1 action_despite_pattern story

**Where:** Chapter 3, after Dev story, before Zara story

**Content:** Jordan finally texts Maya back (action while loop runs)

**Specifications:**
- role: action_despite_pattern
- emotional_register: active
- emotional_intensity: 4
- 110-120 words
- Shows: Jordan typing, deleting, loop running, hitting send, loop still present

**Estimated time:** 30 minutes to write + 15 minutes to integrate

### 7.2 Add 1 second action_despite_pattern story

**Where:** Chapter 2, replace or augment existing Isa story

**Content:** Isa says one true thing to Sam despite version-switching anxiety

**Specifications:**
- role: action_despite_pattern
- emotional_register: active
- emotional_intensity: 3
- 100-110 words
- Shows: Isa with Sam, versions quiet for a moment, Isa says truth, versions resume

**Estimated time:** 30 minutes to write + 15 minutes to integrate

### 7.3 Rewrite 3 exercise placeholders

**Exercises to complete:**

1. **Ch1: Loop Interrupt Practice** (180 words)
   - Narrative bridge: "You are going to practice stopping the loop. Not by solving the question. By interrupting the machinery."
   - Full exercise: grounding, name the loop, four breaths, return

2. **Ch2: Values Clarification** (160 words)
   - Narrative bridge: "You are going to practice naming one thing you wanted before you knew what anyone else wanted."
   - Full exercise: recall moment alone, name the want, sit with it

3. **Ch3: Action Practice** (140 words)
   - Narrative bridge: "You are going to practice acting on one small thing without running scenarios first."
   - Full exercise: choose small action, notice loop, act anyway, notice aftermath

**Estimated time:** 90 minutes total (30 min per exercise)

### 7.4 Add sensory anchors to 2 REFLECTIONs

**Target REFLECTIONs:**

1. **Ch2 REFLECTION (social prediction network):** Add 35 words about jaw tension, breath holding, shoulders rising
2. **Ch3 REFLECTION (cost escalation):** Add 25 words about stomach drop, chest tightness when invitation doesn't come

**Estimated time:** 20 minutes per REFLECTION = 40 minutes total

### 7.5 Rewrite 1 INTEGRATION closing

**Target:** Ch2 INTEGRATION

**Current:** "You are many versions trying to figure out which one is you."

**V4.5:** "You are many versions trying to figure out which one is you. You are still breathing. You are still here. Start with that."

**Estimated time:** 5 minutes

### 7.6 Add 3 sticky sentences

**Target REFLECTIONs:**

1. **Ch1:** "The loop is real. The threat is not."
2. **Ch2:** "You are not fake. You are flexible to the point of disappearing."
3. **Ch3:** "The loop runs. You notice. You act anyway."

**Estimated time:** 15 minutes (identify placement, craft sentences, integrate)

### 7.7 Tag all existing stories with metadata

**7 existing STORY atoms need:**
- emotional_register assignment (6 analytical, 1 embodied)
- emotional_intensity assignment (distribute across 3-5)

**Estimated time:** 30 minutes (review each story, assign metadata)

### Total rewrite time: ~6 hours

**Result:** "The Loop That Runs" goes from 7/10 emotional immersion to 9/10 without changing architecture.

---

## Part 8 — Success Metrics

**How to measure if V4.5 is working:**

### 8.1 Quantitative checks (automated)

✅ All compiled plans pass gates 75-81  
✅ No more than 60% of stories in any register  
✅ No more than 60% of stories at any intensity level  
✅ Every book includes ≥2 action_despite_pattern stories  
✅ All REFLECTIONs flagged by gate 76 reviewed and approved  
✅ All INTEGRATIONs flagged by gate 77 reviewed and approved  
✅ All EXERCISEs have narrative bridges  

### 8.2 Qualitative checks (human review)

✅ Books feel embodied, not just cognitive  
✅ Listeners report "I could feel that in my body" at least once per book  
✅ At least 2 moments per book where listener sees character ACT (not just think)  
✅ Chapters land with weight (body-present, not abstract)  
✅ Exercises flow smoothly (no mechanical breaks)  
✅ At least 3-5 quotable lines per book  

### 8.3 Editorial feedback (post-V4.5)

Target scores from external editors:

- Emotional immersion: 8-9/10 (up from 6-7/10)
- Embodiment: 8-9/10 (up from 6-7/10)
- Character arc design: 7-8/10 (up from 6-6.5/10)
- Audiobook impact: 9/10 (maintained)
- Concept strength: 9/10 (maintained)
- Commercial structure: 9/10 (maintained)

**Success = books are cognitively excellent AND somatically embodied, without violating therapeutic position.**

---

## Part 9 — Summary

### What V4.5 Adds

**Two metadata fields:**
1. emotional_register (analytical/embodied/active/frozen) — distributes emotional variety
2. emotional_intensity (1-5) — enforces voltage variance

**One new STORY role:**
3. action_despite_pattern — shows acting while pattern runs (≥2 per book)

**Four writing standards:**
4. Sensory anchors in REFLECTIONs (20-40 words body sensation)
5. Body-present closings in INTEGRATIONs (final sentence references body/breath/presence)
6. Narrative bridges in EXERCISEs (30-50 words author-voice transition)
7. Sticky sentences in REFLECTIONs (≥1 quotable 8-15 word moment, quality-checked)

**Seven new QA gates:**
- Gates 75-81 enforce distribution, presence, and quality checks

### What Doesn't Change

- 6 section types
- Beat map architecture
- Emotional temperature curve
- Therapeutic position (no resolution, coexistence not cure)
- Plan compiler (deterministic selection)
- K-tables
- Approval workflow

### Timeline

- Dev: 2 days
- Writer training: 2-3 hours
- Rewrite existing book: ~6 hours
- First new V4.5 book: same timeline as V4.4, just following updated standards

### Result

Books that are:
- Conceptually excellent (maintained from V4.4)
- Structurally sound (maintained)
- Emotionally embodied (NEW)
- Somatically grounded (NEW)
- Dynamically varied (NEW)
- Showing action, not just analysis (NEW)

**V4.5 = V4.4 + embodiment discipline + emotional variance enforcement.**

Same architecture. Higher standards. Elite output.

---

## Appendix A — Quick Reference

### STORY Atom V4.5 Schema

```yaml
atom_id: "story_persona_topic_role_NNN"
atom_category: "story"
atom_size: full | micro
role: recognition | embodiment | pattern | mechanism_proof | turning_point | consequence | agency_glimmer | action_despite_pattern
emotional_register: analytical | embodied | active | frozen
emotional_intensity: 1 | 2 | 3 | 4 | 5
persona: "<persona_id>"
topic: "<topic_id>"
body: |
  <60-150 words full, 30-80 words micro>
word_count: <integer>
approval:
  status: approved
  approved_by: "<human>"
  approved_at: "<UTC>"
```

### REFLECTION Atom V4.5 Requirements

- 200-500 words (full), 60-150 words (micro)
- Must include ≥1 sensory anchor (20-40 words body sensation)
- Should include ≥1 sticky sentence (8-15 words, quotable)
- First-person author voice
- No resolution language

### INTEGRATION Atom V4.5 Requirements

- 100-200 words (full), 30-60 words (micro)
- Final sentence must reference body/breath/presence
- First-person author voice
- No future promises, no resolution

### EXERCISE Atom V4.5 Requirements

- 100-300 words (full), 60-120 words (micro)
- Must include narrative_bridge_in field (30-50 words, first-person author voice)
- Guided timing, progressive steps, return-to-present cues
- Second-person imperative voice

### Plan Compiler V4.5 Distribution Rules

- Max 60% stories same emotional_register
- Max 60% stories same emotional_intensity
- 8+ chapters: all four registers, ≥3 intensity levels, ≥1 level-5 story
- 3 chapters: ≥3 registers, ≥3 intensity levels
- ≥2 action_despite_pattern stories, positioned in final 1/3 to 1/2 of book

---

**End of V4.5 Specification**

Hand this to dev. Train writers. Ship books that feel embodied.
