# The Phone You Can't Put Down
## A Therapeutic Audiobook for Gen Z
### Written by Claude for SpiritualTech Systems

---

## OPENING [3 minutes]

You reached for your phone before you even finished listening to that last sentence, didn't you?

Or you're already thinking about checking it. Wondering if there's a notification. If someone texted. If something happened that you're missing right now.

This book is about that reflex. The one that's faster than thought. The one that happens before you decide to do it.

The one that's been running for so long you don't even notice it anymore.

I'm not going to tell you phones are bad or social media is ruining your generation or you need to do a digital detox. Those takes are boring and also useless.

We're going to look at what's actually happening in your brain. Why the phone feels necessary. Why putting it down feels impossible. Why even when you want to stop scrolling, you can't.

Because this isn't about willpower. This is about neuroscience meeting capitalism. This is about how your attention became a commodity and your dopamine system got hacked.

And once you see how it works, you can't unsee it.

So let's look at what you're holding.

---

## CHAPTER 1: THE DOPAMINE SLOT MACHINE [12 minutes]

### The Pull

You open your phone. You don't even remember deciding to do it.

Your thumb just... moved. Instagram. TikTok. Twitter. Messages. Email. Back to Instagram.

Nothing new. You already checked three minutes ago. But you check again anyway.

Because you're not looking for something specific. You're looking for the *possibility* of something.

And that possibility is how they got you.

### What's Actually Happening

Your phone is a slot machine.

And I don't mean that metaphorically. I mean the same psychologists who design casino games helped design your apps.

Because slot machines don't work by always giving you money. They work by *sometimes* giving you money. Variable rewards. Unpredictable payoffs.

And your brain doesn't respond to certainty. It responds to uncertainty with the chance of reward.

Every time you pull down to refresh, you're pulling the slot machine lever.

Every time you open an app, you're spinning the wheel.

Most of the time, nothing happens. No likes, no messages, no validation, no dopamine.

But sometimes—just often enough—something hits.

Someone liked your post. Someone replied. Someone noticed you exist.

And your brain gets a dopamine spike. Not because the reward is huge, but because it was *uncertain*.

The technical term is "variable ratio reinforcement schedule." It's the most addictive reward pattern that exists.

And every app you use is designed around it.

### The Pattern

Here's what's happening in your brain:

1. Anticipation activates (maybe there's something new)
2. Dopamine releases (not from getting the reward, from *anticipating* it)
3. You check
4. Usually nothing (dopamine drops)
5. But sometimes something (dopamine spikes)
6. Brain learns: uncertainty = potential reward
7. Craving intensifies
8. You check more frequently
9. Loop becomes automatic

This is why you check your phone when you're bored. When you're anxious. When you're happy. When you're literally in the middle of doing something else.

Your brain is running the program: "Check the slot machine. Maybe this time there's a reward."

### Why It Won't Stop

Because the apps are *designed* not to let you stop.

Every feature is engineered for maximum engagement. The autoplay. The infinite scroll. The notifications. The red dots. The "Someone liked your story" that makes you open the app even though you know it's probably just your mom.

They have teams of engineers A/B testing every pixel to find out what keeps you scrolling longest.

They know exactly how long to wait before showing you something interesting. They know exactly when your attention is about to wander. They know how to make you feel like you're missing something if you leave.

This isn't conspiracy. This is literally their business model. Their product is your attention. And they're very good at their job.

### The Interrupt

You're not going to delete all your apps. That's not realistic and also probably not what you want.

But you can make it harder for the slot machine to run automatically.

Try this: Before you open an app, pause for three seconds.

Just three.

And ask: "What am I looking for right now?"

If you have an answer ("I'm checking if Sarah responded" or "I want to see what people thought about that thing"), then check.

But if the answer is "I don't know, just checking," that's the slot machine reflex.

And you can choose not to pull the lever.

Not because you should. Not because phones are bad.

But because you're deciding instead of defaulting.

### The Practice

Right now, notice: How many times have you checked your phone today?

You probably don't know. Because most of it was automatic.

For the next 24 hours, try this: Every time you reach for your phone, just notice.

You don't have to stop yourself. Just notice.

"I'm reaching for my phone."

That's it. Awareness before action.

See what you learn about your own patterns.

---

## CHAPTER 2: THE ATTENTION YOU DON'T HAVE [11 minutes]

### The Fracture

You're watching a show. But you're also scrolling. But you're also thinking about responding to that text. But you're also monitoring if anything new happened in the last ninety seconds.

You're not really watching the show. You're not really scrolling. You're not really present anywhere.

Your attention is fragmented across seventeen different things and you're not fully experiencing any of them.

This is your baseline now. This is what normal feels like.

### What's Actually Happening

Your attention span isn't getting shorter because you're weak or lazy or broken.

It's getting shorter because you're training it to be short.

Every time you switch tasks—every time you go from the show to your phone to the text to Instagram—you're teaching your brain that focus is temporary.

The technical term is "continuous partial attention." You're always monitoring everything, never fully engaged with anything.

And here's what most people don't realize: this has a cognitive cost.

Every time you switch your attention, there's a "switching cost." Your brain has to disengage from the old task, move to the new task, re-engage, suppress distractions from the old task, and load the context for the new task.

This takes mental energy. A lot of it.

So when you're "multitasking" (which is actually just rapid task-switching), you're burning through your cognitive resources without accomplishing much of anything.

You end the day exhausted but you can't remember what you actually did.

### The Pattern

Here's the cycle:

1. Start a task that requires focus
2. Feel the discomfort of sustained attention
3. Seek relief through distraction (check phone)
4. Get temporary dopamine hit
5. Return to task
6. Brain is now primed for shorter attention windows
7. Feel discomfort faster
8. Check phone sooner
9. Attention span shrinks
10. Loop intensifies

Your brain is learning that you can't handle boredom, uncertainty, or the normal discomfort of deep focus.

So it starts signaling distress earlier and earlier.

Until you can't make it through a single paragraph without checking something.

### Why It Won't Stop

Because everything in your environment is optimized for interruption.

Notifications. Messages. Updates. The entire digital ecosystem is designed to fragment your attention.

And you can't focus in five-minute increments. That's not how deep work happens. That's not how learning happens. That's not how thinking happens.

You need sustained attention to:
- Solve complex problems
- Learn new skills  
- Have meaningful conversations
- Create anything worth creating
- Understand difficult concepts
- Experience anything deeply

But sustained attention feels uncomfortable now. It feels wrong. It feels like you're missing something.

So you keep checking. And your capacity for deep focus keeps shrinking.

### The Interrupt

You're not going to fix this overnight. Your attention span is like a muscle—it atrophies from disuse and rebuilds slowly.

But you can start.

Try this: Pick one thing—reading, watching something, having a conversation—and commit to ten minutes of undivided attention.

Not an hour. Not all day. Ten minutes.

Put your phone in another room. Not on silent. In another room.

And when your brain screams that you need to check it, notice the discomfort.

"My brain thinks I'm missing something."

You're not. You're just not used to being present anymore.

Sit with it. Let it be uncomfortable.

Ten minutes.

Then check your phone. Nothing important happened. It never does.

### The Practice

Right now, notice: When was the last time you did one thing with your full attention?

Not scrolling while watching. Not half-listening while texting. Just one thing.

If you can't remember, start today.

Pick something small. Do it completely.

See what it feels like to be whole instead of fragmented.

---

## CHAPTER 3: THE PERSON YOU PERFORM [13 minutes]

### The Curation

You take seventeen photos to get one that's good enough to post.

You write a caption, delete it, rewrite it, make it sound casual even though you spent twenty minutes on it.

You post it. You check how it's doing. Three likes. Is that good? You check again. Seven. Okay. You check again.

This isn't sharing your life. This is performing it.

And the performance is so constant you've forgotten there's a difference.

### What's Actually Happening

You have multiple selves now.

There's the you that exists in real life. And then there's:
- Instagram you (curated, aesthetic, having the best time)
- Twitter you (witty, informed, has takes)
- TikTok you (authentic but make it content)
- LinkedIn you (professional, accomplished, networking)
- Discord you (unhinged, the real you except not really)
- Finsta you (actually real except also performed for a different audience)

And each version requires different presentation, different tone, different values, different personality.

You're not one person anymore. You're a portfolio of personas optimized for different platforms.

And the cognitive load of maintaining all these versions is exhausting you in ways you don't even notice.

### The Pattern

Here's how it happens:

1. Experience something in real life
2. Immediately think about how to present it online
3. Curate the experience while it's happening
4. Post the curated version
5. Monitor engagement
6. Feel validated or disappointed based on metrics
7. Adjust future posts based on what performed well
8. Future experiences get filtered through "is this postable"
9. Loop intensifies

You stop having experiences for yourself. You start having experiences for content.

You're at a concert but you're filming it. You're at dinner but you're photographing it. You're with friends but you're thinking about the caption.

You're documenting your life instead of living it.

### Why It Won't Stop

Because engagement feels like connection.

When someone likes your post, your brain interprets it as social acceptance. When someone comments, it feels like they care.

But they don't know you. They know the performance.

And the more you perform, the more isolated you feel. Because nobody's seeing the actual you—the messy, uncertain, unfiltered version that doesn't fit in a grid.

So you feel lonely even though you have followers. You feel unseen even though people are watching.

Because what they're seeing isn't real.

### The Interrupt

You're not going to stop posting. But you can start separating the performance from the reality.

Try this: Have one experience this week that you don't document.

Not because it's not postable. Because it's just for you.

Go somewhere. Do something. See something.

And let it exist only in your memory.

Let it be imperfect, unwitnessed, uncurated.

Let it be real.

### The Practice

Right now, notice: Which version of yourself are you performing right now?

Even listening to this, are you thinking about how you'll talk about it? How it fits into your personal brand?

Just notice.

The you that exists when nobody's watching—that's the one who needs your attention.

Not the one who performs for likes.

---

## CHAPTER 4: THE COMPARISON YOU CAN'T ESCAPE [10 minutes]

### The Feed

You open Instagram. Everyone is doing better than you.

Someone got engaged. Someone's traveling. Someone has their life together. Someone is hot and successful and happy and probably never has anxiety.

And you're... here. Still figuring it out. Still struggling with things that seem easy for everyone else.

This is the comparison trap. And social media makes it inescapable.

### What's Actually Happening

Your brain wasn't designed for this much social comparison.

In a traditional social group, you'd compare yourself to maybe 50-150 people you actually knew. Your tribe. Your community.

Now you're comparing yourself to millions of people's highlight reels simultaneously.

And here's the thing: you're not comparing accurately.

You're comparing your internal experience (messy, uncertain, full of self-doubt) to everyone else's external presentation (curated, filtered, optimized).

You're comparing your blooper reel to their highlight reel and wondering why you're losing.

### The Pattern

Here's the cycle:

1. Open social media
2. See someone's success/beauty/achievement
3. Immediate comparison: "Why don't I have that?"
4. Feel inadequate/jealous/behind
5. Scroll to feel better
6. See more comparisons
7. Feel worse
8. Can't stop scrolling (trying to find evidence you're okay)
9. Find more evidence you're not
10. Loop intensifies

And the algorithm knows this works. So it shows you more of what makes you feel inadequate. Because inadequacy keeps you scrolling.

### Why It Won't Stop

Because social media is designed to trigger comparison.

The likes. The followers. The metrics. Everything is quantified, ranked, visible.

You can't help but compare. It's literally built into the interface.

And even when you know someone's life isn't really perfect, even when you know it's all curated, your brain still responds to the image.

Because your nervous system can't tell the difference between real social threat and digital social comparison.

It just knows: someone else is winning and you're not.

### The Interrupt

You're not going to stop comparing. Comparison is hardwired.

But you can change what you compare.

Try this: Unfollow anyone who makes you feel bad about yourself.

Not because they're bad people. Not because they're doing anything wrong.

Because your nervous system responds to what it sees. And if seeing someone's posts consistently makes you feel inadequate, that's information.

You don't owe anyone your attention. Especially when it costs you your peace.

### The Practice

Right now, scroll through your feed.

Notice your body's response to each post.

Chest tightens? That's comparison triggering.

Stomach drops? That's inadequacy activating.

You don't have to analyze why. Just notice.

Then ask: "Does this person's presence in my feed make my life better or worse?"

Act accordingly.

---

## CHAPTER 5: THE OUTRAGE YOU CAN'T STOP [12 minutes]

### The Scroll

You're scrolling and see something terrible. Actually terrible. Injustice, cruelty, stupidity, harm.

Your body responds immediately. Heart rate up. Jaw clenched. That hot feeling in your chest.

You read the comments. They make it worse. You want to respond, to correct, to make people understand.

You're angry. And the anger feels righteous. Important. Necessary.

But also: you can't stop thinking about it. Hours later you're still mentally arguing. Still upset. Still activated.

This is the outrage loop. And it's killing you slowly.

### What's Actually Happening

Your brain is designed to respond to threat. When you see injustice or harm, your nervous system activates.

This is good. This is how you know what matters. How you mobilize for change.

But social media isn't showing you injustice so you can respond to it. It's showing you injustice because outrage is engagement.

And engagement is profit.

So the algorithm learns: when you're angry, you scroll more. You comment more. You share more.

So it shows you more things that make you angry.

The technical term is "rage farming." And you're the crop.

### The Pattern

Here's the cycle:

1. See something outrageous
2. Nervous system activates (threat response)
3. Feel compelled to engage (fix the threat)
4. Engage (comment/share/argue)
5. Get more outrage content (algorithm learned)
6. Stay activated (can't calm down)
7. Feel exhausted but wired
8. Can't stop checking (need to monitor threat)
9. Loop intensifies

You're not becoming more informed. You're becoming more dysregulated.

You're not changing anything. You're just staying in fight-or-flight mode for hours.

### Why It Won't Stop

Because the outrage feels meaningful.

You're not scrolling mindlessly—you're staying informed. You're bearing witness. You're not complicit.

Except you are scrolling mindlessly. Just with moral justification.

And here's what nobody tells you: you can care about injustice without consuming outrage content 24/7.

You can be informed without being activated constantly.

You can take action without destroying your nervous system.

### The Interrupt

You're not going to stop caring about things. But you can stop feeding the outrage machine.

Try this: Ask yourself, "Can I actually do something about this right now?"

If yes: do the thing. Donate. Organize. Act. Then log off.

If no: you're just consuming trauma for the algorithm. And that helps nobody.

Staying activated doesn't help the cause. It just helps the platform.

### The Practice

Right now, notice: How much of your daily outrage leads to actual action?

How much is just consumption?

How much is just keeping you in a state of perpetual stress?

You can care without carrying it all.

You can act without being activated constantly.

Your nervous system is not a renewable resource.

---

## CHAPTER 6: THE CONNECTION THAT ISN'T [11 minutes]

### The Conversation

You're texting with someone. Back and forth. It feels like connection.

Except you're also texting three other people. And scrolling. And half-watching something.

So you're not really present. And neither are they.

And when you actually see each other in person, there's this weird gap. Like you know everything about each other but also nothing.

Because you've been having parallel monologues, not actual conversations.

### What's Actually Happening

Digital communication creates the illusion of connection without the substance.

You can text someone all day and still feel lonely. Because texting isn't intimacy. It's performance.

You're crafting responses. Editing tone. Managing impression. Even with close friends.

And there's no body language. No facial expressions. No nervous system co-regulation. No shared physical presence.

You're getting the social acknowledgment (someone's responding) without the actual connection (being seen, felt, known).

It's like eating artificial sweetener instead of sugar. Your brain registers "sweet" but your body knows something's missing.

### The Pattern

Here's the cycle:

1. Feel lonely/disconnected
2. Reach out digitally (text/message)
3. Get response (temporary relief)
4. Relief fades (wasn't real connection)
5. Feel lonely again
6. Reach out more
7. Still feel lonely
8. Assume something's wrong with you
9. Loop intensifies

You're having more "conversations" than ever. And feeling more isolated than ever.

Because quantity isn't quality. And digital isn't the same as physical.

### Why It Won't Stop

Because digital connection is easier.

No coordinating schedules. No commuting. No having to be "on." No risk of awkward silences or difficult emotions.

You can craft your response. Delete and rewrite. Present the version of yourself that's funniest, smartest, most together.

But that ease comes at a cost: you never have to be vulnerable. You never have to sit with discomfort. You never have to be truly seen.

And without vulnerability, there's no real connection.

### The Interrupt

You're not going to stop texting. But you can stop treating it like connection.

Try this: Next time you're about to text someone you actually care about, call them instead.

Or better: see them in person.

I know. It's more effort. It's scarier. It's harder to control.

That's why it matters.

Connection requires presence. And presence requires risk.

### The Practice

Right now, think of someone you text frequently but rarely see.

When was the last time you were actually in the same room?

Make a plan to be in the same room again.

Not to do something. Just to exist together.

That's where connection lives.

---

## CHAPTER 7: THE SELF YOU'RE LOSING [12 minutes]

### The Absence

You have a thought. An original thought. Something you're thinking about, curious about, wanting to explore.

Your first impulse: search it. See what other people think. Find the take. Know the consensus.

And just like that, the thought isn't yours anymore.

This is happening all the time now. And you're losing yourself in the process.

### What's Actually Happening

You're outsourcing your thinking to the internet.

Any question, any curiosity, any uncertainty—you Google it instead of sitting with it.

And here's what you lose:

The process of not knowing. The discomfort of figuring something out. The development of your own perspective. The confidence that comes from thinking through something yourself.

You're getting answers faster. But you're not developing the capacity to think.

You're becoming a consumer of other people's thoughts instead of a creator of your own.

### The Pattern

Here's the cycle:

1. Have a question or thought
2. Immediately search for answer
3. Find consensus view
4. Adopt consensus view
5. Skip the process of forming your own opinion
6. Lose capacity for independent thought
7. Feel uncertain without external validation
8. Search more
9. Loop intensifies

You're so used to instant answers that the discomfort of not knowing feels unbearable.

So you never sit with questions. You never develop your own relationship to ideas. You never learn to trust your own thinking.

### Why It Won't Stop

Because not knowing feels dangerous.

What if you're wrong? What if you look stupid? What if there's a right answer and you don't have it?

So you search. And you adopt. And you never develop the muscles of original thought.

And the more you outsource your thinking, the less capable you become of thinking independently.

Until you're not sure what you actually think about anything.

### The Interrupt

You're not going to stop using the internet to learn. But you can start thinking before you search.

Try this: Next time you have a question, sit with it for five minutes before you Google.

Not researching. Not analyzing. Just wondering.

What do you think might be true? What's your intuition? What would make sense?

You don't have to be right. You just have to practice having your own thoughts first.

Then search. Compare. Learn.

But start with you.

### The Practice

Right now, think of something you're curious about.

Before you search, ask yourself: "What do I actually think about this?"

Sit with that for 60 seconds.

Whatever comes up—uninformed, uncertain, incomplete—that's yours.

That's the beginning of thinking.

---

## CHAPTER 8: THE LIFE YOU'RE NOT LIVING [10 minutes]

### The Substitution

You're on your phone for four hours a day. Sometimes more.

That's 28 hours a week. 1,456 hours a year. 60 days.

Two months of your life. Every year. On your phone.

And I'm not saying that to shame you. I'm saying it so you know what you're trading.

Because time on the phone is time not doing something else.

### What's Actually Happening

Every minute you spend scrolling is a minute you're not:

Learning something difficult. Creating something meaningful. Having a real conversation. Sitting with your own thoughts. Developing a skill. Being present in your actual life.

The phone isn't just stealing your attention. It's stealing your potential.

Not because you're weak. Because it's designed to.

And the longer you spend in the loop, the smaller your life becomes.

### The Pattern

Here's what's being lost:

1. Boredom (where creativity comes from)
2. Solitude (where you get to know yourself)
3. Discomfort (where growth happens)
4. Presence (where life actually occurs)
5. Depth (where meaning is found)
6. Focus (where mastery develops)
7. Silence (where you hear your own voice)

You're filling every gap with content. And in the process, you're losing the gaps where you become yourself.

### Why It Won't Stop

Because the alternative feels empty.

What would you do if you weren't on your phone? Just... sit there? Think? Be bored?

Yes. Exactly that.

That's where you find out who you are. What you actually want. What matters to you.

But you've been running from that space for so long, it feels like nothing.

It's not nothing. It's everything.

### The Interrupt

You're not going to quit your phone. But you can reclaim some of what you're trading.

Try this: What's one thing you wish you were doing that you're not?

Reading more? Creating something? Learning a skill? Just being present?

Take 30 minutes this week. Put your phone in another room. Do that thing.

Just 30 minutes. Not every day. Not as a new routine. Just once this week.

See what happens when you're not filling the gap.

### The Practice

Right now, check your screen time.

Look at the number. Really look at it.

That's how much life you're trading.

Is it worth it?

Only you can answer that.

But you have to answer it honestly.

---

## CLOSING: THE PHONE YOU CAN PUT DOWN [7 minutes]

### What We've Covered

We've looked at eight ways your phone is changing you:

The dopamine slot machine. The fragmented attention. The performed self. The endless comparison. The manufactured outrage. The shallow connection. The outsourced thinking. The substituted life.

These aren't separate problems. They're all the same thing:

Your attention has been weaponized against you. And you're losing yourself in the process.

### The Truth

Here's what the apps won't tell you:

You were whole before you had a phone.

You had thoughts without needing to search them. You had conversations without documenting them. You had experiences without performing them. You had self-worth without quantifying it.

And you can have those things again.

Not by deleting everything. Not by going offline forever.

But by remembering: the phone is a tool. Not a replacement for your life.

### The Choice

Every time you reach for your phone, you're making a choice.

Most of the time, it doesn't feel like a choice. It feels automatic. Necessary. Urgent.

But it's still a choice.

And you can start making it consciously.

Not because you should. Not because phones are bad.

But because your attention is the most valuable thing you own.

And right now, you're giving it away for free.

To algorithms that profit from your distraction. To platforms that harvest your engagement. To systems designed to keep you scrolling, comparing, performing, consuming.

You don't owe them your life.

### What Happens Next

You're not going to be perfect at this. You're going to check your phone mindlessly. You're going to get caught in the loops.

But every time you notice—every single time you catch yourself and pause—you're building something different.

A relationship with technology that serves you instead of using you.

A life that happens in the world, not just on a screen.

A self that exists independent of likes, followers, and engagement metrics.

That version of you is still there. Underneath the performance. Underneath the comparison. Underneath the loop.

You just have to put the phone down long enough to find them.

### Final Practice

Right now, put your phone on airplane mode for the next ten minutes.

You don't have to do anything profound. Just be here without checking.

Notice the urge to reach for it. Notice the discomfort of not knowing what you're missing.

You're not missing anything.

You're finding something.

Yourself.

---

## PRODUCTION NOTES

**Total Runtime:** Approximately 91 minutes

**Tone:** Direct, tech-savvy, compassionate without being preachy. Speaks to digital natives who understand the problem but feel powerless against it. Combines neuroscience with platform mechanics to show how the system works.

**TTS Guidance:** Moderate pacing with emphasis on the "what's actually happening" sections. Should feel like someone explaining how you got played, not judging you for it.

**Music/Sound:** Minimal. Perhaps subtle digital texture during practices, but voice-forward. This is about truth-telling, not production value.

**Target Audience:** Gen Z digital natives (18-27) who grew up with smartphones, understand they're addicted but don't know how to change it, and are tired of being told to "just put it down" without understanding the underlying mechanics.

**Therapeutic Framework:** Combines behavioral psychology (variable ratio reinforcement), neuroscience (dopamine system hijacking), media literacy (platform mechanics), and self-compassion. Based on research from Tristan Harris/Center for Humane Technology, digital wellness literature, and attention economy analysis.

---

**END OF SCRIPT**
