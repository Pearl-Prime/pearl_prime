# Phoenix Omega V4.5.1 — Gate Simplification Update

**Version:** V4.5.1  
**Date:** February 2026  
**Status:** Canonical  
**Supersedes:** V4.5 Final

---

## What Changed from V4.5 to V4.5.1

**V4.5.1 = V4.5 with simplified, mechanical gate language.**

All requirements remain identical. Only gate implementation language changed to be more developer-friendly and testable.

**Core changes:**
1. Gates now use mechanical pre-filters (approved vocabulary lists, word counts, field presence checks)
2. Human review is reserved for edge cases only (not primary enforcement)
3. Gates fail-fast where possible (clear pass/fail criteria)
4. Reduced subjective interpretation

**What stayed the same:**
- All metadata fields (emotional_register, emotional_intensity)
- All writing requirements (sensory anchors, body-present closings, narrative bridges, sticky sentences)
- action_despite_pattern requirement: ≥2 per book (NOT ≥1)
- Distribution caps (60% max same register/intensity)
- All other V4.5 specifications

---

## Updated QA Gates (75-81)

### Gate 75: emotional_register Distribution ✅ UNCHANGED

**Rule:**

Every STORY atom must include `emotional_register` field with valid value:
- analytical
- embodied  
- active
- frozen

**Book-level requirements:**

- **Distribution cap:** Maximum 60% of stories in any single register
- **Coverage (8+ chapter books):** All four registers must appear at least once
- **Coverage (3-chapter books):** Minimum three registers must appear
- **Active placement:** All action_despite_pattern stories must have `emotional_register: active`

**Fail conditions:**
- Any STORY atom missing emotional_register field
- >60% of stories share same register
- Coverage requirements not met

**Severity:** CRITICAL (blocks compilation)

**Implementation:** Plan compiler checks during slot selection

---

### Gate 76: emotional_intensity Distribution ✅ UNCHANGED

**Rule:**

Every STORY atom must include `emotional_intensity` field with valid value: 1, 2, 3, 4, or 5

**Book-level requirements:**

- **Distribution cap:** Maximum 60% of stories at any single intensity level
- **Range (8+ chapter books):** Must span at least 3 intensity levels; must include at least one level-5 story
- **Range (3-chapter books):** Must span at least 3 intensity levels

**Fail conditions:**
- Any STORY atom missing emotional_intensity field
- >60% of stories share same intensity
- Range requirements not met

**Severity:** CRITICAL (blocks compilation)

**Implementation:** Plan compiler checks during slot selection

---

### Gate 77: action_despite_pattern Presence ⚡ SIMPLIFIED

**V4.5 version:**
> Check: Every compiled plan includes ≥2 action_despite_pattern stories  
> Check: Stories are positioned in final 1/3 to 1/2 of book  
> Check: All action_despite_pattern stories have emotional_register: active  
> Check: No resolution lexemes in action_despite_pattern story bodies

**V4.5.1 version:**

**Pre-filter (automated):**

1. Count action_despite_pattern stories in compiled plan
   - **Pass:** ≥2 found
   - **Fail:** <2 found

2. Check positioning of all action_despite_pattern stories
   - **8-chapter books:** First action in chapters 5-6, second in 7-8
   - **3-chapter books:** First action in chapter 2, second in chapter 3
   - **Pass:** Positioning requirements met
   - **Fail:** All actions front-loaded in first half

3. Check emotional_register field
   - **Pass:** All action_despite_pattern stories have `emotional_register: active`
   - **Fail:** Any action story has different register

4. Scan story body for resolution lexemes
   - **Approved action verbs:** send, say, raise, submit, walk, speak, ask, choose, decide, act
   - **Forbidden resolution lexemes:** heal, healed, free, freed, lighter, relief, relieved, finally, better, fixed, cured, transformed, breakthrough
   - **Pass:** Contains ≥1 approved action verb AND zero forbidden lexemes
   - **Fail:** Contains forbidden lexemes OR no visible action verb

**Fail conditions:**
- <2 action_despite_pattern stories in plan
- Stories positioned only in first half of book
- Any action story missing `emotional_register: active`
- Any action story body contains resolution lexemes

**Severity:** CRITICAL (blocks compilation)

**Implementation:** Plan compiler enforces count and positioning; lint check scans atom bodies

---

### Gate 78: REFLECTION Sensory Anchor Check ⚡ SIMPLIFIED

**V4.5 version:**
> Scan REFLECTION body for sensory vocabulary... Flag REFLECTIONs with zero sensory words... Human review required

**V4.5.1 version:**

**Approved sensory vocabulary list:**

Body parts: jaw, shoulders, breath, chest, stomach, throat, hands, pulse, heart, spine, neck, face, eyes, mouth, tongue, teeth, ribs, gut, belly, lungs, diaphragm

Sensations: tight, tense, heavy, hot, cold, hollow, clenched, shallow, racing, frozen, numb, electric, weighted, compressed, expanded, constricted, loose, stiff, aching, burning, tingling, prickling, sharp, dull, throbbing

Actions: holds, grips, clenches, rises, drops, tightens, releases, catches, stalls, speeds, slows, contracts, expands, seizes, locks, softens, hardens, flutters, pounds, trembles, shakes

**Pre-filter (automated):**

1. Scan REFLECTION body text for terms from approved vocabulary
2. Count matches
   - **Pass:** ≥3 sensory terms found
   - **Flag for review:** <3 sensory terms found

**Human review (if flagged):**

Reviewer answers: "Does a 20-40 word somatic anchor exist in this REFLECTION?"
- **Approve:** Yes, somatic language present (even if not matching exact vocabulary list)
- **Reject:** No, purely cognitive explanation with no body reference

**Valid exceptions (rare):**
- REFLECTIONs explaining purely abstract mechanisms (e.g., memory encoding, time perception) where somatic anchors would feel forced
- Reviewer must document why exception granted

**Fail conditions:**
- <3 sensory terms AND human reviewer confirms no somatic anchor exists

**Severity:** WARNING (requires human review, not auto-block)

**Implementation:** Automated scan flags atoms; human reviewer approves/rejects flagged atoms before release

---

### Gate 79: INTEGRATION Body-Present Closing Check ⚡ SIMPLIFIED

**V4.5 version:**
> Check final sentence... Must contain body/breath/presence word... Flag abstract-only closings

**V4.5.1 version:**

**Approved body-present vocabulary list:**

Body: body, breath, breathing, chest, heart, pulse, hands, feet, ground, weight, sitting, standing, here, present, still

Presence: now, this moment, right now, currently

Breath: inhale, exhaling, air, lungs

Physical state: alive, existing, remaining, continuing

**Pre-filter (automated):**

1. Extract final 2 sentences of INTEGRATION atom body
2. Scan for terms from approved vocabulary
   - **Pass:** ≥1 body/breath/presence term found in final 2 sentences
   - **Flag for review:** Zero terms found (purely abstract closing)

**Human review (if flagged):**

Reviewer answers: "Is the closing grounded in body/breath/present moment?"
- **Approve:** Yes, closing references physical presence (even if not exact vocabulary match)
- **Reject:** No, ending is purely philosophical/abstract

**Valid exceptions (rare):**
- INTEGRATIONs that return to core thesis where body-present language would dilute philosophical precision
- Reviewer must document why exception granted

**Fail conditions:**
- Zero body/breath/presence terms in final 2 sentences AND human reviewer confirms abstract-only closing

**Severity:** WARNING (requires human review, not auto-block)

**Implementation:** Automated scan flags atoms; human reviewer approves/rejects flagged atoms before release

---

### Gate 80: EXERCISE Narrative Bridge Check ⚡ SIMPLIFIED

**V4.5 version:**
> Every EXERCISE must have narrative_bridge_in field populated... 30-50 words... First-person author voice... Flag if missing

**V4.5.1 version:**

**Pre-filter (automated):**

1. Check field presence
   - **Pass:** `narrative_bridge_in` field exists and is populated
   - **Fail:** Field missing or empty

2. Check word count
   - **Full atoms:** 30-50 words
   - **Micro atoms:** 20-30 words
   - **Pass:** Word count in range
   - **Flag for review:** Word count out of range

3. Check for transition phrases (must contain ≥1)
   - "Here is how"
   - "Here's how"
   - "You are going to practice"
   - "You're going to practice"
   - "Pause with me"
   - "Try this"
   - "Let's practice"
   - "We're going to"
   - **Pass:** Contains ≥1 approved transition phrase
   - **Flag for review:** No transition phrase found

**Human review (if flagged):**

Reviewer confirms:
- Bridge is first-person author voice (not second-person instruction yet)
- Bridge transitions from preceding content into practice
- Tone is conversational and directive

**Fail conditions:**
- Field missing or empty
- Word count <20 or >60 (severe outlier)
- No transition language AND human reviewer confirms bridge is inadequate

**Severity:** WARNING (requires human review for outliers, auto-fail for missing field)

**Implementation:** Automated scan checks presence and basic criteria; human reviews edge cases

---

### Gate 81: Sticky Sentence Presence ⚡ SIMPLIFIED

**V4.5 version:**
> Scan REFLECTION for sentences <20 words... Flag if none found... Human review: quotable moment exists?

**V4.5.1 version:**

**Pre-filter (automated):**

1. Parse REFLECTION body into sentences
2. Count words per sentence
3. Identify sentences meeting sticky criteria:
   - **Length:** 8-15 words
   - **Structure:** No commas (simple construction)
   - **Compression:** No filler words (the, very, really, actually, basically, essentially)

4. Count candidates
   - **Pass:** ≥1 candidate sticky sentence found
   - **Flag for review:** Zero candidates found

**Human review (if flagged):**

Reviewer answers: "Does at least one sentence crystallize a core insight in a quotable way?"

Look for:
- Parallel structure ("X is real. Y is not.")
- Reversal ("You are not X. You are Y.")
- Contrast ("X happens. Y doesn't.")
- Sharp simplicity ("The loop runs.")

**Approve if:**
- A quotable moment exists (even if >15 words, or contains one comma for clarity)
- The REFLECTION uses a different rhetorical strategy that doesn't lend itself to short zingers (e.g., extended narrative-embedded explanation)

**Reject if:**
- All sentences are 18+ words with complex subordinate clauses
- No memorable moments
- Prose feels uniformly academic/dense

**Valid exceptions:**
- Highly technical REFLECTIONs (mechanism-heavy biology explanations) where simplification would lose precision
- Reviewer must document why exception granted

**Fail conditions:**
- Zero short sentences AND human reviewer confirms no quotable moments exist

**Severity:** INFO (quality check, not enforcement — soft gate)

**Implementation:** Automated scan flags atoms; human reviewer provides quality feedback; does not block release but informs revision priorities

---

## Gate Implementation Summary (V4.5.1)

| Gate | Type | Automation | Human Review | Blocks Release? |
|------|------|------------|--------------|-----------------|
| 75 | emotional_register distribution | Full | No | Yes (CRITICAL) |
| 76 | emotional_intensity distribution | Full | No | Yes (CRITICAL) |
| 77 | action_despite_pattern presence | Full | No | Yes (CRITICAL) |
| 78 | REFLECTION sensory anchor | Pre-filter + review | If <3 terms | No (WARNING) |
| 79 | INTEGRATION body-present closing | Pre-filter + review | If no terms | No (WARNING) |
| 80 | EXERCISE narrative bridge | Pre-filter + review | If outlier/missing | Yes if missing (WARNING) |
| 81 | Sticky sentence presence | Pre-filter + review | If zero candidates | No (INFO) |

**CRITICAL gates:** Hard blocks. Compilation fails.  
**WARNING gates:** Soft blocks. Human review required, but can approve exceptions.  
**INFO gates:** Quality feedback. Does not block release.

---

## Vocabulary Lists (Reference)

### Sensory Vocabulary (Gate 78)

**Body parts (31 terms):**
jaw, shoulders, breath, chest, stomach, throat, hands, pulse, heart, spine, neck, face, eyes, mouth, tongue, teeth, ribs, gut, belly, lungs, diaphragm, fingers, palms, wrists, arms, legs, feet, toes, skin, head, forehead

**Sensations (33 terms):**
tight, tense, heavy, hot, cold, hollow, clenched, shallow, racing, frozen, numb, electric, weighted, compressed, expanded, constricted, loose, stiff, aching, burning, tingling, prickling, sharp, dull, throbbing, warm, cool, pressure, squeezing, fluttering, sinking, rising, dropping

**Actions (26 terms):**
holds, grips, clenches, rises, drops, tightens, releases, catches, stalls, speeds, slows, contracts, expands, seizes, locks, softens, hardens, flutters, pounds, trembles, shakes, quickens, hitches, steadies, braces, coils

**Total:** 90 approved sensory terms

---

### Body-Present Vocabulary (Gate 79)

**Body (15 terms):**
body, breath, breathing, chest, heart, pulse, hands, feet, ground, weight, sitting, standing, here, present, still

**Presence (4 terms):**
now, this moment, right now, currently

**Breath (4 terms):**
inhale, exhaling, air, lungs

**Physical state (4 terms):**
alive, existing, remaining, continuing

**Total:** 27 approved body-present terms

---

### Transition Phrases (Gate 80)

**Approved bridge transitions (11 phrases):**

1. "Here is how"
2. "Here's how"
3. "You are going to practice"
4. "You're going to practice"
5. "Pause with me"
6. "Try this"
7. "Let's practice"
8. "We're going to"
9. "This is how"
10. "Now you'll practice"
11. "Let me show you"

**Note:** Variations acceptable if meaning preserved (e.g., "Here is exactly how" contains "Here is how")

---

### Action Verbs (Gate 77)

**Approved action verbs (visible, specific actions):**

send, sends, sent, say, says, said, raise, raises, raised, submit, submits, submitted, walk, walks, walked, speak, speaks, spoke, ask, asks, asked, choose, chooses, chose, decide, decides, decided, act, acts, acted, answer, answers, answered, reply, replies, replied, text, texts, texted, call, calls, called, show, shows, showed, tell, tells, told, respond, responds, responded, move, moves, moved, step, steps, stepped, reach, reaches, reached, open, opens, opened, close, closes, closed, press, presses, pressed, click, clicks, clicked, hit, hits, type, types, typed, write, writes, wrote

**Forbidden resolution lexemes:**

heal, healed, healing, heals, free, freed, freedom, lighter, light, relief, relieved, finally, better, fixed, fix, cured, cure, transformed, transform, breakthrough, broke through, complete, completed, whole, released (in emotional sense), liberated, triumph, triumphed, conquered, overcome, overcame, victory, victorious, solved

---

## Developer Implementation Notes

### Gate 78 Implementation (Sensory Anchor)

```python
def check_sensory_anchor(reflection_body: str) -> dict:
    """
    Gate 78: Check REFLECTION for sensory language.
    
    Returns:
        {
            'pass': bool,
            'flag_for_review': bool,
            'sensory_term_count': int,
            'matched_terms': list
        }
    """
    SENSORY_VOCAB = [
        # Body parts
        'jaw', 'shoulders', 'breath', 'chest', 'stomach', 'throat',
        'hands', 'pulse', 'heart', 'spine', 'neck', 'face',
        # ... (full list from vocabulary section)
        
        # Sensations
        'tight', 'tense', 'heavy', 'hot', 'cold', 'hollow',
        # ... (full list)
        
        # Actions
        'holds', 'grips', 'clenches', 'rises', 'drops', 'tightens',
        # ... (full list)
    ]
    
    body_lower = reflection_body.lower()
    matched_terms = [term for term in SENSORY_VOCAB if term in body_lower]
    count = len(set(matched_terms))  # unique terms only
    
    return {
        'pass': count >= 3,
        'flag_for_review': count < 3,
        'sensory_term_count': count,
        'matched_terms': matched_terms
    }
```

### Gate 79 Implementation (Body-Present Closing)

```python
def check_body_present_closing(integration_body: str) -> dict:
    """
    Gate 79: Check INTEGRATION for body-present closing.
    
    Returns:
        {
            'pass': bool,
            'flag_for_review': bool,
            'matched_terms': list
        }
    """
    BODY_PRESENT_VOCAB = [
        'body', 'breath', 'breathing', 'chest', 'heart', 'pulse',
        'hands', 'feet', 'ground', 'weight', 'sitting', 'standing',
        'here', 'present', 'still', 'now', 'this moment', 'right now',
        'currently', 'inhale', 'exhaling', 'air', 'lungs', 'alive',
        'existing', 'remaining', 'continuing'
    ]
    
    # Extract final 2 sentences
    sentences = split_sentences(integration_body)
    final_sentences = sentences[-2:] if len(sentences) >= 2 else sentences
    final_text = ' '.join(final_sentences).lower()
    
    matched_terms = [term for term in BODY_PRESENT_VOCAB if term in final_text]
    
    return {
        'pass': len(matched_terms) > 0,
        'flag_for_review': len(matched_terms) == 0,
        'matched_terms': matched_terms
    }
```

### Gate 80 Implementation (Narrative Bridge)

```python
def check_narrative_bridge(exercise_atom: dict) -> dict:
    """
    Gate 80: Check EXERCISE for narrative bridge.
    
    Returns:
        {
            'pass': bool,
            'flag_for_review': bool,
            'issues': list
        }
    """
    TRANSITION_PHRASES = [
        "here is how", "here's how",
        "you are going to practice", "you're going to practice",
        "pause with me", "try this", "let's practice",
        "we're going to", "this is how", "now you'll practice",
        "let me show you"
    ]
    
    bridge = exercise_atom.get('narrative_bridge_in', '')
    atom_size = exercise_atom.get('atom_size', 'full')
    
    issues = []
    
    # Check presence
    if not bridge or len(bridge.strip()) == 0:
        return {
            'pass': False,
            'flag_for_review': False,  # Hard fail
            'issues': ['CRITICAL: narrative_bridge_in field missing or empty']
        }
    
    # Check word count
    word_count = len(bridge.split())
    if atom_size == 'full':
        if word_count < 30 or word_count > 50:
            issues.append(f'Word count {word_count} outside 30-50 range')
    elif atom_size == 'micro':
        if word_count < 20 or word_count > 30:
            issues.append(f'Word count {word_count} outside 20-30 range')
    
    # Check transition phrase
    bridge_lower = bridge.lower()
    has_transition = any(phrase in bridge_lower for phrase in TRANSITION_PHRASES)
    if not has_transition:
        issues.append('No approved transition phrase found')
    
    return {
        'pass': len(issues) == 0,
        'flag_for_review': len(issues) > 0,
        'issues': issues
    }
```

### Gate 81 Implementation (Sticky Sentence)

```python
def check_sticky_sentence(reflection_body: str) -> dict:
    """
    Gate 81: Check REFLECTION for sticky sentence.
    
    Returns:
        {
            'pass': bool,
            'flag_for_review': bool,
            'candidate_count': int,
            'candidates': list
        }
    """
    FILLER_WORDS = ['the', 'very', 'really', 'actually', 'basically', 'essentially']
    
    sentences = split_sentences(reflection_body)
    candidates = []
    
    for sentence in sentences:
        word_count = len(sentence.split())
        has_comma = ',' in sentence
        
        # Check sticky criteria
        if 8 <= word_count <= 15 and not has_comma:
            # Check for filler words
            sentence_lower = sentence.lower()
            has_filler = any(filler in sentence_lower.split() for filler in FILLER_WORDS)
            
            if not has_filler:
                candidates.append({
                    'text': sentence,
                    'word_count': word_count
                })
    
    return {
        'pass': len(candidates) >= 1,
        'flag_for_review': len(candidates) == 0,
        'candidate_count': len(candidates),
        'candidates': candidates
    }
```

---

## Summary of Changes (V4.5 → V4.5.1)

**What changed:**
- Gates 78-81 now use mechanical pre-filters with approved vocabulary lists
- Clear pass/fail criteria before human review
- Human review reserved for edge cases only
- Developer-friendly implementation (vocabulary lists, sample code)

**What stayed the same:**
- All V4.5 requirements (≥2 action stories, sensory anchors, body-present closings, narrative bridges, sticky sentences)
- All metadata fields
- All distribution caps
- All writing standards

**Why this matters:**
- Gates are now implementable in 1-2 days (not ambiguous)
- Reduced subjective interpretation
- Clear automation boundary (what machines check vs what humans check)
- Faster CI/CD pipeline (most atoms pass pre-filter, only exceptions need human review)

---

## Migration from V4.5 to V4.5.1

**No atom changes required.** This is a gate implementation update only.

**Dev work:**
1. Implement vocabulary lists (3 lists: sensory, body-present, transitions)
2. Implement pre-filter checks (Gates 78-81)
3. Wire flagged atoms to human review queue
4. Update CI pipeline to run new checks

**Timeline:** 1 day (gate logic only, no compiler changes)

**Writer impact:** None. Standards are identical to V4.5.

---

## Next Steps

1. **Dev:** Implement Gates 78-81 with vocabulary lists and pre-filter logic
2. **QA:** Test pre-filters against existing V4.4 atoms to calibrate thresholds
3. **Writer:** No changes needed (V4.5 training already covers requirements)
4. **Release:** V4.5.1 gates go live; V4.5 writing standards already in effect

**V4.5.1 is production-ready.**

---

**End of V4.5.1 Specification Update**
