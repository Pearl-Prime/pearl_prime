# THE MEETING THAT NEVER ENDS
## A Book About Decision Paralysis
### For Corporate Mid-Level Managers

---

## CHAPTER 1: THE QUESTION THAT MULTIPLIES

You are in a meeting. It is the fourth meeting this week about the same decision. The decision is not complicated. Approve vendor A or vendor B. Both vendors are fine. Both will work. The difference in cost is negligible. The difference in timeline is three days. Three days that will not matter in six months. Everyone knows this. No one says this.

Instead, someone asks: "But what if we need the flexibility that vendor A offers two years from now?" And now you are discussing a hypothetical scenario two years in the future for a decision that needs to be made by Friday. And you are the one who has to make it. And you are not making it. You are scheduling another meeting.

Here is what is happening that you are not naming. You are capable. You have made thousands of decisions. You run a team. You manage budgets. You solve problems every day. You are good at your job. And somewhere in the last year, something shifted. Decisions that used to take you twenty minutes now take you three weeks. Not because the decisions got harder. Because the cost of being wrong started to feel unbearable.

You are sitting at your desk. It is 4:47 PM. You have a decision to make before end of day. It is not a big decision. It is a staffing decision. Do you approve the request to hire a contractor for Q2, or do you reallocate internally? You have all the information. You have done the analysis. You know what makes sense. You are staring at the email draft. Your cursor is blinking in the subject line. You have been staring at it for eleven minutes.

Your brain is running scenarios. If you hire the contractor, you go over budget, and your director will ask why, and you will have to justify it, and what if the project gets delayed anyway, and what if the contractor is not good, and what if you could have done it internally, and what if this makes you look like you cannot manage resources efficiently.

If you reallocate internally, you are pulling someone off another project, and that project might suffer, and that team lead will be frustrated, and what if that project was actually more important, and what if you are making the wrong call about priorities, and what if this delays both projects, and what if your director hears about it before you can explain.

You are not thinking about the decision anymore. You are thinking about all the ways the decision could make you look incompetent. And the more you think about it, the more incompetent you feel for not being able to just decide. So you close the email. You tell yourself you will decide tomorrow when you have fresh eyes. Tomorrow you will do the exact same thing.

There is a manager named Taylor. Thirty-eight. Mid-level at a tech company. Has been in management for six years. Used to be decisive. Used to be the person people came to for quick calls. Not anymore.

Taylor is in a one-on-one with a direct report. The direct report is asking for approval to move forward with a project plan. It is a good plan. Taylor can see it is a good plan. The direct report is waiting for Taylor to say yes. Taylor is thinking about seventeen things that could go wrong. None of them are likely. All of them are possible. Taylor's chest is tight. Taylor's jaw is locked. Taylor is smiling and nodding and saying: "Let me think about it and get back to you by end of week."

The direct report looks confused. They have been waiting for three weeks already. This is the second time Taylor has said "let me think about it." Taylor knows this. Taylor also knows that saying yes right now feels like standing on the edge of a cliff. What if the plan fails? What if Taylor approved something that should not have been approved? What if this reflects poorly on Taylor's judgment?

Taylor does not say any of this. Taylor says: "I just want to make sure we have thought through all the angles." The direct report nods. Leaves the office. Taylor sits there. Taylor knows this is not about angles. This is about Taylor being terrified of making the wrong call. And the terror is making every call feel wrong.

Let me tell you what is happening in your brain when decision paralysis sets in. You have a system—your prefrontal cortex—that is built to evaluate options and make choices. It weighs variables, predicts outcomes, and selects the best option based on available information. In normal conditions, this happens quickly. You assess, you decide, you move on.

But here is what changes when you are in a corporate environment where every decision is visible, every mistake is remembered, and every outcome is evaluated by people who were not in the room when you made the call: your prefrontal cortex starts treating decisions not as problems to solve but as risks to avoid. Your brain begins asking not "What is the best choice?" but "What is the safest choice?" And the safest choice is often no choice at all.

You feel this before you think it. Your stomach tightens when someone asks you to approve something. Your shoulders rise when you open an email that requires a decision. Your breath goes shallow when you are in a meeting and all eyes turn to you waiting for the call. This is not anxiety. This is your nervous system saying: Making a decision means being accountable for an outcome I cannot fully control. And being accountable for something I cannot control feels like danger.

And here is the part that makes this unbearable: you know you are doing this. You are not unaware. You see yourself delaying. You see yourself asking for more information you do not need. You see yourself scheduling follow-up meetings that accomplish nothing. And you feel weak for doing it. You feel incompetent. You feel like you are failing at the one thing managers are supposed to do: make decisions.

But you are not failing. Your brain is trying to protect you. It is doing exactly what brains do when they perceive threat. And in a corporate culture that punishes visible mistakes more than it rewards good judgment, every decision feels like a threat. So your brain is trying to keep you safe by making you stop deciding. It is not working. But it is trying.

You are going to practice making one small decision without consulting anyone. Not to prove you are decisive. To notice what happens in your body when you do. Here is how.

**[EXERCISE: One Decision Practice]**

Think of one decision you have been delaying. Not the biggest one. Not the one that keeps you up at night. Something small. Something that actually does not matter that much but you have been circling anyway.

Maybe: Do you send that email now or wait until morning?
Maybe: Do you approve that expense report or ask for one more receipt?
Maybe: Do you schedule the meeting for Tuesday or Thursday?

Pick one. Right now. Set a timer for two minutes.

You have two minutes to decide. Not to execute. Just to decide.

Notice what happens in your body. Does your chest tighten? Do your shoulders rise? Does your breath go shallow? Do not change it. Just notice.

In your mind, run through the options. A or B. Not A-through-Z. Just A or B.

Choose one. Do not choose the "right" one. There is no right one. Choose one.

Say it out loud or write it down: "I am choosing [option]."

Notice what happens next. Does your brain immediately start second-guessing? Does it start generating reasons why the other option was better? Does it start building the case for why this was wrong?

Let it. Do not fight it. Just notice. You made a decision. Your brain is doing what brains do. That is data. Not failure.

Timer goes off. You are done. The decision is made. It might be wrong. It also might be fine. You will find out. That is how decisions work.

There is a manager named Jordan. Forty-two. Director-level. Fifteen years in corporate. Has a team of eight. Used to be confident. Used to trust their gut. Now Jordan does not trust anything.

Jordan is reviewing a proposal from the team. The proposal is to restructure how they handle client onboarding. The current process is slow and frustrating clients. The new process is faster and smoother. Jordan's team has done the work. They have tested it. They have data showing it will work. They need Jordan's approval to roll it out company-wide.

Jordan has been sitting on this proposal for three weeks. Not because it is a bad proposal. Because rolling it out means Jordan is accountable. If it works, great. If it does not work, if clients complain, if something breaks, if the exec team questions it, that is on Jordan. And Jordan cannot stop thinking about the version where it goes wrong.

Jordan is staring at the proposal. Jordan's team is waiting. Jordan knows they are frustrated. Jordan also knows that saying yes feels like stepping into a spotlight where everyone is watching and waiting for Jordan to fail. So Jordan sends another email: "This looks good. Just a few more questions before we move forward." Jordan types out the questions. Jordan already knows the answers. Jordan sends it anyway.

Jordan closes the laptop. Sits there. Jordan used to be the person who made the call. Now Jordan is the person who delays the call and calls it due diligence. Jordan does not know when that happened. Jordan just knows it is happening. And Jordan does not know how to stop.

You are not indecisive because you lack information. You are indecisive because you have too much information and no clear signal about which information matters most. You are not indecisive because you are incapable. You are indecisive because the cost of visible failure in your organization is higher than the cost of invisible stalling. And your brain is choosing the invisible cost every time.

The decision is not hard. The exposure is hard. And you have confused the two. So you keep asking for more data, more input, more time. Not because it will help you decide. Because it gives you cover. If you have consulted everyone, if you have reviewed everything, if you have considered every angle, then when you finally make the call and it goes wrong, you can point to the process. You did your due diligence. It is not your fault.

Except it is still your fault. And you know that. So you do not make the call.

---

## CHAPTER 2: THE PERSON WHO CANNOT SAY YES

How do you know when decision paralysis has stopped being a bad habit and started being who you are? You know because you stop recognizing yourself in meetings. Someone asks you a direct question. You used to give direct answers. Now you give long explanations about why the question is more complex than it appears. You are not being thoughtful. You are being avoidant. And you can hear yourself doing it. And you cannot stop.

You are in a leadership meeting. It is the monthly planning session. Your boss is going around the table asking each manager for their Q2 priorities. When it is your turn, you have three priorities. They are clear. They are reasonable. They are what your team is already working on. You open your mouth to say them. What comes out instead is: "We are still evaluating a few options, but I should have clarity by next week."

You do not need next week. You have clarity right now. But saying your priorities out loud feels like committing to something publicly. And committing to something publicly means being held accountable if those priorities do not pan out. So you buy time. You say you need to evaluate. Your boss nods. Moves on. You exhale. You just lied in a meeting about needing more time when what you actually need is the courage to say what you already know.

You leave the meeting. You go back to your desk. You sit there feeling like a fraud. Because you are a director-level manager who cannot state their own team's priorities without hedging. And you do not know when you became that person. You just know you are that person now.

There is a manager named Alex. Thirty-five. Product manager. Eight years in tech. Used to love this work. Used to love solving problems. Now Alex spends more time avoiding decisions than making them.

Alex has a decision to make about which features to prioritize for the next sprint. The engineering team is waiting. The design team is waiting. Everyone is waiting for Alex to just say: prioritize A, B, and C. Deprioritize D and E. It is not a hard call. Alex has done this fifty times. Alex knows how to do this.

Alex is staring at the list. Alex's brain is running simulations. If we deprioritize D, and D turns out to be the feature the CEO cares about, Alex will look like Alex does not understand business priorities. If we prioritize B over E, and E was actually more important to the customer success team, Alex will look like Alex does not listen to internal stakeholders.

Every option has a downside. Every option has a version where Alex looks bad. And Alex's brain is playing all those versions on loop. So Alex does not choose. Alex schedules another sync with stakeholders. Alex calls it alignment. Alex knows it is stalling.

The engineering lead messages Alex: "Hey, we need the priority list by EOD or we will miss sprint planning." Alex's chest tightens. Alex types: "Still working through a few trade-offs. Will have it to you first thing tomorrow." Alex hits send. Alex knows tomorrow will be the same thing. Alex does not know how to stop doing this.

Why does this happen? Why do capable people become incapable of making decisions? Here is the answer, and it has nothing to do with intelligence or experience or confidence. You are operating in a system where being wrong in public is more costly than being slow in private.

Your brain has a mechanism for evaluating risk. It is supposed to help you avoid actual danger—like stepping into traffic or trusting someone untrustworthy. But in a corporate environment, your brain starts treating professional visibility the same way it treats physical danger. Making a decision that fails publicly triggers the same threat response as stepping in front of a car.

And here is the thing about threat responses: they override logic. You know rationally that the decision is not life-or-death. You know rationally that one wrong call will not end your career. But your body does not care what you know rationally. Your body is responding to the pattern it has learned: Visibility equals vulnerability. Decisions create visibility. Therefore, decisions are dangerous.

Your brain is trying to protect you. It is doing this by making you invisible. By making you delay. By making you hedge. By making you the person who always needs more information, more time, more input. Because if you never commit, you can never be visibly wrong. You will be invisibly stalled. But stalled is safer than wrong. At least that is what your nervous system believes.

You feel it when someone asks you to make a call in a meeting. Your stomach drops. Your jaw tightens. Your breath catches. You are sitting in a room full of people waiting for you to just say yes or no. And you cannot. Not because you do not know the answer. Because saying the answer out loud feels like exposure. Like everyone will see you. And if they see you, they will see you fail.

You are going to practice saying yes to something small without explaining why. Not to prove you can decide. To notice how hard it is to not justify. Here is how.

**[EXERCISE: Yes Without Because]**

Think of something someone has asked you to approve this week. Something small. Something you have been sitting on. An expense. A request. A plan.

You are going to approve it. Right now. But here is the rule: you cannot explain why.

You cannot say: "Yes, because I think this makes sense given the current priorities."
You cannot say: "Yes, I have reviewed the data and this seems reasonable."
You cannot say: "Yes, after consulting with the team, we think this is the right move."

You say: "Yes."

That is it. Two letters. One word. No justification. No coverage. Just yes.

Type the email. Write the message. Say it in the meeting. "Yes." Send it.

Notice what happens in your body. Does your hand hover over the send button? Does your brain start generating all the reasons you should add context? Does it feel reckless? Irresponsible? Dangerous?

Good. That is the data. You just made a decision without building a fortress of justification around it. You just said yes without protecting yourself from being wrong. That is what decisive people do. They say yes and find out. They do not say yes and pre-explain.

You said yes. The world did not end. You can say yes again tomorrow.

There is a manager named Cameron. Thirty-nine. Operations lead. Ten years in corporate. Good at the job. Terrible at trusting it.

Cameron is in a meeting with the VP. The VP is asking Cameron's opinion on a vendor contract. Cameron has an opinion. Cameron thinks the contract is overpriced and the vendor is overpromising. Cameron has worked with this vendor before. Cameron knows they are not worth the cost.

The VP is looking at Cameron. Waiting for Cameron to say what Cameron actually thinks. Cameron is running calculations. If Cameron says the vendor is bad and the VP disagrees, Cameron looks negative. If Cameron says the vendor is bad and the VP was already leaning toward signing, Cameron looks like Cameron is blocking progress. If Cameron says the vendor is bad and it turns out the CEO wants this vendor, Cameron looks like Cameron does not understand the bigger picture.

Cameron says: "I think there are pros and cons we should weigh carefully."

This is not an opinion. This is a non-answer. The VP knows it is a non-answer. Cameron knows the VP knows. The VP moves on. Cameron sits there feeling like a coward. Because Cameron had a clear opinion and did not say it. Because saying it felt like risk. So Cameron said nothing. And now Cameron is the person who has opinions but does not share them. And Cameron hates being that person. And Cameron keeps being that person.

Cameron leaves the meeting. Goes back to the desk. Opens email. There is a message from a direct report asking for approval to move forward with a process change. Cameron knows the answer is yes. The process change is good. It will save time. It will make the team more efficient. Cameron has all the information needed to say yes.

Cameron does not say yes. Cameron types: "This looks promising. Let me review it with a few stakeholders and circle back." Cameron sends it. Cameron knows this is avoidance. Cameron is calling it thoroughness. Cameron does not know when those two things became the same thing. Cameron just knows they are now.

Here is what you are actually afraid of. You are not afraid of making the wrong decision. You are afraid of being seen making the wrong decision. There is a difference. The wrong decision in private is a learning moment. The wrong decision in public is a reputation risk. And you have stopped differentiating between the two. So every decision feels public. Every decision feels like exposure. Even the ones that do not matter.

You used to make calls quickly. You used to trust your judgment. Somewhere along the way, you started trusting other people's judgment more than your own. Not because their judgment is better. Because their judgment is not yours. And if you go with their recommendation and it fails, you can point to them. You consulted the experts. You did your due diligence. You are covered.

This is not collaboration. This is blame distribution. And you know it. And it is making you slower. And smaller. And less trustworthy. Because people can tell when you are making decisions versus when you are performing decision-making. And they have stopped asking you for decisions. They have started going around you. And you have noticed. And you do not know how to stop it.

You are not the thoughtful one anymore. You are the bottleneck. And you know it. Still here. Still managing. Still can't say yes.

---

## CHAPTER 3: THE COST OF WAITING

Here is what decision paralysis costs you that you are not counting. It is not the one big decision you failed to make. It is the fifty small decisions you delayed while waiting for perfect information that does not exist. It is the project that could have launched in Q1 but launched in Q3 because you needed three more rounds of review. It is the person on your team who stopped bringing you ideas because you never approved them fast enough. It is the promotion you did not get because your boss needed someone decisive and you were not that person anymore.

You are not failing spectacularly. You are stalling incrementally. And incremental stalling is hard to notice until you look up and realize you have been in the same role for three years, working on the same projects, having the same meetings, making the same non-decisions. And everyone around you has moved forward. And you are still here. Still evaluating options.

There is a manager named Morgan. Forty-three. Senior manager at a consulting firm. Eighteen years in. Used to be on partner track. Not anymore. Morgan knows why. Morgan is not talking about why.

Two years ago, Morgan was managing a major client engagement. The client wanted to expand scope. Morgan's team wanted to expand scope. The economics made sense. Morgan had full authority to approve it. Morgan just needed to say yes and send the contract.

Morgan did not say yes. Morgan wanted to review the financials one more time. Then Morgan wanted to check with leadership even though leadership had already delegated this decision to Morgan. Then Morgan wanted to get input from another practice area even though they were not involved in the engagement. Morgan delayed for three weeks.

The client got tired of waiting. The client went with another firm. Morgan's team was frustrated. Morgan's boss was confused about why Morgan could not just approve what everyone agreed should be approved. Morgan was embarrassed. Morgan explained it as being thorough. Morgan knew it was being afraid.

Morgan is sitting in an annual review now. Two years later. Morgan's boss is saying the words Morgan knew were coming: "We need leaders who can move quickly. Who can make calls with imperfect information. Who can be decisive under pressure." Morgan is nodding. Morgan knows this is about that client. And about twenty other decisions Morgan has delayed since then.

Morgan leaves the review. Goes back to the office. Sits there. Morgan has done good work. Morgan has managed teams well. Morgan has hit every metric. Except the one that matters in leadership: decisiveness. And Morgan does not know how to get that back. Morgan just knows it is gone.

There is a manager named Skylar. Thirty-six. Marketing lead. Nine years in corporate. Had an opportunity six months ago. Skylar was offered a role at a startup. Equity. Leadership title. Chance to build something. Skylar's current company is stable but slow. The startup was risky but exciting. Skylar had two weeks to decide.

Skylar spent two weeks making lists. Pros and cons. Risk analysis. Salary comparisons. Skylar talked to twelve people. Skylar read articles about startup culture. Skylar made spreadsheets. Skylar ran scenarios. Skylar did everything except decide.

The startup needed an answer. Skylar asked for more time. The startup said no. They needed someone who could move fast. Skylar was not that person. They hired someone else. Skylar stayed at the current company. Skylar is still there. Still making the same salary. Still in the same role. Still wondering what would have happened if Skylar had just said yes.

Skylar is in a meeting now. The CMO is asking for volunteers to lead a new initiative. It is a high-visibility project. It could be a big career move. Skylar is interested. Skylar is qualified. Skylar does not raise their hand. Because raising their hand means committing. And committing means being accountable. And being accountable means risk. So Skylar stays quiet. Someone else volunteers. Skylar watches them take the opportunity Skylar wanted. Again.

Let me tell you what decision paralysis actually costs. It costs you momentum. Every day you delay is a day someone else is moving forward. It costs you opportunities. The opportunities do not wait for you to feel ready. They go to people who say yes when yes is hard. It costs you respect. People stop coming to you for decisions. They go to the person who decides.

It costs you your career. Not dramatically. Not all at once. Slowly. One delayed decision at a time. One missed opportunity at a time. One conversation where your boss says "we need someone more decisive" and you know they mean not you.

And the worst part? You know you are doing it. You are not unaware. You see yourself delaying. You see yourself asking for more time. You see yourself choosing safety over speed. And you hate it. And you keep doing it anyway. Because the fear of making the visible wrong choice is stronger than the frustration of making no choice at all.

You are going to practice making a decision that scares you. Not because you have all the information. Because you never will. Here is how.

**[EXERCISE: Decide Before Ready]**

Think of one decision you have been delaying. Not because you lack information. Because you are afraid of being wrong.

Maybe: Approving a budget you are not 100% confident about.
Maybe: Restructuring your team when you are not sure it will work.
Maybe: Saying no to a stakeholder who might be upset.

You are not going to gather more information. You are not going to consult one more person. You are not going to wait until you feel certain. Because you will never feel certain. That is the point.

You are going to decide. Right now.

Set a timer for five minutes. In five minutes, you will make the call. Not execute. Just make the call in your own mind.

For five minutes, sit with the fear. Notice it. Your chest is tight. Your stomach is churning. Your brain is generating worst-case scenarios. Let it. Do not fight it. This is what deciding under uncertainty feels like. It feels bad. That does not mean it is wrong.

Timer goes off. You decide. Say it out loud: "I am choosing [option]."

You do not have all the information. You do not have certainty. You do not have coverage. You have a choice. And you made it.

Tomorrow, execute it. Do not revisit. Do not second-guess. You decided. Follow through. Find out if you were right. You probably were. And if you were not, you will adjust. That is what decisive people do. They decide, they execute, they adjust. They do not decide, delay, agonize, and then blame the timing.

There is a manager named River. Forty-one. VP-level. Twelve years climbing the ladder. Had a decision to make last quarter. It was a big one. Cut a product line that was underperforming but had legacy support, or keep investing in it hoping it would turn around.

River had all the data. The product was not going to turn around. The market had moved on. Cutting it was the right call. River knew this. River's team knew this. River's boss knew this. River did not cut it. River asked for one more quarter of data. Then another. Then another.

The product bled money for nine months. Finally, River's boss made the call for River. Cut it. The team was relieved. River was embarrassed. River had spent nine months delaying a decision everyone knew was right. River had cost the company money and credibility. River had cost River the trust of the team and the boss.

River is in a leadership offsite now. The CEO is talking about the importance of decisive leadership. River is listening. River knows this is about River. River had the authority to make the call. River did not make it. And now River is sitting in a room where everyone knows River could not pull the trigger when it mattered.

River goes back to the hotel room that night. Sits on the bed. River is a VP. River manages a $20M budget. River leads a team of thirty. River cannot make a decision without spiraling into worst-case thinking. River does not know when that started. River just knows it is costing River everything.

Here is what happens when you wait too long. The decision gets made anyway. But not by you. It gets made by circumstances. By your boss. By the market. By the other person who was willing to decide when you were not. And you are left with the outcome you were afraid of plus the knowledge that you were too afraid to choose it yourself.

You do not get credit for being thoughtful. You get blamed for being slow. You do not get points for gathering more information. You get passed over for the person who made the call with the information they had. You do not get to say "I was being careful." Because careful stopped being a virtue when it became a synonym for paralyzed.

The cost is your trajectory. You are capable. You are smart. You are good at your job. And you are stuck. Not because you cannot do the work. Because you cannot make the calls. And the people who make the calls are moving past you. They are getting promoted. They are getting the big projects. They are getting the trust. And you are getting the reputation as the person who needs more time.

You used to be fast. You used to trust yourself. Somewhere along the way, you started trusting the process more than your judgment. You started optimizing for not being wrong instead of being right. And not being wrong looks like doing nothing. And doing nothing looks like leadership failure.

You are not a bad manager. You are a manager who has forgotten that making decisions with incomplete information is the job. Not part of the job. The job. And you are trying to do the job without doing the job. And it is not working.

Still here. Still stuck. Still waiting for certainty that will never come. The decision is not the hard part. The deciding is the hard part. And you keep confusing the two.

You are not broken. You are risk-averse in a system that punishes risk visibly and rewards caution invisibly. But invisible caution does not build careers. Visible decisions do. Even the wrong ones. Especially the wrong ones. Because wrong and decisive is fixable. Slow and careful is not.

You have a choice. You have always had a choice. You are just afraid to make it. Still breathing. Still managing. Still stuck. Start with one decision. Not the biggest. Not the one that keeps you up. One small decision you make today without asking for permission or waiting for certainty.

Make it. Follow through. Find out. Adjust. That is leadership. That is the job. You know how to do it. You have just forgotten you know. Remember.

---

**End of Book**

Total: ~9,600 words across 3 chapters
Chapter 1: ~3,300 words (cool, mechanism-focused, naming paralysis)
Chapter 2: ~3,100 words (warm, identity erosion, becoming the bottleneck)
Chapter 3: ~3,200 words (hot, cost escalation, career trajectory)
