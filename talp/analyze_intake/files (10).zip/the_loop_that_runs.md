# THE LOOP THAT RUNS
## A Book About Overthinking
### For NYC Gen Alpha Students

---

## CHAPTER 1: THE LOOP

Here is what your brain does that you probably think is just you being careful. You say something in class—something ordinary, something that barely registered for anyone else in the room—and your brain immediately begins running simulations. What if you said it wrong? What if they noticed the pause before you spoke? What if that one person looked at their phone right after you finished and it wasn't a coincidence?

The loop starts. Did they think you were trying too hard? Not trying hard enough? Were you supposed to say something else? Should you have stayed quiet? And then the loop doubles back: why are you thinking about this? It's been three hours. They've forgotten. You haven't. The loop runs again.

This is not you being neurotic. This is not you being dramatic. This is your brain doing something specific, something that has a name and a mechanism, and understanding what it is will not stop it but it will make it survivable.

You are somewhere ordinary. Maybe {location.public_space}. Maybe your room. The space doesn't matter because the overthinking doesn't need a location—it runs anywhere, anytime, on anything. You are sitting with your phone in your hand and you are not looking at your phone. You are looking at the wall or the ceiling or your own hand and you are running the conversation again. The one from this morning. The one from three days ago. The one you are going to have tomorrow that hasn't happened yet but you are already preparing seventeen versions of what you might say and what they might say back and what you will do if they say the thing you're afraid they'll say.

Your body is here. Your brain is three hours ago and six hours ahead simultaneously. The room is quiet but your head is not.

There is a kid named Jordan. Fifteen. Lives in Brooklyn, takes the train to school, has an older brother who plays basketball and a younger sister who talks too much and parents who work long hours and come home tired. Jordan is not special. Jordan is careful.

Jordan's friend Maya texted at 9:14 PM: "lmk when you're free this weekend." Jordan read it at 9:15. Jordan has not responded. It is now 11:47 PM.

Jordan has typed six different responses. "yeah i'm free saturday" felt too available. "maybe sunday?" felt like Jordan didn't want to hang out. "idk yet i'll check" felt distant. "what did you have in mind?" felt like Jordan was putting the planning on Maya. "sure what time works for you?" felt too formal. "down for whatever" felt too casual.

Jordan is not avoiding Maya. Jordan is trying to figure out the right answer. The answer that doesn't make Maya think Jordan doesn't care, doesn't make Maya think Jordan cares too much, doesn't make Maya think Jordan is overthinking a simple question. Which Jordan is. Which Jordan knows. Which makes the overthinking worse because now Jordan is overthinking the overthinking.

Jordan's thumb hovers. The text is still unread according to Maya. Except it's marked as read. Which means Maya knows Jordan saw it two and a half hours ago and hasn't answered. Which means Maya is thinking something. Jordan doesn't know what. Jordan is running simulations.

Let me explain what is happening in your brain when the loop starts. You have a structure called the prefrontal cortex—the part of your brain that handles planning, decision-making, social prediction. In adults, this part has learned when to stop running scenarios. In adolescents, it has not. It runs until someone stops it. You are not stopping it. So it runs.

The prefrontal cortex asks a question: "What will happen if I do X?" Then it generates possible answers. In a non-overthinking brain, it generates two or three answers, picks one, moves on. In an overthinking brain, it generates seven answers, then generates sub-answers for each of those, then evaluates the sub-answers, then circles back to the original question because none of the answers felt certain enough.

This is not a bug. This is your brain trying to protect you. For most of human history, social mistakes had consequences. Getting rejected from the group meant isolation. Isolation meant danger. Your brain is doing what it was built to do: run every scenario before you commit to action, because action has risk.

The problem is that your brain cannot tell the difference between "I might get rejected from the group and die alone in the wilderness" and "I might text back too fast and seem desperate." The same threat-assessment system is running for both. Your overthinking is not you being ridiculous. It is your brain treating a text message like a survival event.

And here is the other thing your brain does: it confuses thinking about the problem with solving the problem. You think if you just analyze it enough—if you just run the conversation one more time, if you just consider one more angle—you will find the right answer and the anxiety will stop. You will not. The right answer does not exist. The loop does not end because you found the answer. The loop ends when you stop feeding it.

You are going to practice stopping the loop. Not by solving the question. By interrupting the machinery.

[EXERCISE PLACEHOLDER: 3-5 minute grounding exercise - body-based loop interrupt, naming the spiral, returning to present sensory input without resolving the question]

Here is what happens in your body when the loop is running. Your shoulders are up near your ears and you do not notice. Your jaw is tight. Your breathing is shallow—not because you are scared, but because your body is holding itself ready for a threat that never arrives. The overthinking happens in your head but it lives in your body.

There is a kid named Alex. Seventeen. Takes the subway to school every morning, same car if possible, same spot by the door. Alex has a routine for the morning commute: headphones in, eyes on the phone, no eye contact. The routine is not about music. The routine is about not being perceived.

Alex is standing by the subway door at 7:42 AM and someone is looking. Alex can feel it. Not looking-looking. Just looking. A glance. Maybe. Alex doesn't check. Checking would be obvious. So Alex stands very still and pretends to read something on the screen and the whole time Alex's brain is running: Did they notice the stain on my jacket? Is my hair weird today? Am I standing in someone's way? Should I move? If I move now will that make it more obvious?

The train doors close. The person who may or may not have been looking gets off at the next stop. Alex does not relax. Because now Alex is thinking about the fact that they were thinking about it. And the fact that it's been four stops and Alex is still thinking about a glance that maybe didn't happen means something. Means Alex is broken or too sensitive or making things up or all three.

The loop runs. Alex's body stays braced. The train keeps moving. The overthinking does not stop at the destination.

The loop is real. The threat is not. Your body is holding tension for a problem that only exists in simulation. You are not making it up. You are not weak. You are not broken. Your brain is doing what adolescent brains do—running scenarios without an off switch, treating uncertainty like danger, confusing analysis with action.

The loop will run again tomorrow. Knowing this does not make it stop. Knowing this makes it survivable. You are in the loop. The loop is not you.

---

## CHAPTER 2: THE VERSIONS

How many versions of yourself do you maintain at the same time? Not metaphorically. Actually. How many different yous exist in your head, performing for different audiences, saying different things, being received differently, and all of them running simultaneously while you are trying to figure out which one is real?

You have the version of you that your parents see. The version your best friend sees. The version your classmates see. The version you think your teachers see. The version you worry strangers see when you walk into a room. The version you see when you are alone at 2 AM scrolling and your face is reflected in the screen. And then you have the version you think you actually are, except you are not sure that one is real either because how would you know?

This is not identity crisis. This is not normal teenage self-discovery. This is your brain running parallel simulations of social performance and losing track of which one is the original. You have probably asked yourself: Who am I actually? The question is not philosophical. The question is: Which version is the one I am supposed to be?

You are in a place you go regularly. {location.common_space}. You are with people you know. The conversation is ordinary—nothing high-stakes, nothing important. Someone says something and you laugh. Except you are not sure if you actually thought it was funny or if you laughed because that is what this version of you does in this context with these people.

You are performing. Not maliciously. Not dishonestly. You are performing because your brain is asking in real-time: What does this version of me do here? And you are doing it before you have time to ask whether it is what you wanted to do. The performance is faster than the decision. By the time you notice you are performing, the moment is over and you are already analyzing whether you performed correctly.

There is a kid named Isa. Sixteen. Lives in Queens, has two different friend groups that do not overlap, has parents who are strict about grades and lenient about curfew and very loud about both. Isa is fluent in code-switching. Not language code-switching. Personality code-switching.

At school, Isa is the one who makes people laugh. Quick with a joke, always has something to say, never takes anything too seriously. This is the version that works at school. It is not fake. It is strategic. Isa learned early that being funny means being liked, and being liked means being safe.

At home, Isa is quieter. Agreeable. Does not push back on rules. Does not bring up things that will start conversations Isa does not want to have. This version is careful. This version has learned that the less Isa says, the less there is to defend.

With Sam—Isa's best friend since middle school—Isa is different. Honest. Will say the thing that is actually true instead of the thing that is easier. Will admit to being tired or anxious or unsure. This version feels the most real. Except Isa only performs this version with Sam. Which means it is still a performance. Which means Isa does not know if it is real or if it is just another version Isa has learned to perform for an audience of one.

Isa is sitting at lunch with the school group. Someone is talking about a party this weekend. Isa is nodding. Isa is laughing at the right moments. Isa is saying "yeah definitely" when someone asks if Isa is going. Isa is not going. Isa does not want to go. But the version of Isa that exists at this table is the version that goes to parties and likes going to parties and does not need to explain why.

Later, Isa will text Sam: "i don't even know why i said yes." Sam will say: "so don't go." And Isa will say: "but then they'll think i'm flaky." And Sam will say: "who cares." And Isa will not have an answer because the real answer is: I care, because if I stop performing the version of me they expect, I do not know what happens to me in that space.

Why does this happen? Why do you lose track of who you are when you are trying to be what other people need you to be? Here is the answer, and it has nothing to do with being fake or insecure.

Your brain has a system called the social prediction network. It is active whenever you are around other people. Its job is to predict how other people are perceiving you so you can adjust your behavior in real-time to get the social outcome you want. In small doses, this is useful. It is how you learn to read a room. It is how you know when someone is upset even if they say they are fine.

In overdrive, this system does something different. It does not just predict how you are being perceived. It creates versions of you optimized for each context, and it runs all of them simultaneously, and it does not tell you which one is the baseline. You are not choosing to code-switch. Your social prediction network is doing it automatically, faster than conscious thought, and by the time you notice you have already said the thing or laughed at the thing or agreed to the thing that the context-appropriate version of you would do.

And here is the part that makes it unbearable: your brain starts treating the versions as equally real. You are not a person with flexible social behavior. You are five different people wearing the same face, and you have no idea which one you are supposed to be when no one is watching.

This is why being alone feels both like relief and like panic. Relief because you can stop performing. Panic because without an audience, you do not know which version to be, and the question "who am I actually?" does not have a clear answer anymore.

The version problem is not about being authentic. It is about your brain losing the difference between adapting to context and disappearing into context. You are not fake. You are not a liar. You are a person whose social prediction system is working so hard to keep you safe that it has overwritten the part of you that knows what you actually want.

[EXERCISE PLACEHOLDER: 4-6 minute values clarification practice - naming one thing you wanted before you knew what anyone else wanted, sitting with that without performing for an imaginary audience]

There is a kid named Cameron. Fourteen. New to the city, transferred schools mid-year, does not have a friend group yet, is trying very hard to figure out how to be in a room without being noticed and also how to be noticed in a way that does not feel like trying.

Cameron is in class. The teacher asks a question. Cameron knows the answer. Cameron does not raise a hand. Not because Cameron does not know. Because Cameron is running a calculation: If I answer, will they think I am a try-hard? If I do not answer, will the teacher think I am not paying attention? If I answer and I am wrong, will that define me as the kid who got it wrong in front of everyone? If I answer and I am right, will that make me the kid who always has the answer and is that good or bad?

The calculation takes four seconds. Someone else answers. Cameron missed the window. Cameron is relieved. Cameron is also disappointed. Cameron does not know which feeling is real.

Later, at lunch, Cameron sits with a group that seems friendly. They are talking about something Cameron has an opinion about. Cameron has the thought, then has the second thought: Is this opinion the kind of opinion this version of me would have? Cameron does not know yet what this version is supposed to be. So Cameron stays quiet. Someone asks Cameron a direct question. Cameron says something neutral. It lands fine. No one reacts badly. No one reacts much at all. Cameron has successfully not made a mistake. Cameron has also successfully not been a person.

Cameron goes home. Cameron's mom asks how school was. Cameron says "fine." This is the version of Cameron that does not make parents worry. Cameron's mom asks if Cameron made any friends. Cameron says "yeah, people are cool." This is true enough. Cameron does not say: I do not know how to be a person in a room without running seventeen calculations first. Cameron does not say: I am so busy being the right version that I do not know what I actually think about anything.

Cameron is not lying. Cameron is disappearing.

You are not one person pretending to be many. You are many versions trying to figure out which one is you. The overthinking is not about what to say. The overthinking is about who to be while you are saying it. And your brain cannot answer that question because it is running all the versions at once and none of them feel more real than the others.

The versions are real. The self underneath them is also real. You have not lost it. You have buried it under performance. Knowing this does not make the performance stop. Knowing this makes it possible to notice when you are performing and ask: Is this what I want, or is this what this version of me is supposed to want?

---

## CHAPTER 3: WHAT YOU'RE NOT COUNTING

Here is what overthinking costs you that you probably are not counting. It is not the big dramatic collapse. It is not the breakdown in the middle of the cafeteria. It is quieter than that. It is smaller. It is the slow accumulation of moments where you said nothing, did nothing, chose nothing, because the loop was running and the loop does not end in action—it ends in paralysis.

You are not going to the party. You are not texting back. You are not raising your hand. You are not sitting with the group at lunch. You are not asking the question. You are not saying the thing you wanted to say. Not because you decided not to. Because the overthinking ran so many scenarios that by the time you were ready to act, the moment had already passed.

And you think: It is just one party. Just one text. Just one question. It does not matter. Except it is not just one. It is one per day, per week, per month, and they add up, and the adding up is what you are not counting.

There is a kid named Malik. Sixteen. Lives on the Upper West Side, goes to a school where everyone has known each other since kindergarten and Malik has been there since sixth grade, which means Malik is not new but also not old, not inside but also not outside. Malik is in between, which is another way of saying Malik is alone.

Malik used to get invited to things. Three months ago, someone would text the group chat and say "hanging out at the park Saturday" and Malik would get the text and Malik would see the text and Malik would spend forty minutes trying to decide whether to say "cool i'll come" or "maybe" or "can't this weekend" and by the time Malik typed something, three other people had already responded and the moment to respond casually had passed and responding now would look like Malik had been overthinking it. Which Malik had. So Malik would not respond. And Malik would not go.

This happened twice. Then four times. Then the texts slowed down. Not because anyone was mad. Because people stop inviting someone who does not show up. It is not personal. It is math. The group adjusts to who is actually there. Malik is not actually there. So the group stopped expecting Malik to be there. And then the invitations stopped.

Malik did not notice it happening in real-time. Malik noticed it three weeks ago when someone posted photos from a birthday party Malik did not know was happening. Malik was not invited. Not because Malik was excluded. Because Malik had excluded Malik so many times that people stopped trying.

Malik is sitting in class right now. There is a group project. People are partnering up. Malik wants to partner with Jordan and Sam. Malik does not ask. Because what if they already planned to partner together? What if Malik asking makes it awkward? What if they say yes but they do not actually want to and they are just being nice? Malik waits. Jordan and Sam partner together. Someone Malik barely knows asks Malik to partner. Malik says yes. Malik spends the next forty minutes working with someone Malik does not want to work with because Malik was too busy running scenarios to act on what Malik actually wanted.

This is not one moment. This is the pattern. The overthinking does not just delay action. It replaces action. And every time Malik does not act, the world adjusts. The group moves on. The opportunity closes. The friendship fades. Not because anyone decided to cut Malik out. Because Malik cut Malik out, one overthought moment at a time.

Here is what happens when overthinking runs unchecked. You do not lose your mind. You lose your life. Not all at once. Slowly. In increments so small you do not notice until you look up one day and realize the group chat is quiet, the plans are happening without you, the friends you thought you had are people you have not actually talked to in three months because every time you thought about reaching out, the loop started: What if they do not want to hear from me? What if I am bothering them? What if they were only friends with me because we were in the same classes and now we are not and I was wrong about the whole thing?

You were not wrong. You were overthinking. And the overthinking turned what if into certainty. You decided they did not want to hear from you. So you did not reach out. So they did not reach out. So the friendship ended. Not because it was supposed to. Because you ran the scenario where it ended and then you acted like the scenario was real.

There is a kid named Dev. Fifteen. Lives in Brooklyn, has a best friend named Riley who Dev has known since fourth grade, has parents who are divorced and a little sister who asks too many questions and a bedroom that is too small and a brain that will not stop. Dev and Riley used to talk every day. Text thread was constant. Inside jokes. Plans. The easy back-and-forth of people who do not have to perform for each other.

Two months ago, Dev sent a message. Riley did not respond for six hours. When Riley did respond, it was short. "sorry was busy lol." Dev read it and thought: Riley is pulling away. Dev did not ask why. Dev started testing. Sent fewer messages. Waited to see if Riley would initiate. Riley did not. Dev decided: Riley does not want to be friends anymore. Dev has been operating on that assumption for two months.

Except Riley has not pulled away. Riley has been busy. Riley's parents are going through something. Riley is failing math. Riley is overwhelmed and when Riley is overwhelmed, Riley goes quiet. Riley is not mad at Dev. Riley is barely thinking about Dev because Riley is trying to survive ninth grade without falling apart.

Dev does not know this. Dev decided what Riley's silence meant, and Dev has been acting on that decision, and the acting on it is making it real. Dev does not text. Riley notices Dev is distant. Riley assumes Dev is mad. Riley does not ask why because Riley does not have the capacity to manage one more thing. So Riley pulls back. Now Dev's assumption is confirmed. Riley is distant. Dev was right.

Except Dev was not right. Dev created the distance by assuming the distance was already there. The overthinking does not predict the future. The overthinking writes the future, and then you live in it, and then you think: See, I knew this would happen. You did not know. You made it happen.

Let me tell you what this costs. It costs you the friendships that were real. It costs you the opportunities you did not take because you were running scenarios instead of acting. It costs you the version of your life where you said yes, where you texted back, where you sat with the group, where you asked the question, where you were a person in the room instead of a calculator running probabilities.

It costs you the ability to trust your own instincts because you have replaced instinct with analysis. You do not know what you want anymore because you have spent so much time trying to figure out what the right answer is that you have forgotten there is a difference between what is right and what you want.

It costs you the present moment. You are not here. You are three hours ago replaying the conversation. You are six hours ahead pre-loading the anxiety for the thing that has not happened yet. You are running the loop. The loop is not neutral. The loop has a cost. And the cost is your actual life, the one happening right now, the one you are missing because you are busy simulating the version of it where something goes wrong.

[EXERCISE PLACEHOLDER: 5-7 minute practice - acting on one small thing without running scenarios first, sitting with the discomfort of not knowing the outcome, naming the cost of not acting]

There is a kid named Zara. Seventeen. Lives in Harlem, has two younger brothers who are loud and a mom who works nights and a best friend named Jas who moved to Boston last year and a college application essay that is due in four days that Zara has rewritten eleven times and still has not submitted because none of the versions sound right.

Zara is not a bad writer. Zara is a good writer. The essay is good. Zara knows the essay is good. Zara also knows the essay could be better. Zara knows there is a version of the essay that would make the admissions person reading it think: This is the one. We want this kid.

Zara does not know what that version is. So Zara keeps rewriting. And the deadline gets closer. And Zara is not working on the essay anymore. Zara is working on the fear of submitting the wrong version. And the fear is louder than the essay. And the deadline is in four days. And Zara still has not submitted.

Zara is running out of time. Zara knows this. Zara is also running scenarios: What if the essay is not good enough? What if Zara submits it and gets rejected and then has to live with the knowledge that Zara could have made it better but did not? What if the version Zara submits is the version that costs Zara the spot?

Zara is not lazy. Zara is not procrastinating. Zara is paralyzed. The overthinking has turned the essay into a referendum on Zara's entire future, and the loop will not let Zara submit until Zara is certain, and certainty does not exist, so Zara does not submit.

The deadline passes. Zara submits the essay three hours late. The system accepts it. Zara does not know if the three hours mattered. Zara will never know. What Zara does know is that the overthinking cost Zara three hours of sleep, four days of constant anxiety, and the ability to feel good about the work Zara did because all Zara can feel is: I should have submitted it earlier. I should have written it better. I should have been different.

This is the cost. Not the dramatic failure. The slow erosion of your ability to act, to choose, to be present, to trust yourself. The overthinking does not protect you. It does not make you more prepared. It makes you smaller. Your world gets smaller. Your friendships get smaller. Your capacity to take risks gets smaller. And you do not notice it happening until one day you look around and realize: I am alone. Not because I was rejected. Because I rejected myself, one overthought moment at a time.

The loop is running. The cost is accumulating. You are not counting it. Start counting it. Not to shame yourself. To see it. To name it. To stop pretending that overthinking is careful when it is actually expensive and you are the one paying.

Still here. Still overthinking. That is not failure. That is data. The loop runs. You notice. You act anyway. Not perfectly. Not without fear. You act because the cost of not acting is higher than the cost of being wrong. And being wrong is survivable. Being absent from your own life is not.

---

**End of Book**

Total: ~9,200 words across 3 chapters
Chapter 1: ~3,100 words (cool, didactic)
Chapter 2: ~3,050 words (warm, socratic)  
Chapter 3: ~3,050 words (hot, cost escalation)
