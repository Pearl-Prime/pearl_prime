# General Gen Z Template Set

**Mechanism:** Autonomic Regulation  
**Engine:** False Alarm

---

## Architecture Decision

**Problem:** Previous "Gen Z Professional" templates assume work context (Slack, meetings, `years_in_workforce`). They don't work for:
- College students (18-22)
- Gap year / unemployed Gen Z
- General Gen Z contexts

**Solution:** Create context-agnostic templates that use flexible variables. The *voice* stays consistent (internet-literate, therapy-adjacent, self-aware), but *context* comes from variable files.

---

## Persona Profile

**Age Range:** 18-29  
**Contexts:** College, early career, freelance, gap year, any  
**Defining Trait:** Grew up online, knows the vocabulary for mental health but lacks the tools

**Core Voice Characteristics:**
- Internet-literate (memes, discourse, parasocial relationships)
- Therapy-adjacent vocabulary (knows "anxiety," "trauma," "triggers")
- Self-aware to the point of paralysis
- Knows what they're "supposed" to do but can't make it work
- Performance of wellness on social media while struggling privately
- Imposter syndrome about their own feelings ("is this even real anxiety or am I just dramatic")

**Core Anxiety Pattern:**
- Body reacts before mind catches up
- Every notification could be bad news
- Hyperaware of their own anxiety (meta-anxiety)
- Knowing the terms doesn't help
- Can't distinguish real threat from noise

---

## Variable Structure (Flexible)

The templates use context-agnostic variables. Different variable files provide student vs worker vs general context.

### Core Variables (Used in Templates)

```yaml
# Context-agnostic variables
{{character.name}}
{{character.age}}
{{character.context_anchor}}     # "in their second year of college" OR "two years into their first real job"
{{character.time_reference}}     # "semesters" OR "years" OR "months"

{{location.place}}               # Generic: "their room", "the library", "the apartment"
{{location.anchor}}              # "Sitting at their desk" OR "In the library" OR "At the coffee shop"

{{trigger.event}}                # Generic: "notification", "message", "email"
{{trigger.time}}                 # "10 PM", "Monday morning", etc.
{{trigger.context}}              # Situation-specific detail
{{trigger.typical_reality}}      # What it usually turns out to be

{{body.primary}}                 # "chest tighten", "stomach drop"
{{body.secondary}}               # "hands get clammy", "breath catch"

{{stakes.internal}}              # What they fear losing (identity, competence, belonging)
{{stakes.external}}              # What's actually at risk (grade, job, relationship)

{{isolation.line}}               # Why they can't tell anyone
{{coping.failed_attempt}}        # What they've tried that doesn't work
```

---

## Variable Files by Context

### Student Variables

```yaml
# variables/gen_z/student/characters.yaml

characters:
  - name: Jordan
    age: 20
    context_anchor: in their second year at State
    time_reference: semesters
    
  - name: Maya
    age: 19
    context_anchor: a freshman still figuring out how college works
    time_reference: months
    
  - name: Alex
    age: 21
    context_anchor: a junior with two more years to figure it out
    time_reference: semesters
```

```yaml
# variables/gen_z/student/locations.yaml

locations:
  - place: their dorm room
    anchor: Sitting on the bed, laptop open
    detail: roommate's side empty for once
    
  - place: the library
    anchor: At a table in the back corner
    detail: headphones in, pretending to study
    
  - place: the campus coffee shop
    anchor: In line for their second coffee
    detail: avoiding eye contact with classmates
```

```yaml
# variables/gen_z/student/triggers.yaml

triggers:
  false_alarm:
    - event: Canvas notification
      time: Sunday night
      context: assignment due tomorrow
      typical_reality: a grade posted from last week
      fear: failing the class
      
    - event: text from the group chat
      time: mid-afternoon
      context: after missing class
      typical_reality: someone asking for notes
      fear: they're talking about me
      
    - event: email from the professor
      time: Monday morning
      context: after submitting the paper late
      typical_reality: a class-wide announcement
      fear: academic probation
      
    - event: Instagram story view
      time: late at night
      context: after posting something vulnerable
      typical_reality: random acquaintances watching
      fear: someone's going to screenshot and judge
```

```yaml
# variables/gen_z/student/stakes.yaml

stakes:
  internal:
    - "being the person who has it together"
    - "proving they deserve to be here"
    - "not being the one who can't handle it"
    
  external:
    - "their GPA"
    - "the scholarship"
    - "not having to explain failure to parents"
    
  isolation:
    - "They couldn't exactly bring that up in the group chat"
    - "Nobody in the dorm talked about feeling like this"
    - "Instagram was all highlight reels"
```

---

### Worker Variables

```yaml
# variables/gen_z/worker/characters.yaml

characters:
  - name: Jordan
    age: 25
    context_anchor: two years into their first real job
    time_reference: years
    
  - name: Maya
    age: 24
    context_anchor: six months past the "new job" excuse
    time_reference: months
    
  - name: Alex
    age: 27
    context_anchor: three years in and still not sure this is right
    time_reference: years
```

```yaml
# variables/gen_z/worker/locations.yaml

locations:
  - place: their apartment
    anchor: At the desk in the corner that passes for a home office
    detail: laptop open, Slack notifications piling up
    
  - place: the open office
    anchor: At the hot desk by the window
    detail: headphones in, pretending to focus
    
  - place: the coffee shop
    anchor: At the regular table with the outlet
    detail: avoiding the coworking crowd
```

```yaml
# variables/gen_z/worker/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the manager
      time: 9 PM
      context: after leaving something unfinished
      typical_reality: a scheduling question
      fear: I'm getting fired
      
    - event: calendar invite with no subject
      time: Friday afternoon
      context: from someone two levels up
      typical_reality: a routine check-in
      fear: something's wrong
      
    - event: email marked urgent
      time: Monday morning
      context: before logging on
      typical_reality: a mass announcement
      fear: something I did
      
    - event: "Can we talk?" message
      time: mid-afternoon
      context: right after submitting work
      typical_reality: a clarifying question
      fear: it's bad
```

```yaml
# variables/gen_z/worker/stakes.yaml

stakes:
  internal:
    - "being competent enough to be here"
    - "not being found out as someone who doesn't know what they're doing"
    - "proving the degree was worth it"
    
  external:
    - "rent"
    - "the job itself"
    - "not having to move back home"
    
  isolation:
    - "They couldn't exactly bring that up in the team standup"
    - "Nobody at work talked about feeling like this"
    - "LinkedIn was all wins"
```

---

### General Variables (Context-Flexible)

```yaml
# variables/gen_z/general/characters.yaml

characters:
  - name: Jordan
    age: 23
    context_anchor: somewhere between college and figuring out what's next
    time_reference: years
    
  - name: Maya
    age: 22
    context_anchor: in that weird gap where everyone asks what the plan is
    time_reference: months
```

```yaml
# variables/gen_z/general/triggers.yaml

triggers:
  false_alarm:
    - event: notification
      time: late at night
      context: while already spiraling about something else
      typical_reality: nothing important
      fear: confirmation of whatever they were already worried about
      
    - event: text from someone they haven't heard from
      time: out of the blue
      context: unexpected
      typical_reality: catching up
      fear: bad news, confrontation, something they did wrong
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Gen Z (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.age}}
- {{character.context_anchor}}
- {{trigger.event}}
- {{trigger.time}}
- {{trigger.context}}
- {{trigger.typical_reality}}
- {{body.primary}}
- {{body.secondary}}
- {{location.place}}
- {{location.anchor}}
- {{stakes.internal}}
- {{isolation.line}}

### Template

{{character.name}} was {{character.age}}.

{{character.context_anchor}}.
Long enough to know better.
Not long enough to actually feel like it.

The {{trigger.event}} came through at {{trigger.time}}.
{{trigger.context}}.

Their {{body.primary}}.
Then their {{body.secondary}}.

They hadn't even looked at it yet.

{{location.anchor}},
they felt it before they could name it—
that spike of something that said *this is it, this is the thing you were afraid of*.

They checked.

{{trigger.typical_reality}}.

Nothing bad.
Nothing that should have made their body react like that.

But it did.

And it wasn't just that one.
It was every notification.
Every "can we talk."
Every message that started with a name instead of a greeting.

They knew it was "just anxiety."
They'd read the threads, seen the TikToks,
could probably explain the nervous system if someone asked.

But knowing what it was called
didn't make it stop.

{{stakes.internal}}.
And their body treating every ping like confirmation
that they were about to lose it.

The worst part wasn't the feeling.
It was the performance—
acting normal in {{location.place}},
typing normal responses,
while something underneath kept screaming
*you're not okay and everyone's going to find out*.

{{isolation.line}}.

So they didn't.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Gen Z (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}
- {{body.secondary}}
- {{coping.failed_attempt}}
- {{character.time_reference}}

### Template

{{character.name}} had tried everything the internet told them to.

Breathe.
Ground yourself.
Name five things you can see.

They had the apps.
They knew the terms.
They'd saved the infographics.

None of it stopped the {{body.primary}} when a notification came through.
None of it kept their {{body.secondary}} when things went quiet.

{{coping.failed_attempt}}.
It worked for maybe a week.
Then the feeling found a way around it.

They'd tried being more on top of things—
responding faster, checking more often—
thinking that staying ahead would make the anxiety go away.

It made it worse.

They'd tried being less available—
muting notifications, setting "boundaries"—
but the fear of missing something
was worse than the fear of seeing it.

They'd tried logic.

*It's probably nothing.*
*Most notifications aren't emergencies.*
*Statistically, things are usually fine.*

The numbers made sense.
Their body didn't care about numbers.

Every strategy they tried
became another thing to manage.

And underneath all the self-improvement,
all the "doing the work,"
all the advice from people who seemed to have it figured out,
the spike still came.

Right on cue.
Every time.

Like their body had decided that existing in this world
meant permanent threat assessment.

And the trying was becoming its own kind of exhausting.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Gen Z (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.place}}
- {{location.anchor}}
- {{body.primary}}
- {{body.secondary}}

### Template

{{character.name}} was in {{location.place}} when it happened again.

A notification.
Their {{body.primary}}.
Their {{body.secondary}}.
The whole familiar sequence.

But this time, instead of reaching for a strategy,
they just... noticed.

*There it is.*
*The spike.*
*Same as always.*

Not "why am I like this."
Not "I need to calm down."
Just: *oh, this again*.

And something weird happened.

They didn't feel calm exactly.
But they felt less at war with it.

The spike was still there.
But it wasn't an emergency anymore.
It was just a thing their body was doing.

Like their nervous system had been trained—
by years of everything being online,
everything being immediate,
everything potentially mattering—
to stay ready for whatever came next.

Not because something was wrong with them.
Because that's what nervous systems do
when they're paying attention to a world that doesn't pause.

The spike wasn't a malfunction.
It was their body doing its job.
Maybe too well.
Maybe unable to distinguish between
"might be important" and "actually dangerous."

The notification turned out to be nothing.
Their body didn't know that yet.
But they did.

And for the first time,
that gap didn't feel like failure.

It just felt like lag.
Like their system running a little behind the facts.

They could feel the spike
and still check the message normally.

They could notice the alarm
and not let it run the show.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Gen Z (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{trigger.event}}
- {{body.primary}}
- {{stakes.internal}}
- {{character.time_reference}}

### Template

The spikes still came.

{{character.name}} wasn't pretending they didn't.

Every {{trigger.event}} still made their {{body.primary}}.
That probably wasn't going to change.
That was probably what growing up in a world
where everything is immediate
and everything is potentially documented
did to a nervous system.

But something had shifted in what happened next.

Before, it was:
notification → spike → panic about the spike → try to fix it → spiral → exhaustion

Now it was more like:
notification → spike → *okay, that's the thing* → check → move on

One layer instead of five.

They still had the apps.
They still used them sometimes.
But they'd stopped expecting them to turn them into someone
who didn't feel this.

That person didn't exist.
Or if they did, they weren't posting about it honestly.

{{stakes.internal}}.
The stakes were still real.
The notifications weren't going away.

But the nervous system running on high alert
didn't mean something was actually wrong.
It just meant they were paying attention.

And paying attention was different from drowning in it.

Some days were still hard.
Some spikes still felt like too much.

But they'd stopped adding the second layer—
the judgment about being anxious,
the anxiety about anxiety,
the performance of being fine.

One layer was enough.

They could feel it and function.

Not fixed.
Not "healed."
Just... handling it.

Which, honestly?
For someone their age, in this world?

That was actually a lot.
```

---

## Quality Validation Checklist

### Recognition
- [x] Identity anchor present (age, context, stakes)
- [x] Internal stakes present ("being competent," "not being found out")
- [x] Somatic activation present (body.primary, body.secondary)
- [x] No reframe language ✓
- [x] No insight claims ✓
- [x] No relief signals ✓
- [x] Works for student AND worker contexts via variables

### Mechanism Proof
- [x] Constraint loop shown (strategies become more things to manage)
- [x] Repeated failure shown (apps, logic, boundaries—none work)
- [x] Pattern language present ("every time," "right on cue")
- [x] No instructions ✓
- [x] No technique names ✓
- [x] No resolution ✓
- [x] Context-agnostic coping references

### Turning Point
- [x] Exactly one meaning inversion ("spike as lag, not malfunction")
- [x] Interpretation shift present ("body doing its job too well")
- [x] No full resolution ✓
- [x] No mastery claims ✓
- [x] No permanence language ✓
- [x] Works for any Gen Z context

### Embodiment
- [x] Relational shift shown (one layer instead of five)
- [x] Lived example present (notification → spike → check → move on)
- [x] Ongoing/imperfect framing ("That probably wasn't going to change")
- [x] No cure language ✓
- [x] No permanence claims ✓
- [x] Realistic resolution for Gen Z ("handling it" = a lot)

---

## Voice Markers (Consistent Across All Contexts)

| Element | Gen Z Voice |
|---------|-------------|
| Self-awareness | High — knows the terms, meta-aware |
| Relationship to mental health | Vocabulary-rich but tool-poor |
| Coping references | Apps, infographics, TikToks, "doing the work" |
| Social media awareness | Performance vs reality gap |
| Resolution framing | "Handling it" — not fixed, not thriving, functioning |
| Unique tension | Knowing doesn't help |
| Isolation framing | Can't be vulnerable in spaces that perform wellness |

---

## How Variables Switch Context

**Same template, different feel:**

**Student hydration:**
> "Jordan was 20. In their second year at State. Long enough to know better..."
> "Sitting on the bed, laptop open, they felt it before they could name it..."
> "They couldn't exactly bring that up in the group chat."

**Worker hydration:**
> "Jordan was 25. Two years into their first real job. Long enough to know better..."
> "At the desk in the corner that passes for a home office, they felt it before they could name it..."
> "They couldn't exactly bring that up in the team standup."

**General hydration:**
> "Jordan was 23. Somewhere between college and figuring out what's next. Long enough to know better..."
> "At the coffee shop, third hour there, they felt it before they could name it..."
> "They couldn't exactly post about it honestly."

Same voice. Same arc. Same mechanism. Different world.

---

## File Structure

```
templates/anxiety/false_alarm/
├── gen_z/                        # ← NEW: Context-agnostic
│   ├── recognition.md
│   ├── mechanism_proof.md
│   ├── turning_point.md
│   └── embodiment.md
├── gen_z_professionals/          # ← EXISTING: Work-specific (optional to keep)
│   └── ...
├── gen_alpha_students/           # ← EXISTING: Teen-specific
│   └── ...

variables/gen_z/
├── student/                      # ← College context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── stakes.yaml
├── worker/                       # ← Early career context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── stakes.yaml
├── general/                      # ← Flexible context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── stakes.yaml
└── locations/                    # ← Location overlays
    ├── la/
    ├── nyc/
    ├── london/
    └── ...
```

---

## Mapping

| Persona ID | Template Set | Variable Set |
|------------|--------------|--------------|
| `gen_z` | `gen_z/` | `gen_z/general/` |
| `gen_z_students` | `gen_z/` | `gen_z/student/` |
| `gen_z_professionals` | `gen_z/` | `gen_z/worker/` |
| `gen_z_la` | `gen_z/` | `gen_z/worker/` + `gen_z/locations/la/` |
| `gen_z_nyc` | `gen_z/` | `gen_z/worker/` + `gen_z/locations/nyc/` |

One template set serves all Gen Z contexts. Variables provide specificity.

---

*End of General Gen Z Template Set*
