# General Gen Alpha Template Set

**Mechanism:** Autonomic Regulation  
**Engine:** False Alarm

---

## Architecture Decision

**Problem:** Previous "Gen Alpha Student" templates assume school context (classes, assignments, teachers). They don't fully cover:
- Sports/activities contexts
- Social/friend group dynamics outside school
- Online/gaming contexts
- Family dynamics
- Summer/break periods

**Solution:** Create context-flexible templates that use the Gen Alpha *voice* (shorter, more direct, less abstract) while allowing variables to set the context.

---

## Persona Profile

**Age Range:** 12-17  
**Contexts:** School, sports, social, online, family, activities  
**Defining Trait:** Knows the word "anxiety" but not the frameworks; less patience for explanation

**Core Voice Characteristics:**
- Shorter sentences
- Less abstract thinking
- More direct language
- Social stakes dominate ("being weird," "making it a whole thing")
- Less sophisticated vocabulary for internal states
- More action-oriented than introspective
- Digital native but different relationship than Gen Z (grew up with TikTok, not Facebook)

**Core Anxiety Pattern:**
- Body reacts strongly, hard to name why
- Social radar always on
- Fear of being "the weird one" or "too much"
- Doesn't want to "make it a whole thing"
- Adults don't get it
- Knows something is off but lacks language for it

**Key Differences from Gen Z:**

| Gen Z (18-29) | Gen Alpha (12-17) |
|---------------|-------------------|
| Over-intellectualized self-awareness | Knows something's wrong, can't articulate it well |
| Therapy-adjacent vocabulary | Knows "anxiety" but not frameworks |
| Meta-anxiety (anxious about being anxious) | Just wants it to stop |
| Performance of wellness | Performance of being normal |
| "Doing the work" | "I'm fine" |
| Long-form self-reflection | Short, direct |
| Career/identity stakes | Social/belonging stakes |

---

## Variable Structure (Flexible)

### Core Variables (Used in Templates)

```yaml
# Context-agnostic variables
{{character.name}}
{{character.age}}
{{character.context_anchor}}     # "eighth grade" OR "sophomore year" OR "club soccer"
{{character.world}}              # "school" OR "the team" OR "the group chat"

{{location.place}}               # Generic: "their room", "the bathroom", "the car"
{{location.anchor}}              # "Sitting in their room" OR "In the locker room"

{{trigger.event}}                # Generic: "notification", "message", "look"
{{trigger.time}}                 # "after practice", "during lunch", "at night"
{{trigger.context}}              # Situation-specific detail
{{trigger.typical_reality}}      # What it usually is

{{body.primary}}                 # "stomach flip", "face get hot"
{{body.secondary}}               # "hands go weird", "couldn't breathe right"

{{social.fear}}                  # "being weird", "being too much", "being left out"
{{social.group}}                 # "the friend group", "the team", "everyone"

{{adult.reference}}              # "mom", "the coach", "the teacher"
{{dismissal.line}}               # Why they can't tell anyone / why adults don't get it
```

---

## Variable Files by Context

### School Variables

```yaml
# variables/gen_alpha/school/characters.yaml

characters:
  - name: Mia
    age: 14
    context_anchor: in eighth grade
    world: school
    grade: 8th
    
  - name: Jayden
    age: 15
    context_anchor: a freshman
    world: high school
    grade: 9th
    
  - name: Zoe
    age: 16
    context_anchor: a sophomore who should have it figured out by now
    world: school
    grade: 10th
    
  - name: Kai
    age: 13
    context_anchor: in seventh grade
    world: middle school
    grade: 7th
```

```yaml
# variables/gen_alpha/school/locations.yaml

locations:
  - place: the school bathroom
    anchor: In the bathroom between classes
    detail: the one stall that locks
    
  - place: their bedroom
    anchor: Lying on the bed, phone in hand
    detail: door closed, lights off
    
  - place: the library
    anchor: At a table in the back
    detail: pretending to do homework
    
  - place: the hallway
    anchor: Walking to class
    detail: headphones in, eyes down
    
  - place: the car
    anchor: In the backseat on the way home
    detail: hoping mom doesn't ask questions
```

```yaml
# variables/gen_alpha/school/triggers.yaml

triggers:
  false_alarm:
    - event: group chat notification
      time: during class
      context: phone buzzing in their pocket
      typical_reality: someone sending memes
      fear: being talked about
      
    - event: being left on read
      time: after sending a message
      context: the little "seen" but no response
      typical_reality: person got distracted
      fear: they're mad, they hate me
      
    - event: a look from someone across the room
      time: during lunch
      context: couldn't tell if it was at them
      typical_reality: person looking at something else
      fear: everyone's noticed something wrong
      
    - event: teacher calling their name
      time: in class
      context: wasn't paying attention
      typical_reality: routine question
      fear: in trouble, everyone staring
      
    - event: post they weren't tagged in
      time: scrolling at night
      context: friends all there, them not
      typical_reality: whoever posted just forgot
      fear: being cut out on purpose
```

```yaml
# variables/gen_alpha/school/social.yaml

social:
  fears:
    - "being weird"
    - "being too much"
    - "making it a whole thing"
    - "being the one who can't handle it"
    - "being left out"
    
  groups:
    - "the friend group"
    - "everyone"
    - "the people at their lunch table"
    - "the group chat"
    
  dismissals:
    - "Couldn't tell anyone without making it weird"
    - "Mom would just worry and make it worse"
    - "The counselor would probably call home"
    - "Friends would think they were being dramatic"
```

---

### Sports/Activities Variables

```yaml
# variables/gen_alpha/sports/characters.yaml

characters:
  - name: Marcus
    age: 15
    context_anchor: in his second year on varsity
    world: the team
    sport: basketball
    
  - name: Lily
    age: 14
    context_anchor: just made the competitive squad
    world: the team
    sport: dance
    
  - name: Tyler
    age: 16
    context_anchor: been playing since fifth grade
    world: club soccer
    sport: soccer
    
  - name: Ava
    age: 13
    context_anchor: new to the team this year
    world: volleyball
    sport: volleyball
```

```yaml
# variables/gen_alpha/sports/locations.yaml

locations:
  - place: the locker room
    anchor: Sitting on the bench before practice
    detail: everyone else loud, them quiet
    
  - place: the car ride home
    anchor: In the backseat after the game
    detail: dad asking how it went
    
  - place: the sideline
    anchor: On the bench during the game
    detail: waiting to go in
    
  - place: their room
    anchor: Lying in bed after practice
    detail: body tired, brain not
    
  - place: the gym
    anchor: Stretching before warmups
    detail: trying to look normal
```

```yaml
# variables/gen_alpha/sports/triggers.yaml

triggers:
  false_alarm:
    - event: coach calling them over
      time: during practice
      context: couldn't hear what about
      typical_reality: lineup question
      fear: getting benched, cut from the team
      
    - event: text from a teammate
      time: night before a game
      context: just a name, no message yet
      typical_reality: logistics question
      fear: drama, someone's mad
      
    - event: parent in the stands looking at their phone
      time: during the game
      context: couldn't see their expression
      typical_reality: checking work email
      fear: disappointed, filming a mistake
      
    - event: getting subbed out
      time: middle of the game
      context: coach didn't say why
      typical_reality: normal rotation
      fear: did something wrong, not good enough
      
    - event: team group chat going quiet
      time: after a loss
      context: usually active
      typical_reality: everyone just tired
      fear: blame, people talking elsewhere
```

```yaml
# variables/gen_alpha/sports/social.yaml

social:
  fears:
    - "letting the team down"
    - "being the weak link"
    - "coach noticing something's off"
    - "teammates thinking they can't handle pressure"
    
  groups:
    - "the team"
    - "the starters"
    - "the coaches"
    - "the parents in the stands"
    
  dismissals:
    - "Couldn't tell coach without looking soft"
    - "Teammates would think they couldn't handle it"
    - "Dad would say to push through"
    - "Everyone else seemed fine"
```

---

### Online/Gaming Variables

```yaml
# variables/gen_alpha/online/characters.yaml

characters:
  - name: Alex
    age: 14
    context_anchor: online more than anywhere else
    world: the server
    platform: Discord
    
  - name: Sam
    age: 15
    context_anchor: been in the community for two years
    world: the group
    platform: gaming
    
  - name: Jordan
    age: 13
    context_anchor: finally part of the inner circle
    world: the chat
    platform: group DMs
```

```yaml
# variables/gen_alpha/online/triggers.yaml

triggers:
  false_alarm:
    - event: getting kicked from a voice channel
      time: mid-conversation
      context: connection issue probably
      typical_reality: Discord glitched
      fear: they wanted them gone
      
    - event: message deleted in the chat
      time: right after they said something
      context: couldn't see what it was
      typical_reality: someone fixing a typo
      fear: about them, laughing at them
      
    - event: friend's status going offline
      time: while they were talking
      context: suddenly gone
      typical_reality: parent made them get off
      fear: avoiding them specifically
      
    - event: not being added to the new group
      time: seeing others mention it
      context: wasn't invited
      typical_reality: hit member limit, will add later
      fear: purposely excluded
      
    - event: someone vague-posting
      time: scrolling their feed
      context: could be about anything
      typical_reality: not about them
      fear: definitely about them
```

---

### Family Variables

```yaml
# variables/gen_alpha/family/characters.yaml

characters:
  - name: Emma
    age: 14
    context_anchor: the oldest, supposed to have it together
    world: home
    family_role: oldest sibling
    
  - name: Noah
    age: 13
    context_anchor: the middle kid, easy to overlook
    world: home
    family_role: middle child
    
  - name: Olivia
    age: 15
    context_anchor: only child, all the attention
    world: home
    family_role: only child
```

```yaml
# variables/gen_alpha/family/triggers.yaml

triggers:
  false_alarm:
    - event: parent's tone changing
      time: at dinner
      context: couldn't tell why
      typical_reality: work stress, nothing to do with them
      fear: they know something, they're mad
      
    - event: "we need to talk" from mom
      time: after school
      context: no other context
      typical_reality: logistics, schedule stuff
      fear: in trouble, something bad
      
    - event: parents talking quietly
      time: in the other room
      context: couldn't hear what about
      typical_reality: adult stuff, bills
      fear: about them, divorce, something wrong
      
    - event: sibling getting more attention
      time: family dinner
      context: their thing being talked about
      typical_reality: just their turn
      fear: being forgotten, less loved
```

```yaml
# variables/gen_alpha/family/social.yaml

social:
  fears:
    - "disappointing them"
    - "being the problem child"
    - "them finding out something's wrong"
    - "making them worry"
    
  groups:
    - "the family"
    - "mom and dad"
    - "everyone at home"
    
  dismissals:
    - "Mom would freak out and make it worse"
    - "Dad would say everyone feels like that"
    - "They'd make a whole thing about it"
    - "Easier to just say 'I'm fine'"
```

---

### General Variables (Context-Flexible)

```yaml
# variables/gen_alpha/general/characters.yaml

characters:
  - name: Mia
    age: 14
    context_anchor: old enough to know something was off
    world: their life
    
  - name: Jayden
    age: 15
    context_anchor: trying to figure out why everything felt so hard
    world: everywhere
    
  - name: Zoe
    age: 13
    context_anchor: just wanting to feel normal
    world: their world
```

```yaml
# variables/gen_alpha/general/triggers.yaml

triggers:
  false_alarm:
    - event: notification
      time: any time
      context: could be anything
      typical_reality: nothing important
      fear: something bad
      
    - event: someone's tone changing
      time: mid-conversation
      context: couldn't tell why
      typical_reality: unrelated to them
      fear: they did something wrong
      
    - event: silence where there should be noise
      time: when they expected a response
      context: waiting
      typical_reality: person busy
      fear: being ignored on purpose
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Gen Alpha (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.age}}
- {{character.context_anchor}}
- {{trigger.event}}
- {{trigger.time}}
- {{trigger.context}}
- {{trigger.typical_reality}}
- {{body.primary}}
- {{body.secondary}}
- {{location.place}}
- {{location.anchor}}
- {{social.fear}}
- {{dismissal.line}}

### Template

{{character.name}} was {{character.age}}.

{{character.context_anchor}}.
Old enough to know when something felt wrong.
Not old enough to know what to do about it.

The {{trigger.event}} came at {{trigger.time}}.
{{trigger.context}}.

Their {{body.primary}}.
Then their {{body.secondary}}.

They didn't even know what it was yet.

{{location.anchor}},
their body decided before their brain caught up.
Something was wrong. Had to be.

They checked.

{{trigger.typical_reality}}.

Nothing bad.
Nothing that should have made them feel like that.

But it did anyway.

And it wasn't just that one time.
It was a lot of things.
Notifications. Looks. Silences.
Stuff that probably meant nothing
but made their body act like something was really wrong.

They knew the word for it. Anxiety.
They'd seen it on TikTok, heard people talk about it.

But knowing what to call it
didn't make it stop happening.

The worst part was acting normal.
Laughing at the right times.
Saying "I'm fine" when asked.
Not being the one who made it weird.

{{social.fear}}.
That was the thing they couldn't let happen.

{{dismissal.line}}.

So they didn't say anything.
Just kept it inside
and hoped it would go away on its own.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Gen Alpha (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}
- {{body.secondary}}
- {{social.group}}
- {{adult.reference}}

### Template

{{character.name}} had tried stuff.

Deep breaths. That thing where you count to ten.
Putting the phone down.
Going for a walk.

None of it stopped the {{body.primary}} when something happened.
None of it kept their {{body.secondary}} when things got quiet.

They'd tried being more on top of things.
Checking more. Responding faster.
If they could just stay ahead of it, maybe it would stop.

It didn't.
It just meant more things to check.

They'd tried ignoring it.
Just pushing through.
Acting like it wasn't happening.

That worked for a little bit.
Then it came back worse.

They'd tried telling themselves it was nothing.

*It's probably fine.*
*Everyone else is fine.*
*Stop being weird about it.*

Their brain got it.
Their body didn't care.

Every time they tried to fix it,
it just became another thing to deal with.

And underneath all the trying,
the feeling kept coming back.
Same as before.
Every time.

Like their body had decided
that everything might be a problem
and it wasn't going to take any chances.

{{adult.reference}} would probably say
everyone feels like this sometimes.
That didn't help either.

Because "sometimes" wasn't the problem.
The problem was it felt like always.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Gen Alpha (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.place}}
- {{location.anchor}}
- {{body.primary}}
- {{body.secondary}}
- {{trigger.event}}

### Template

{{character.name}} was in {{location.place}} when it happened again.

{{trigger.event}}.
Their {{body.primary}}.
Their {{body.secondary}}.
Same as always.

But this time, something was different.

Not the feeling.
The feeling was exactly the same.

It was more like...
they noticed it happening.
Like watching it from a little bit outside.

*Oh. There it is.*
*The thing.*

Not "why am I like this."
Not "I need to make it stop."
Just: *that's happening again.*

And weirdly, that made it a little smaller.

Not gone.
Just... not the whole thing.

They could feel their {{body.primary}}
and also know it was probably nothing.
Both at the same time.

Like their body was doing one thing
and they could know something different.

Maybe that was just how it worked.
Body freaks out first.
Brain catches up later.

Not because something was wrong with them.
Because that's what bodies do
when they're trying to keep you safe
and don't know what's actually dangerous.

The {{trigger.event}} turned out to be nothing.
Their body didn't know that yet.
But they did.

And for the first time,
that gap felt okay.

Like lag in a game.
Body running a little behind.
Annoying, but not the end of the world.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Gen Alpha (General)
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.age}}
- {{trigger.event}}
- {{body.primary}}
- {{social.fear}}
- {{social.group}}

### Template

The feeling didn't go away.

{{character.name}} wasn't pretending it did.

{{trigger.event}} still made their {{body.primary}}.
That still happened.
That was probably just going to keep happening.

But something changed about what happened after.

Before, it was like:
thing happens → body freaks → try to stop it → can't → it gets worse → feel bad about it

Now it was more like:
thing happens → body freaks → okay, that's the thing → wait → it passes

Less steps.
Less fighting it.
Less making it into a bigger deal.

They still felt it.
They just stopped trying so hard to not feel it.

And weirdly, that helped more than anything else they'd tried.

Last week, {{social.group}} went quiet.
Their brain immediately went to the worst thing.
Their {{body.primary}}.
The whole familiar thing.

They noticed it.
Let it be there.
Didn't chase it.

Turned out to be nothing.

And even if it hadn't been—
even if something was actually wrong—
they realized they could have dealt with it.
Not perfectly.
But they could have figured it out.

The body freaking out wasn't a prediction.
It was just the body freaking out.

{{social.fear}}—that still mattered.
Being {{character.age}} still felt hard sometimes.

But the feeling that something was wrong all the time?
That got smaller.

Not gone.
Not fixed.
Just... smaller.

They could have the feeling
and also be okay.

Not perfect.
Just... handling it.

Which, honestly?
Was a lot better than before.
```

---

## Quality Validation Checklist

### Recognition
- [x] Identity anchor present (age, context)
- [x] Social stakes present ("being weird," "making it a whole thing")
- [x] Somatic activation present (body.primary, body.secondary)
- [x] No reframe language ✓
- [x] No insight claims ✓
- [x] No relief signals ✓
- [x] Gen Alpha voice: shorter sentences, less abstract
- [x] Works for school, sports, online, family contexts

### Mechanism Proof
- [x] Constraint loop shown (trying makes it worse)
- [x] Repeated failure shown (breathing, ignoring, logic—none work)
- [x] Pattern language present ("every time," "same as before")
- [x] Adult dismissal referenced
- [x] No instructions ✓
- [x] No technique names ✓
- [x] No resolution ✓

### Turning Point
- [x] Exactly one meaning inversion ("lag in a game")
- [x] Interpretation shift present (body/brain separation)
- [x] No full resolution ✓
- [x] No mastery claims ✓
- [x] No permanence language ✓
- [x] Teen-appropriate insight (simpler than Gen Z)

### Embodiment
- [x] Relational shift shown (less steps, less fighting)
- [x] Lived example present (group went quiet → notice → wait → passes)
- [x] Ongoing/imperfect framing ("probably just going to keep happening")
- [x] No cure language ✓
- [x] No permanence claims ✓
- [x] Realistic teen resolution ("handling it" = better than before)

---

## Voice Markers (Consistent Across All Contexts)

| Element | Gen Alpha Voice |
|---------|-----------------|
| Sentence length | Short. Direct. |
| Self-awareness | Knows something's wrong, can't fully articulate why |
| Vocabulary | Simpler — "the thing," "freaks out," "goes weird" |
| Relationship to mental health | Knows "anxiety" exists, doesn't have frameworks |
| Social stakes | Dominant — "being weird," "making it a thing" |
| Adult relationship | They don't get it, would make it worse |
| Resolution framing | "Handling it" — not analyzed, just coping |
| Unique tension | Wants it to stop, doesn't want to be dramatic about it |
| Insight style | Concrete metaphors ("like lag in a game") |

---

## Voice Comparison: Gen Alpha vs Gen Z

| Element | Gen Alpha | Gen Z |
|---------|-----------|-------|
| "I noticed the feeling" | "That's happening again." | "I'm noticing somatic activation consistent with my anxiety patterns." |
| Coping attempt | "That thing where you count to ten" | "The 4-7-8 breathing technique I learned from a podcast" |
| Why they can't tell | "They'd make a whole thing about it" | "I can't be vulnerable in spaces that perform wellness" |
| Resolution | "Handling it. Better than before." | "Functioning. Not fixed, but managing." |
| Metaphor style | "Like lag in a game" | "Like my nervous system was trained to scan for threats" |

Same mechanism. Same arc. Different developmental voice.

---

## How Variables Switch Context

**Same template, different feel:**

**School:**
> "Mia was 14. In eighth grade. Old enough to know when something felt wrong..."
> "In the bathroom between classes, their body decided before their brain caught up..."
> "Couldn't tell anyone without making it weird."

**Sports:**
> "Marcus was 15. In his second year on varsity. Old enough to know when something felt wrong..."
> "Sitting on the bench before practice, their body decided before their brain caught up..."
> "Couldn't tell coach without looking soft."

**Online:**
> "Alex was 14. Online more than anywhere else. Old enough to know when something felt wrong..."
> "In their room, headphones on, their body decided before their brain caught up..."
> "Couldn't say anything without making it weird in the server."

**Family:**
> "Emma was 14. The oldest, supposed to have it together. Old enough to know when something felt wrong..."
> "At dinner, trying to eat normally, their body decided before their brain caught up..."
> "Mom would freak out and make it worse."

Same voice. Same arc. Same mechanism. Different world.

---

## File Structure

```
templates/anxiety/false_alarm/
├── gen_alpha/                    # ← NEW: Context-agnostic
│   ├── recognition.md
│   ├── mechanism_proof.md
│   ├── turning_point.md
│   └── embodiment.md
├── gen_alpha_students/           # ← EXISTING: School-specific (optional to keep)
│   └── ...

variables/gen_alpha/
├── school/                       # ← School context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── social.yaml
├── sports/                       # ← Sports/activities context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── social.yaml
├── online/                       # ← Online/gaming context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── social.yaml
├── family/                       # ← Family context
│   ├── characters.yaml
│   ├── locations.yaml
│   ├── triggers.yaml
│   └── social.yaml
└── general/                      # ← Flexible context
    ├── characters.yaml
    ├── locations.yaml
    ├── triggers.yaml
    └── social.yaml
```

---

## Mapping

| Persona ID | Template Set | Variable Set |
|------------|--------------|--------------|
| `gen_alpha` | `gen_alpha/` | `gen_alpha/general/` |
| `gen_alpha_students` | `gen_alpha/` | `gen_alpha/school/` |
| `gen_alpha_athletes` | `gen_alpha/` | `gen_alpha/sports/` |
| `gen_alpha_online` | `gen_alpha/` | `gen_alpha/online/` |

One template set serves all Gen Alpha contexts. Variables provide specificity.

---

## Summary

| Persona | Templates | Variable Contexts |
|---------|-----------|-------------------|
| Gen Alpha | 4 (general) | School, Sports, Online, Family, General |
| Gen Z | 4 (general) | Student, Worker, General, + Location overlays |

**Total coverage:**
- Gen Alpha: 5 contexts from 1 template set
- Gen Z: 3+ contexts from 1 template set

System scales through variables, not template multiplication.

---

*End of General Gen Alpha Template Set*
