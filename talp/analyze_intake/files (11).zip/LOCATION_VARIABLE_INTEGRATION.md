# Location Variable Integration & Gap Analysis

**Date:** January 2026  
**Source Files:** 14 uploaded location YAML files

---

## Uploaded Location Files (14)

| File | City | Country | Region | Status |
|------|------|---------|--------|--------|
| `atlanta.yaml` | Atlanta | USA | Southeast | ✅ Ready |
| `beijing.yaml` | Beijing | China | North China | ✅ Ready |
| `boston.yaml` | Boston | USA | New England | ✅ Ready |
| `chicago.yaml` | Chicago | USA | Midwest | ✅ Ready |
| `cincinnati.yaml` | Cincinnati | USA | Midwest | ✅ Ready |
| `dc.yaml` | Washington DC | USA | Mid-Atlantic | ✅ Ready |
| `houston.yaml` | Houston | USA | Gulf Coast | ✅ Ready |
| `london.yaml` | London | UK | Greater London | ✅ Ready |
| `los_angeles.yaml` | Los Angeles | USA | Southern California | ✅ Ready |
| `melbourne.yaml` | Melbourne | Australia | Victoria | ✅ Ready |
| `phoenix.yaml` | Phoenix | USA | Southwest | ✅ Ready |
| `san_francisco.yaml` | San Francisco | USA | Bay Area | ✅ Ready |
| `seattle.yaml` | Seattle | USA | Pacific Northwest | ✅ Ready |
| `vancouver.yaml` | Vancouver | Canada | Pacific Northwest | ✅ Ready |

---

## Location File Structure

Each location YAML provides:

```yaml
_metadata:
  location: city_id
  city: City Name
  state/country: Region
  locale: en-US / en-GB / zh-CN / etc.
  currency_symbol: $ / £ / ¥
  currency_code: USD / GBP / CNY / etc.

location:
  transit_scene:        # How people get around
  school_building:      # School locations (for Gen Alpha)
  digital_space:        # Online spaces (Discord, group chat, etc.)
  landmarks:            # Local landmarks
  neighborhoods:        # Neighborhoods
  transit_system:       # Transit system name
  transit_line:         # Specific transit lines
  city_name:            # City name
  dwelling_type:        # Typical housing
  neighborhood_vibe:    # Neighborhood character
  cheap_food:           # Cheap local food
  expensive_food:       # Expensive local food
  weather_complaint:    # Local weather gripe

historical_figures:     # Local historical figures
climate:
  signals:              # Weather/climate alerts
```

---

## Persona-to-Location Mapping

### Gen Z Location Variants (23 in unified_personas.yaml)

| Persona ID | Location File | Template | Status |
|------------|---------------|----------|--------|
| `atlanta_gen_z` | `atlanta.yaml` | `gen_z/` | ✅ Ready |
| `austin_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `austin.yaml` |
| `boston_gen_z` | `boston.yaml` | `gen_z/` | ✅ Ready |
| `chicago_gen_z` | `chicago.yaml` | `gen_z/` | ✅ Ready |
| `cincinnati_gen_z` | `cincinnati.yaml` | `gen_z/` | ✅ Ready |
| `dc_gen_z` | `dc.yaml` | `gen_z/` | ✅ Ready |
| `england_gen_z` | `london.yaml` | `gen_z/` | ✅ Ready (use London) |
| `houston_gen_z` | `houston.yaml` | `gen_z/` | ✅ Ready |
| `london_gen_z` | `london.yaml` | `gen_z/` | ✅ Ready |
| `melbourne_gen_z` | `melbourne.yaml` | `gen_z/` | ✅ Ready |
| `nyc_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `nyc.yaml` |
| `opinion_gen_z` | N/A | `gen_z/` | ⚠️ Not location-based |
| `phoenix_gen_z` | `phoenix.yaml` | `gen_z/` | ✅ Ready |
| `san_diego_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `san_diego.yaml` |
| `santa_barbara_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `santa_barbara.yaml` |
| `seattle_gen_z` | `seattle.yaml` | `gen_z/` | ✅ Ready |
| `sf_gen_z` | `san_francisco.yaml` | `gen_z/` | ✅ Ready |
| `sydney_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `sydney.yaml` |
| `taipei_taiwan_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `taipei.yaml` |
| `tainan_taiwan_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `tainan.yaml` |
| `taiwan_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `taiwan.yaml` |
| `toronto_gen_z` | ❌ Missing | `gen_z/` | ❌ Need `toronto.yaml` |
| `vancouver_gen_z` | `vancouver.yaml` | `gen_z/` | ✅ Ready |

**Gen Z Summary:**
- ✅ **13 covered** (have location files)
- ❌ **9 missing** location files
- ⚠️ **1 special** (`opinion_gen_z` - not location-based)

---

### Gen Alpha Location Variants (25 in unified_personas.yaml)

| Persona ID | Location File | Template | Status |
|------------|---------------|----------|--------|
| `atlanta_gen_alpha` | `atlanta.yaml` | `gen_alpha/` | ✅ Ready |
| `austin_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `austin.yaml` |
| `boston_gen_alpha` | `boston.yaml` | `gen_alpha/` | ✅ Ready |
| `chicago_gen_alpha` | `chicago.yaml` | `gen_alpha/` | ✅ Ready |
| `china_gen_alpha` | `beijing.yaml` | `gen_alpha/` | ✅ Ready (use Beijing) |
| `cincinnati_gen_alpha` | `cincinnati.yaml` | `gen_alpha/` | ✅ Ready |
| `dc_gen_alpha` | `dc.yaml` | `gen_alpha/` | ✅ Ready |
| `england_gen_alpha` | `london.yaml` | `gen_alpha/` | ✅ Ready (use London) |
| `houston_gen_alpha` | `houston.yaml` | `gen_alpha/` | ✅ Ready |
| `la_gen_alpha` | `los_angeles.yaml` | `gen_alpha/` | ✅ Ready |
| `london_gen_alpha` | `london.yaml` | `gen_alpha/` | ✅ Ready |
| `melbourne_gen_alpha` | `melbourne.yaml` | `gen_alpha/` | ✅ Ready |
| `nyc_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `nyc.yaml` |
| `opinion_gen_alpha` | N/A | `gen_alpha/` | ⚠️ Not location-based |
| `phoenix_gen_alpha` | `phoenix.yaml` | `gen_alpha/` | ✅ Ready |
| `san_diego_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `san_diego.yaml` |
| `santa_barbara_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `santa_barbara.yaml` |
| `seattle_gen_alpha` | `seattle.yaml` | `gen_alpha/` | ✅ Ready |
| `sf_gen_alpha` | `san_francisco.yaml` | `gen_alpha/` | ✅ Ready |
| `sydney_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `sydney.yaml` |
| `taipei_taiwan_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `taipei.yaml` |
| `tainan_taiwan_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `tainan.yaml` |
| `taiwan_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `taiwan.yaml` |
| `toronto_gen_alpha` | ❌ Missing | `gen_alpha/` | ❌ Need `toronto.yaml` |
| `vancouver_gen_alpha` | `vancouver.yaml` | `gen_alpha/` | ✅ Ready |

**Gen Alpha Summary:**
- ✅ **15 covered** (have location files)
- ❌ **9 missing** location files
- ⚠️ **1 special** (`opinion_gen_alpha` - not location-based)

---

## Missing Location Files (9)

Need to create these location YAML files:

| Location | Personas Using It | Priority |
|----------|-------------------|----------|
| `nyc.yaml` | `nyc_gen_z`, `nyc_gen_alpha` | 🔴 HIGH |
| `sydney.yaml` | `sydney_gen_z`, `sydney_gen_alpha` | 🔴 HIGH |
| `toronto.yaml` | `toronto_gen_z`, `toronto_gen_alpha` | 🟡 MEDIUM |
| `austin.yaml` | `austin_gen_z`, `austin_gen_alpha` | 🟡 MEDIUM |
| `san_diego.yaml` | `san_diego_gen_z`, `san_diego_gen_alpha` | 🟡 MEDIUM |
| `taipei.yaml` | `taipei_taiwan_gen_z`, `taipei_taiwan_gen_alpha` | 🟡 MEDIUM |
| `tainan.yaml` | `tainan_taiwan_gen_z`, `tainan_taiwan_gen_alpha` | 🟢 LOW |
| `taiwan.yaml` | `taiwan_gen_z`, `taiwan_gen_alpha` | 🟢 LOW (generic) |
| `santa_barbara.yaml` | `santa_barbara_gen_z`, `santa_barbara_gen_alpha` | 🟢 LOW |

---

## Coverage Summary

### Location Files

| Status | Count | Percentage |
|--------|-------|------------|
| ✅ Have location file | 14 | 61% |
| ❌ Missing location file | 9 | 39% |
| **Total unique locations** | **23** | 100% |

### Persona Coverage (48 location variants)

| Status | Gen Z | Gen Alpha | Total |
|--------|-------|-----------|-------|
| ✅ Ready (have location file) | 13 | 15 | 28 |
| ❌ Missing location file | 9 | 9 | 18 |
| ⚠️ Not location-based | 1 | 1 | 2 |
| **Total** | **23** | **25** | **48** |

**28 of 48 location variant personas are ready** (58%)

---

## How Location Variables Work

### Template + Base Variables + Location Overlay

```
FINAL OUTPUT = Template + Base Variables + Location Variables
```

**Example: `seattle_gen_z`**

1. **Template:** `templates/anxiety/false_alarm/gen_z/recognition.md`
2. **Base Variables:** `variables/gen_z/worker/` (characters, triggers, stakes)
3. **Location Overlay:** `variables/locations/seattle.yaml` (transit, landmarks, food, weather)

**Hydration Process:**

```python
# Pseudocode
template = load("templates/anxiety/false_alarm/gen_z/recognition.md")
base_vars = load("variables/gen_z/worker/")
location_vars = load("variables/locations/seattle.yaml")

# Merge variables (location overrides base where applicable)
merged_vars = {**base_vars, **location_vars}

# Hydrate template
output = hydrate(template, merged_vars)
```

---

## Variable Mapping Table

### How Location YAML Fields Map to Template Variables

| Location YAML Field | Template Variable | Example |
|---------------------|-------------------|---------|
| `location.transit_scene[0]` | `{{location.transit}}` | "Link light rail" |
| `location.neighborhoods[0]` | `{{location.neighborhood}}` | "Capitol Hill" |
| `location.dwelling_type` | `{{location.dwelling}}` | "studio in Capitol Hill" |
| `location.cheap_food` | `{{location.cheap_food}}` | "Dick's burgers or teriyaki" |
| `location.expensive_food` | `{{location.expensive_food}}` | "craft coffee at Stumptown" |
| `location.weather_complaint` | `{{location.weather}}` | "constant drizzle and grey skies" |
| `location.landmarks[0]` | `{{location.landmark}}` | "Space Needle" |
| `location.city_name` | `{{location.city}}` | "Seattle" |
| `climate.signals[0]` | `{{location.climate_signal}}` | "atmospheric river warning" |

### Gen Alpha Specific

| Location YAML Field | Template Variable | Use Case |
|---------------------|-------------------|----------|
| `location.school_building[0]` | `{{location.school_spot}}` | "the hallway by the art room" |
| `location.digital_space[0]` | `{{location.online_space}}` | "the group chat" |

---

## Integration with Template System

### File Structure

```
SOURCE_OF_TRUTH/
├── templates/
│   └── anxiety/false_alarm/
│       ├── gen_z/                    # Gen Z templates
│       └── gen_alpha/                # Gen Alpha templates
│
├── variables/
│   ├── gen_z/
│   │   ├── worker/                   # Base worker variables
│   │   ├── student/                  # Base student variables
│   │   └── general/                  # Flexible base variables
│   │
│   ├── gen_alpha/
│   │   ├── school/                   # Base school variables
│   │   ├── sports/                   # Base sports variables
│   │   └── general/                  # Flexible base variables
│   │
│   └── locations/                    # Location overlays
│       ├── atlanta.yaml              ✅
│       ├── austin.yaml               ❌ MISSING
│       ├── beijing.yaml              ✅
│       ├── boston.yaml               ✅
│       ├── chicago.yaml              ✅
│       ├── cincinnati.yaml           ✅
│       ├── dc.yaml                   ✅
│       ├── houston.yaml              ✅
│       ├── london.yaml               ✅
│       ├── los_angeles.yaml          ✅
│       ├── melbourne.yaml            ✅
│       ├── nyc.yaml                  ❌ MISSING
│       ├── phoenix.yaml              ✅
│       ├── san_diego.yaml            ❌ MISSING
│       ├── san_francisco.yaml        ✅
│       ├── santa_barbara.yaml        ❌ MISSING
│       ├── seattle.yaml              ✅
│       ├── sydney.yaml               ❌ MISSING
│       ├── taipei.yaml               ❌ MISSING
│       ├── tainan.yaml               ❌ MISSING
│       ├── taiwan.yaml               ❌ MISSING
│       ├── toronto.yaml              ❌ MISSING
│       └── vancouver.yaml            ✅
```

---

## Persona Resolution Logic

```python
def resolve_persona(persona_id):
    """
    Given a persona_id like 'seattle_gen_z', resolve to:
    - template_set: which templates to use
    - base_variables: which base variable files to use
    - location_file: which location overlay to use
    """
    
    # Parse persona_id
    if persona_id.endswith('_gen_z'):
        generation = 'gen_z'
        location = persona_id.replace('_gen_z', '')
    elif persona_id.endswith('_gen_alpha'):
        generation = 'gen_alpha'
        location = persona_id.replace('_gen_alpha', '')
    else:
        # Non-location persona (e.g., 'healthcare_rns')
        return special_resolution(persona_id)
    
    # Determine base context
    if generation == 'gen_z':
        base_context = 'worker'  # Default to worker for Gen Z
    else:
        base_context = 'school'  # Default to school for Gen Alpha
    
    return {
        'template_set': f'templates/anxiety/false_alarm/{generation}/',
        'base_variables': f'variables/{generation}/{base_context}/',
        'location_file': f'variables/locations/{location}.yaml'
    }

# Examples
resolve_persona('seattle_gen_z')
# {
#   'template_set': 'templates/anxiety/false_alarm/gen_z/',
#   'base_variables': 'variables/gen_z/worker/',
#   'location_file': 'variables/locations/seattle.yaml'
# }

resolve_persona('boston_gen_alpha')
# {
#   'template_set': 'templates/anxiety/false_alarm/gen_alpha/',
#   'base_variables': 'variables/gen_alpha/school/',
#   'location_file': 'variables/locations/boston.yaml'
# }
```

---

## Next Steps

### Immediate: Copy Uploaded Files

1. Move the 14 uploaded location YAML files to `SOURCE_OF_TRUTH/variables/locations/`
2. Verify structure consistency

### Short-term: Create Missing Location Files (9)

Priority order:
1. 🔴 `nyc.yaml` - Major market
2. 🔴 `sydney.yaml` - Major market  
3. 🟡 `toronto.yaml` - Canadian market
4. 🟡 `austin.yaml` - Tech hub
5. 🟡 `san_diego.yaml` - California market
6. 🟡 `taipei.yaml` - Taiwan market
7. 🟢 `tainan.yaml` - Taiwan secondary
8. 🟢 `taiwan.yaml` - Generic Taiwan
9. 🟢 `santa_barbara.yaml` - California secondary

### Medium-term: Professional Personas (17)

Separate track - these need new template sets, not just location variables.

---

## Quick Reference

### What's Ready Now (28 personas)

**Gen Z (13):**
- `atlanta_gen_z`, `boston_gen_z`, `chicago_gen_z`, `cincinnati_gen_z`, `dc_gen_z`, `england_gen_z`, `houston_gen_z`, `london_gen_z`, `melbourne_gen_z`, `phoenix_gen_z`, `seattle_gen_z`, `sf_gen_z`, `vancouver_gen_z`

**Gen Alpha (15):**
- `atlanta_gen_alpha`, `boston_gen_alpha`, `chicago_gen_alpha`, `china_gen_alpha`, `cincinnati_gen_alpha`, `dc_gen_alpha`, `england_gen_alpha`, `houston_gen_alpha`, `la_gen_alpha`, `london_gen_alpha`, `melbourne_gen_alpha`, `phoenix_gen_alpha`, `seattle_gen_alpha`, `sf_gen_alpha`, `vancouver_gen_alpha`

### What Needs Location Files (18 personas)

**Gen Z (9):**
- `austin_gen_z`, `nyc_gen_z`, `san_diego_gen_z`, `santa_barbara_gen_z`, `sydney_gen_z`, `taipei_taiwan_gen_z`, `tainan_taiwan_gen_z`, `taiwan_gen_z`, `toronto_gen_z`

**Gen Alpha (9):**
- `austin_gen_alpha`, `nyc_gen_alpha`, `san_diego_gen_alpha`, `santa_barbara_gen_alpha`, `sydney_gen_alpha`, `taipei_taiwan_gen_alpha`, `tainan_taiwan_gen_alpha`, `taiwan_gen_alpha`, `toronto_gen_alpha`

---

*End of Location Variable Integration & Gap Analysis*
