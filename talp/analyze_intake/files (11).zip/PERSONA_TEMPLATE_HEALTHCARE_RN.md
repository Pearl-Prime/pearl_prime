# Persona Template Set: Healthcare RN

**Mechanism:** Autonomic Regulation  
**Engine:** False Alarm

---

## Persona Profile

**Role:** Registered Nurse (RN)  
**Settings:** Hospital (med-surg, ICU, ED, L&D), clinic, long-term care  
**Experience Range:** New grad to 20+ years  

**Core Context:**
- 12-hour shifts, rotating days/nights
- High-stakes environment — errors cost lives
- Constant interruptions, competing priorities
- Knows the physiology of stress but can't control their own
- Compassion fatigue is occupational hazard
- Must appear calm for patients and families regardless of internal state

**Core Anxiety Pattern:**
- Hypervigilance that doesn't turn off
- Body reacts to every alarm, call light, overhead page — even when most aren't emergencies
- Can't distinguish "real emergency" signal from "routine task" signal anymore
- Anxiety about making mistakes that harm patients
- Bringing work home — replaying shifts, checking the schedule app

**Stakes:**
- Patient safety (external, real)
- Professional license (external, real)
- Identity as competent caregiver (internal)
- Being seen as "not handling it" by peers

**Unique Tension:**
- They understand the HPA axis, know what cortisol does, can explain fight-or-flight to patients
- None of that knowledge helps when their own body won't stand down
- Medical knowledge becomes another source of frustration, not relief

**Language Register:**
- Clinical vocabulary available but not overused
- Direct, efficient communication style (trained into them)
- Dark humor as coping mechanism (but not in templates — keep it earnest)
- Practical, skeptical of "wellness" fluff

---

## Variable Files

```yaml
# variables/personas/healthcare_rn/characters.yaml

characters:
  - name: Sarah
    years_experience: 8
    unit: med-surg
    shift: nights
    title: staff nurse
    hospital_type: community hospital
    
  - name: Marcus
    years_experience: 3
    unit: ICU
    shift: days
    title: staff nurse
    hospital_type: academic medical center
    
  - name: Priya
    years_experience: 12
    unit: emergency department
    shift: rotating
    title: charge nurse
    hospital_type: level 1 trauma center
    
  - name: James
    years_experience: 5
    unit: cardiac step-down
    shift: nights
    title: staff nurse
    hospital_type: community hospital
    
  - name: Elena
    years_experience: 2
    unit: labor and delivery
    shift: days
    title: staff nurse
    hospital_type: women's hospital
    
  - name: David
    years_experience: 15
    unit: oncology
    shift: days
    title: clinical nurse specialist
    hospital_type: cancer center
```

```yaml
# variables/personas/healthcare_rn/locations.yaml

locations:
  - place: nurses station
    detail: the charting alcove between rooms 4 and 5
    unit_descriptor: the unit
    
  - place: break room
    detail: the chair by the window that nobody else uses
    unit_descriptor: the floor
    
  - place: supply room
    detail: between the IV pumps and the linen cart
    unit_descriptor: the department
    
  - place: parking garage
    detail: the third level where she always parks
    unit_descriptor: the hospital
    
  - place: car
    detail: still in scrubs, engine running
    unit_descriptor: work
    
  - place: med room
    detail: pulling meds for the 0600 pass
    unit_descriptor: the unit
    
  - place: hallway
    detail: outside room 12
    unit_descriptor: the floor
```

```yaml
# variables/personas/healthcare_rn/triggers.yaml

triggers:
  false_alarm:
    - event: call light
      sound: the familiar chime
      time: two hours into shift
      context: when she already had three things pending
      typical_reality: a request for ice chips
      
    - event: overhead page
      sound: the tone before an announcement
      time: middle of the night
      context: while charting at the station
      typical_reality: a routine page to pharmacy
      
    - event: monitor alarm
      sound: the beeping from down the hall
      time: during handoff
      context: a room that wasn't even hers
      typical_reality: a loose lead
      
    - event: phone buzzing
      sound: the Vocera going off
      time: just as she sat down to chart
      context: four patients, all stable
      typical_reality: a lab callback on a non-urgent result
      
    - event: charge nurse approaching
      sound: footsteps coming toward the station
      time: end of shift
      context: when she was almost done
      typical_reality: a routine question about tomorrow's schedule
      
    - event: rapid response alarm
      sound: the overhead announcement
      time: 3 AM
      context: not her patient, not her floor
      typical_reality: happened two units away
```

```yaml
# variables/personas/healthcare_rn/body_sensations.yaml

sensations:
  - primary: chest tighten
    secondary: breath catch
    related_action: hands pausing mid-task
    
  - primary: heart rate jump
    secondary: adrenaline hit
    related_action: already moving before thinking
    
  - primary: stomach clench
    secondary: jaw set
    related_action: scanning for the source
    
  - primary: whole body brace
    secondary: shoulders come up
    related_action: mentally running through her patients
    
  - primary: pulse spike
    secondary: hyperalert feeling
    related_action: checking the monitor bank reflexively
```

```yaml
# variables/personas/healthcare_rn/work_context.yaml

work_context:
  patient_loads:
    - "five patients tonight"
    - "a full assignment"
    - "six beds, two admits pending"
    - "the whole pod"
    
  shift_references:
    - "four hours left in a twelve"
    - "second night in a row"
    - "halfway through the stretch"
    - "just back from days off"
    
  peer_references:
    - "the day shift nurse"
    - "the charge nurse"
    - "the resident on call"
    - "the aide working her hall"
    - "the float nurse"
    
  common_tasks:
    - "charting"
    - "med pass"
    - "assessment rounds"
    - "hanging a new bag"
    - "waiting on a callback"
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Healthcare RN
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.years_experience}}
- {{character.unit}}
- {{character.shift}}
- {{trigger.event}}
- {{trigger.sound}}
- {{trigger.time}}
- {{trigger.context}}
- {{trigger.typical_reality}}
- {{body.primary}}
- {{body.secondary}}
- {{location.place}}
- {{work.patient_load}}

### Template

{{character.name}} had been a nurse for {{character.years_experience}} years.

Long enough to know the difference between a real emergency and everything else.
Long enough to trust her instincts when something was actually wrong.

But lately, her body wasn't making that distinction anymore.

The {{trigger.event}} came {{trigger.time}}—
{{trigger.context}}.

{{trigger.sound}}.

Her {{body.primary}}.
Then her {{body.secondary}}.

She was already halfway out of the chair before she registered what it was.

{{trigger.typical_reality}}.

Nothing urgent.
Nothing that should have made her body react like a code was called.

But it did.

And it wasn't just that one.
It was every alarm.
Every page.
Every set of footsteps coming toward the station.

Her body had stopped distinguishing between
the call light that means emergency
and the call light that means someone needs a blanket.

She knew the physiology.
She'd explained fight-or-flight to anxious patients a hundred times.
Adrenaline, cortisol, the HPA axis—she could draw the diagram.

None of that helped when her own nervous system
treated a loose telemetry lead like a patient coding.

{{work.patient_load}}.
All stable.
And still, {{character.name}} couldn't shake the feeling
that something was about to go wrong.

The worst part was pretending she was fine.
Smiling at families.
Keeping her voice steady during report.
Acting like she wasn't vibrating at a frequency
that had nothing to do with what was actually happening on the unit.

She couldn't exactly tell the charge nurse:
"Hey, my body thinks we're in a mass casualty event,
but also all my patients are fine and I have no reason to feel like this."

So she didn't.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Healthcare RN
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}
- {{body.secondary}}
- {{character.unit}}
- {{work.shift_reference}}

### Template

{{character.name}} had tried to fix it.

Breathe.
That's what she told patients.
Slow breaths.
In through the nose.

It worked on them.
It didn't work on her.

Or it worked a little—after.
Never during.
Never when the alarm first hit and her {{body.primary}}
before she even knew what room it was coming from.

She'd tried leaving work at work.
But her body brought it home anyway.
Lying in bed after a shift,
heart rate finally settling,
then the sound of a car alarm outside
and her {{body.secondary}} like she was back on the unit.

She'd tried the apps.
Five minutes of guided meditation in the break room,
earbuds in,
eyes closed,
and then the door opened and someone needed something
and her body was right back where it started.

She'd tried rationalizing.

*Most alarms aren't emergencies.*
*Most call lights are routine.*
*The monitor alarming down the hall isn't even your patient.*

Her brain understood.
Her body didn't care.

{{work.shift_reference}}.
{{character.unit}} was quiet.
And still her nervous system was running surveillance
like she was the only thing standing between
her patients and disaster.

The trying was exhausting.
The trying harder was worse.

Every strategy she used to manage it
became another thing to manage.

And underneath all the effort,
the alarm kept coming.
Right on cue.
Every time.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Healthcare RN
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.place}}
- {{location.detail}}
- {{body.primary}}
- {{body.secondary}}
- {{body.related_action}}

### Template

{{character.name}} was in the {{location.place}}—
{{location.detail}}—
when it happened again.

An alarm.
Her {{body.primary}}.
Her {{body.secondary}}.
{{body.related_action}}.

The whole sequence.

But this time, she didn't fight it.

She just noticed.

*There it is.*
*The spike.*
*Same as always.*

Not "why am I like this."
Not "I need to calm down before someone notices."
Just: *this is what my body does now.*

And something shifted.

The alarm turned out to be nothing.
Her body didn't know that yet.
But she did.

And for the first time,
she let there be a gap between the two.

Her body was doing its job.
It had been trained—by years of real emergencies, real codes,
real moments where the alarm meant something—
to respond fast, stay alert, keep scanning.

It wasn't broken.
It was *good at its job.*
Maybe too good.
Maybe unable to clock out when she did.

The spike wasn't a malfunction.
It was vigilance that hadn't learned
the difference between "possible emergency"
and "probably nothing."

That wasn't her fault.
That was her nervous system doing exactly what it was designed to do
in an environment where anything *could* be an emergency.

The alarm wasn't the problem.
Her relationship to the alarm was the problem.

She didn't need to stop the spike.
She needed to stop treating the spike like proof
that something was wrong with her.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Healthcare RN
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{trigger.event}}
- {{trigger.sound}}
- {{character.unit}}
- {{body.primary}}
- {{location.unit_descriptor}}

### Template

The alarms didn't stop.

{{character.name}} wasn't pretending they did.

Every {{trigger.event}} still made her {{body.primary}}.
{{trigger.sound}} still triggered the same initial hit.

That was probably permanent.
That was probably what years of {{character.unit}} did to a nervous system.

But something had changed in what happened after.

Before, it was:
alarm → spike → panic about the spike → try to suppress it → exhaustion

Now it was:
alarm → spike → *okay, that's the spike* → check the situation → move on

One layer instead of three.

She stopped expecting herself to be calm.
She started letting herself be alert and okay at the same time.

Some shifts were still hard.
Some spikes still felt like too much.
But she'd stopped adding the second layer—
the judgment,
the "why can't I handle this,"
the performance of being fine.

Her body was going to do what it was going to do.
She could let it do that
without believing it meant she was failing.

The other night, a rapid response got called
two units away.
Not her patient.
Not her floor.
Her body reacted anyway.

And she let it.

Noticed the spike.
Didn't chase it.
Went back to charting.

It wasn't a cure.
It wasn't even really calm.
But it was different.

She was still a nurse who felt everything.
She just wasn't a nurse who was at war with feeling it anymore.

That turned out to be enough.
Not fixed.
Functional.

And honestly—
after {{character.years_experience}} years in {{location.unit_descriptor}}—
functional was more than most people managed.
```

---

## Quality Validation Checklist

### Recognition
- [x] Identity anchor: "nurse for X years," specific unit, shift
- [x] Internal stakes: professional competence, being seen as not handling it
- [x] Somatic activation: chest tighten, heart rate jump, body bracing
- [x] No reframe language ✓
- [x] No insight claims ✓
- [x] No relief signals ✓
- [x] No forbidden phrases ✓
- [x] Persona-specific: alarms, call lights, charting, charge nurse, HPA axis knowledge

### Mechanism Proof
- [x] Constraint loop: trying to control it makes it worse
- [x] Repeated failure: breathing doesn't work during, apps interrupted, rationalizing fails
- [x] Pattern language: "every alarm," "every time"
- [x] No instructions ✓
- [x] No technique names ✓
- [x] No resolution ✓
- [x] Persona-specific: break room meditation, explaining fight-or-flight to patients

### Turning Point
- [x] Exactly one meaning inversion: "The alarm isn't the problem. Her relationship to the alarm was the problem."
- [x] Interpretation shift: vigilance as competence, not malfunction
- [x] No full resolution ✓
- [x] No mastery claims ✓
- [x] No permanence language ✓
- [x] Persona-specific: "trained by years of real emergencies"

### Embodiment
- [x] Relational shift: one layer instead of three
- [x] Lived example: rapid response two units away, let it happen, went back to charting
- [x] Ongoing/imperfect framing: "That was probably permanent," "Some shifts were still hard"
- [x] No cure language ✓
- [x] No permanence claims ✓
- [x] Persona-specific: "functional" as the realistic goal

---

## Mechanism Signals Check

**Required signals present:**

| Signal Category | Examples in Templates |
|-----------------|----------------------|
| settling_language | "she let it," "didn't chase it," "went back to charting" |
| body_awareness_language | "chest tighten," "heart rate jump," "spike," "body bracing" |

**Forbidden signals absent:**

| Signal Category | Status |
|-----------------|--------|
| certainty_dependent_language | ✓ Not present |
| control_success_language | ✓ Not present |
| cure_language | ✓ Not present |

---

## Voice Profile Summary

| Element | Healthcare RN |
|---------|---------------|
| Knowledge of anxiety | High (clinical) — but it doesn't help |
| Self-awareness | Practical, frustrated |
| Coping attempts | Breathing (teaches it to patients), apps (interrupted), rationalizing |
| Stakes | Patient safety, license, professional identity |
| Vocabulary | Clinical available but not overused, efficient |
| Relationship to mental health | Knows the science, skeptical of "wellness" |
| Insight framing | "Trained by years of real emergencies," "good at its job" |
| Resolution framing | "Functional" — realistic, not idealistic |
| Unique tension | Knows the physiology, can't apply it to self |

---

## Location Variants (Variables Only)

Same templates work for all healthcare settings. Only variables change:

| Setting | Variable Differences |
|---------|---------------------|
| **Hospital Med-Surg** | Call lights, med passes, admits, discharges |
| **ICU** | Vent alarms, drip titrations, codes more common |
| **Emergency Department** | Triage, ambulance arrivals, trauma alerts |
| **Labor & Delivery** | Fetal monitor alarms, decels, stat sections |
| **Oncology** | Chemo protocols, family conferences, end of life |
| **Outpatient/Clinic** | Phone triage, prior auths, inbox messages |
| **Long-term Care** | Falls, family complaints, staffing |

Each setting gets its own variable files. Same templates serve all.

---

*End of Healthcare RN Template Set*
