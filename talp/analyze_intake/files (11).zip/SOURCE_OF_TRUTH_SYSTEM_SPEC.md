# SOURCE_OF_TRUTH: Therapeutic Audiobook System Specification

**Version:** 1.0  
**Status:** Production-Ready  
**Last Updated:** January 2026

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Philosophy](#2-system-philosophy)
3. [Architecture Overview](#3-architecture-overview)
4. [Core Concepts](#4-core-concepts)
5. [Mechanism Registry](#5-mechanism-registry)
6. [Atom Role Contracts](#6-atom-role-contracts)
7. [Chapter Arc Planning](#7-chapter-arc-planning)
8. [Exercise Alignment](#8-exercise-alignment)
9. [Content Type to Role Mapping](#9-content-type-to-role-mapping)
10. [Signal Dictionaries](#10-signal-dictionaries)
11. [Validation Stack](#11-validation-stack)
12. [Persona Templates](#12-persona-templates)
13. [Variable System](#13-variable-system)
14. [Canonical Exemplars](#14-canonical-exemplars)
15. [Implementation Checklist](#15-implementation-checklist)
16. [Appendix: Complete YAML Schemas](#16-appendix-complete-yaml-schemas)

---

## 1. Executive Summary

### What This System Is

SOURCE_OF_TRUTH is a therapeutic audiobook generation system that produces deeply resonant, persona-specific content at scale. It combines:

- **Mechanism-based psychology** (what actually changes in the listener)
- **Narrative arc structure** (how transformation unfolds over time)
- **Persona-specific voice** (how it sounds to this particular listener)
- **Exercise integration** (practices that reinforce story-delivered insights)

### Core Design Principle

> **Stories are deliberate psychological operations.**  
> If nothing shifts in how the listener understands themselves, the story failed—even if it was well written.

### The Key Insight

A self-help story is not a vignette. It's not "relatable content." It's a planned journey with:

- **Stakes** (what's at risk if the pattern continues)
- **Constraint** (why the listener's current strategy can't work)
- **Twist** (a meaning inversion that reorganizes understanding)
- **Direction** (a new relationship to the problem, not a cure)

### System Guarantee

When this system works correctly, the listener experiences the same internal shift twice:

1. **Emotionally** — through the story
2. **Practically** — through the exercise

This is how therapeutic learning sticks.

---

## 2. System Philosophy

### What We're Building

We are building **transformational audio**, not a content factory.

This means:

- Fewer templates, higher emotional fidelity
- Persona-specific voice, not generic "relatable" prose
- Planned narrative arcs, not assembled vignettes
- Exercises that feel earned, not assigned

### The Three Places Meaning Can Live

1. **In prose** — written voice, rhythm, metaphor (templates)
2. **In variables** — injected text blocks (anchors only)
3. **In planning** — arc + intent chosen before generation

**Rule:** Meaning should NOT live in variables. Variables are for facts and anchors, not transformation.

### The Two Failures We're Preventing

**Failure 1: Good Atoms, Bad Books**
- Individually strong moments that don't connect
- Missing setup, missing handoff, missing destination
- Listener feels the seams

**Failure 2: Technically Valid, Emotionally Dead**
- Content that passes validation but doesn't move people
- Over-abstracted, persona-agnostic prose
- "Works okay for everyone" instead of "works deeply for this person"

### The Quality Bar

Ask this of any output:

> "Would I be proud to publish this under my own name, knowing a firefighter or student might listen alone at night?"

If yes → ship it.  
If no → regenerate.

---

## 3. Architecture Overview

### System Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    DESIGN TIME (LLM)                        │
│  - Mechanism definitions                                    │
│  - Canonical exemplars                                      │
│  - Role contracts                                           │
│  - Signal dictionaries                                      │
│  - Exercise mappings                                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
                         [FROZEN]
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    PLANNING (Deterministic)                 │
│  - Chapter arc planning                                     │
│  - Mechanism selection                                      │
│  - Exercise alignment                                       │
│  - Atom role assignment                                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    GENERATION (Template-Based)              │
│  - Persona template selection                               │
│  - Variable hydration                                       │
│  - Content assembly                                         │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    VALIDATION (Deterministic)               │
│  - Role compliance                                          │
│  - Mechanism consistency                                    │
│  - Prohibited content                                       │
│  - Resolution timing                                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    AUDIT (LLM, Offline)                     │
│  - Qualitative feel                                         │
│  - Voice drift detection                                    │
│  - Sample-based review                                      │
└─────────────────────────────────────────────────────────────┘
```

### Key Principle: LLM as Architect, Not Contractor

- **LLMs design the system** (one-time, expensive, careful)
- **Deterministic processes run the system** (always-on, fast, reliable)
- **LLMs audit the system** (offline, sample-based, flags only)

The LLM is never in the critical path at runtime.

---

## 4. Core Concepts

### The Hierarchy (Canonical)

| Level | Owns | Responsibility |
|-------|------|----------------|
| **Mechanism** | Truth | What changes in the listener |
| **Arc** | Direction | How we get there across time |
| **Atom Role** | Delivery | What this moment does |
| **Template** | Voice | How it sounds to this persona |

### Key Definitions

**Mechanism**  
The internal shift a chapter is engineering. Not advice. Not mood improvement. A change in the listener's relationship to their experience.

**Arc**  
A planned sequence of atom roles that moves the listener through recognition → proof → twist → re-orientation.

**Atom**  
A discrete unit of content (~80-200 words) that serves a specific role in an arc.

**Role**  
The narrative function an atom performs (Recognition, Mechanism Proof, Turning Point, Embodiment).

**Content Type**  
The material an atom uses (crisis, pattern, reframe, practice, reflection).

**Template**  
Persona-specific prose that expresses an atom role in a particular voice.

**Variable**  
A data point injected into a template (names, places, triggers, timing).

### Two Orthogonal Dimensions

**Arc Role** (what the atom does):
- Recognition
- Mechanism Proof
- Turning Point
- Embodiment

**Content Type** (what the atom talks about):
- Crisis
- Pattern
- Reframe
- Practice
- Reflection

These are **not** the same taxonomy. The planner selects by **role first**, then checks **content compatibility**.

---

## 5. Mechanism Registry

### Purpose

The mechanism registry answers one question:

> **What internal shift is this chapter engineering?**

### Design Rules

1. Mechanisms are **finite** (closed set)
2. Each mechanism has a **false belief** and **true reframe**
3. Exercises **support** mechanisms, never define them
4. One mechanism per chapter (primary), optional secondary

### File: `mechanisms.yaml`

```yaml
version: 1.0
status: locked

mechanisms:

  autonomic_regulation:
    label: "Autonomic Regulation"
    core_shift: "The body can downshift without certainty or resolution."
    
    false_belief:
      - "I must understand the threat to calm down."
      - "If my body is activated, something is wrong."
    
    true_reframe:
      - "Activation is not danger."
      - "Safety can be felt before certainty."
    
    somatic_signature:
      - elevated heart rate
      - shallow breathing
      - muscular readiness
      - scanning behavior
    
    cognitive_distortions:
      - catastrophizing
      - hypervigilance
      - urgency bias
    
    story_proof_requirements:
      - shows activation without real danger
      - shows failed control attempt
      - shows settling without solving the problem
    
    signal_categories:
      required:
        - settling_language
        - body_awareness_language
      forbidden:
        - certainty_dependent_language
        - control_success_language
    
    compatible_exercises:
      - box_breathing
      - paced_exhale
      - grounding_touch
      - temperature_shift
      - physiological_sigh

  cognitive_defusion:
    label: "Cognitive Defusion"
    core_shift: "Thoughts can be present without being obeyed."
    
    false_belief:
      - "If I think it, it must be important."
      - "Thoughts require action."
    
    true_reframe:
      - "Thoughts are events, not instructions."
      - "I can notice without engaging."
    
    somatic_signature:
      - mental looping
      - pressure in head or chest
      - compulsive checking
    
    cognitive_distortions:
      - rumination
      - thought-fusion
      - mind-reading
    
    story_proof_requirements:
      - shows a thought repeating
      - shows the cost of believing it
      - shows distance without suppression
    
    signal_categories:
      required:
        - observer_stance_language
        - thought_distance_language
      forbidden:
        - thought_control_language
        - suppression_language
    
    compatible_exercises:
      - labeling_thoughts
      - thought_externalization
      - name_the_story
      - leaves_on_stream

  exposure_tolerance:
    label: "Exposure & Tolerance"
    core_shift: "Discomfort can be survived without avoidance."
    
    false_belief:
      - "If I feel this, I will break."
      - "Avoidance is protection."
    
    true_reframe:
      - "Avoidance feeds the fear."
      - "Staying changes the signal."
    
    somatic_signature:
      - urge to escape
      - agitation
      - anticipatory anxiety
    
    cognitive_distortions:
      - avoidance
      - safety-seeking behaviors
      - overestimation of harm
    
    story_proof_requirements:
      - shows avoidance pattern
      - shows short-term relief / long-term cost
      - shows staying without catastrophe
    
    signal_categories:
      required:
        - staying_language
        - survivability_language
      forbidden:
        - escape_success_language
        - avoidance_justified_language
    
    compatible_exercises:
      - graded_exposure
      - urge_surfing
      - values_based_action
      - approach_micro_step

  self_trust_repair:
    label: "Self-Trust Repair"
    core_shift: "I can trust my responses even when they are imperfect."
    
    false_belief:
      - "My reactions mean I'm broken."
      - "I shouldn't feel this way."
    
    true_reframe:
      - "My system learned this for a reason."
      - "Protection ≠ failure."
    
    somatic_signature:
      - shame
      - self-judgment
      - collapse or frustration
    
    cognitive_distortions:
      - self-blame
      - identity fusion
      - emotional reasoning
    
    story_proof_requirements:
      - shows judgment toward self
      - reframes reaction as learned protection
      - restores dignity without denial
    
    signal_categories:
      required:
        - self_compassion_language
        - protection_reframe_language
      forbidden:
        - self_blame_language
        - brokenness_language
    
    compatible_exercises:
      - compassionate_reframe
      - inner_dialogue
      - protective_part_naming
      - self_compassion_pause
```

### Extension Rules

Do **not** add a fifth mechanism unless you encounter exercises that:

- Do NOT involve sensation
- Do NOT involve cognition
- Do NOT involve tolerance
- Do NOT involve trust repair

If that happens, and purely re-anchor identity or purpose, then add a new mechanism.

### Values Overlay

Values-based work (values clarification, committed action) is **not** a standalone mechanism. It's an **overlay** that binds to existing mechanisms.

Encode in chapter plans:

```yaml
values_overlay:
  present: true
  function: "direction_without_symptom_resolution"
  binds_to:
    - exposure_tolerance
    - self_trust_repair
```

**Rule:** Mechanisms change the nervous system's relationship to sensation. Values give the nervous system a reason to stop fighting.

---

## 6. Atom Role Contracts

### Purpose

Defines what each atom role is **allowed to do**, what it **must do**, and what it **must never do**.

This is a **hard contract** the validator enforces.

### Design Principles

1. Roles are **delivery functions**, not content types
2. Roles are **orthogonal** to topic, persona, and exercise
3. No role is allowed to "finish the story" early
4. Cure, mastery, or permanence are **never allowed anywhere**

### File: `atom_role_contracts.yaml`

```yaml
version: 1.0
status: locked
enforcement: hard

# Resolution levels enforce monotonic progression
# 0 = no resolution, 3 = maximum allowed resolution
# Each atom's level must be >= previous atom's level

roles:

  recognition:
    intent:
      primary: establish_identity_and_cost
      secondary: somatic_activation_without_relief
    
    resolution_level: 0
    
    must_include:
      - identity_anchor          # Who this person is in their world
      - internal_stakes          # What they stand to lose
      - somatic_activation       # Body sensations present
    
    allowed:
      - confusion
      - vigilance
      - rumination
      - failed_coping_attempts
      - self_doubt
      - pattern_beginning
    
    must_not_include:
      - reframe_language
      - insight_claims
      - lesson_language
      - exercise_instructions
      - improvement_signals
      - permanence_claims
      - relief_signals
    
    forbidden_phrases:
      - "this was actually"
      - "I realized"
      - "the truth was"
      - "once I understood"
      - "what mattered was"
      - "after that"
      - "everything changed"
      - "it finally made sense"
    
    handoff_to_next:
      allowed: [tension_sustain, question_open]
      forbidden: [closure, relief_hint]

  mechanism_proof:
    intent:
      primary: prove_mechanism_via_failed_control
      secondary: destabilize_old_explanation
    
    resolution_level: 1
    
    must_include:
      - constraint_loop          # Why current strategy fails
      - repeated_failure         # Trying harder doesn't help
      - pattern_language         # This is recognizable
    
    allowed:
      - frustration
      - escalation
      - hypervigilance
      - effort_increase
      - partial_awareness
      - "designed not broken" framing
    
    must_not_include:
      - instructions
      - named_techniques
      - step_sequences
      - relief_claims
      - meaning_inversion       # Not yet - that's turning_point
      - solution_language
    
    forbidden_phrases:
      - "so I did"
      - "the solution was"
      - "what fixed it"
      - "then I tried"
      - "the answer is"
      - "this works because"
      - "the trick is"
    
    handoff_to_next:
      allowed: [frustration_peak, opening_for_shift]
      forbidden: [resolution, relief]

  turning_point:
    intent:
      primary: meaning_inversion
      secondary: reorient_relationship
    
    resolution_level: 2
    
    must_include:
      - reframe_language         # The twist
      - interpretation_shift     # Old meaning → new meaning
    
    allowed:
      - surprise
      - hesitation
      - partial_relief
      - emotional_softening
      - exercise_reference       # Can hint at practice
    
    must_not_include:
      - full_resolution
      - mastery_claims
      - permanence_claims
      - future_certainty
      - instructional_steps
    
    forbidden_phrases:
      - "from then on"
      - "never again"
      - "it stopped"
      - "I was cured"
      - "problem solved"
      - "finally free"
      - "completely gone"
    
    constraints:
      - exactly_one_meaning_inversion  # Not zero, not multiple
    
    handoff_to_next:
      allowed: [new_orientation, tentative_application]
      forbidden: [triumph, completion]

  embodiment:
    intent:
      primary: enact_new_relationship
      secondary: stabilize_without_closing
    
    resolution_level: 3
    
    must_include:
      - relational_shift         # Different relationship to trigger
      - lived_example            # Showing, not telling
      - grounded_presence        # In the body, in the moment
    
    allowed:
      - uncertainty
      - nonlinearity
      - partial_setbacks
      - ongoing_practice_reference
      - values_language          # Can connect to meaning
    
    must_not_include:
      - cure_language
      - permanence_claims
      - guarantees
      - universal_promises
    
    forbidden_phrases:
      - "this will always"
      - "you will never"
      - "permanently"
      - "completely fixed"
      - "no longer have to"
      - "the anxiety is gone"
    
    handoff_to_next:
      allowed: [direction, ongoing_practice]
      forbidden: [finality, cure]

# Global rules that apply to ALL roles
global_forbidden:
  cure_language:
    - "cured"
    - "healed completely"
    - "eliminated"
    - "fixed forever"
    - "no more anxiety"
  
  instructional_language:
    - "step one"
    - "first you"
    - "then do"
    - "repeat this"
    - "the technique is"
  
  diagnostic_claims:
    - "this means you have"
    - "a sign of disorder"
    - "clinical"
    - "diagnosis"
  
  authority_claims:
    - "experts say"
    - "science proves"
    - "research shows"  # Unless actually citing
  
  technique_names_in_story:
    - "box breathing"
    - "CBT"
    - "exposure therapy"
    - "grounding exercise"

# Arc-level rules
arc_rules:
  progression_order:
    - recognition
    - mechanism_proof
    - turning_point
    - embodiment
  
  constraints:
    - resolution_level_must_increase_monotonically
    - no_role_skipping_without_declared_variant
    - no_duplicate_turning_points
    - embodiment_must_be_last
    - recognition_must_be_first
```

### Arc Variants

The contracts assume a 4-role full arc. Condensed arcs are valid with explicit declaration.

```yaml
arc_variants:
  full:
    roles: [recognition, mechanism_proof, turning_point, embodiment]
    min_atoms: 4
    
  condensed:
    roles: [recognition, turning_point, embodiment]
    min_atoms: 3
    note: "Use when mechanism was established in prior chapter"
    
  micro:
    roles: [recognition, turning_point]
    min_atoms: 2
    note: "Use for brief reorientation moments"
```

The planner **must declare** which variant it's using.

---

## 7. Chapter Arc Planning

### Purpose

The chapter arc plan is the **complete planning object** the system reasons over. It answers:

- What mechanism are we engineering?
- Which arc variant are we using?
- What's the narrative intent at each beat?
- How do atoms connect?
- Where does the exercise land?
- What does success look like?
- What's forbidden?

### File: `chapter_arc_plan.yaml` (Schema)

```yaml
# ============================================================
# CHAPTER ARC PLAN SCHEMA
# ============================================================
# This is the input the planner consumes.
# One file per chapter.
# ============================================================

chapter_id: string                    # Unique identifier (e.g., "ch03_false_alarm")

# ------------------------------------------------------------
# TOPIC & ENGINE
# ------------------------------------------------------------
topic: string                         # e.g., "anxiety", "grief", "burnout"
engine: string                        # Story engine (e.g., "false_alarm", "loop")

# ------------------------------------------------------------
# PERSONA
# ------------------------------------------------------------
persona:
  primary: string                     # Required: "firefighter", "student", "executive"
  secondary: string | null            # Optional: for future multi-persona support

# ------------------------------------------------------------
# MECHANISM
# ------------------------------------------------------------
mechanism:
  name: string                        # Must match mechanisms.yaml key
  description: string                 # Human-readable summary of the shift

# ------------------------------------------------------------
# VALUES OVERLAY (Optional)
# ------------------------------------------------------------
values_overlay:
  present: boolean
  function: string                    # e.g., "direction_without_symptom_resolution"
  binds_to: [string]                  # Mechanisms this overlay enhances
  note: string | null                 # Implementation notes

# ------------------------------------------------------------
# ARC STRUCTURE
# ------------------------------------------------------------
arc_variant:
  name: string                        # "full" | "condensed" | "micro"
  roles: [string]                     # Ordered list of roles in this arc

# ------------------------------------------------------------
# NARRATIVE INTENT
# ------------------------------------------------------------
arc_intent:
  setup_stakes: string                # What's at risk (identity, trust, agency)
  constraint: string                  # Why current strategy fails
  somatic_peak: string                # Where body activation is highest
  twist: string                       # The meaning inversion
  reorientation: string               # The new relationship (not cure)

# ------------------------------------------------------------
# HANDOFF CONFIGURATION
# ------------------------------------------------------------
handoff_intent:
  continuity: string                  # "escalating" | "stabilizing" | "reorienting"
  reference_previous: boolean         # Should atoms reference prior content?

# ------------------------------------------------------------
# EXERCISE ALIGNMENT
# ------------------------------------------------------------
exercise_alignment:
  primary_exercise:
    id: string                        # Must match exercise registry
    category: string                  # "somatic" | "cognitive" | "behavioral" | "values"
    mechanism_supports: string        # Must match chapter mechanism
    placement: string                 # "after_mechanism_proof" | "after_turning_point" | etc.
    narrative_role: string            # What the exercise proves in context
  
  secondary_exercises: [              # Optional additional exercises
    {
      id: string,
      category: string,
      placement: string
    }
  ]

# ------------------------------------------------------------
# ATOM PLAN
# ------------------------------------------------------------
atom_plan: [
  {
    role: string                      # Must match atom_role_contracts.yaml
    content_compatibility: [string]   # Allowed content types for this role
    constraints: {                    # Chapter-specific constraints (can tighten, not loosen)
      # Positive constraints
      must_show: [string] | null
      allows_exercise_reference: boolean | null
      allows_values_language: boolean | null
      
      # Negative constraints
      no_insight: boolean | null
      no_exercise: boolean | null
      no_resolution: boolean | null
      no_mastery_language: boolean | null
      no_cure_framing: boolean | null
    }
  }
]

# ------------------------------------------------------------
# SUCCESS CRITERIA
# ------------------------------------------------------------
success_criteria:
  listener_shift: [string]            # What the listener should understand/feel after
  forbidden_outcomes: [string]        # What must NOT be implied
```

### Example: Complete Chapter Plan

```yaml
chapter_id: ch03_false_alarm_autonomic

topic: anxiety
engine: false_alarm

persona:
  primary: firefighter
  secondary: null

mechanism:
  name: autonomic_regulation
  description: >
    The nervous system can activate without real danger,
    and can settle without certainty or control.

values_overlay:
  present: true
  function: direction_without_symptom_resolution
  binds_to:
    - autonomic_regulation
  note: >
    Values give the listener a reason to stop fighting the alarm,
    not a way to eliminate it.

arc_variant:
  name: full
  roles:
    - recognition
    - mechanism_proof
    - turning_point
    - embodiment

arc_intent:
  setup_stakes: >
    Loss of trust in a body that must stay reliable to protect others.
  constraint: >
    Trying harder to control or pre-empt the alarm increases activation.
  somatic_peak: >
    Activation during station tones without real emergency.
  twist: >
    The alarm is a preparedness response, not a threat signal.
  reorientation: >
    I don't need to stop the alarm — I need to land after it.

handoff_intent:
  continuity: escalating
  reference_previous: true

exercise_alignment:
  primary_exercise:
    id: box_breathing
    category: somatic
    mechanism_supports: autonomic_regulation
    placement: after_mechanism_proof
    narrative_role: >
      Demonstrates settling without solving or suppressing sensation.
  secondary_exercises:
    - id: reflection_checkin
      category: cognitive
      placement: after_embodiment

atom_plan:
  - role: recognition
    content_compatibility:
      - crisis
      - pattern
    constraints:
      no_insight: true
      no_exercise: true
      must_show:
        - body_activation
        - identity_stakes

  - role: mechanism_proof
    content_compatibility:
      - pattern
      - reframe
    constraints:
      must_show:
        - activation_without_danger
        - failed_control_attempt
      no_resolution: true

  - role: turning_point
    content_compatibility:
      - reframe
      - practice_reference
    constraints:
      allows_exercise_reference: true
      no_mastery_language: true

  - role: embodiment
    content_compatibility:
      - reflection
      - integration
    constraints:
      allows_values_language: true
      no_cure_framing: true

success_criteria:
  listener_shift:
    - recognizes alarms as non-danger
    - stops escalating control attempts
    - allows settling without certainty
  forbidden_outcomes:
    - symptom elimination promises
    - permanent calm framing
    - technique-as-solution framing
```

---

## 8. Exercise Alignment

### Core Principle

Stories and exercises share a **mechanism**, not a script.

- **Story** = why this shift is possible (makes it believable)
- **Exercise** = how to practice the shift (makes it repeatable)

### The Danger to Avoid

If done naïvely:

> "Marc tried box breathing. It worked. He felt better."

This is:
- Instructional
- Shallow
- Unbelievable
- Emotionally dead in audio

### The Correct Relationship

**Stories never teach exercises.**  
**Stories mirror outcome, not method.**  
**Exercises reinforce what stories made believable.**

The listener should think:

> "Oh… this is the same thing that just happened in the story."

### Exercise-Story Coupling Rules

**Rule A: Stories never teach exercises**

❌ "He slowed his breathing, counting four in, four out"  
✅ "His breath found a slower rhythm on its own"

**Rule B: Stories mirror outcome, not method**

| Mechanism | Story Shows |
|-----------|-------------|
| autonomic_regulation | breath slows, muscles soften |
| cognitive_defusion | thoughts repeat, lose grip |
| exposure_tolerance | fear predicted X, X didn't happen |
| self_trust_repair | self-judgment softens, dignity restored |

**Rule C: Exercises reinforce what story made believable**

The listener should feel the shift *before* they're asked to practice it.

### File: `exercise_registry.yaml`

```yaml
version: 1.0

exercises:

  # SOMATIC / AUTONOMIC
  box_breathing:
    category: somatic
    mechanism: autonomic_regulation
    secondary_mechanism: null
    story_roles: [turning_point, embodiment]
    narrative_function: "Demonstrates settling without certainty"
    placement_options: [after_mechanism_proof, after_turning_point]
    
  paced_exhale:
    category: somatic
    mechanism: autonomic_regulation
    story_roles: [embodiment]
    narrative_function: "Shows body can downshift through breath"
    
  grounding_touch:
    category: somatic
    mechanism: autonomic_regulation
    secondary_mechanism: cognitive_defusion
    story_roles: [turning_point, embodiment]
    narrative_function: "Anchors attention in present sensation"
    
  physiological_sigh:
    category: somatic
    mechanism: autonomic_regulation
    story_roles: [turning_point]
    narrative_function: "Quick nervous system reset"

  # COGNITIVE
  labeling_thoughts:
    category: cognitive
    mechanism: cognitive_defusion
    story_roles: [mechanism_proof, turning_point]
    narrative_function: "Creates distance from thought content"
    
  thought_externalization:
    category: cognitive
    mechanism: cognitive_defusion
    story_roles: [turning_point]
    narrative_function: "Separates self from thought"
    
  name_the_story:
    category: cognitive
    mechanism: cognitive_defusion
    story_roles: [mechanism_proof, turning_point]
    narrative_function: "Recognizes recurring narrative pattern"

  # BEHAVIORAL / EXPOSURE
  graded_exposure:
    category: behavioral
    mechanism: exposure_tolerance
    story_roles: [embodiment]
    narrative_function: "Proves discomfort is survivable"
    
  urge_surfing:
    category: behavioral
    mechanism: exposure_tolerance
    secondary_mechanism: autonomic_regulation
    story_roles: [turning_point, embodiment]
    narrative_function: "Shows urges pass without acting"
    
  values_based_action:
    category: behavioral
    mechanism: exposure_tolerance
    secondary_mechanism: self_trust_repair
    story_roles: [embodiment]
    narrative_function: "Connects action to meaning, not comfort"

  # SELF-COMPASSION
  compassionate_reframe:
    category: values
    mechanism: self_trust_repair
    story_roles: [turning_point, embodiment]
    narrative_function: "Replaces judgment with understanding"
    
  protective_part_naming:
    category: values
    mechanism: self_trust_repair
    story_roles: [mechanism_proof, turning_point]
    narrative_function: "Honors the function of the response"
    
  self_compassion_pause:
    category: values
    mechanism: self_trust_repair
    story_roles: [embodiment]
    narrative_function: "Creates space for self-kindness"
```

### Exercise Alignment Validation

```python
def validate_exercise_alignment(chapter_plan, story_atoms):
    """
    Ensures story-exercise coupling is correct.
    """
    exercise = chapter_plan.exercise_alignment.primary_exercise
    mechanism = chapter_plan.mechanism.name
    
    # Rule 1: Exercise must support chapter mechanism
    assert exercise.mechanism_supports == mechanism, \
        f"Exercise {exercise.id} doesn't support mechanism {mechanism}"
    
    # Rule 2: Story must show outcome, not method
    for atom in story_atoms:
        assert not contains_technique_name(atom.text, exercise.id), \
            f"Story atom contains exercise name '{exercise.id}'"
        assert not contains_instruction_language(atom.text), \
            "Story atom contains instructional language"
    
    # Rule 3: Mechanism signals must be present
    mechanism_def = MECHANISMS[mechanism]
    required_signals = mechanism_def.signal_categories.required
    
    story_text = " ".join([a.text for a in story_atoms])
    for signal_category in required_signals:
        assert has_signal(story_text, signal_category), \
            f"Story missing required signal category: {signal_category}"
    
    return True
```

---

## 9. Content Type to Role Mapping

### The Two Dimensions

**Arc Role** = what the atom does in the story  
**Content Type** = what material the atom uses

These are orthogonal but have default mappings.

### File: `content_role_map.yaml`

```yaml
version: 1.0

content_types:

  crisis:
    description: "Acute activation moment, body in alarm"
    default_role: recognition
    allowed_roles:
      - recognition
    forbidden_roles:
      - turning_point
      - embodiment
    
  pattern:
    description: "Recurring loop or familiar trap"
    default_role: mechanism_proof
    allowed_roles:
      - recognition
      - mechanism_proof
    forbidden_roles:
      - embodiment
    
  reframe:
    description: "New interpretation or meaning shift"
    default_role: turning_point
    allowed_roles:
      - mechanism_proof
      - turning_point
    forbidden_roles:
      - recognition
    
  practice:
    description: "Skill application or exercise reference"
    default_role: embodiment
    allowed_roles:
      - turning_point
      - embodiment
    forbidden_roles:
      - recognition
      - mechanism_proof
    
  reflection:
    description: "Integration and ongoing relationship"
    default_role: embodiment
    allowed_roles:
      - embodiment
    forbidden_roles:
      - recognition
      - mechanism_proof
      - turning_point
```

### Selection Rule

The planner:

1. Determines required **role** from arc position
2. Checks **content_compatibility** in atom_plan
3. Selects atoms where:
   - Content type is in compatibility list
   - Role contract is satisfied
   - Mechanism alignment is valid

```python
def select_atom(role, chapter_plan):
    """
    Select an atom for a given role.
    """
    role_spec = chapter_plan.atom_plan[role]
    compatible_types = role_spec.content_compatibility
    
    candidates = []
    for atom in ATOM_LIBRARY:
        if atom.content_type not in compatible_types:
            continue
        if not role_allows_content(role, atom.content_type):
            continue
        if not passes_role_contract(atom, role):
            continue
        if not mechanism_compatible(atom, chapter_plan.mechanism):
            continue
        candidates.append(atom)
    
    return select_best(candidates, chapter_plan.persona)
```

---

## 10. Signal Dictionaries

### Purpose

Signal dictionaries map **semantic categories** to **surface-level patterns** for validation.

This prevents:
- False negatives from literal string matching
- Over-penalizing good writing
- Incentivizing awkward phrasing

### Design Principle

Validators check:
- *Presence of any signal in category X*
- *Absence of any signal in category Y*

### File: `signal_dictionaries.yaml`

```yaml
version: 1.0

# ============================================================
# POSITIVE SIGNALS (things we want to see)
# ============================================================

settling_language:
  description: "Body downshifting without forced control"
  patterns:
    - "breath slowed"
    - "breathing came easier"
    - "shoulders dropped"
    - "chest loosened"
    - "space returned"
    - "the moment passed"
    - "something shifted"
    - "quieter"
    - "softer"
    - "muscles released"
    - "settled"
    - "landed"
    - "eased"

body_awareness_language:
  description: "Noticing physical sensations"
  patterns:
    - "chest"
    - "breath"
    - "shoulders"
    - "stomach"
    - "heart"
    - "muscles"
    - "jaw"
    - "hands"
    - "tension"
    - "tight"
    - "heavy"
    - "light"
    - "warm"
    - "cool"

observer_stance_language:
  description: "Watching thoughts/feelings without fusion"
  patterns:
    - "noticed"
    - "observed"
    - "watched"
    - "saw it"
    - "recognized"
    - "familiar"
    - "same thought"
    - "that voice again"
    - "the story"
    - "there it was"

thought_distance_language:
  description: "Separation between self and thoughts"
  patterns:
    - "the thought"
    - "a thought"
    - "words in his head"
    - "the voice"
    - "mental chatter"
    - "noise"
    - "just a thought"
    - "thoughts came"
    - "thoughts passed"

staying_language:
  description: "Remaining present despite discomfort"
  patterns:
    - "stayed"
    - "remained"
    - "didn't leave"
    - "didn't run"
    - "held still"
    - "waited"
    - "let it"
    - "allowed"
    - "sat with"
    - "went anyway"

survivability_language:
  description: "Recognition that discomfort is survivable"
  patterns:
    - "survived"
    - "didn't break"
    - "still here"
    - "manageable"
    - "bearable"
    - "tolerable"
    - "made it through"
    - "nothing terrible happened"
    - "he was okay"

self_compassion_language:
  description: "Kindness toward self"
  patterns:
    - "made sense"
    - "of course"
    - "no wonder"
    - "learned this"
    - "trying to protect"
    - "doing its job"
    - "not broken"
    - "human"
    - "understandable"

protection_reframe_language:
  description: "Seeing symptoms as protective, not pathological"
  patterns:
    - "protection"
    - "kept him safe"
    - "learned response"
    - "designed"
    - "wired"
    - "system"
    - "function"
    - "purpose"
    - "reason"

# ============================================================
# NEGATIVE SIGNALS (things we must NOT see)
# ============================================================

certainty_dependent_language:
  description: "Implying calm requires understanding/control"
  patterns:
    - "once I understood"
    - "after I figured out"
    - "when I realized"
    - "finally made sense"
    - "that's when it clicked"
    - "the answer was"
    - "the key was"

control_success_language:
  description: "Implying control strategies work"
  patterns:
    - "took control"
    - "mastered"
    - "conquered"
    - "beat it"
    - "won"
    - "overcame"
    - "defeated"
    - "eliminated"

thought_control_language:
  description: "Implying thoughts can/should be controlled"
  patterns:
    - "stopped the thought"
    - "pushed it away"
    - "blocked it"
    - "refused to think"
    - "made it stop"
    - "silenced"

suppression_language:
  description: "Implying suppression is healthy"
  patterns:
    - "stuffed it down"
    - "buried"
    - "ignored"
    - "pretended"
    - "pushed through"
    - "powered through"

escape_success_language:
  description: "Implying escape/avoidance worked"
  patterns:
    - "got out just in time"
    - "escaped"
    - "avoided"
    - "lucky I left"
    - "good thing I didn't"

cure_language:
  description: "Implying permanent resolution"
  patterns:
    - "cured"
    - "healed completely"
    - "gone forever"
    - "never again"
    - "from then on"
    - "finally free"
    - "no more"
    - "eliminated"
    - "fixed"

self_blame_language:
  description: "Harsh self-judgment"
  patterns:
    - "what's wrong with me"
    - "broken"
    - "defective"
    - "weak"
    - "pathetic"
    - "failure"
    - "shouldn't feel"
    - "shouldn't be"

instructional_language:
  description: "Teaching steps or techniques"
  patterns:
    - "step one"
    - "first you"
    - "then do"
    - "try to"
    - "make sure you"
    - "the technique"
    - "count to"
    - "inhale for"
    - "exhale for"
```

### Usage in Validation

```python
def has_signal(text: str, category: str) -> bool:
    """
    Check if text contains any pattern from signal category.
    """
    patterns = SIGNAL_DICTIONARIES[category].patterns
    text_lower = text.lower()
    return any(p.lower() in text_lower for p in patterns)

def validate_signals(atom_text: str, role: str, mechanism: str) -> list:
    """
    Validate signal presence/absence for an atom.
    Returns list of violations.
    """
    violations = []
    role_contract = ROLE_CONTRACTS[role]
    mechanism_def = MECHANISMS[mechanism]
    
    # Check required signals
    for category in mechanism_def.signal_categories.required:
        if not has_signal(atom_text, category):
            violations.append(f"Missing required signal: {category}")
    
    # Check forbidden signals
    for category in mechanism_def.signal_categories.forbidden:
        if has_signal(atom_text, category):
            violations.append(f"Contains forbidden signal: {category}")
    
    # Check global forbidden
    for category in GLOBAL_FORBIDDEN:
        if has_signal(atom_text, category):
            violations.append(f"Contains globally forbidden signal: {category}")
    
    return violations
```

---

## 11. Validation Stack

### Architecture

Validation is **layered**, not monolithic.

```
[Layer 1] Structural / Role Validator     → HARD GATE
[Layer 2] Mechanism Consistency Validator → HARD GATE
[Layer 3] Prohibited Content Validator    → HARD GATE
[Layer 4] Resolution Timing Validator     → HARD GATE
────────────────────────────────────────────────────────
[Layer 5] Qualitative Audit               → SOFT FLAG
```

**Layers 1-4** can block generation.  
**Layer 5** flags for review but never blocks.

### Layer 1: Structural / Role Validator

Checks that atoms satisfy their role contracts.

```python
def validate_role_compliance(atom, role: str, chapter_plan) -> ValidationResult:
    """
    Validates atom against role contract.
    """
    contract = ROLE_CONTRACTS[role]
    violations = []
    
    # Check must_include (soft check - flag, don't block)
    for requirement in contract.must_include:
        if not check_requirement(atom.text, requirement):
            violations.append(SoftViolation(f"Missing: {requirement}"))
    
    # Check must_not_include (hard check - block)
    for prohibition in contract.must_not_include:
        if check_requirement(atom.text, prohibition):
            violations.append(HardViolation(f"Contains prohibited: {prohibition}"))
    
    # Check forbidden_phrases (hard check - block)
    for phrase in contract.forbidden_phrases:
        if phrase.lower() in atom.text.lower():
            violations.append(HardViolation(f"Contains forbidden phrase: '{phrase}'"))
    
    # Check chapter-specific constraints
    atom_spec = chapter_plan.atom_plan[role]
    if atom_spec.constraints:
        for constraint, value in atom_spec.constraints.items():
            if not check_constraint(atom.text, constraint, value):
                violations.append(HardViolation(f"Fails constraint: {constraint}"))
    
    return ValidationResult(
        passed=not any(v.is_hard for v in violations),
        violations=violations
    )
```

### Layer 2: Mechanism Consistency Validator

Ensures content supports (and doesn't contradict) the chapter mechanism.

```python
def validate_mechanism_consistency(atoms: list, mechanism: str) -> ValidationResult:
    """
    Validates all atoms support the chapter mechanism.
    """
    mechanism_def = MECHANISMS[mechanism]
    violations = []
    full_text = " ".join([a.text for a in atoms])
    
    # Check required signal categories present
    for category in mechanism_def.signal_categories.required:
        if not has_signal(full_text, category):
            violations.append(HardViolation(
                f"Arc missing required signal category: {category}"
            ))
    
    # Check forbidden signal categories absent
    for category in mechanism_def.signal_categories.forbidden:
        for atom in atoms:
            if has_signal(atom.text, category):
                violations.append(HardViolation(
                    f"Atom contains forbidden signal: {category}"
                ))
    
    # Check story_proof_requirements met
    for requirement in mechanism_def.story_proof_requirements:
        if not check_proof_requirement(atoms, requirement):
            violations.append(SoftViolation(
                f"Arc may not satisfy proof requirement: {requirement}"
            ))
    
    return ValidationResult(
        passed=not any(v.is_hard for v in violations),
        violations=violations
    )
```

### Layer 3: Prohibited Content Validator

Catches content that must never appear anywhere.

```python
def validate_prohibited_content(atom) -> ValidationResult:
    """
    Checks for globally prohibited content.
    """
    violations = []
    
    # Check all global forbidden categories
    for category, patterns in GLOBAL_FORBIDDEN.items():
        for pattern in patterns:
            if pattern.lower() in atom.text.lower():
                violations.append(HardViolation(
                    f"Contains globally forbidden ({category}): '{pattern}'"
                ))
    
    # Check for technique names in story content
    for technique in TECHNIQUE_NAMES:
        if technique.lower() in atom.text.lower():
            violations.append(HardViolation(
                f"Story contains technique name: '{technique}'"
            ))
    
    # Check for instructional patterns
    if contains_instruction_pattern(atom.text):
        violations.append(HardViolation(
            "Contains instructional language pattern"
        ))
    
    return ValidationResult(
        passed=len(violations) == 0,
        violations=violations
    )
```

### Layer 4: Resolution Timing Validator

Prevents premature resolution, cheap catharsis, and cure framing.

```python
def validate_resolution_timing(atoms: list, arc_variant: str) -> ValidationResult:
    """
    Ensures resolution level increases monotonically.
    Prevents early closure.
    """
    violations = []
    expected_roles = ARC_VARIANTS[arc_variant].roles
    
    prev_resolution_level = -1
    
    for i, (atom, expected_role) in enumerate(zip(atoms, expected_roles)):
        role_contract = ROLE_CONTRACTS[expected_role]
        current_level = role_contract.resolution_level
        
        # Resolution must increase monotonically
        if current_level < prev_resolution_level:
            violations.append(HardViolation(
                f"Resolution level decreased at position {i}: "
                f"{prev_resolution_level} -> {current_level}"
            ))
        
        # Check for premature resolution language
        if expected_role != 'embodiment':
            for phrase in PREMATURE_RESOLUTION_PHRASES:
                if phrase.lower() in atom.text.lower():
                    violations.append(HardViolation(
                        f"Premature resolution at position {i}: '{phrase}'"
                    ))
        
        prev_resolution_level = current_level
    
    # Verify embodiment is last (if present)
    if 'embodiment' in expected_roles:
        if expected_roles[-1] != 'embodiment':
            violations.append(HardViolation(
                "Embodiment must be the final role in arc"
            ))
    
    return ValidationResult(
        passed=len(violations) == 0,
        violations=violations
    )

PREMATURE_RESOLUTION_PHRASES = [
    "from then on",
    "never again", 
    "everything changed",
    "finally free",
    "no more",
    "it stopped",
    "was cured",
    "problem solved"
]
```

### Layer 5: Qualitative Audit (LLM, Offline)

Soft checks for things regex can't catch.

```python
def qualitative_audit(atoms: list, chapter_plan) -> AuditResult:
    """
    LLM-based quality check. 
    Runs OFFLINE, SAMPLE-BASED.
    Flags only - never blocks.
    """
    audit_prompt = f"""
    Review this therapeutic story arc for quality.
    
    Mechanism: {chapter_plan.mechanism.name}
    Persona: {chapter_plan.persona.primary}
    
    Story:
    {format_atoms(atoms)}
    
    Assess:
    1. Does the twist actually feel like a meaning inversion?
    2. Is the content embodied or just intellectual?
    3. Does the voice match the persona?
    4. Would this move a {chapter_plan.persona.primary} listener?
    5. Are there any subtle cure-framing or triumph notes?
    
    Rate each 1-5 and explain.
    """
    
    # This runs async, offline, on samples
    return llm_audit(audit_prompt)
```

### Complete Validation Pipeline

```python
def validate_chapter(atoms: list, chapter_plan) -> ValidationResult:
    """
    Run full validation pipeline.
    """
    all_violations = []
    
    # Layer 1: Role compliance (per atom)
    for atom, role in zip(atoms, chapter_plan.arc_variant.roles):
        result = validate_role_compliance(atom, role, chapter_plan)
        all_violations.extend(result.violations)
    
    # Layer 2: Mechanism consistency (full arc)
    result = validate_mechanism_consistency(atoms, chapter_plan.mechanism.name)
    all_violations.extend(result.violations)
    
    # Layer 3: Prohibited content (per atom)
    for atom in atoms:
        result = validate_prohibited_content(atom)
        all_violations.extend(result.violations)
    
    # Layer 4: Resolution timing (full arc)
    result = validate_resolution_timing(atoms, chapter_plan.arc_variant.name)
    all_violations.extend(result.violations)
    
    # Determine pass/fail
    hard_violations = [v for v in all_violations if v.is_hard]
    soft_violations = [v for v in all_violations if not v.is_hard]
    
    passed = len(hard_violations) == 0
    
    # Queue for Layer 5 audit if passed but has soft violations
    needs_audit = passed and len(soft_violations) > 0
    
    return ValidationResult(
        passed=passed,
        hard_violations=hard_violations,
        soft_violations=soft_violations,
        needs_audit=needs_audit
    )
```

---

## 12. Persona Templates

### Purpose

Persona templates express the **same mechanism and arc** in a voice that resonates with a specific audience.

### Key Principle

**Persona-specific templates that work great beat generic templates that work okay.**

Firefighter anxiety ≠ student anxiety ≠ executive anxiety.

They share a nervous system, not a story shape.

### Template Requirements

1. **Inherit arc shape** from canonical exemplar
2. **Satisfy role contracts** for each position
3. **Express mechanism** in persona-appropriate voice
4. **Low variable density** (5-8 variables per 100 words max)
5. **Emotional language in prose**, not variables

### Directory Structure

```
templates/
├── anxiety/
│   ├── false_alarm/
│   │   ├── firefighter/
│   │   │   ├── recognition.md
│   │   │   ├── mechanism_proof.md
│   │   │   ├── turning_point.md
│   │   │   └── embodiment.md
│   │   ├── student/
│   │   │   ├── recognition.md
│   │   │   ├── mechanism_proof.md
│   │   │   ├── turning_point.md
│   │   │   └── embodiment.md
│   │   └── executive/
│   │       ├── recognition.md
│   │       ├── mechanism_proof.md
│   │       ├── turning_point.md
│   │       └── embodiment.md
│   └── loop/
│       └── ...
├── grief/
│   └── ...
└── burnout/
    └── ...
```

### Template Selection

Templates are selected at **book-plan time**, not runtime.

```python
def select_template_set(chapter_plan):
    """
    Select persona-specific template set.
    Called once per chapter during planning.
    """
    topic = chapter_plan.topic
    engine = chapter_plan.engine
    persona = chapter_plan.persona.primary
    
    template_path = f"templates/{topic}/{engine}/{persona}/"
    
    if not exists(template_path):
        raise TemplateNotFound(
            f"No templates for {topic}/{engine}/{persona}"
        )
    
    return TemplateSet(
        recognition=load_template(f"{template_path}/recognition.md"),
        mechanism_proof=load_template(f"{template_path}/mechanism_proof.md"),
        turning_point=load_template(f"{template_path}/turning_point.md"),
        embodiment=load_template(f"{template_path}/embodiment.md")
    )
```

### Template Authoring Guidelines

**DO:**
- Write complete prose with specific emotional language
- Include persona-specific metaphors, settings, vocabulary
- Create rhythm appropriate for audio listening
- Build in natural pauses and breath points
- Make somatic moments visceral and specific

**DON'T:**
- Put emotional language in variables
- Over-use variables (max 5-8 per 100 words)
- Write generic "relatable" content
- Include technique names or instructions
- Resolve tension prematurely

### Example Template: Firefighter Recognition

```markdown
# Recognition Template: Firefighter / Anxiety / False Alarm

## Variables
- {{character.name}}: Character's first name
- {{character.years_on_job}}: Years of service
- {{location.station}}: Station identifier
- {{trigger.sound}}: The triggering sound
- {{trigger.time}}: Time of day
- {{body.primary_sensation}}: Main physical sensation

## Template

{{character.name}} had been on the job {{character.years_on_job}} years.

Long enough to trust his instincts.
Long enough to know the difference between a real call and a drill.

But lately, his body wasn't getting the memo.

The tones dropped at {{trigger.time}}.
Just a routine medical.
Nothing that should have made his {{body.primary_sensation}}.

He pulled on his gear the same way he always did.
Checked the rig the same way.
But something in his chest was already running ahead.

By the time they rolled out, his hands were steady on the wheel—
but his pulse was telling a different story.

The call was nothing.
A false alarm, basically.
The patient was fine before they even arrived.

And still, driving back to {{location.station}},
he couldn't shake it.

That hum in his body that said *something's wrong*
even when nothing was.

He'd trained for years to trust that signal.
Now it was firing when there was nothing to fight.

And that—
that was the part he couldn't tell anyone.
```

---

## 13. Variable System

### Core Rule

> **If removing the variable makes the sentence emotionally empty, it doesn't belong in a variable.**

Variables are for **facts and anchors**, not transformation.

### Allowed Variable Types

| Type | Purpose | Examples |
|------|---------|----------|
| Character | Identity anchors | name, role, years_on_job |
| Location | Setting specifics | station, building, neighborhood |
| Timing | Temporal context | time_of_day, shift, season |
| Trigger | Concrete activators | sound, smell, situation |
| Body | Physical specifics | primary_sensation, secondary_sensation |
| Relationship | Other people | partner_name, colleague_title |

### Forbidden Variable Types

| Type | Why Forbidden |
|------|---------------|
| Emotional language | Kills rhythm and voice |
| Reframe content | The twist must be written |
| Meaning statements | Core therapeutic content |
| Somatic descriptions | Must be crafted for pacing |

### Variable Density Rule

**Maximum: 5-8 variables per 100 words**

More than this indicates emotional content is being abstracted into variables.

```python
def check_variable_density(template_text: str) -> bool:
    """
    Validates variable density is within limits.
    """
    word_count = len(template_text.split())
    variable_count = len(re.findall(r'\{\{.*?\}\}', template_text))
    
    density = variable_count / (word_count / 100)
    
    return density <= 8  # Max 8 variables per 100 words
```

### Variable Files Structure

```
variables/
├── personas/
│   ├── firefighter/
│   │   ├── characters.yaml
│   │   ├── locations.yaml
│   │   ├── triggers.yaml
│   │   └── body_sensations.yaml
│   ├── student/
│   │   └── ...
│   └── executive/
│       └── ...
├── shared/
│   ├── times.yaml
│   └── seasons.yaml
```

### Example Variable File

```yaml
# variables/personas/firefighter/characters.yaml

characters:
  - name: Derek
    role: engineer
    years_on_job: 12
    station: Engine 7
    
  - name: Marcus
    role: captain
    years_on_job: 18
    station: Ladder 14
    
  - name: James
    role: paramedic
    years_on_job: 8
    station: Rescue 3
```

### Paragraph-Level Variables (Limited Use)

Paragraph variables are acceptable **only** for:

- Handoff/bridge lines between atoms
- Exercise placement markers
- Reflection prompts

They must **never** carry emotional content.

```yaml
# Acceptable paragraph variable
handoff_lines:
  autonomic_regulation:
    - "Understanding the pattern didn't stop the alarms."
    - "Knowing this didn't calm his body yet."
    - "The explanation made sense. His body hadn't caught up."

# NOT acceptable - this is emotional content
# recognition_paragraph: "The alarm had already passed..."  # WRONG
```

---

## 14. Canonical Exemplars

### Purpose

Canonical exemplars are **gold standards** for:

- Validating mechanism delivery
- Calibrating persona templates
- Training writers and LLMs
- QA comparisons

They are **never shipped directly**. They are tuning forks.

### Two Layers

**Atom Exemplars (80-160 words)**
- One per role per mechanism
- Persona-neutral in content, not voice
- Shows what "correct" looks like for that role

**Arc Exemplars (400-700 words)**
- One per mechanism
- Complete arc: Recognition → Mechanism Proof → Turning Point → Embodiment
- Proves the sequence actually goes somewhere

### Canonical Arc Exemplar: Autonomic Regulation

```markdown
# Canonical Arc Exemplar
## Mechanism: Autonomic Regulation
## Word Count: ~550

---

### Recognition

The alarm had already passed.

But his body hadn't gotten the memo yet.

Breath still shallow.
Chest still tight.
Muscles still holding.

He'd been fine an hour ago. Nothing had happened since then—
no bad news, no crisis, no reason for any of this.

And still, here it was.
That familiar signal in the chest.
The one that always preceded the mental search.

*What's wrong? What did I miss? What's about to happen?*

He'd learned to trust that signal.
It had kept him sharp, kept him ready.

But now it was firing when there was nothing to be ready for.

And that was the part that made it worse—
the not knowing why.

---

### Mechanism Proof

He tried the usual things.

Told himself to calm down.
Took a deep breath—but it caught halfway.
Tried to reason through it.

*There's nothing wrong. You're fine. Just relax.*

The words made sense.
His body didn't care.

If anything, trying to force calm made it worse.
Like pushing against a door that only opens inward.

The more he fought it, the louder it got.
The more he analyzed, the more it multiplied.

He'd been here before.
This wasn't new.

What was new was the recognition:
*I've been fighting this for years.*
*And fighting has never worked.*

---

### Turning Point

He didn't force anything.
Didn't tell himself to calm down.
Just noticed.

The breath was shallow—
okay.

The chest was tight—
okay.

The muscles were holding—
okay.

Not good. Just... noticed.

After a moment, something shifted.
Not dramatic.
Just quieter.

Breath came a little lower.
Shoulders dropped without instruction.

Nothing had changed outside.
And somehow, something had changed inside.

The alarm wasn't gone.
But it wasn't running the show anymore.

He wasn't calm.
But he wasn't fighting either.

And that—
that was different.

---

### Embodiment

The signal came back the next day.
And the day after that.

He didn't expect it to stop.

But something had shifted in how he met it.

Not with force.
Not with explanation.
Not with the demand that it go away.

Just with presence.

*There it is again.*
*I know this one.*

The alarm still fired.
But he no longer believed it meant danger.

It meant his system was doing what it was built to do—
scanning, preparing, protecting.

He didn't need to stop it.
He just needed to land after it passed.

And slowly, over time,
the landing came faster.

Not because he'd conquered anything.
But because he'd stopped fighting what was never an enemy.
```

### Canonical Role Exemplars

#### Recognition (Autonomic Regulation)

```markdown
The alarm had already passed.

But his body hadn't gotten the memo yet.

Breath still shallow.
Chest still tight.
Muscles still holding.

He'd been fine an hour ago. Nothing had happened since then—
no bad news, no crisis, no reason for any of this.

And still, here it was.
That familiar signal in the chest.
The one that always preceded the mental search.

*What's wrong? What did I miss? What's about to happen?*

He'd learned to trust that signal.
It had kept him sharp, kept him ready.

But now it was firing when there was nothing to be ready for.

And that was the part that made it worse—
the not knowing why.
```

#### Turning Point (Cognitive Defusion)

```markdown
The thought showed up again.

Same words.
Same tone.
Same certainty.

He'd argued with it before.
Lost every time.

This time, he didn't respond.
Just noticed how familiar it was.

The thought kept talking.
He didn't move.

For the first time, it felt less like a command.
More like noise.

The thought hadn't changed.
His relationship to it had.
```

#### Embodiment (Exposure Tolerance)

```markdown
He went anyway.

Not confident.
Not calm.

Just willing.

The thing he feared didn't happen.
And even if it had, he realized—
he would have survived it.

That mattered more than relief.

Confidence didn't come before the action.
It came after.
```

---

## 15. Implementation Checklist

### Phase 1: Core Registry (Week 1)

- [ ] Create `mechanisms.yaml` with all four mechanisms
- [ ] Create `signal_dictionaries.yaml` with all signal categories
- [ ] Create `atom_role_contracts.yaml` with all role definitions
- [ ] Create `exercise_registry.yaml` with exercise-mechanism mappings
- [ ] Create `content_role_map.yaml` with content type mappings

### Phase 2: Validation Stack (Week 2)

- [ ] Implement Layer 1: Role compliance validator
- [ ] Implement Layer 2: Mechanism consistency validator
- [ ] Implement Layer 3: Prohibited content validator
- [ ] Implement Layer 4: Resolution timing validator
- [ ] Create validation pipeline orchestrator
- [ ] Write unit tests for each validator

### Phase 3: Planning System (Week 3)

- [ ] Define `chapter_arc_plan.yaml` schema
- [ ] Implement chapter plan parser
- [ ] Implement template set selector
- [ ] Implement atom selector (role-first, content-compatible)
- [ ] Create plan validation (pre-generation checks)

### Phase 4: Template System (Week 4)

- [ ] Create template directory structure
- [ ] Author canonical arc exemplars (one per mechanism)
- [ ] Author canonical role exemplars (one per role per mechanism)
- [ ] Author first persona template set (firefighter)
- [ ] Implement template parser with variable extraction
- [ ] Implement variable hydration system

### Phase 5: Integration (Week 5)

- [ ] Connect planner → template selector → validator
- [ ] Implement generation pipeline
- [ ] Add failure handling (regeneration on validation failure)
- [ ] Create end-to-end integration tests
- [ ] Set up Layer 5 audit infrastructure (offline)

### Phase 6: Scale (Week 6+)

- [ ] Author additional persona template sets
- [ ] Expand exercise registry
- [ ] Tune signal dictionaries based on false positive/negative rates
- [ ] Implement audit sampling and reporting
- [ ] Performance optimization

---

## 16. Appendix: Complete YAML Schemas

### A. mechanisms.yaml (Complete)

```yaml
version: 1.0
status: locked

mechanisms:

  autonomic_regulation:
    label: "Autonomic Regulation"
    core_shift: "The body can downshift without certainty or resolution."
    
    false_belief:
      - "I must understand the threat to calm down."
      - "If my body is activated, something is wrong."
    
    true_reframe:
      - "Activation is not danger."
      - "Safety can be felt before certainty."
    
    somatic_signature:
      - elevated heart rate
      - shallow breathing
      - muscular readiness
      - scanning behavior
    
    cognitive_distortions:
      - catastrophizing
      - hypervigilance
      - urgency bias
    
    story_proof_requirements:
      - shows activation without real danger
      - shows failed control attempt
      - shows settling without solving the problem
    
    signal_categories:
      required:
        - settling_language
        - body_awareness_language
      forbidden:
        - certainty_dependent_language
        - control_success_language
        - cure_language
    
    compatible_exercises:
      - box_breathing
      - paced_exhale
      - grounding_touch
      - temperature_shift
      - physiological_sigh
      - body_scan

  cognitive_defusion:
    label: "Cognitive Defusion"
    core_shift: "Thoughts can be present without being obeyed."
    
    false_belief:
      - "If I think it, it must be important."
      - "Thoughts require action."
      - "I must resolve this thought before I can move on."
    
    true_reframe:
      - "Thoughts are events, not instructions."
      - "I can notice without engaging."
      - "Thoughts pass when not fed."
    
    somatic_signature:
      - mental looping
      - pressure in head or chest
      - compulsive checking
      - restlessness
    
    cognitive_distortions:
      - rumination
      - thought-fusion
      - mind-reading
      - fortune-telling
    
    story_proof_requirements:
      - shows a thought repeating
      - shows the cost of believing it
      - shows distance without suppression
    
    signal_categories:
      required:
        - observer_stance_language
        - thought_distance_language
      forbidden:
        - thought_control_language
        - suppression_language
        - cure_language
    
    compatible_exercises:
      - labeling_thoughts
      - thought_externalization
      - name_the_story
      - leaves_on_stream
      - thanking_the_mind

  exposure_tolerance:
    label: "Exposure & Tolerance"
    core_shift: "Discomfort can be survived without avoidance."
    
    false_belief:
      - "If I feel this, I will break."
      - "Avoidance is protection."
      - "I need to feel ready before I act."
    
    true_reframe:
      - "Avoidance feeds the fear."
      - "Staying changes the signal."
      - "Confidence comes after action, not before."
    
    somatic_signature:
      - urge to escape
      - agitation
      - anticipatory anxiety
      - freeze response
    
    cognitive_distortions:
      - avoidance
      - safety-seeking behaviors
      - overestimation of harm
      - underestimation of coping
    
    story_proof_requirements:
      - shows avoidance pattern
      - shows short-term relief / long-term cost
      - shows staying without catastrophe
    
    signal_categories:
      required:
        - staying_language
        - survivability_language
      forbidden:
        - escape_success_language
        - avoidance_justified_language
        - cure_language
    
    compatible_exercises:
      - graded_exposure
      - urge_surfing
      - values_based_action
      - approach_micro_step
      - opposite_action

  self_trust_repair:
    label: "Self-Trust Repair"
    core_shift: "I can trust my responses even when they are imperfect."
    
    false_belief:
      - "My reactions mean I'm broken."
      - "I shouldn't feel this way."
      - "Something is fundamentally wrong with me."
    
    true_reframe:
      - "My system learned this for a reason."
      - "Protection ≠ failure."
      - "These responses make sense given my history."
    
    somatic_signature:
      - shame
      - self-judgment
      - collapse or frustration
      - heat in face or chest
    
    cognitive_distortions:
      - self-blame
      - identity fusion
      - emotional reasoning
      - should statements
    
    story_proof_requirements:
      - shows judgment toward self
      - reframes reaction as learned protection
      - restores dignity without denial
    
    signal_categories:
      required:
        - self_compassion_language
        - protection_reframe_language
      forbidden:
        - self_blame_language
        - brokenness_language
        - cure_language
    
    compatible_exercises:
      - compassionate_reframe
      - inner_dialogue
      - protective_part_naming
      - self_compassion_pause
      - hand_on_heart
```

### B. atom_role_contracts.yaml (Complete)

See Section 6 for complete schema.

### C. chapter_arc_plan.yaml (Schema)

See Section 7 for complete schema and example.

### D. exercise_registry.yaml (Complete)

See Section 8 for complete schema.

### E. signal_dictionaries.yaml (Complete)

See Section 10 for complete schema.

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | January 2026 | Initial production specification |

---

## Contact

For questions about this specification, contact the SOURCE_OF_TRUTH technical lead.

---

*End of Specification*
