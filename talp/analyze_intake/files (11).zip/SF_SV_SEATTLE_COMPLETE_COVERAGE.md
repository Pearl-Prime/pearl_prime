# SF/SV and Seattle Persona Coverage

## Architecture Decision

**Do founders and IC techies need separate templates?**

YES — the voice is fundamentally different:

| Element | SF/SV Founder | SF/SV IC Techie |
|---------|---------------|-----------------|
| Stakes | Company survival, employees' livelihoods, runway | Career, performance review, job security |
| Self-talk | "Everyone's depending on me" | "Am I good enough to be here?" |
| Anxiety source | Existential (will this work?) | Competence (am I performing?) |
| Loneliness | Can't show weakness to team | Can't admit struggle to manager |
| Knowledge gap | Knows they're supposed to have answers | Knows they're supposed to ask questions |
| Imposter flavor | "I'm responsible for 20 people's mortgages" | "Everyone here is smarter than me" |

**Conclusion:**
- **SF/SV Founders** → NEW template set (different voice)
- **SF/SV IC Techies** → Use Gen Z Professional templates + specific variables
- **Seattle** → Use Gen Z Professional templates + specific variables (culture differs but generational voice is same)

---

# PART 1: SF/SV FOUNDERS

## Full Template Set (New Voice)

### Persona Profile

**Role:** Founder, Co-founder, CEO of early-to-growth stage startup  
**Stage:** Seed through Series B (pre-product-market-fit to scaling)  
**Age Range:** 24-35 (skewing Gen Z / young Millennial)

**Core Context:**
- Responsible for company survival
- Managing runway, investors, team, product simultaneously
- Can't show anxiety to team — they need to project confidence
- Board members, investors, advisors all watching
- Every decision feels existential

**Core Anxiety Pattern:**
- Hypervigilance about company health metrics
- Every Slack, email, text could be bad news (churn, resignation, investor concern)
- Can't distinguish between "routine check-in" and "something's wrong"
- Body reacts to every notification like runway just got shorter

**Unique Tension:**
- They chose this — can't complain about stress they signed up for
- Success stories make it look easy; struggling feels like personal failure
- Supposed to be the calm one, the leader, the one with answers
- Meditation apps feel like another thing to optimize

**Stakes:**
- Company survival (external, real)
- Team members' jobs and families (external, real)
- Identity as capable leader (internal)
- Investor trust (external)
- Years of work potentially worth nothing

---

## Variable Files

```yaml
# variables/sf_sv_founders/characters.yaml

characters:
  - name: Alex
    age: 29
    title: CEO & Co-founder
    company_stage: Series A
    team_size: 18
    months_runway: 14
    funding_raised: $4M
    
  - name: Priya
    age: 27
    title: Founder & CEO
    company_stage: Seed
    team_size: 6
    months_runway: 9
    funding_raised: $1.2M
    
  - name: Marcus
    age: 32
    title: Co-founder & CTO
    company_stage: Series B
    team_size: 45
    months_runway: 18
    funding_raised: $15M
    
  - name: Sarah
    age: 26
    title: Solo Founder
    company_stage: Pre-seed
    team_size: 3
    months_runway: 6
    funding_raised: $500K
    
  - name: Jordan
    age: 30
    title: CEO & Co-founder
    company_stage: Series A
    team_size: 24
    months_runway: 11
    funding_raised: $8M
```

```yaml
# variables/sf_sv_founders/locations.yaml

locations:
  - workspace: the office
    detail: the glass-walled room they call the "founder's corner"
    building: WeWork in SoMa
    commute: a twelve-minute walk from the apartment
    
  - workspace: apartment
    detail: the desk wedged between the bed and the window
    building: one-bedroom in the Mission
    commute: none—couldn't sleep anyway
    
  - workspace: coffee shop
    detail: the corner table at Sightglass
    building: their unofficial second office
    commute: around the corner from the real office
    
  - workspace: investor's office
    detail: the conference room with the view of the Bay
    building: Sand Hill Road
    commute: the 280 from the city
    
  - workspace: coworking event space
    detail: backstage at the demo day venue
    building: somewhere in SoMa
    commute: Uber from the office
```

```yaml
# variables/sf_sv_founders/triggers.yaml

triggers:
  false_alarm:
    - event: text from the lead investor
      time: 9 PM Sunday
      context: board meeting on Tuesday
      typical_reality: logistics question
      catastrophic_fear: they're pulling out
      
    - event: Slack from the head of engineering
      time: 11 PM
      context: week before launch
      typical_reality: a code review question
      catastrophic_fear: critical bug, launch delay
      
    - event: email from the biggest customer
      time: Monday morning
      context: contract renewal coming up
      typical_reality: a feature request
      catastrophic_fear: they're churning
      
    - event: "Can we talk?" from a key employee
      time: Friday afternoon
      context: after a tough all-hands
      typical_reality: feedback about the meeting
      catastrophic_fear: they're quitting
      
    - event: calendar invite from a board member
      time: mid-week
      context: outside the normal board schedule
      typical_reality: intro to a potential hire
      catastrophic_fear: emergency board meeting
      
    - event: notification from the bank
      time: any time
      context: always
      typical_reality: routine transaction
      catastrophic_fear: something's wrong with the account
```

```yaml
# variables/sf_sv_founders/stakes.yaml

stakes:
  team_references:
    - "eighteen people counting on this working"
    - "a team that left good jobs to be here"
    - "people with mortgages and kids"
    - "engineers who turned down FAANG offers"
    
  runway_references:
    - "fourteen months of runway"
    - "nine months until the money runs out"
    - "burning $200K a month"
    - "six months to hit the metrics or raise again"
    
  investor_references:
    - "investors who believed in this"
    - "a board that's watching the numbers"
    - "VCs who took a bet on us"
    - "angels who wrote checks when no one else would"
    
  identity_stakes:
    - "years of work riding on this"
    - "the thing I've told everyone I'm building"
    - "what I gave up a good career for"
    - "what I've asked everyone else to sacrifice for"
```

```yaml
# variables/sf_sv_founders/body_sensations.yaml

sensations:
  - primary: chest tighten
    secondary: that familiar weight
    context_thought: something's wrong with the company
    
  - primary: stomach drop
    secondary: adrenaline hit
    context_thought: this is the moment it falls apart
    
  - primary: heart rate spike
    secondary: mind start racing through scenarios
    context_thought: running the numbers, calculating runway
    
  - primary: whole body tense
    secondary: jaw clench
    context_thought: I need to fix this before anyone notices
    
  - primary: that jolt of dread
    secondary: hands pause mid-motion
    context_thought: I can't let the team see this
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: SF/SV Founder
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.title}}
- {{character.company_stage}}
- {{character.team_size}}
- {{character.months_runway}}
- {{trigger.event}}
- {{trigger.time}}
- {{trigger.context}}
- {{trigger.typical_reality}}
- {{trigger.catastrophic_fear}}
- {{body.primary}}
- {{body.secondary}}
- {{stakes.team_reference}}
- {{location.workspace}}

### Template

{{character.name}} had raised the money.
Hired the team.
Shipped the product.
Done everything you're supposed to do.

None of it made the anxiety stop.

The {{trigger.event}} came through at {{trigger.time}}.
{{trigger.context}}.

Their {{body.primary}}.
Then {{body.secondary}}.

Before they even opened it, their brain was already running scenarios.
{{trigger.catastrophic_fear}}.

They checked.

{{trigger.typical_reality}}.

Nothing urgent.
Nothing catastrophic.
Nothing that should have made their body react like the company was about to die.

But it did.

And it wasn't just that one.
It was every notification.
Every "quick call" request.
Every message that started with a name instead of a greeting.

{{stakes.team_reference}}.
{{character.months_runway}} months of runway.
Investors who believed in this.
And their body treating every ping like the whole thing was about to collapse.

The worst part was the performance.

In front of the team, they had to be steady.
Confident.
The one with answers.

Nobody could know that their nervous system
was running a continuous threat assessment
on every Slack channel, every email, every calendar invite.

Sitting in {{location.workspace}},
they looked calm.
Answered messages.
Made decisions.

And underneath, something was always scanning.
Always waiting for the thing that would finally prove
this was all about to fall apart.

They couldn't exactly tell their co-founder:
"I feel like I'm going to throw up every time I see a notification from our biggest customer."

So they didn't.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: SF/SV Founder
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}
- {{body.secondary}}
- {{character.team_size}}
- {{stakes.runway_reference}}

### Template

{{character.name}} had tried to manage it.

The meditation app.
The morning routine.
The "CEO coach" who cost $500 an hour.

None of it stopped the {{body.primary}} when a message came through.
None of it kept their {{body.secondary}} when they saw an unexpected calendar invite.

They'd tried compartmentalizing.
"Leave work at work."
But when you're responsible for {{character.team_size}} people's livelihoods,
work doesn't stay at work.
It follows you home.
It wakes you up at 3 AM.
It's there in the shower, in the car, in the middle of dinner.

They'd tried logic.

*Most messages aren't emergencies.*
*The company is fine.*
*Metrics are on track.*
*{{stakes.runway_reference}}—that's plenty of time.*

The numbers made sense.
Their body didn't care about numbers.

They'd tried being more available—
answering faster, checking more often—
thinking that staying on top of everything would make the anxiety go away.

It made it worse.

They'd tried being less available—
blocking time, turning off notifications—
but then the fear of missing something critical
was worse than the fear of seeing it.

Every strategy they tried
became another thing to manage.

And underneath all the optimization,
all the routines,
all the advice from people who'd "been there,"
the alarm kept firing.

Right on cue.
Every time.

Like their nervous system had decided that running a startup
meant permanent threat assessment.

And maybe it was right.
Maybe things really could fall apart at any moment.

But treating every moment like that moment
was becoming its own kind of unsustainable.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: SF/SV Founder
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.workspace}}
- {{location.detail}}
- {{body.primary}}
- {{body.secondary}}
- {{character.team_size}}

### Template

{{character.name}} was in {{location.workspace}}—
{{location.detail}}—
when it happened again.

A notification.
Their {{body.primary}}.
Their {{body.secondary}}.
The whole familiar sequence.

But this time, instead of immediately checking,
they paused.

Not to suppress it.
Not to breathe through it.
Just to notice.

*There it is.*
*The spike.*
*Same as always.*

And something shifted.

Not in the situation.
In their relationship to it.

Their nervous system was doing exactly what a nervous system does
when everything depends on everything working.

It was scanning.
Protecting.
Staying alert.

Not because something was wrong.
Because their body had learned—
through months of real emergencies, real close calls, real moments where things almost fell apart—
that vigilance was survival.

It wasn't broken.
It was *doing its job too well.*

The alarm wasn't a sign of weakness.
It was the cost of caring about something this much.

{{character.team_size}} people.
Their work.
Their vision.

Of course their body was on high alert.

That wasn't a malfunction.
That was a nervous system calibrated for stakes this high.

The spike still came.
But it stopped feeling like proof that something was wrong with them.

It started feeling like proof that they were paying attention.

And paying attention was different from drowning in it.

They could feel the alarm
and still check the message calmly.

They could notice the spike
and still make a clear decision.

The alarm didn't have to run the show.
It just had to be there.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: SF/SV Founder
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{trigger.event}}
- {{body.primary}}
- {{character.team_size}}
- {{stakes.identity_stake}}

### Template

The spikes didn't stop.

{{character.name}} wasn't pretending they did.

Every {{trigger.event}} still made their {{body.primary}}.
That was probably permanent.
That was probably what building something this hard did to a person.

But something had changed in what happened next.

Before, it was:
notification → spike → catastrophize → check frantically → try to calm down → fail → exhaustion

Now it was:
notification → spike → *okay, there's the alarm* → check normally → move on

One layer instead of five.

They stopped expecting to be a founder who didn't feel this.
They started being a founder who felt it and led anyway.

Last week, their biggest customer sent a vague email.
Subject line: "Quick question."

Their body did the thing.
Stomach dropped.
Chest tightened.
Brain started running churn scenarios.

They noticed it.
Didn't chase it.
Opened the email.

It was actually a quick question.

And even if it hadn't been—
even if the customer was churning—
they realized they would have handled it.
Not calmly.
But competently.

The alarm wasn't a prediction.
It was just an alarm.

{{character.team_size}} people still depended on them.
{{stakes.identity_stake}}.
The stakes were still real.

But the nervous system running threat assessment on everything
didn't mean everything was a threat.

They were still a founder whose body ran hot.
They just weren't at war with it anymore.

Some days were still hard.
Some spikes still felt like too much.

But they'd stopped adding the second layer—
the shame about being anxious,
the fear that feeling this meant they couldn't handle it.

They could feel it and handle it.

That turned out to be the whole job.
```

---

# PART 2: SF/SV IC TECHIES

## Variable Files Only (Use Gen Z Professional Templates)

**Why no new templates:** IC techies share the Gen Z Professional voice — internet-literate, therapy-adjacent vocabulary, self-aware about mental health. The stakes and triggers differ, but the generational voice is consistent.

---

### Location 2A: SF Early-Stage Startup IC

```yaml
# variables/gen_z_professional/sf_early_stage/characters.yaml

characters:
  - name: Kevin
    age: 26
    role: founding engineer
    years_in_workforce: 3
    company_stage: seed
    team_size: 8
    equity_percent: "0.5%"
    
  - name: Jasmine
    age: 25
    role: first product hire
    years_in_workforce: 2
    company_stage: pre-seed
    team_size: 5
    equity_percent: "0.3%"
    
  - name: Tyler
    age: 27
    role: head of design
    years_in_workforce: 4
    company_stage: Series A
    team_size: 15
    equity_percent: "0.2%"
    
  - name: Maya
    age: 24
    role: early engineer
    years_in_workforce: 2
    company_stage: seed
    team_size: 6
    equity_percent: "0.4%"
```

```yaml
# variables/gen_z_professional/sf_early_stage/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the founder
      time: 11 PM
      context: week before launch
      typical_reality: excitement about a feature
      
    - event: all-hands meeting added to calendar
      time: Monday morning
      context: with no agenda
      typical_reality: product update
      fear: layoffs, pivot, shutdown
      
    - event: "Got a sec?" DM
      time: during deep work
      context: from the CEO
      typical_reality: quick product question
      
    - event: investor visit announced
      time: mid-week
      context: between funding rounds
      typical_reality: routine board prep
      
    - event: Slack channel going quiet
      time: after a tense discussion
      context: about company direction
      typical_reality: people doing focused work
      
    - event: founder's mood shift
      time: after a call
      context: door closed, voice low
      typical_reality: difficult customer conversation
```

```yaml
# variables/gen_z_professional/sf_early_stage/industry_terms.yaml

industry_terms:
  stressors:
    - "runway"
    - "burn rate"
    - "pivot talk"
    - "investor meeting"
    - "launch week"
    - "the metrics"
    
  unique_pressures:
    - "wearing multiple hats"
    - "no process, just chaos"
    - "founder mood as weather"
    - "equity that might be worth nothing"
    - "building the plane while flying it"
    
  hierarchy:
    - "founder"
    - "CEO"
    - "co-founder"
    - "first hire"
    - "early team"
    
  stakes_language:
    - "we're all in this together"
    - "startup family"
    - "mission-driven"
    - "before product-market fit"
```

---

### Location 2B: SF Growth-Stage Startup IC

```yaml
# variables/gen_z_professional/sf_growth_stage/characters.yaml

characters:
  - name: Aiden
    age: 27
    role: senior software engineer
    years_in_workforce: 4
    company_stage: Series B
    team_size: 85
    
  - name: Priya
    age: 26
    role: product manager
    years_in_workforce: 3
    company_stage: Series C
    team_size: 150
    
  - name: Marcus
    age: 28
    role: engineering manager
    years_in_workforce: 5
    company_stage: Series B
    team_size: 70
    
  - name: Lily
    age: 25
    role: senior designer
    years_in_workforce: 3
    company_stage: Series C
    team_size: 120
```

```yaml
# variables/gen_z_professional/sf_growth_stage/triggers.yaml

triggers:
  false_alarm:
    - event: reorg announcement email
      time: Monday morning
      context: after leadership changes
      typical_reality: team restructuring, same role
      
    - event: skip-level meeting invite
      time: mid-week
      context: during performance cycle
      typical_reality: routine check-in
      
    - event: Slack from VP of Engineering
      time: end of day
      context: after a big release
      typical_reality: kudos message
      
    - event: "Confidential" calendar hold
      time: Friday afternoon
      context: layoffs in the news
      typical_reality: comp review (good news)
      
    - event: team headcount freeze announcement
      time: all-hands
      context: market downturn
      typical_reality: hiring pause, not layoffs
      
    - event: competitor acquisition news
      time: morning news cycle
      context: in their space
      typical_reality: doesn't affect their strategy
```

```yaml
# variables/gen_z_professional/sf_growth_stage/industry_terms.yaml

industry_terms:
  stressors:
    - "reorg"
    - "headcount freeze"
    - "performance cycle"
    - "promo committee"
    - "stack ranking"
    - "PIP"
    
  unique_pressures:
    - "scaling pains"
    - "process overhead"
    - "politics emerging"
    - "losing startup feel"
    - "IPO pressure"
    
  hierarchy:
    - "VP"
    - "director"
    - "senior manager"
    - "manager"
    - "senior IC"
    - "IC"
    
  stakes_language:
    - "leveling"
    - "scope"
    - "impact"
    - "visibility"
```

---

### Location 2C: SF/SV Big Tech IC (FAANG)

```yaml
# variables/gen_z_professional/sv_big_tech/characters.yaml

characters:
  - name: Chen
    age: 27
    role: software engineer (L4)
    years_in_workforce: 4
    company: large tech company
    team: infrastructure
    
  - name: Aaliyah
    age: 26
    role: product manager
    years_in_workforce: 3
    company: tech giant
    team: consumer products
    
  - name: Derek
    age: 28
    role: senior engineer (L5)
    years_in_workforce: 5
    company: big tech
    team: machine learning
    
  - name: Emma
    age: 25
    role: data scientist
    years_in_workforce: 2
    company: tech giant
    team: ads
    
  - name: Raj
    age: 29
    role: tech lead (L6)
    years_in_workforce: 6
    company: large tech company
    team: cloud services
```

```yaml
# variables/gen_z_professional/sv_big_tech/locations.yaml

locations:
  - workspace: campus office
    detail: the desk in the building with the good café
    building: main campus
    commute: the company shuttle from SF
    
  - workspace: home office
    detail: the standing desk setup
    building: apartment in Mountain View
    commute: none—WFH day
    
  - workspace: micro-kitchen
    detail: standing by the snacks
    building: their building
    commute: quick break between meetings
    
  - workspace: phone booth
    detail: the small room for private calls
    building: open office floor
    commute: across the floor
    
  - workspace: outdoor seating
    detail: the courtyard table
    building: between buildings
    commute: walking meeting
```

```yaml
# variables/gen_z_professional/sv_big_tech/triggers.yaml

triggers:
  false_alarm:
    - event: calibration meeting added to calendar
      time: during perf season
      context: manager's calendar blocked
      typical_reality: routine process
      fear: getting downleveled
      
    - event: Slack from skip-level
      time: after a project shipped
      context: unusual direct message
      typical_reality: kudos
      fear: something went wrong
      
    - event: "layoffs" trending on Blind
      time: any time
      context: always
      typical_reality: different company
      fear: their company next
      
    - event: org announcement email
      time: Monday morning
      context: after leadership shuffle
      typical_reality: new VP, team unaffected
      fear: team being dissolved
      
    - event: PIP mentioned in team meeting
      time: during 1:1 prep
      context: manager discussing another team
      typical_reality: general information
      fear: am I next?
      
    - event: recruiter reaching out
      time: LinkedIn notification
      context: normal recruiting
      typical_reality: routine poaching attempt
      fear: they know something about layoffs
```

```yaml
# variables/gen_z_professional/sv_big_tech/industry_terms.yaml

industry_terms:
  stressors:
    - "calibration"
    - "perf cycle"
    - "stack ranking"
    - "PIP"
    - "layoffs"
    - "reorg"
    - "leveling"
    - "promo packet"
    
  unique_pressures:
    - "golden handcuffs"
    - "RSU cliff"
    - "refresher grant"
    - "perf rating"
    - "exceeds vs meets"
    - "scope for level"
    
  hierarchy:
    - "VP"
    - "director"
    - "senior manager"
    - "manager"
    - "TL/TLM"
    - "senior (L5/E5)"
    - "mid (L4/E4)"
    - "junior (L3/E3)"
    
  workplace:
    - "campus"
    - "the building"
    - "the org"
    - "the team"
    - "Blind"
    - "the shuttle"
```

```yaml
# variables/gen_z_professional/sv_big_tech/body_sensations.yaml

sensations:
  - primary: stomach drop
    secondary: that familiar dread
    context: perf season
    
  - primary: chest tighten
    secondary: mind racing through scenarios
    context: reorg rumors
    
  - primary: adrenaline spike
    secondary: checking Blind immediately
    context: any company news
    
  - primary: jaw clench
    secondary: shoulders tense
    context: calibration week
    
  - primary: that cold feeling
    secondary: scrolling for information
    context: layoff headlines
```

---

# PART 3: SEATTLE COVERAGE

## Assessment: Templates or Variables?

**Seattle Big Tech** (Amazon, Microsoft, etc.) shares Gen Z Professional voice but has distinct culture:

| Element | SF Tech | Seattle Tech |
|---------|---------|--------------|
| Culture | "Move fast, break things" | "Earn trust," "Bias for action" |
| Anxiety source | Startup instability | Corporate politics, PIPs |
| Hierarchy | Flat-ish | Very leveled |
| Unique stressors | Runway, pivots | Stack ranking, pip culture |
| Social vibe | Scrappy, informal | More corporate, process-heavy |

**Conclusion:** Same Gen Z Professional templates work. Need Seattle-specific variables for:
- Amazon culture
- Microsoft culture
- Seattle gaming (different vibe)

---

### Location 3A: Seattle Amazon

```yaml
# variables/gen_z_professional/seattle_amazon/characters.yaml

characters:
  - name: Jordan
    age: 27
    role: SDE II
    years_in_workforce: 4
    team: AWS
    level: L5
    
  - name: Priya
    age: 26
    role: product manager
    years_in_workforce: 3
    team: retail
    level: L5
    
  - name: Marcus
    age: 28
    role: senior SDE
    years_in_workforce: 5
    team: Alexa
    level: L6
    
  - name: Emily
    age: 25
    role: SDE I
    years_in_workforce: 2
    team: AWS
    level: L4
    
  - name: Kevin
    age: 29
    role: SDM
    years_in_workforce: 6
    team: Prime
    level: L6
```

```yaml
# variables/gen_z_professional/seattle_amazon/locations.yaml

locations:
  - workspace: the office
    detail: the desk on the floor with the good views of the needle
    building: Day 1 tower
    commute: the light rail from Capitol Hill
    
  - workspace: home office
    detail: the second bedroom converted to office
    building: apartment in Ballard
    commute: none—WFH day
    
  - workspace: coffee shop
    detail: the corner table
    building: local spot in SLU
    commute: a ten-minute walk
    
  - workspace: phone booth
    detail: the small room for the difficult call
    building: their floor
    commute: down the hall
    
  - workspace: the spheres
    detail: walking through on a break
    building: campus
    commute: between meetings
```

```yaml
# variables/gen_z_professional/seattle_amazon/triggers.yaml

triggers:
  false_alarm:
    - event: meeting with skip-level
      time: during Forte season
      context: unusual invite
      typical_reality: skip-level check-in (normal)
      fear: discussion about performance
      
    - event: "Pivot" email from HR
      time: any time
      context: reorg rumors
      typical_reality: benefits update
      fear: the PIP talk
      
    - event: manager's calendar suddenly blocked
      time: mid-week
      context: during planning season
      typical_reality: planning meetings
      fear: stack ranking discussions
      
    - event: Blind post about their org
      time: evening
      context: scrolling after work
      typical_reality: random complaining
      fear: something they don't know
      
    - event: doc review comments from leadership
      time: before a big meeting
      context: six-pager review
      typical_reality: normal pushback
      fear: idea getting killed
      
    - event: new IC joining at their level
      time: team announcement
      context: headcount increase
      typical_reality: team growth
      fear: competition for promo
```

```yaml
# variables/gen_z_professional/seattle_amazon/industry_terms.yaml

industry_terms:
  stressors:
    - "Forte"
    - "OLR"
    - "stack ranking"
    - "PIP"
    - "Pivot"
    - "URA"
    - "TT" 
    - "LE"
    
  unique_pressures:
    - "leadership principles"
    - "writing culture"
    - "six-pager"
    - "bar raiser"
    - "earn trust"
    - "bias for action"
    - "disagree and commit"
    
  hierarchy:
    - "VP"
    - "director"
    - "senior manager"
    - "manager"
    - "L7"
    - "L6"
    - "L5"
    - "L4"
    
  workplace:
    - "Day 1"
    - "the spheres"
    - "SLU"
    - "the org"
    - "Blind"
    - "Chime"
```

---

### Location 3B: Seattle Microsoft

```yaml
# variables/gen_z_professional/seattle_microsoft/characters.yaml

characters:
  - name: Alex
    age: 27
    role: software engineer II
    years_in_workforce: 4
    team: Azure
    level: 62
    
  - name: Mei
    age: 26
    role: PM
    years_in_workforce: 3
    team: Office
    level: 61
    
  - name: David
    age: 28
    role: senior engineer
    years_in_workforce: 5
    team: Windows
    level: 63
    
  - name: Sarah
    age: 25
    role: engineer
    years_in_workforce: 2
    team: Teams
    level: 60
    
  - name: Ravi
    age: 29
    role: principal engineer
    years_in_workforce: 6
    team: AI
    level: 64
```

```yaml
# variables/gen_z_professional/seattle_microsoft/locations.yaml

locations:
  - workspace: the office
    detail: the desk in building 40-something
    building: Redmond campus
    commute: the connector from Seattle
    
  - workspace: home office
    detail: the setup in the spare room
    building: house in Kirkland
    commute: none—flex day
    
  - workspace: campus café
    detail: the table by the window
    building: the commons
    commute: a short walk between buildings
    
  - workspace: conference room
    detail: the one that actually has working AV
    building: their building
    commute: down the hall
    
  - workspace: coffee shop
    detail: the regular spot
    building: downtown Bellevue
    commute: after a dentist appointment
```

```yaml
# variables/gen_z_professional/seattle_microsoft/triggers.yaml

triggers:
  false_alarm:
    - event: connect meeting invite
      time: during review season
      context: manager blocking time
      typical_reality: normal 1:1
      fear: bad review discussion
      
    - event: email from HR
      time: any time
      context: always
      typical_reality: benefits or policy update
      fear: something about their role
      
    - event: reorg announcement
      time: leadership meeting
      context: after Satya's email
      typical_reality: different org affected
      fear: their team moving
      
    - event: Teams message from skip-level
      time: unusual time
      context: after shipping something
      typical_reality: congrats
      fear: something went wrong
      
    - event: Yammer post about their product
      time: during work hours
      context: public discussion
      typical_reality: user feedback
      fear: exec seeing problems
      
    - event: sudden calendar change from manager
      time: day of scheduled 1:1
      context: moved, not cancelled
      typical_reality: conflict
      fear: avoiding difficult conversation
```

```yaml
# variables/gen_z_professional/seattle_microsoft/industry_terms.yaml

industry_terms:
  stressors:
    - "Connect"
    - "review season"
    - "calibration"
    - "rewards"
    - "impact"
    - "reorg"
    
  unique_pressures:
    - "growth mindset"
    - "model coach care"
    - "one Microsoft"
    - "level expectations"
    - "IC vs manager track"
    
  hierarchy:
    - "CVP"
    - "VP"
    - "partner"
    - "principal"
    - "senior"
    - "level 60-67"
    
  workplace:
    - "campus"
    - "Redmond"
    - "building [number]"
    - "the connector"
    - "Teams"
```

---

### Location 3C: Seattle Gaming

```yaml
# variables/gen_z_professional/seattle_gaming/characters.yaml

characters:
  - name: Jake
    age: 27
    role: game designer
    years_in_workforce: 4
    company: major studio
    team: live service
    
  - name: Mia
    age: 26
    role: software engineer
    years_in_workforce: 3
    company: indie studio
    team: gameplay
    
  - name: Tyler
    age: 28
    role: senior artist
    years_in_workforce: 5
    company: AAA studio
    team: environment art
    
  - name: Zoe
    age: 25
    role: QA lead
    years_in_workforce: 3
    company: game studio
    team: quality assurance
    
  - name: Chris
    age: 29
    role: technical director
    years_in_workforce: 6
    company: established studio
    team: engine
```

```yaml
# variables/gen_z_professional/seattle_gaming/triggers.yaml

triggers:
  false_alarm:
    - event: production meeting moved up
      time: morning of
      context: during crunch
      typical_reality: schedule adjustment
      fear: milestone in danger
      
    - event: Slack from the EP
      time: late night
      context: close to ship date
      typical_reality: encouragement
      fear: scope change
      
    - event: review embargo lifting
      time: launch window
      context: everyone watching
      typical_reality: normal reviews
      fear: bad scores
      
    - event: player count dashboard alert
      time: after launch
      context: live service game
      typical_reality: expected fluctuation
      fear: game dying
      
    - event: studio all-hands announced
      time: between projects
      context: industry layoffs in news
      typical_reality: project announcement
      fear: studio closing
      
    - event: publisher meeting added
      time: mid-production
      context: without context
      typical_reality: milestone check-in
      fear: project getting cancelled
```

```yaml
# variables/gen_z_professional/seattle_gaming/industry_terms.yaml

industry_terms:
  stressors:
    - "crunch"
    - "gold master"
    - "day one patch"
    - "metacritic"
    - "player count"
    - "live service metrics"
    - "studio closure"
    
  unique_pressures:
    - "passion exploitation"
    - "crunch culture"
    - "project-based employment"
    - "publisher pressure"
    - "review scores"
    
  hierarchy:
    - "EP (executive producer)"
    - "creative director"
    - "lead"
    - "senior"
    - "mid"
    - "junior"
    
  workplace:
    - "the studio"
    - "production"
    - "the bullpen"
    - "the war room"
```

---

# SUMMARY: What You Now Have

## Templates (Voice Layer)

| Persona | Template Set | Location Coverage |
|---------|--------------|-------------------|
| Gen Z Professional | 1 set (4 templates) | All 10+ Gen Z locations |
| SF/SV Founder | 1 set (4 templates) | Founder-specific |
| Healthcare RN | 1 set (4 templates) | All healthcare settings |
| Gen Alpha Student | 1 set (4 templates) | All school settings |

## Variables (Details Layer)

| Persona | Variable Sets |
|---------|---------------|
| Gen Z Professional | 13 sets (NYC finance, SF tech, London, LA, Boston, Chicago, Seattle, Austin, remote, NYC creative, SF early-stage, SF growth, SV big tech) |
| SF/SV Founder | 1 set |
| Healthcare RN | 1 set (covers all units) |
| Gen Alpha Student | 1 set (covers all school types) |
| Seattle-specific | 3 sets (Amazon, Microsoft, Gaming) |

## Total Assets

- **Template sets:** 4
- **Variable sets:** 18+
- **Unique books possible:** 500+ (before adding more topics/engines)

**The system is working:** Maximum reuse of templates, maximum variety through variables.

---

*End of SF/SV and Seattle Coverage*
