# Opinion Author Generation System - Developer Spec

## Executive Summary

The current system generates topic-specific opinion author files by copying the same 3 Gen Z authors to ALL personas. This creates a demographic mismatch - SMB owners and Silicon Valley founders hearing "7 years since high school" content doesn't resonate.

**The fix:** Create generation-appropriate opinion author templates and modify the generation script to select the correct template based on persona demographics.

---

## Current Architecture (What Exists)

### File Types

| Type | Naming Pattern | Purpose | Status |
|------|----------------|---------|--------|
| Base professional authors | `{persona_id}_authors.yaml` | 12 expert voices (clinical, wellness, leadership, etc.) | ✅ Working |
| Topic opinion authors | `{persona_id}__{topic}__authors.yaml` | 1-3 lived-experience peer voices per topic | ⚠️ Broken |
| Location peer authors | `{location}_{generation}_authors.yaml` | 10-12 location-specific peer voices | ✅ Working |
| Location variables | `{location}_{generation}_variables.yaml` | Cost of living, neighborhoods, cultural details | ✅ Working |

### Current Generation Flow (Broken)

```
opinion_gen_z_authors.yaml (source template)
        ↓
generation script copies to ALL personas
        ↓
sv_techie__anxiety__authors.yaml      → Gen Z authors (OK for sv_techie)
smb_owners__anxiety__authors.yaml     → Gen Z authors (WRONG for SMB owners)
silicon_valley_founders__anxiety__authors.yaml → Gen Z authors (WRONG)
sf_founders__anxiety__authors.yaml    → Gen Z authors (WRONG)
```

### The 3 Gen Z Opinion Authors (Currently Used Everywhere)

```yaml
# Alex Rivera - lived_through style
- bio: "navigating anxiety, burnout, and identity pressure in early adulthood"
- pov_spine.cost_paid: "7 years since high school"
- dialect_profile.generation: genz
- slang_density_max.audiobook: 0.08

# Jordan Lee - contrarian_soft style  
- bio: "challenges common self-help assumptions with calm, precise reframes"
- dialect_profile.generation: genz

# Maya Chen - lived_through style
- bio: "why achievement without clarity leads to anxiety"
- dialect_profile.generation: genz
```

---

## Required Fix

### Step 1: Create Generation-Specific Opinion Author Templates

Create these source templates:

```
authors/templates/
├── opinion_gen_z_authors.yaml      # Ages 18-28 (existing)
├── opinion_gen_alpha_authors.yaml  # Ages 10-17 (needs creation)
├── opinion_millennial_authors.yaml # Ages 29-44 (needs creation)
├── opinion_gen_x_authors.yaml      # Ages 45-59 (needs creation)
├── opinion_boomer_authors.yaml     # Ages 60+ (needs creation, optional)
└── opinion_ageless_authors.yaml    # No age markers (fallback)
```

### Step 2: Create Persona-to-Generation Mapping

```yaml
# config/persona_demographics.yaml
personas:
  # Gen Z personas (use opinion_gen_z_authors.yaml)
  sv_techie:
    primary_generation: gen_z
    age_range: [22, 28]
    
  # Millennial/Gen X personas (use opinion_millennial_authors.yaml or opinion_gen_x_authors.yaml)
  smb_owners:
    primary_generation: millennial_gen_x
    age_range: [32, 55]
    
  silicon_valley_founders:
    primary_generation: millennial
    age_range: [28, 45]
    
  sf_founders:
    primary_generation: millennial
    age_range: [28, 45]
    
  dc_lawyers:
    primary_generation: millennial_gen_x
    age_range: [30, 55]
    
  healthcare_rn:
    primary_generation: millennial
    age_range: [25, 50]
    
  firefighters:
    primary_generation: millennial_gen_x
    age_range: [25, 55]
    
  creative_freelancers:
    primary_generation: millennial
    age_range: [25, 40]
    
  # Gen Alpha personas (use opinion_gen_alpha_authors.yaml)
  # Note: Gen Alpha opinion authors should be older mentors, not peers
  nyc_gen_alpha:
    primary_generation: gen_alpha
    age_range: [10, 17]
    opinion_author_generation: millennial  # Their opinion authors are adults
```

### Step 3: Modify Generation Script

```python
# Pseudocode for updated generation logic

def generate_topic_authors(persona_id: str, topic: str):
    # Load persona config
    persona_config = load_yaml(f"config/persona_demographics.yaml")
    persona = persona_config["personas"][persona_id]
    
    # Determine which opinion author template to use
    if persona.get("opinion_author_generation"):
        # Override for special cases (e.g., Gen Alpha uses adult authors)
        template_gen = persona["opinion_author_generation"]
    else:
        template_gen = persona["primary_generation"]
    
    # Map to template file
    template_map = {
        "gen_z": "opinion_gen_z_authors.yaml",
        "gen_alpha": "opinion_gen_alpha_authors.yaml", 
        "millennial": "opinion_millennial_authors.yaml",
        "millennial_gen_x": "opinion_millennial_authors.yaml",  # Use millennial as default
        "gen_x": "opinion_gen_x_authors.yaml",
        "ageless": "opinion_ageless_authors.yaml"
    }
    
    template_file = template_map.get(template_gen, "opinion_ageless_authors.yaml")
    
    # Load template and generate
    template = load_yaml(f"authors/templates/{template_file}")
    
    # Filter authors by topic domain match (existing logic)
    matched_authors = filter_by_topic(template["authors"], topic)
    
    # Output
    output = {
        "persona_id": persona_id,
        "topic": topic,
        "generated_from": f"authors/templates/{template_file}",
        "authors": matched_authors
    }
    
    save_yaml(output, f"authors/generated/{persona_id}__{topic}__authors.yaml")
```

---

## Opinion Author Template Specs

### Gen Z Template (Existing - Minor Updates)

```yaml
# opinion_gen_z_authors.yaml
generation: gen_z
age_markers:
  - "since high school"
  - "in my early twenties"
  - "graduating into"
  - "first apartment"
  - "entry-level"

authors:
  - id: opinion_alex_rivera
    generation: gen_z
    pov_spine:
      cost_paid: "Learning this cost me 7 years since high school..."
    dialect_profile:
      generation: genz
      slang_density_max:
        audiobook: 0.08
        podcast: 0.15
        tiktok: 0.3
    # ... rest of existing config
```

### Millennial Template (NEW - Create This)

```yaml
# opinion_millennial_authors.yaml
generation: millennial
age_markers:
  - "in my thirties"
  - "after a decade of"
  - "mid-career"
  - "juggling work and family"
  - "mortgage"
  - "promotion track"

authors:
  - id: opinion_marcus_chen
    name: Marcus Chen
    display_name: Marcus Chen
    generation: millennial
    author_class: opinion_author
    opinion_style: lived_through
    authority_source: lived_experience
    bio_80w: |
      Marcus writes from fifteen years navigating corporate burnout, 
      career pivots, and the pressure to have it all figured out by now. 
      His voice is direct and experienced, focused on what actually 
      worked after trying everything that didn't.
    domains:
      - lived_experience
      - career_transitions
      - work_life_balance
      - burnout_recovery
    tones:
      - direct
      - experienced
      - pragmatic
    voice_profile_id: V_EN_M_GROUNDED_10
    pov: first
    constraints:
      moralizing: forbidden
      universal_claims: forbidden
      disclosure_ok: true
    voice_fingerprint:
      pov_ratio:
        first_person_min: 0.08
        second_person_max: 0.02
      sentence_length_avg_words: [8, 16]
      stance_markers_min_per_1k_words: 4
      boundary_markers_required: true
      authority_sources_allowed:
        - lived_experience
        - professional_experience
        - reflection
      forbidden_phrases:
        - you should
        - everyone needs
        - the best way
        - always
        - must
      emotional_temperature_max: medium
    dialect_profile:
      generation: millennial
      slang_density_max:
        audiobook: 0.03
        podcast: 0.08
        tiktok: 0.15
      allowed_registers:
        - conversational
        - professional_casual
        - reflective
      forbidden_registers:
        - meme_spam
        - corporate_jargon
        - gen_z_slang
    pov_spine:
      belief: |
        Burnout isn't a personal failure—it's what happens when 
        systems demand more than humans can sustainably give.
      former_belief: |
        I used to think working harder was always the answer. 
        That success meant never saying no.
      tension: |
        I've built a more sustainable life, but I still catch myself 
        falling into old patterns. Progress isn't linear.
      refusal: |
        I refuse to pretend there's a hack that fixes everything. 
        I refuse to sell the hustle. I refuse to shame anyone for 
        struggling in a system designed to extract maximum output.
      cost_paid: |
        Learning this cost me my health at 32, a marriage, and 
        two years rebuilding from scratch. That breakdown taught me 
        what no productivity book ever could.
      boundary: |
        I'm sharing what I learned the hard way, not prescribing 
        a formula. What worked for me might not work for you, 
        and that's okay.

  - id: opinion_rachel_okonkwo
    name: Rachel Okonkwo
    display_name: Rachel Okonkwo
    generation: millennial
    author_class: opinion_author
    opinion_style: contrarian_soft
    authority_source: reframing
    bio_80w: |
      Rachel spent a decade in high-pressure environments before 
      realizing the rules she'd internalized weren't serving her. 
      She challenges conventional wisdom about success, ambition, 
      and what it means to have a good life—without judgment.
    domains:
      - reframing
      - ambition
      - values_clarification
      - success_redefinition
    tones:
      - calm
      - incisive
      - thoughtful
    voice_profile_id: V_EN_F_CLEAR_04
    pov: first
    constraints:
      moralizing: forbidden
      sensationalism: forbidden
    voice_fingerprint:
      pov_ratio:
        first_person_min: 0.06
        second_person_max: 0.02
      sentence_length_avg_words: [8, 18]
      stance_markers_min_per_1k_words: 3
      boundary_markers_required: true
      authority_sources_allowed:
        - reframing
        - reflection
        - professional_observation
      forbidden_phrases:
        - you have to
        - this is the truth
        - everyone knows
        - just
      emotional_temperature_max: low
    dialect_profile:
      generation: millennial
      slang_density_max:
        audiobook: 0.02
        podcast: 0.06
        tiktok: 0.12
      allowed_registers:
        - precise
        - professional_casual
        - analytical
      forbidden_registers:
        - hype
        - aggressive_irony
        - gen_z_slang

  - id: opinion_david_park
    name: David Park
    display_name: David Park
    generation: millennial
    author_class: opinion_author
    opinion_style: lived_through
    authority_source: reflection
    bio_80w: |
      David focuses on meaning and purpose after years of chasing 
      metrics that didn't matter. His perspective centers on what 
      happens when you achieve everything you thought you wanted 
      and still feel empty.
    domains:
      - meaning
      - purpose
      - values
      - midlife_recalibration
    tones:
      - introspective
      - measured
      - sincere
    voice_profile_id: V_EN_M_CALM_03
    pov: first
    constraints:
      advice_language: forbidden
    voice_fingerprint:
      pov_ratio:
        first_person_min: 0.07
        second_person_max: 0.015
      sentence_length_avg_words: [7, 15]
      stance_markers_min_per_1k_words: 4
      boundary_markers_required: true
      authority_sources_allowed:
        - reflection
        - lived_experience
      forbidden_phrases:
        - you need to
        - the right way
        - success means
        - should
      emotional_temperature_max: medium_low
    dialect_profile:
      generation: millennial
      slang_density_max:
        audiobook: 0.02
        podcast: 0.05
        tiktok: 0.10
      allowed_registers:
        - reflective
        - thoughtful_conversational
      forbidden_registers:
        - sarcasm
        - meme_language
        - corporate_speak
```

### Gen X Template (NEW - Create This)

```yaml
# opinion_gen_x_authors.yaml
generation: gen_x
age_markers:
  - "in my forties"
  - "after twenty years"
  - "watching my kids"
  - "parents aging"
  - "second act"
  - "seen this cycle before"

authors:
  - id: opinion_karen_mitchell
    name: Karen Mitchell
    display_name: Karen Mitchell
    generation: gen_x
    author_class: opinion_author
    opinion_style: lived_through
    authority_source: lived_experience
    bio_80w: |
      Karen has navigated three recessions, two career reinventions, 
      and the sandwich generation squeeze. Her voice carries the 
      weight of experience without the weariness—she's seen what 
      doesn't work and has no patience for pretense.
    domains:
      - lived_experience
      - resilience
      - pragmatic_adaptation
      - multi_generational_pressure
    tones:
      - no_nonsense
      - warm
      - experienced
    voice_profile_id: V_EN_F_WARM_01
    pov: first
    constraints:
      moralizing: forbidden
      universal_claims: forbidden
      disclosure_ok: true
    voice_fingerprint:
      pov_ratio:
        first_person_min: 0.07
        second_person_max: 0.02
      sentence_length_avg_words: [8, 16]
      stance_markers_min_per_1k_words: 4
      boundary_markers_required: true
      authority_sources_allowed:
        - lived_experience
        - observation
        - reflection
      forbidden_phrases:
        - you should
        - everyone needs
        - back in my day
        - kids these days
      emotional_temperature_max: medium
    dialect_profile:
      generation: gen_x
      slang_density_max:
        audiobook: 0.01
        podcast: 0.04
        tiktok: 0.08
      allowed_registers:
        - direct_conversational
        - warm_professional
        - reflective
      forbidden_registers:
        - corporate_jargon
        - millennial_therapy_speak
        - gen_z_slang
    pov_spine:
      belief: |
        You can't control what happens to you, but you can 
        control how you respond. That's not toxic positivity—
        it's survival.
      former_belief: |
        I used to think if I just worked hard enough and followed 
        the rules, everything would work out. The rules changed 
        three times while I was following them.
      tension: |
        I'm still figuring this out. Twenty-five years in and 
        I'm still learning. That's not failure—that's life.
      refusal: |
        I refuse to pretend any of this is easy. I refuse to 
        sell quick fixes. I refuse to judge anyone for being 
        overwhelmed by genuinely overwhelming circumstances.
      cost_paid: |
        Learning this cost me a lot—health scares, relationship 
        strain, years of running on empty. But I'm still here, 
        and I know things now I wish someone had told me earlier.
      boundary: |
        This is what worked for me. Your situation is different. 
        Take what's useful, leave the rest.

  - id: opinion_james_thurston
    # ... similar structure
    
  - id: opinion_linda_vasquez
    # ... similar structure
```

### Ageless Template (NEW - Create This)

For personas where age isn't relevant or spans too wide a range:

```yaml
# opinion_ageless_authors.yaml
generation: ageless
age_markers: []  # None - deliberately age-neutral

authors:
  - id: opinion_sam_taylor
    name: Sam Taylor
    display_name: Sam Taylor
    generation: null  # Explicitly no generation
    author_class: opinion_author
    opinion_style: lived_through
    authority_source: lived_experience
    bio_80w: |
      Sam writes from experience navigating anxiety, pressure, and 
      the search for sustainable wellbeing. Their voice is grounded 
      and honest, focused on what they learned rather than 
      prescribing what others should do.
    # ... config with NO age-specific references
    pov_spine:
      cost_paid: |
        Learning this took years of struggle—lost sleep, constant 
        second-guessing, periods of exhaustion. But that struggle 
        taught me something I can share.
      # Note: NO "since high school" or "in my thirties" etc.
```

---

## Topic-to-Author Matching Logic

Not all opinion authors fit all topics. The generation script should filter authors by domain match:

```yaml
# config/topic_domain_mapping.yaml
topics:
  anxiety:
    required_domains: [lived_experience, clinical, recovery]
    preferred_domains: [anxiety, mental_health]
    
  financial_stress:
    required_domains: [lived_experience]
    preferred_domains: [financial, career, practical]
    
  purpose:
    required_domains: [meaning, values, reflection]
    preferred_domains: [purpose, ambition, values_clarification]
    
  grief:
    required_domains: [lived_experience]
    preferred_domains: [grief, loss, recovery]
    exclude_styles: [contrarian_soft]  # Grief needs gentler approach
    
  boundaries:
    required_domains: [lived_experience, recovery]
    preferred_domains: [boundaries, relationships, self_trust]
    
  # ... etc for all 17 topics
```

### Author Selection Logic

```python
def filter_by_topic(authors: list, topic: str) -> list:
    topic_config = load_yaml("config/topic_domain_mapping.yaml")["topics"][topic]
    
    matched = []
    for author in authors:
        author_domains = set(author["domains"])
        required = set(topic_config.get("required_domains", []))
        preferred = set(topic_config.get("preferred_domains", []))
        excluded_styles = topic_config.get("exclude_styles", [])
        
        # Must have at least one required domain
        if not author_domains.intersection(required):
            continue
            
        # Check style exclusions
        if author.get("opinion_style") in excluded_styles:
            continue
            
        # Score by preferred domain overlap
        score = len(author_domains.intersection(preferred))
        matched.append((author, score))
    
    # Return top 3 by score, minimum 1
    matched.sort(key=lambda x: x[1], reverse=True)
    return [m[0] for m in matched[:3]] if matched else authors[:1]
```

---

## Validation Checklist

Before deploying updated generation:

### Template Validation
- [ ] Each generation template has 3 distinct authors
- [ ] No cross-generation slang (Gen X authors don't say "lowkey")
- [ ] Age markers are consistent within template
- [ ] pov_spine.cost_paid references appropriate life stage
- [ ] dialect_profile.generation matches template generation
- [ ] slang_density_max decreases with age (Gen Z highest, Gen X lowest)

### Generation Script Validation
- [ ] Persona mapping covers all personas
- [ ] Fallback to ageless template works
- [ ] Topic filtering returns 1-3 authors
- [ ] Output YAML is valid
- [ ] generated_from field shows correct source template

### Output Validation
- [ ] SMB owners files use millennial/gen_x authors
- [ ] SV techie files use gen_z authors
- [ ] Gen Alpha persona files use appropriate mentor authors
- [ ] No "7 years since high school" in non-Gen-Z outputs

---

## File Inventory (Current State)

### Base Professional Authors (✅ Complete)
- `smb_owners_authors.yaml` - 12 authors
- `silicon_valley_founders_authors.yaml` - 12 authors
- `sf_founders_authors.yaml` - 12 authors
- `sv_techie_authors.yaml` - 12 authors (assumed)

### Topic Opinion Authors (⚠️ Need Regeneration)
68+ files across 4 personas × 17 topics, all currently using Gen Z template

### Location Peer Authors (✅ Complete)
- NYC Gen Z - validated
- Vancouver Gen Z - validated (minor rent adjustment needed)
- Plus 21 other location files

### Templates Needed
- [ ] `opinion_gen_z_authors.yaml` - exists, may need cleanup
- [ ] `opinion_millennial_authors.yaml` - CREATE
- [ ] `opinion_gen_x_authors.yaml` - CREATE  
- [ ] `opinion_ageless_authors.yaml` - CREATE
- [ ] `opinion_gen_alpha_authors.yaml` - CREATE (for mentor voices)

---

## Questions for Product Decision

1. **Do SMB owners need their own opinion authors, or can they share with silicon_valley_founders?**
   - Current: Both get Gen Z (wrong)
   - Recommendation: Both use millennial template, different personas get different base authors

2. **Should Gen Alpha personas have peer opinion authors or adult mentor voices?**
   - Recommendation: Adult mentor voices (millennial) since Gen Alpha are minors

3. **How many opinion authors per topic?**
   - Current: 1-3 depending on topic
   - `purpose` topic only has Maya Chen
   - Should all topics have 3 authors for variety?

4. **Should topic-specific filtering be stricter?**
   - Current: Grief uses all 3 authors
   - Should grief exclude contrarian_soft style?

---

## Implementation Priority

1. **HIGH**: Create `opinion_millennial_authors.yaml` template
2. **HIGH**: Update generation script with persona-to-generation mapping
3. **MEDIUM**: Create `opinion_gen_x_authors.yaml` template
4. **MEDIUM**: Create `opinion_ageless_authors.yaml` template
5. **LOW**: Create `opinion_gen_alpha_authors.yaml` template
6. **LOW**: Implement topic-to-author domain filtering

---

## Contact

Questions about this spec: [escalate to Nihala]
Questions about voice fingerprinting: [reference SOURCE_OF_TRUTH documentation]
Questions about TTS integration: [reference ElevenLabs SSML specs]
