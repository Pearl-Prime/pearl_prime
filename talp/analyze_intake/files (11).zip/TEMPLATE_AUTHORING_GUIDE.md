# Template Authoring Guide

**For Writers Creating Persona-Specific Therapeutic Content**

---

## What This Guide Is For

You're writing templates that will become therapeutic audiobooks. These templates are the voice layer of a carefully designed system. Your job is to make the mechanism *land* for a specific listener — not to invent the mechanism, not to design the arc, but to express it in a voice that makes someone driving home at night think: *"That's me."*

This guide tells you:
- What you're writing and why it matters
- What each atom role requires
- What's forbidden (and why)
- How to use variables correctly
- How to check your own work

Read this before writing your first template. Reference it when you're stuck.

---

## The One Thing to Remember

> **If it doesn't move the listener, it doesn't matter how correct it is.**

You're not writing content. You're writing a psychological operation disguised as a story. Every sentence either earns trust or loses it. Every pause either lets the body settle or rushes past the moment.

The listener is alone. They're probably exhausted. They chose this audiobook because something isn't working in their life. Your words are the only thing in the room with them.

Write like that matters.

---

## Part 1: Understanding the System

### The Hierarchy (Know Your Place In It)

| Layer | Who Owns It | What It Does |
|-------|-------------|--------------|
| **Mechanism** | System designers | Defines what internal shift we're engineering |
| **Arc** | Planners | Determines how we get there across time |
| **Role** | Contracts | Specifies what each moment must do |
| **Template** | **You** | Expresses it in a voice that resonates |

You don't decide what changes in the listener — that's the mechanism.
You don't decide the sequence — that's the arc.
You don't decide what each moment must accomplish — that's the role contract.

**You decide how it sounds.** That's everything.

### The Four Mechanisms (What You're Serving)

Every chapter engineers one of these shifts:

**Autonomic Regulation**
> "The body can downshift without certainty or resolution."

The listener learns their alarm system can settle even when nothing is resolved. The body doesn't need answers to feel safe.

**Cognitive Defusion**
> "Thoughts can be present without being obeyed."

The listener learns they can notice thoughts without believing them, engaging them, or acting on them. Thoughts become weather, not commands.

**Exposure Tolerance**
> "Discomfort can be survived without avoidance."

The listener learns that staying with discomfort doesn't break them. Avoidance feeds fear; presence shrinks it.

**Self-Trust Repair**
> "I can trust my responses even when they are imperfect."

The listener learns their reactions aren't failures — they're learned protections. They can trust themselves even when their system is loud.

**Your job:** Express whichever mechanism the chapter serves in a voice the persona will recognize as their own.

### The Four Atom Roles (What You're Writing)

Every story arc moves through four roles. You write one template per role.

| Role | Job | Emotional Target |
|------|-----|------------------|
| **Recognition** | Make them feel seen | "That's exactly what happens to me" |
| **Mechanism Proof** | Show why their strategy fails | "I've tried that too — it doesn't work" |
| **Turning Point** | Deliver the twist | "Oh... I never thought of it that way" |
| **Embodiment** | Show the new relationship | "Maybe I could do that" |

These are not optional. These are not suggestions. Each role has a contract. Your template must satisfy it.

---

## Part 2: Role Contracts

### Recognition

**Your job:** Establish identity and cost. Make the listener feel seen before you teach them anything.

**Must include:**
- Identity anchor (who this person is in their world)
- Internal stakes (what they stand to lose)
- Somatic activation (body sensations present)

**Allowed:**
- Confusion
- Vigilance
- Rumination
- Failed coping attempts
- Self-doubt

**Forbidden:**
- Any reframe or insight ("I realized...")
- Any lesson ("What mattered was...")
- Any improvement ("Then it got better...")
- Any exercise reference
- Any relief

**Forbidden phrases:**
- "this was actually"
- "I realized"
- "the truth was"
- "once I understood"
- "what mattered was"
- "after that"
- "everything changed"

**Resolution level:** 0 (no resolution whatsoever)

**The test:** If the listener feels any relief during Recognition, you've failed. They should feel *seen*, not *helped*. The help comes later.

---

### Mechanism Proof

**Your job:** Show why the listener's current strategy can't work. Not because they're doing it wrong — because the strategy itself is the trap.

**Must include:**
- Constraint loop (why trying harder makes it worse)
- Repeated failure (the pattern keeps happening)
- Pattern language (this is recognizable, familiar)

**Allowed:**
- Frustration
- Escalation
- Effort increase
- Partial awareness
- "Designed, not broken" framing

**Forbidden:**
- Instructions of any kind
- Named techniques
- Step sequences
- Relief claims
- Solution language
- The twist (that's next)

**Forbidden phrases:**
- "so I did"
- "the solution was"
- "what fixed it"
- "then I tried"
- "the answer is"
- "this works because"
- "the trick is"

**Resolution level:** 1 (slight increase — they see the pattern, but no relief yet)

**The test:** The listener should think: *"Yes, I've done exactly that, and it never works."* They should feel the frustration of the trap, not the hope of escape.

---

### Turning Point

**Your job:** Deliver the meaning inversion. This is the twist — the moment understanding reorganizes.

**Must include:**
- Reframe language (the old meaning becomes new)
- Interpretation shift (what they thought was X is actually Y)

**Allowed:**
- Surprise
- Hesitation
- Partial relief
- Emotional softening
- Exercise reference (can hint at practice)

**Forbidden:**
- Full resolution
- Mastery claims
- Permanence claims
- Future certainty
- Instructional steps

**Forbidden phrases:**
- "from then on"
- "never again"
- "it stopped"
- "I was cured"
- "problem solved"
- "finally free"
- "completely gone"

**Resolution level:** 2 (interpretive relief — they see differently, but aren't "fixed")

**Constraints:**
- Exactly ONE meaning inversion (not zero, not multiple)
- The twist should feel discovered, not delivered

**The test:** The listener's brain should quietly reorganize. They shouldn't feel lectured. They should feel like they figured something out — even though you led them there.

---

### Embodiment

**Your job:** Show the new relationship in motion. Not victory — orientation. Not cure — direction.

**Must include:**
- Relational shift (different relationship to the trigger)
- Lived example (showing, not telling)
- Grounded presence (in the body, in the moment)

**Allowed:**
- Uncertainty
- Nonlinearity
- Partial setbacks
- Ongoing practice reference
- Values language

**Forbidden:**
- Cure language
- Permanence claims
- Guarantees
- Universal promises

**Forbidden phrases:**
- "this will always"
- "you will never"
- "permanently"
- "completely fixed"
- "no longer have to"
- "the anxiety is gone"

**Resolution level:** 3 (maximum allowed — but still not "cured")

**The test:** The listener should think: *"That's not perfect, but it's different. Maybe I could do that."* They should feel possibility, not completion.

---

## Part 3: Writing for Audio

### Rhythm Matters More Than Meaning

In text, readers control pace. In audio, you control pace.

This means:
- Short sentences land harder
- Fragments create breath
- Repetition builds weight
- Silence is a tool

**Bad (reads fine, sounds flat):**
> He noticed that his chest was tight and his breathing was shallow, which made him wonder if something was wrong.

**Good (sounds like it matters):**
> His chest was tight.
> Breathing shallow.
> That familiar question: *What's wrong?*

The second version has pauses built in. The listener's body responds to the rhythm, not just the meaning.

### Write for the Ear, Not the Eye

Read everything aloud. If you stumble, rewrite.

- Avoid complex sentences
- Avoid parentheticals
- Avoid words that sound alike ("he'd heard her")
- Avoid tongue-twisters

**Bad:**
> He'd heard her hypothesis, though he thought the theory was thoroughly theoretical.

**Good:**
> She had a theory. He wasn't convinced.

### Somatic Pacing

Therapeutic audio isn't just narrative — it's physiological.

Your job is to:
1. **Activate** the listener's body (Recognition)
2. **Hold** tension without relief (Mechanism Proof)
3. **Allow** release at the right moment (Turning Point)
4. **Integrate** the shift (Embodiment)

This means you need to know where the listener's body is at each moment.

**Recognition** = body activated, breath shallow, scanning
**Mechanism Proof** = frustration building, effort increasing
**Turning Point** = pause, reframe, first softening
**Embodiment** = settling, landing, new rhythm

Write with this in mind. The twist doesn't just change meaning — it changes breathing.

---

## Part 4: Persona Voice

### Why Persona Matters

Firefighter anxiety ≠ student anxiety ≠ executive anxiety.

They share a nervous system. They don't share a story shape.

A firefighter's alarm fires when station tones drop.
A student's alarm fires when grades are posted.
An executive's alarm fires when the board meeting starts.

Same mechanism. Different world. Different language. Different stakes.

Your job is to write *for this person*, not for "people in general."

### Voice Elements to Calibrate

**Vocabulary**
- Use words this person would use
- Avoid clinical language unless the persona is clinical
- Match education level and professional register

**Setting**
- Ground the story in their world
- Use specific, concrete details they'd recognize
- Make the physical environment real

**Stakes**
- What does this person actually fear losing?
- Identity? Competence? Safety of others? Status?
- Make the stakes specific to their life

**Relationships**
- Who matters to this person?
- Crew? Classmates? Direct reports? Patients?
- Use relationships they'd recognize

### Example: Same Mechanism, Different Persona

**Autonomic Regulation — Firefighter Voice**

> Derek had been on the job twelve years.
> Long enough to trust his instincts.
>
> But lately, his body wasn't getting the memo.
>
> The tones dropped at 3 AM.
> Routine medical.
> Nothing that should've made his chest lock up.
>
> He pulled on his gear the same way he always did.
> Checked the rig.
> But something in his chest was already running ahead.
>
> The call was nothing.
> Patient was stable before they arrived.
>
> Driving back to the station,
> he couldn't shake it.
>
> That hum in his body that said *something's wrong*
> even when nothing was.

**Autonomic Regulation — Student Voice**

> Maya had always been good at school.
> That was the thing people knew about her.
>
> But lately, "good at school" felt like a costume she wasn't sure still fit.
>
> The professor posted grades at 8 AM.
> She'd been awake since 5, refreshing.
>
> Her roommate was still asleep.
> The room was quiet.
> But something in her chest was already running calculations.
>
> She got an A-.
> That should've been fine.
>
> Walking to her first class,
> she couldn't shake it.
>
> That feeling that said *not good enough*
> even when the evidence said otherwise.

Same mechanism. Same arc position. Completely different voice.

---

## Part 5: Variables

### The Rule

> **If removing the variable makes the sentence emotionally empty, it doesn't belong in a variable.**

Variables are for **facts and anchors**, not transformation.

### What Goes in Variables

| Type | Purpose | Examples |
|------|---------|----------|
| Character | Identity anchors | `{{character.name}}`, `{{character.years_on_job}}` |
| Location | Setting specifics | `{{location.station}}`, `{{location.building}}` |
| Timing | Temporal context | `{{trigger.time}}`, `{{setting.shift}}` |
| Trigger | Concrete activators | `{{trigger.sound}}`, `{{trigger.event}}` |
| Body | Physical specifics | `{{body.primary_sensation}}` |
| Relationship | Other people | `{{colleague.name}}`, `{{partner.title}}` |

### What Never Goes in Variables

| Type | Why Forbidden |
|------|---------------|
| Emotional language | Kills rhythm and voice |
| Reframe content | The twist must be written |
| Meaning statements | Core therapeutic content |
| Somatic descriptions | Must be crafted for pacing |
| Resolution language | Must be controlled precisely |

### Variable Density

**Maximum: 5-8 variables per 100 words**

If you have more than this, you're probably putting emotional content in variables.

**Bad (over-variabled):**
> {{character.name}} felt {{emotion.primary}} when {{trigger.event}} happened. Their {{body.sensation}} told them {{interpretation.initial}}.

**Good (variables as anchors only):**
> {{character.name}} felt it before he could name it. The {{trigger.sound}} at {{trigger.time}} shouldn't have mattered. But his chest was already tight.

In the good version, the emotional content ("felt it before he could name it," "shouldn't have mattered," "already tight") is written, not injected.

### Variable Syntax

Use double curly braces: `{{category.field}}`

```
{{character.name}}
{{character.years_on_job}}
{{location.station}}
{{trigger.time}}
{{trigger.sound}}
{{body.primary_sensation}}
```

Variables are replaced during hydration. Write the template as if the variable contains the right word — check rhythm by reading aloud with a placeholder.

---

## Part 6: Forbidden Content

### Global Prohibitions (Apply to ALL Roles)

These phrases/patterns must **never** appear in any template:

**Cure Language**
- "cured"
- "healed completely"
- "eliminated"
- "fixed forever"
- "no more anxiety"
- "gone for good"

**Instructional Language**
- "step one"
- "first you"
- "then do"
- "repeat this"
- "the technique is"
- "try to"

**Diagnostic Claims**
- "this means you have"
- "a sign of disorder"
- "clinical"
- "diagnosis"

**Authority Claims**
- "experts say"
- "science proves"
- "research shows" (unless actually citing)

**Technique Names in Story**
- "box breathing"
- "CBT"
- "exposure therapy"
- "grounding exercise"
- "mindfulness"

### Why These Are Forbidden

**Cure language** breaks trust. The listener knows they're not cured. If you promise cure and they're not cured tomorrow, they'll distrust everything you said.

**Instructional language** breaks immersion. The story becomes a lecture. The listener stops feeling and starts taking notes (or tuning out).

**Technique names** collapse story into teaching. The moment you name "box breathing," the listener is no longer experiencing settling — they're being assigned homework.

### The Subtle Traps

Watch for these — they're easy to write and hard to catch:

**Premature insight:**
> ❌ He realized the alarm wasn't danger.

(Don't say "realized" until Turning Point, and even then, show it rather than state it.)

**Accidental resolution:**
> ❌ After that, things got easier.

(This is forbidden before Embodiment, and even in Embodiment, "easier" is too clean.)

**Smuggled instruction:**
> ❌ He let himself breathe more slowly.

(This sounds like story but reads like instruction. Instead: "His breath found a slower rhythm on its own.")

**Certainty-dependent framing:**
> ❌ Once he understood what was happening, he felt better.

(This implies insight = relief. The mechanism is the opposite: relief can come *before* understanding.)

---

## Part 7: Self-Review Checklist

Before submitting any template, check these:

### Role Compliance

- [ ] Does this template serve its assigned role?
- [ ] Does it include all "must include" elements?
- [ ] Does it avoid all "must not include" elements?
- [ ] Does it avoid all forbidden phrases for this role?
- [ ] Is the resolution level appropriate? (0/1/2/3)

### Mechanism Alignment

- [ ] Does this template support the assigned mechanism?
- [ ] Does it avoid contradicting the mechanism?
- [ ] For Recognition: Is there somatic activation without relief?
- [ ] For Mechanism Proof: Is there failed control without solution?
- [ ] For Turning Point: Is there exactly one meaning inversion?
- [ ] For Embodiment: Is there new relationship without cure?

### Voice & Persona

- [ ] Does this sound like this persona?
- [ ] Is the vocabulary appropriate?
- [ ] Are the settings and stakes specific to their world?
- [ ] Would this person recognize themselves?

### Audio Quality

- [ ] Have I read this aloud?
- [ ] Do the sentences have rhythm?
- [ ] Are there natural pause points?
- [ ] Does the pacing match the emotional moment?

### Variable Discipline

- [ ] Are variables used only for anchors (names, places, times)?
- [ ] Is emotional content written, not injected?
- [ ] Is variable density ≤ 8 per 100 words?
- [ ] Do the sentences still work if I remove the variables?

### Forbidden Content

- [ ] No cure language anywhere
- [ ] No instructional language anywhere
- [ ] No technique names in story
- [ ] No premature resolution
- [ ] No certainty-dependent framing

---

## Part 8: Examples

### Complete Template: Recognition (Firefighter / Autonomic Regulation)

```markdown
# Recognition Template
## Persona: Firefighter
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}: First name
- {{character.years_on_job}}: Years of service
- {{location.station}}: Station identifier  
- {{trigger.time}}: Time the call dropped
- {{body.primary_sensation}}: Main physical sensation

### Template

{{character.name}} had been on the job {{character.years_on_job}} years.

Long enough to trust his instincts.
Long enough to know the difference between a real call and a drill.

But lately, his body wasn't getting the memo.

The tones dropped at {{trigger.time}}.
Routine medical.
Nothing that should've made his {{body.primary_sensation}}.

He pulled on his gear the same way he always did.
Checked the rig.
But something in his chest was already running ahead.

By the time they rolled out, his hands were steady—
but his pulse was telling a different story.

The call was nothing.
False alarm, basically.
The patient was fine before they even arrived.

And still, driving back to {{location.station}},
he couldn't shake it.

That hum in his body that said *something's wrong*
even when nothing was.

He'd trained for years to trust that signal.
Now it was firing when there was nothing to fight.

And that—
that was the part he couldn't tell anyone.
```

**Why this works:**
- Identity anchor: firefighter, years on job, station
- Stakes: can't trust his own body, can't tell anyone
- Somatic activation: chest, pulse, "hum in his body"
- No insight, no relief, no resolution
- Persona-specific: tones, gear, rig, station
- Variables are anchors only
- Rhythm built for audio

---

### Complete Template: Turning Point (Firefighter / Autonomic Regulation)

```markdown
# Turning Point Template
## Persona: Firefighter
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}: First name
- {{location.detail}}: Specific location in station

### Template

{{character.name}} stood in the {{location.detail}} longer than usual.

Didn't rush.
Didn't check the board.
Didn't do anything, really.

Just stood there.

The alarm had already passed.
The call was hours ago.
But his body was still holding on.

He noticed it—
chest still braced,
shoulders still up,
breath still shallow.

Not because something was wrong.
Because his system was still on watch.

He didn't try to fix it.
Didn't tell himself to calm down.
Just noticed.

And somewhere in that noticing,
something shifted.

Not dramatic.
Just quieter.

Breath came a little lower.
Shoulders dropped without instruction.

The alarm wasn't gone.
But it wasn't running the show anymore.

It was a signal.
Not a command.

His body had been doing its job—
keeping him ready,
keeping him sharp.

It wasn't broken.
It was trained.

And maybe—
maybe he didn't need to stop the alarm.

Maybe he just needed to land after it passed.
```

**Why this works:**
- Exactly one meaning inversion: "signal, not command"
- No cure, no permanence, no mastery
- Shows the shift through body, not explanation
- The insight feels discovered, not delivered
- "Maybe" keeps it tentative
- Variables are minimal (name, location)
- Rhythm builds to the turn, then softens

---

### What NOT to Write

**Bad Recognition (contains insight):**
> Derek felt anxious, but then he realized it was just his nervous system overreacting. Once he understood that, he started to feel better.

**Why it's bad:** Contains "realized," "understood," and improvement. This is Turning Point content shoved into Recognition. The listener gets relief before they've earned it.

---

**Bad Mechanism Proof (contains instruction):**
> He tried deep breathing, counting to four on the inhale and six on the exhale. It helped a little, but not enough.

**Why it's bad:** Names a technique and describes steps. Even though it says "not enough," it's still teaching. The listener is now thinking about counting, not feeling the trap.

---

**Bad Turning Point (multiple twists):**
> He realized the alarm was just his body protecting him. And then he understood that his thoughts were just noise. And finally, he saw that avoidance had been feeding the fear all along.

**Why it's bad:** Three meaning inversions in one atom. This is overwhelming and dilutes each insight. One twist, landed fully, is worth more than three rushed.

---

**Bad Embodiment (cure framing):**
> From then on, he never felt anxious at the station again. The alarm was gone, and he finally felt like himself.

**Why it's bad:** "From then on," "never," "gone," "finally" — all forbidden. This promises cure and will be false for the listener. It breaks trust and invalidates everything before it.

---

## Part 9: Quick Reference Card

Print this. Keep it visible while writing.

### The Four Roles

| Role | Job | Resolution |
|------|-----|------------|
| Recognition | Make them feel seen | 0 |
| Mechanism Proof | Show why they're stuck | 1 |
| Turning Point | Deliver the twist | 2 |
| Embodiment | Show new relationship | 3 |

### Always Forbidden

- Cure language ("cured," "gone," "fixed")
- Permanence ("never again," "from then on")
- Instructions ("step one," "try to," "count to")
- Technique names ("box breathing," "CBT")
- Premature insight (before Turning Point)
- Certainty-dependent relief ("once I understood")

### Variables

- YES: names, places, times, triggers
- NO: emotions, insights, meanings, descriptions
- MAX: 8 per 100 words

### Audio Rhythm

- Short sentences land
- Fragments create breath
- Repetition builds weight
- Read aloud always

### The Test

Recognition: "That's me."
Mechanism Proof: "I've tried that — it doesn't work."
Turning Point: "Oh... I never thought of it that way."
Embodiment: "Maybe I could do that."

---

## Final Note

You're not writing self-help content.

You're writing for someone who is alone, probably at night, probably exhausted, who chose this audiobook because something in their life isn't working.

Your words will be the only thing in the room with them.

Write like that matters.

Because it does.

---

*End of Template Authoring Guide*
