# Persona Template Sets

## Gen Z Professional & Gen Alpha Student

**Mechanism:** Autonomic Regulation  
**Engine:** False Alarm

---

# PERSONA 1: Gen Z Professional

## Profile

**Age Range:** 22-29  
**Context:** Early-career professional, 1-5 years in workforce  
**Work Environment:** Hybrid/remote, Slack-heavy, video calls, open offices  
**Core Anxiety:** Imposter syndrome, career uncertainty, financial precarity  
**Stakes:** Being "found out," falling behind peers, job security  
**Language Register:** Casual-professional blend, internet-literate, self-aware about mental health but lacking tools  

## Variables

```yaml
# variables/personas/gen_z_professional/characters.yaml
characters:
  - name: Jordan
    age: 26
    role: product associate
    years_in_workforce: 3
    company_type: tech startup
    
  - name: Priya
    age: 24
    role: junior analyst
    years_in_workforce: 2
    company_type: consulting firm
    
  - name: Marcus
    age: 27
    role: account coordinator
    years_in_workforce: 4
    company_type: marketing agency
    
  - name: Lily
    age: 25
    role: associate designer
    years_in_workforce: 2
    company_type: design studio
```

```yaml
# variables/personas/gen_z_professional/locations.yaml
locations:
  - workspace: apartment desk
    detail: the corner of the living room that's supposed to be an office
    commute: none
    
  - workspace: open office
    detail: the hot desk by the window
    commute: forty-minute train ride
    
  - workspace: coworking space
    detail: the communal table near the coffee bar
    commute: fifteen-minute bike ride
    
  - workspace: coffee shop
    detail: the back corner with the outlet
    commute: walk from the apartment
```

```yaml
# variables/personas/gen_z_professional/triggers.yaml
triggers:
  false_alarm:
    - event: Slack notification from manager
      time: 9 AM Monday
      context: before the weekly sync
      
    - event: calendar invite with no subject
      time: end of day Friday
      context: from someone two levels up
      
    - event: email marked urgent
      time: 7 AM
      context: before logging on
      
    - event: "Can we talk?" message
      time: mid-afternoon
      context: right after submitting work
```

```yaml
# variables/personas/gen_z_professional/body_sensations.yaml
sensations:
  - primary: chest tighten
    secondary: stomach drop
    
  - primary: heart rate spike
    secondary: hands get clammy
    
  - primary: jaw clench
    secondary: shoulders creep up
    
  - primary: breath catch
    secondary: face flush
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Gen Z Professional  
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.role}}
- {{character.years_in_workforce}}
- {{trigger.event}}
- {{trigger.time}}
- {{trigger.context}}
- {{body.primary}}
- {{location.workspace}}

### Template

{{character.name}} had been a {{character.role}} for {{character.years_in_workforce}} years.

Not long enough to stop feeling like everyone else knew something they didn't.

The {{trigger.event}} came through at {{trigger.time}}.
{{trigger.context}}.

Nothing about it should have made their {{body.primary}}.

But it did.

Sitting at {{location.workspace}},
they felt it before they could name it—
that spike of something that said *this is it, this is when they figure out you don't belong here*.

They clicked the notification.
Read it twice.
It was nothing.
A scheduling thing.
Completely normal.

And still, twenty minutes later,
their body was acting like they'd been called into HR.

They knew it was "just anxiety."
They'd read the articles, listened to the podcasts, 
knew all the vocabulary.

But knowing what it was called
didn't make it stop.

The worst part wasn't the feeling.
It was the performance—
acting fine in the meeting,
typing normal responses,
while something underneath kept screaming
*you're about to be exposed*.

They couldn't exactly bring that up in the team standup.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Gen Z Professional
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}
- {{body.secondary}}

### Template

{{character.name}} had tried everything the internet told them to.

Breathe.
Ground yourself.
Name five things you can see.

They had a meditation app with a 47-day streak.
They'd done the therapy intake twice but never followed up.
They knew cortisol was involved somehow.

None of it stopped the {{body.primary}} when a message came through.
None of it kept their {{body.secondary}} when they saw a meeting invite.

The apps helped a little—after.
But never before.
Never in the actual moment.

They'd started checking Slack less.
Then checking it more, just to get the anxiety over with.
Then muting notifications.
Then unmuting them because missing something felt worse.

Every strategy worked for a week, maybe two.
Then the feeling found a way around it.

The thing nobody told them was this:
trying harder to not feel anxious
was its own kind of exhausting.

They were managing their anxiety so carefully
that managing it had become a second job.

And somehow, despite all the effort,
the spike still came.
Every time.
Right on schedule.

Like their body hadn't gotten the memo
that everything was fine.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Gen Z Professional
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.detail}}
- {{body.primary}}

### Template

{{character.name}} was sitting at {{location.detail}} when it happened again.

The notification sound.
The instant {{body.primary}}.
The whole routine.

But this time, they didn't reach for a coping strategy.
Didn't open the app.
Didn't tell themselves to calm down.

They just... noticed.

*There it is.*
*That's the spike.*

Not "why is this happening" or "how do I make it stop."
Just: *oh, this again*.

And something weird happened.

They didn't feel calm exactly.
But they felt... less at war with it.

The spike was still there.
But it wasn't an emergency anymore.
It was just... a thing their body was doing.

Like their nervous system had been trained to scan for threats—
because that's what nervous systems do—
and it was doing its job a little too well.

Not broken.
Just... overqualified for the situation.

The notification was nothing.
Their body didn't know that yet.
But they did.

And for the first time,
that gap between what their body felt and what they knew
didn't feel like failure.

It just felt like lag.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Gen Z Professional
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{trigger.event}}

### Template

The spikes still came.

{{character.name}} wasn't pretending they didn't.

Every {{trigger.event}} still triggered the same initial jolt.
That probably wasn't going to change overnight.
Maybe not ever completely.

But something had shifted in how they met it.

Less "what's wrong with me."
More "okay, there's my nervous system doing the thing."

Less trying to fix it before the meeting.
More letting it be there while they did the meeting anyway.

It wasn't a hack.
It wasn't a cure.
It was more like... a different relationship.

Some days were still hard.
Some spikes still felt like too much.
But they'd stopped adding a second layer—
the panic about the panic,
the anxiety about being anxious.

One layer was enough.

They still had the meditation app.
They still used it sometimes.
But they'd stopped expecting it to make them a person who didn't feel this.

That person didn't exist.
This person—the one who felt it and worked anyway—
that person was actually doing fine.

Not fixed.
Functioning.

And honestly?
That was more than the apps had ever promised.
```

---

---

# PERSONA 2: Gen Alpha Student

## Profile

**Age Range:** 12-17  
**Context:** Middle school or high school student  
**Environment:** School, bedroom, phone, group chats, social media  
**Core Anxiety:** Social standing, academic pressure, being perceived  
**Stakes:** Fitting in, not being weird, grades, future (vaguely)  
**Language Register:** Contemporary teen, shorter sentences, less abstract, more direct, less patience for explanation  

## Variables

```yaml
# variables/personas/gen_alpha_student/characters.yaml
characters:
  - name: Mia
    age: 15
    grade: sophomore
    school_type: public high school
    
  - name: Jayden
    age: 14
    grade: freshman
    school_type: charter school
    
  - name: Zoe
    age: 13
    grade: eighth grade
    school_type: middle school
    
  - name: Kai
    age: 16
    grade: junior
    school_type: private school
```

```yaml
# variables/personas/gen_alpha_student/locations.yaml
locations:
  - place: bedroom
    detail: sitting on the bed with the door closed
    time_of_day: after school
    
  - place: school bathroom
    detail: the one on the second floor nobody uses
    time_of_day: between classes
    
  - place: car
    detail: backseat while mom drives
    time_of_day: morning
    
  - place: library
    detail: the back corner by the window
    time_of_day: during study hall
```

```yaml
# variables/personas/gen_alpha_student/triggers.yaml
triggers:
  false_alarm:
    - event: notification from the group chat
      context: after being quiet for a while
      fear: they're talking about me
      
    - event: teacher calling their name
      context: in the middle of class
      fear: I did something wrong
      
    - event: being left on read
      context: after sending something vulnerable
      fear: they think I'm weird
      
    - event: seeing a post they weren't tagged in
      context: their friend group went somewhere
      fear: I'm being left out
```

```yaml
# variables/personas/gen_alpha_student/body_sensations.yaml
sensations:
  - primary: stomach flip
    secondary: face get hot
    
  - primary: heart start racing
    secondary: hands shake a little
    
  - primary: chest get tight
    secondary: hard to breathe right
    
  - primary: whole body tense up
    secondary: feel kind of dizzy
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Gen Alpha Student
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.grade}}
- {{trigger.event}}
- {{trigger.context}}
- {{trigger.fear}}
- {{body.primary}}
- {{body.secondary}}
- {{location.place}}
- {{location.detail}}

### Template

{{character.name}} was {{location.detail}} when their phone buzzed.

{{trigger.event}}.
{{trigger.context}}.

Their {{body.primary}}.
Then their {{body.secondary}}.

They hadn't even looked at it yet.

Just the buzz was enough.

They picked up the phone.
Checked.
It was nothing.
Literally nothing important.

But their body didn't get that.

For like ten minutes after,
they still felt weird.
Still felt like something bad was about to happen
even though nothing was happening.

This kept happening lately.
Not just with the phone.
With everything.

Walking into class. {{body.primary}}.
Seeing people laugh across the hall. *Are they laughing at me?*
Teacher looks in their direction. *What did I do?*

They knew it was probably anxiety.
They'd heard that word enough times.
They'd even told their friends "I have anxiety" 
like it explained something.

But knowing the word didn't make the feeling stop.

And they couldn't really explain it to anyone.
Not in a way that didn't sound dramatic.
Not in a way that made sense even to them.

It just felt like their body was always waiting
for something bad to happen.

Even when nothing was.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Gen Alpha Student
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{body.primary}}

### Template

{{character.name}} had tried stuff.

Deep breaths.
That thing where you name five things you can see.
Putting the phone in another room.

Sometimes it helped.
Mostly it didn't.

The {{body.primary}} came anyway.

They'd tried telling themselves it wasn't a big deal.
That didn't work.
They'd tried ignoring it.
That made it worse.
They'd tried distracting themselves.
That worked until it didn't.

The annoying part was,
they knew nothing bad was actually happening.

Like, logically, they knew.
But their body was doing its own thing.
And their body didn't care about logic.

It was like—
imagine knowing a test isn't that important
but still feeling like you're going to throw up before it.

That.
But for random stuff.
Stuff that shouldn't even matter.

The worst part was feeling like this was their fault somehow.
Like if they just tried harder to be calm,
they would be calm.

But trying harder to be calm
actually made them feel more not-calm.

Which made no sense.
But that's how it worked.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Gen Alpha Student
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{location.place}}
- {{body.primary}}
- {{body.secondary}}

### Template

{{character.name}} was in the {{location.place}} when it happened again.

The feeling.
The {{body.primary}}.
The {{body.secondary}}.
The whole thing.

But this time, instead of trying to make it stop,
they just kind of... watched it.

Like, *okay, there it is*.

Not "why am I like this."
Not "I need to calm down."
Just... noticing.

And it was weird,
but the feeling didn't get bigger.

It was still there.
They still felt it.
But it was like—
it wasn't in charge anymore?

They had this thought:
*Maybe this is just what my body does when it thinks something might be wrong.*

Not because something IS wrong.
Just because bodies do that.
It's like a smoke alarm that goes off when you're just making toast.

The alarm isn't broken.
It's just... sensitive.

That didn't make the feeling go away.
But it made it feel less like a problem with them
and more like a thing that was just... happening.

Which was different.

Not fixed.
But different.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Gen Alpha Student
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{trigger.event}}
- {{body.primary}}

### Template

The feelings still came.

Every time {{trigger.event}},
{{character.name}} still felt their {{body.primary}}.

That part didn't magically change.

But how they dealt with it did.

Before, it was like:
feeling → panic about feeling → try to fix feeling → feel worse → spiral

Now it was more like:
feeling → *oh, that again* → wait → it passes

Not always.
Some days still sucked.
Some days they still felt like something was wrong with them.

But more often now,
they could feel the thing
and not make it into a whole thing.

They stopped expecting to become someone
who never felt anxious.

That wasn't realistic.
That probably wasn't even a real person.

They were just trying to be someone who felt it
and kept going anyway.

Someone who didn't need to fix it first.
Someone who could let it be there and still do stuff.

That person felt more possible.

Not perfect.
Not cured.
Just... handling it.

Which was actually a lot.
```

---

---

# Template Quality Checklist

Both persona sets validated against role contracts:

## Recognition
- [x] Identity anchor present
- [x] Internal stakes present  
- [x] Somatic activation present
- [x] No reframe language
- [x] No insight claims
- [x] No relief signals
- [x] No forbidden phrases

## Mechanism Proof
- [x] Constraint loop shown (trying harder doesn't work)
- [x] Repeated failure shown
- [x] Pattern language present
- [x] No instructions
- [x] No technique names
- [x] No resolution language

## Turning Point
- [x] Exactly one meaning inversion
- [x] Interpretation shift present
- [x] No full resolution
- [x] No mastery claims
- [x] No permanence language

## Embodiment
- [x] Relational shift shown
- [x] Lived example present
- [x] Ongoing/imperfect framing
- [x] No cure language
- [x] No permanence claims

---

# Voice Comparison

| Element | Gen Z Professional | Gen Alpha Student |
|---------|-------------------|-------------------|
| Sentence length | Medium, some complex | Short, direct |
| Self-awareness | High, over-intellectualized | Present but less articulate |
| Vocabulary | Internet-literate, therapy-adjacent | Simpler, more immediate |
| Stakes framing | Career, being "found out" | Social, being "weird" |
| Coping attempts | Apps, podcasts, strategies | Deep breaths, distraction |
| Insight voice | "Like my nervous system was..." | "It's like a smoke alarm..." |
| Resolution framing | "Functioning" | "Handling it" |
| Meta-awareness | Knows all the terms | Knows "anxiety" but not much else |

Both personas deliver the same mechanism (autonomic regulation) and satisfy the same contracts, but sound completely different.

That's the system working correctly.
