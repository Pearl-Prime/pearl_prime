# Gen Z Professional Variable Files

## All Location Variants

**Template Set:** `templates/gen_z_professional/` (ONE set, shared by all)  
**Mechanism:** Autonomic Regulation  
**Engine:** False Alarm

---

# Location 1: NYC Finance

```yaml
# variables/gen_z_professional/nyc_finance/characters.yaml

characters:
  - name: Jordan
    age: 26
    role: associate
    years_in_workforce: 3
    company_type: investment bank
    team: M&A
    
  - name: Priya
    age: 25
    role: analyst
    years_in_workforce: 2
    company_type: hedge fund
    team: research
    
  - name: Marcus
    age: 27
    role: associate
    years_in_workforce: 4
    company_type: private equity firm
    team: deal team
    
  - name: Sophie
    age: 24
    role: first-year analyst
    years_in_workforce: 1
    company_type: bulge bracket bank
    team: capital markets
    
  - name: Daniel
    age: 28
    role: senior associate
    years_in_workforce: 5
    company_type: asset management
    team: portfolio management
```

```yaml
# variables/gen_z_professional/nyc_finance/locations.yaml

locations:
  - workspace: trading floor
    detail: the desk by the window with three monitors
    building: midtown tower
    commute: the 6 train from Brooklyn
    
  - workspace: glass conference room
    detail: the one they call the fishbowl
    building: downtown office
    commute: the PATH from Jersey City
    
  - workspace: apartment desk
    detail: the corner of the studio that passes for an office
    building: walk-up in Murray Hill
    commute: none—WFH day
    
  - workspace: WeWork hot desk
    detail: the quiet floor nobody uses before 9
    building: coworking space in FiDi
    commute: twenty-minute walk from the East Village
    
  - workspace: Starbucks on Park
    detail: the back corner with the outlet
    building: ground floor of a client's building
    commute: between meetings
```

```yaml
# variables/gen_z_professional/nyc_finance/triggers.yaml

triggers:
  false_alarm:
    - event: email from the MD
      time: 6:47 AM
      context: two days before bonus announcements
      typical_reality: a scheduling request
      
    - event: Bloomberg terminal alert
      time: during market hours
      context: while working on a model
      typical_reality: a routine price movement
      
    - event: calendar invite with no subject
      time: 4 PM Friday
      context: from a VP she barely knew
      typical_reality: a coffee chat invitation
      
    - event: Slack ping from the staffer
      time: 11 PM
      context: after she'd closed the laptop
      typical_reality: a heads-up about tomorrow's workflow
      
    - event: "Got a minute?" text from her analyst class
      time: lunch break
      context: right after the town hall
      typical_reality: gossip about the reorg
      
    - event: missed call from HR
      time: mid-morning
      context: during a live deal
      typical_reality: benefits enrollment reminder
```

```yaml
# variables/gen_z_professional/nyc_finance/industry_terms.yaml

industry_terms:
  stressors:
    - "bonus season"
    - "deal closing"
    - "MD review"
    - "staffing call"
    - "pitch deadline"
    - "live deal"
    - "model review"
    
  time_pressure:
    - "market close"
    - "earnings call"
    - "end of quarter"
    - "signing deadline"
    
  hierarchy:
    - "MD"
    - "VP"
    - "associate"
    - "analyst"
    - "staffer"
    
  workplace:
    - "the floor"
    - "the bullpen"
    - "the fishbowl"
    - "the partner track"
```

```yaml
# variables/gen_z_professional/nyc_finance/body_sensations.yaml

sensations:
  - primary: chest tighten
    secondary: stomach drop
    
  - primary: heart rate spike
    secondary: hands get clammy
    
  - primary: jaw clench
    secondary: shoulders creep toward ears
    
  - primary: breath catch
    secondary: that familiar dread
    
  - primary: adrenaline hit
    secondary: mind start racing through worst cases
```

---

# Location 2: SF Tech / Startups

```yaml
# variables/gen_z_professional/sf_tech/characters.yaml

characters:
  - name: Maya
    age: 26
    role: product manager
    years_in_workforce: 3
    company_type: Series B startup
    team: growth
    
  - name: Kevin
    age: 25
    role: software engineer
    years_in_workforce: 2
    company_type: pre-IPO company
    team: platform
    
  - name: Jasmine
    age: 27
    role: senior designer
    years_in_workforce: 4
    company_type: design-forward startup
    team: product design
    
  - name: Tyler
    age: 24
    role: founding engineer
    years_in_workforce: 2
    company_type: seed-stage startup
    team: core product
    
  - name: Aiden
    age: 28
    role: engineering manager
    years_in_workforce: 5
    company_type: mid-stage startup
    team: infrastructure
```

```yaml
# variables/gen_z_professional/sf_tech/locations.yaml

locations:
  - workspace: open office
    detail: the standing desk by the snack wall
    building: SoMa loft space
    commute: the N from the Outer Sunset
    
  - workspace: apartment desk
    detail: the kitchen table that doubles as an office
    building: shared apartment in the Mission
    commute: none—async day
    
  - workspace: coffee shop
    detail: the corner table at Sightglass
    building: ground floor of a converted warehouse
    commute: a fifteen-minute bike ride
    
  - workspace: WeWork
    detail: the phone booth she booked for focused work
    building: coworking space on Market
    commute: BART from Oakland
    
  - workspace: rooftop deck
    detail: the picnic table with the best WiFi
    building: their office building
    commute: elevator from the fourth floor
```

```yaml
# variables/gen_z_professional/sf_tech/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the CEO
      time: 11 PM
      context: week before the board meeting
      typical_reality: a "thinking out loud" message
      
    - event: calendar invite labeled "Quick sync"
      time: end of day Friday
      context: after shipping a big feature
      typical_reality: feedback and kudos
      
    - event: PagerDuty alert
      time: 3 AM
      context: during on-call rotation
      typical_reality: a non-critical warning
      
    - event: "Can we chat?" in the #general channel
      time: Monday morning
      context: after a quiet weekend
      typical_reality: logistics about the offsite
      
    - event: Figma comment notification
      time: during deep work
      context: on a design she'd just shared
      typical_reality: a minor question about spacing
      
    - event: GitHub PR review request
      time: right before standup
      context: from the tech lead
      typical_reality: routine code review
```

```yaml
# variables/gen_z_professional/sf_tech/industry_terms.yaml

industry_terms:
  stressors:
    - "board meeting"
    - "demo day"
    - "runway"
    - "burn rate"
    - "product review"
    - "launch week"
    - "on-call rotation"
    
  time_pressure:
    - "sprint deadline"
    - "quarterly OKRs"
    - "Series B timeline"
    - "ship date"
    
  hierarchy:
    - "CEO"
    - "CTO"
    - "VP of Product"
    - "tech lead"
    - "PM"
    - "IC"
    
  workplace:
    - "the office"
    - "the Slack"
    - "async"
    - "the standup"
    - "the all-hands"
```

```yaml
# variables/gen_z_professional/sf_tech/body_sensations.yaml

sensations:
  - primary: chest tighten
    secondary: stomach flip
    
  - primary: heart rate jump
    secondary: mind start spiraling
    
  - primary: adrenaline hit
    secondary: hyperalert feeling
    
  - primary: breath get shallow
    secondary: shoulders tense
    
  - primary: that jolt of dread
    secondary: hands pause over the keyboard
```

---

# Location 3: London Finance / Consulting

```yaml
# variables/gen_z_professional/london_finance/characters.yaml

characters:
  - name: Olivia
    age: 26
    role: associate
    years_in_workforce: 3
    company_type: management consultancy
    team: financial services practice
    
  - name: James
    age: 25
    role: analyst
    years_in_workforce: 2
    company_type: investment bank
    team: European coverage
    
  - name: Amara
    age: 27
    role: senior consultant
    years_in_workforce: 4
    company_type: strategy firm
    team: transformation
    
  - name: Ravi
    age: 24
    role: junior associate
    years_in_workforce: 1
    company_type: Big Four
    team: deals advisory
    
  - name: Charlotte
    age: 28
    role: associate director
    years_in_workforce: 5
    company_type: asset manager
    team: client coverage
```

```yaml
# variables/gen_z_professional/london_finance/locations.yaml

locations:
  - workspace: open-plan office
    detail: the hot desk near the window overlooking the Gherkin
    building: Canary Wharf tower
    commute: the Jubilee line from Clapham
    
  - workspace: client site
    detail: the borrowed office on the executive floor
    building: client headquarters in the City
    commute: the Central line from Stratford
    
  - workspace: flat desk
    detail: the corner of the bedroom that serves as an office
    building: flatshare in Hackney
    commute: none—WFH day
    
  - workspace: café table
    detail: the back corner of a Pret
    building: ground floor of their office building
    commute: between meetings
    
  - workspace: WeWork
    detail: the quiet room she booked for a difficult call
    building: Shoreditch coworking space
    commute: the Overground from Peckham
```

```yaml
# variables/gen_z_professional/london_finance/triggers.yaml

triggers:
  false_alarm:
    - event: email from the partner
      time: 7 AM
      context: before the client presentation
      typical_reality: a minor formatting request
      
    - event: Teams message from the engagement manager
      time: end of day
      context: after submitting the deck
      typical_reality: a "well done" and minor feedback
      
    - event: calendar invite from HR
      time: mid-afternoon
      context: during performance review season
      typical_reality: benefits enrollment reminder
      
    - event: WhatsApp from a colleague
      time: Sunday evening
      context: after a week on the road
      typical_reality: travel logistics for Monday
      
    - event: missed call from the MD
      time: during lunch
      context: while grabbing a Pret sandwich
      typical_reality: a reschedule request
      
    - event: Outlook notification marked urgent
      time: 10 PM
      context: while trying to switch off
      typical_reality: a non-urgent FYI CC'd to everyone
```

```yaml
# variables/gen_z_professional/london_finance/industry_terms.yaml

industry_terms:
  stressors:
    - "client presentation"
    - "partner review"
    - "case interview prep"
    - "proposal deadline"
    - "engagement wrap-up"
    - "staffing decisions"
    
  time_pressure:
    - "quarter end"
    - "Monday steering committee"
    - "board pack deadline"
    - "exit week"
    
  hierarchy:
    - "partner"
    - "director"
    - "engagement manager"
    - "senior consultant"
    - "analyst"
    
  workplace:
    - "the office"
    - "client site"
    - "the Wharf"
    - "the City"
```

---

# Location 4: LA Entertainment / Creative

```yaml
# variables/gen_z_professional/la_entertainment/characters.yaml

characters:
  - name: Zoe
    age: 26
    role: development coordinator
    years_in_workforce: 3
    company_type: production company
    team: scripted TV
    
  - name: Marcus
    age: 25
    role: junior agent's assistant
    years_in_workforce: 2
    company_type: talent agency
    team: literary department
    
  - name: Ava
    age: 27
    role: social media manager
    years_in_workforce: 4
    company_type: entertainment brand
    team: digital marketing
    
  - name: Derek
    age: 24
    role: post-production coordinator
    years_in_workforce: 2
    company_type: streaming platform
    team: original content
    
  - name: Isabella
    age: 28
    role: creative executive
    years_in_workforce: 5
    company_type: studio
    team: features
```

```yaml
# variables/gen_z_professional/la_entertainment/locations.yaml

locations:
  - workspace: open office
    detail: the desk in the bullpen near the exec's office
    building: studio lot in Burbank
    commute: the 101 from Silver Lake
    
  - workspace: apartment desk
    detail: the folding table in the corner of the studio
    building: apartment in Koreatown
    commute: none—development day
    
  - workspace: café
    detail: the patio table at Alfred's
    building: on Melrose
    commute: a ten-minute drive from the office
    
  - workspace: production office
    detail: a temporary desk in the trailer
    building: on location
    commute: wherever the shoot is
    
  - workspace: coworking space
    detail: the private room she splurged on
    building: WeWork in Culver City
    commute: surface streets from Mar Vista
```

```yaml
# variables/gen_z_professional/la_entertainment/triggers.yaml

triggers:
  false_alarm:
    - event: text from the showrunner
      time: 11 PM
      context: while notes were due
      typical_reality: a scheduling question
      
    - event: email from the agent
      time: Monday morning
      context: after a pilot didn't get picked up
      typical_reality: a new submission
      
    - event: Slack from her boss
      time: during a table read
      context: when she was supposed to be invisible
      typical_reality: a coffee order
      
    - event: calendar invite from the VP
      time: end of day Friday
      context: after a tough week
      typical_reality: a team check-in
      
    - event: "Call me when you can" voicemail
      time: mid-afternoon
      context: from a number she didn't recognize
      typical_reality: a vendor callback
      
    - event: Instagram DM from an industry contact
      time: late at night
      context: after a premiere
      typical_reality: a "nice meeting you" follow-up
```

```yaml
# variables/gen_z_professional/la_entertainment/industry_terms.yaml

industry_terms:
  stressors:
    - "pilot season"
    - "staffing season"
    - "upfronts"
    - "notes call"
    - "premiere"
    - "table read"
    - "coverage"
    
  time_pressure:
    - "delivery date"
    - "script deadline"
    - "festival submission"
    - "network notes"
    
  hierarchy:
    - "showrunner"
    - "EP"
    - "VP"
    - "director of development"
    - "coordinator"
    - "assistant"
    
  workplace:
    - "the lot"
    - "the office"
    - "set"
    - "post"
    - "the agency"
```

---

# Location 5: Boston Biotech / Healthcare Adjacent

```yaml
# variables/gen_z_professional/boston_biotech/characters.yaml

characters:
  - name: Emily
    age: 26
    role: clinical research associate
    years_in_workforce: 3
    company_type: biotech startup
    team: clinical operations
    
  - name: Ryan
    age: 25
    role: research scientist
    years_in_workforce: 2
    company_type: pharma company
    team: discovery
    
  - name: Anita
    age: 27
    role: regulatory affairs specialist
    years_in_workforce: 4
    company_type: medical device company
    team: submissions
    
  - name: Michael
    age: 24
    role: lab technician
    years_in_workforce: 2
    company_type: academic spinoff
    team: process development
    
  - name: Lauren
    age: 28
    role: project manager
    years_in_workforce: 5
    company_type: CRO
    team: oncology
```

```yaml
# variables/gen_z_professional/boston_biotech/locations.yaml

locations:
  - workspace: open lab
    detail: the bench near the window
    building: Kendall Square campus
    commute: the Red Line from Somerville
    
  - workspace: office desk
    detail: the cubicle in the regulatory wing
    building: Cambridge headquarters
    commute: the commuter rail from the suburbs
    
  - workspace: apartment desk
    detail: the standing desk in the alcove
    building: apartment in Jamaica Plain
    commute: none—data analysis day
    
  - workspace: conference room
    detail: the one they use for sponsor calls
    building: their office building
    commute: down the hall from the lab
    
  - workspace: coffee shop
    detail: the table by the outlet at Tatte
    building: ground floor of a Kendall tower
    commute: a five-minute walk between meetings
```

```yaml
# variables/gen_z_professional/boston_biotech/triggers.yaml

triggers:
  false_alarm:
    - event: email from the PI
      time: early morning
      context: during a critical trial phase
      typical_reality: a literature recommendation
      
    - event: Slack from the CMO
      time: end of day
      context: after submitting the IND
      typical_reality: a "nice work" message
      
    - event: missed call from the site
      time: during lunch
      context: while she was away from her desk
      typical_reality: a routine enrollment update
      
    - event: calendar invite from regulatory
      time: Monday morning
      context: a week before the FDA meeting
      typical_reality: prep meeting logistics
      
    - event: Teams message from the project lead
      time: 9 PM
      context: while reviewing data
      typical_reality: a timeline question
      
    - event: notification from the CTMS
      time: mid-afternoon
      context: during a site visit
      typical_reality: a routine protocol update
```

```yaml
# variables/gen_z_professional/boston_biotech/industry_terms.yaml

industry_terms:
  stressors:
    - "FDA submission"
    - "data lock"
    - "site audit"
    - "enrollment deadline"
    - "sponsor visit"
    - "protocol deviation"
    
  time_pressure:
    - "IND deadline"
    - "PDUFA date"
    - "data cutoff"
    - "quarterly report"
    
  hierarchy:
    - "CMO"
    - "VP of Clinical"
    - "PI"
    - "project lead"
    - "CRA"
    - "associate"
    
  workplace:
    - "the lab"
    - "the office"
    - "site"
    - "Kendall"
    - "the sponsor"
```

---

# Location 6: Chicago Consulting / Corporate

```yaml
# variables/gen_z_professional/chicago_corporate/characters.yaml

characters:
  - name: Megan
    age: 26
    role: senior analyst
    years_in_workforce: 3
    company_type: management consultancy
    team: operations practice
    
  - name: David
    age: 25
    role: associate
    years_in_workforce: 2
    company_type: Big Four
    team: advisory
    
  - name: Keisha
    age: 27
    role: consultant
    years_in_workforce: 4
    company_type: boutique strategy firm
    team: consumer goods
    
  - name: Brian
    age: 24
    role: analyst
    years_in_workforce: 2
    company_type: corporate strategy
    team: M&A integration
    
  - name: Sarah
    age: 28
    role: engagement manager
    years_in_workforce: 5
    company_type: consulting firm
    team: financial services
```

```yaml
# variables/gen_z_professional/chicago_corporate/locations.yaml

locations:
  - workspace: open office
    detail: the hot desk on the 40th floor
    building: Loop high-rise
    commute: the Blue Line from Logan Square
    
  - workspace: client site
    detail: the war room they've been living in for weeks
    building: client headquarters in the suburbs
    commute: the Metra from downtown
    
  - workspace: apartment desk
    detail: the desk in the second bedroom they converted
    building: condo in Lincoln Park
    commute: none—WFH day
    
  - workspace: airport lounge
    detail: the quiet corner of the United Club
    building: O'Hare Terminal 1
    commute: between flights
    
  - workspace: coffee shop
    detail: the back table at Intelligentsia
    building: in the Monadnock
    commute: a ten-minute walk from the office
```

```yaml
# variables/gen_z_professional/chicago_corporate/triggers.yaml

triggers:
  false_alarm:
    - event: email from the partner
      time: 6 AM
      context: travel day
      typical_reality: flight logistics
      
    - event: Slack from the engagement manager
      time: Sunday evening
      context: before Monday's client meeting
      typical_reality: a deck comment
      
    - event: Teams notification
      time: during a client workshop
      context: from someone back at the office
      typical_reality: an unrelated question
      
    - event: calendar invite from staffing
      time: Friday afternoon
      context: when the project was winding down
      typical_reality: next engagement preview
      
    - event: text from a senior manager
      time: late at night
      context: while working on deliverables
      typical_reality: a "get some sleep" message
      
    - event: missed call from the client
      time: mid-morning
      context: while in another meeting
      typical_reality: a reschedule request
```

---

# Location 7: Seattle Tech

```yaml
# variables/gen_z_professional/seattle_tech/characters.yaml

characters:
  - name: Alex
    age: 26
    role: software development engineer
    years_in_workforce: 3
    company_type: big tech
    team: AWS
    
  - name: Mei
    age: 25
    role: program manager
    years_in_workforce: 2
    company_type: tech giant
    team: cloud services
    
  - name: Jordan
    age: 27
    role: senior engineer
    years_in_workforce: 4
    company_type: gaming company
    team: platform
    
  - name: Nikita
    age: 24
    role: data scientist
    years_in_workforce: 2
    company_type: e-commerce
    team: recommendations
    
  - name: Chris
    age: 28
    role: engineering lead
    years_in_workforce: 5
    company_type: enterprise software
    team: core infrastructure
```

```yaml
# variables/gen_z_professional/seattle_tech/locations.yaml

locations:
  - workspace: campus office
    detail: the desk in the building nearest the lake
    building: corporate campus
    commute: the shuttle from Capitol Hill
    
  - workspace: home office
    detail: the standing desk by the window
    building: apartment in Ballard
    commute: none—remote day
    
  - workspace: coffee shop
    detail: the corner table at the local roaster
    building: in Fremont
    commute: a short walk from home
    
  - workspace: shared workspace
    detail: the reserved desk
    building: WeWork in South Lake Union
    commute: the streetcar from downtown
    
  - workspace: conference room
    detail: the one named after a mountain
    building: their office building
    commute: elevator from the lobby
```

```yaml
# variables/gen_z_professional/seattle_tech/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the skip-level
      time: end of day
      context: during promo season
      typical_reality: a project question
      
    - event: page from the on-call system
      time: 2 AM
      context: during their rotation
      typical_reality: a non-critical alert
      
    - event: email from HR
      time: Monday morning
      context: after the reorg announcement
      typical_reality: benefits information
      
    - event: calendar invite from the director
      time: Friday afternoon
      context: after a tough sprint
      typical_reality: team celebration
      
    - event: Teams message from their manager
      time: during focus time
      context: after a design review
      typical_reality: minor feedback
      
    - event: notification from the ticketing system
      time: mid-afternoon
      context: while deep in code
      typical_reality: a routine bug assignment
```

---

# Location 8: Austin Tech / Startup

```yaml
# variables/gen_z_professional/austin_tech/characters.yaml

characters:
  - name: Jake
    age: 26
    role: product designer
    years_in_workforce: 3
    company_type: growth-stage startup
    team: design
    
  - name: Aaliyah
    age: 25
    role: frontend engineer
    years_in_workforce: 2
    company_type: fintech startup
    team: web platform
    
  - name: Cole
    age: 27
    role: customer success manager
    years_in_workforce: 4
    company_type: SaaS company
    team: enterprise accounts
    
  - name: Destiny
    age: 24
    role: marketing coordinator
    years_in_workforce: 2
    company_type: tech startup
    team: growth
    
  - name: Hunter
    age: 28
    role: engineering manager
    years_in_workforce: 5
    company_type: late-stage startup
    team: mobile
```

```yaml
# variables/gen_z_professional/austin_tech/locations.yaml

locations:
  - workspace: converted warehouse office
    detail: the standing desk near the ping pong table
    building: East Austin startup space
    commute: a fifteen-minute bike ride from downtown
    
  - workspace: home office
    detail: the desk in the spare room
    building: house in Mueller
    commute: none—remote day
    
  - workspace: coffee shop
    detail: the couch by the window
    building: a local spot on South Congress
    commute: a short drive from the office
    
  - workspace: coworking space
    detail: the dedicated desk she finally got
    building: Capital Factory
    commute: the bus from Hyde Park
    
  - workspace: patio
    detail: the outdoor table with decent shade
    building: their office courtyard
    commute: through the back door
```

```yaml
# variables/gen_z_professional/austin_tech/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the founder
      time: 10 PM
      context: before the investor update
      typical_reality: a thought about positioning
      
    - event: email from a customer
      time: early morning
      context: after a product launch
      typical_reality: a feature request
      
    - event: calendar invite from the CEO
      time: mid-week
      context: during a pivot discussion
      typical_reality: an all-hands planning session
      
    - event: text from her manager
      time: weekend
      context: when she was trying to unplug
      typical_reality: a "saw this, thought of you" article
      
    - event: Figma comment notification
      time: during a design sprint
      context: from a stakeholder
      typical_reality: a clarifying question
      
    - event: GitHub notification
      time: right before standup
      context: on a PR she'd submitted
      typical_reality: an approval
```

---

# Location 9: Remote / Distributed

```yaml
# variables/gen_z_professional/remote_distributed/characters.yaml

characters:
  - name: Sam
    age: 26
    role: senior engineer
    years_in_workforce: 3
    company_type: fully remote startup
    team: backend
    
  - name: Taylor
    age: 25
    role: product manager
    years_in_workforce: 2
    company_type: distributed company
    team: core product
    
  - name: Morgan
    age: 27
    role: content strategist
    years_in_workforce: 4
    company_type: remote-first agency
    team: client services
    
  - name: Casey
    age: 24
    role: customer support lead
    years_in_workforce: 2
    company_type: async company
    team: customer experience
    
  - name: Riley
    age: 28
    role: design lead
    years_in_workforce: 5
    company_type: globally distributed
    team: product design
```

```yaml
# variables/gen_z_professional/remote_distributed/locations.yaml

locations:
  - workspace: home office
    detail: the converted closet that became an office
    building: apartment
    commute: ten steps from the bedroom
    
  - workspace: kitchen table
    detail: the spot with the best lighting for calls
    building: rental house
    commute: none
    
  - workspace: coworking space
    detail: the monthly hot desk
    building: local coworking
    commute: a ten-minute drive
    
  - workspace: coffee shop
    detail: the regular table
    building: the neighborhood café
    commute: a short walk
    
  - workspace: library
    detail: the quiet study room
    building: public library
    commute: a bike ride away
```

```yaml
# variables/gen_z_professional/remote_distributed/triggers.yaml

triggers:
  false_alarm:
    - event: Slack notification
      time: during their focus block
      context: from someone in a different timezone
      typical_reality: a non-urgent FYI
      
    - event: email from the CEO
      time: early morning their time
      context: sent at midnight the CEO's time
      typical_reality: a company update
      
    - event: calendar invite for a "quick sync"
      time: outside normal working hours
      context: from someone who forgot about timezones
      typical_reality: rescheduled once they saw the time
      
    - event: missed call on Zoom
      time: while they were making coffee
      context: five minutes before a scheduled meeting
      typical_reality: someone joining early
      
    - event: Notion comment notification
      time: weekend
      context: from a colleague catching up
      typical_reality: async collaboration, not urgent
      
    - event: message in the #general channel
      time: during their lunch break
      context: flagged as important
      typical_reality: a process update, not personal
```

```yaml
# variables/gen_z_professional/remote_distributed/industry_terms.yaml

industry_terms:
  stressors:
    - "async expectations"
    - "timezone overlap"
    - "always-on feeling"
    - "video fatigue"
    - "documentation pressure"
    
  time_pressure:
    - "sync window"
    - "handoff time"
    - "EOD their time"
    - "before the EU wakes up"
    
  hierarchy:
    - "CEO"
    - "team lead"
    - "manager"
    - "IC"
    
  workplace:
    - "Slack"
    - "Notion"
    - "the async channel"
    - "the weekly sync"
    - "the Loom"
```

---

# Location 10: NYC Creative / Media

```yaml
# variables/gen_z_professional/nyc_creative/characters.yaml

characters:
  - name: Dani
    age: 26
    role: associate editor
    years_in_workforce: 3
    company_type: digital media company
    team: features
    
  - name: Kai
    age: 25
    role: social media manager
    years_in_workforce: 2
    company_type: media brand
    team: audience development
    
  - name: Jordan
    age: 27
    role: senior copywriter
    years_in_workforce: 4
    company_type: creative agency
    team: brand
    
  - name: Nia
    age: 24
    role: junior publicist
    years_in_workforce: 2
    company_type: PR agency
    team: entertainment
    
  - name: Leo
    age: 28
    role: creative strategist
    years_in_workforce: 5
    company_type: digital agency
    team: strategy
```

```yaml
# variables/gen_z_professional/nyc_creative/locations.yaml

locations:
  - workspace: open office
    detail: the desk near the mood boards
    building: loft in Dumbo
    commute: the F from the Lower East Side
    
  - workspace: apartment desk
    detail: the corner of the studio apartment
    building: walk-up in Bushwick
    commute: none—writing day
    
  - workspace: café
    detail: the communal table at the trendy spot
    building: in Williamsburg
    commute: a fifteen-minute walk
    
  - workspace: client office
    detail: borrowed desk in the marketing department
    building: Midtown tower
    commute: the L and the 6
    
  - workspace: coworking space
    detail: the day pass she splurged on
    building: WeWork in SoHo
    commute: the N from Astoria
```

```yaml
# variables/gen_z_professional/nyc_creative/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the EIC
      time: 8 PM
      context: when the issue was closing
      typical_reality: a "nice work" message
      
    - event: text from the client
      time: weekend
      context: after presenting the campaign
      typical_reality: excitement about the concept
      
    - event: email marked high priority
      time: Monday morning
      context: from someone in the C-suite
      typical_reality: an FYI CC
      
    - event: Instagram DM from an industry contact
      time: late at night
      context: after an event
      typical_reality: networking follow-up
      
    - event: calendar invite from creative director
      time: end of day
      context: after submitting concepts
      typical_reality: review scheduling
      
    - event: Google Doc comment notification
      time: during focused work
      context: on a draft she'd just shared
      typical_reality: a minor edit suggestion
```

---

# Summary: Template-to-Variable Relationship

**One Template Set:**
```
templates/gen_z_professional/anxiety/false_alarm/
├── recognition.md
├── mechanism_proof.md
├── turning_point.md
└── embodiment.md
```

**Ten Variable Sets:**
```
variables/gen_z_professional/
├── nyc_finance/
├── sf_tech/
├── london_finance/
├── la_entertainment/
├── boston_biotech/
├── chicago_corporate/
├── seattle_tech/
├── austin_tech/
├── remote_distributed/
└── nyc_creative/
```

**Books Generated:** 10 locations × topics × engines = hundreds of unique books from ONE template set.

---

# Voice Consistency Check

All locations share these Gen Z Professional voice markers:

| Element | Consistent Across All Locations |
|---------|--------------------------------|
| Self-awareness | High — knows the vocabulary, over-intellectualizes |
| Relationship to mental health | Has the apps, read the articles, done the intake |
| Coping attempts | Meditation apps, breathing exercises, therapy-adjacent |
| Stakes framing | Career, being "found out," imposter syndrome |
| Resolution | "Functioning" not "fixed" |
| Humor/tone | Self-deprecating awareness without being precious |

**What varies:**
- Industry-specific triggers (MD email vs CEO Slack vs showrunner text)
- Workplace vocabulary (trading floor vs standup vs table read)
- Location details (subway vs BART vs the 101)
- Hierarchy terms (MD/VP vs CEO/tech lead vs EP/showrunner)

Same voice. Different world. That's the system working correctly.

---

*End of Gen Z Professional Variable Files*
