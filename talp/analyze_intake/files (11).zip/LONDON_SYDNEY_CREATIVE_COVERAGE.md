# London, Sydney & Creative Persona Coverage

## Architecture Decisions

### Do these need new templates or just variables?

| Persona | Decision | Reasoning |
|---------|----------|-----------|
| London Tech | Variables only | Same Gen Z voice, different location |
| London Creative (Agency) | Variables only | Same Gen Z voice, creative industry |
| Sydney Tech | Variables only | Same Gen Z voice, Australian context |
| Sydney Finance | Variables only | Same Gen Z voice, Australian context |
| Sydney Creative | Variables only | Same Gen Z voice, Australian context |
| **Creative Freelancer/Independent** | **NEW TEMPLATE SET** | Different voice — no employer buffer, rejection is personal, you ARE the product |

### Why Freelance Creatives Need Their Own Voice

| Gen Z Professional (Employed) | Creative Freelancer/Independent |
|-------------------------------|--------------------------------|
| "Will I get fired?" | "Will I get hired again?" |
| Performance review anxiety | Client rejection anxiety |
| Imposter syndrome at work | "Am I actually talented?" |
| Stable income, fear of losing it | No stable income, always hunting |
| Company is the buffer | YOU are the product |
| Bad day = bad day | Bad project = identity crisis |
| Can blame the org | Can only blame yourself |

The freelancer's relationship to their anxiety is fundamentally different — there's no institution between them and rejection.

---

# PART 1: LONDON

## London Tech (Fintech, Startups, Scale-ups)

```yaml
# variables/gen_z_professional/london_tech/characters.yaml

characters:
  - name: Ollie
    age: 26
    role: software engineer
    years_in_workforce: 3
    company_type: fintech startup
    team: payments
    
  - name: Priya
    age: 25
    role: product manager
    years_in_workforce: 2
    company_type: scale-up
    team: growth
    
  - name: James
    age: 27
    role: senior engineer
    years_in_workforce: 4
    company_type: challenger bank
    team: platform
    
  - name: Fatima
    age: 24
    role: data scientist
    years_in_workforce: 2
    company_type: AI startup
    team: ML
    
  - name: Tom
    age: 28
    role: engineering lead
    years_in_workforce: 5
    company_type: e-commerce scale-up
    team: infrastructure
```

```yaml
# variables/gen_z_professional/london_tech/locations.yaml

locations:
  - workspace: open office
    detail: the standing desk near the kitchen
    building: converted warehouse in Shoreditch
    commute: the Overground from Peckham
    
  - workspace: flat desk
    detail: the corner of the bedroom that serves as an office
    building: flatshare in Hackney
    commute: none—WFH day
    
  - workspace: WeWork
    detail: the hot desk on the quiet floor
    building: coworking in Old Street
    commute: the Northern line from Clapham
    
  - workspace: coffee shop
    detail: the back table at the local roaster
    building: somewhere in Dalston
    commute: a short walk from the flat
    
  - workspace: pub garden
    detail: laptop out, pint untouched
    building: the one near the office
    commute: team "offsite"
```

```yaml
# variables/gen_z_professional/london_tech/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the CTO
      time: 9 PM
      context: before the board meeting
      typical_reality: a thought about the roadmap
      
    - event: calendar invite from the founder
      time: Friday afternoon
      context: startup rumours swirling
      typical_reality: team drinks organisation
      
    - event: message from investor relations
      time: mid-week
      context: between funding rounds
      typical_reality: routine reporting request
      
    - event: "Quick chat?" from manager
      time: Monday morning
      context: after a tough sprint
      typical_reality: project reprioritisation
      
    - event: all-hands meeting announced
      time: unusual time
      context: market downturn news
      typical_reality: product update
      
    - event: Glassdoor notification
      time: evening
      context: someone posted a review
      typical_reality: positive review from a leaver
```

```yaml
# variables/gen_z_professional/london_tech/industry_terms.yaml

industry_terms:
  stressors:
    - "runway"
    - "burn rate"
    - "Series A pressure"
    - "investor update"
    - "pivot discussions"
    - "hiring freeze"
    
  british_workplace:
    - "the all-hands"
    - "a quick chat"
    - "a catch-up"
    - "popping by"
    - "having a word"
    
  hierarchy:
    - "founder"
    - "CTO"
    - "VP"
    - "lead"
    - "senior"
    - "mid"
    
  locations:
    - "Shoreditch"
    - "Old Street"
    - "the Silicon Roundabout"
    - "Kings Cross"
    - "Farringdon"
```

---

## London Creative (Agency)

```yaml
# variables/gen_z_professional/london_agency/characters.yaml

characters:
  - name: Lily
    age: 26
    role: senior designer
    years_in_workforce: 3
    company_type: creative agency
    team: brand
    
  - name: Marcus
    age: 25
    role: copywriter
    years_in_workforce: 2
    company_type: advertising agency
    team: creative
    
  - name: Zara
    age: 27
    role: art director
    years_in_workforce: 4
    company_type: design studio
    team: campaigns
    
  - name: Ben
    age: 24
    role: junior creative
    years_in_workforce: 2
    company_type: digital agency
    team: social
    
  - name: Aisha
    age: 28
    role: creative strategist
    years_in_workforce: 5
    company_type: integrated agency
    team: strategy
```

```yaml
# variables/gen_z_professional/london_agency/locations.yaml

locations:
  - workspace: studio
    detail: the desk covered in mood boards
    building: agency loft in Shoreditch
    commute: the Central line from Stratford
    
  - workspace: flat desk
    detail: kitchen table, natural light
    building: flatshare in Brixton
    commute: none—concept day
    
  - workspace: client office
    detail: borrowed meeting room
    building: client HQ in the City
    commute: the Jubilee line from the studio
    
  - workspace: café
    detail: corner table at the place with good wifi
    building: somewhere in Soho
    commute: between meetings
    
  - workspace: pub
    detail: the booth in the back
    building: agency local
    commute: post-presentation drinks
```

```yaml
# variables/gen_z_professional/london_agency/triggers.yaml

triggers:
  false_alarm:
    - event: email from the CD
      time: 11 PM
      context: pitch week
      typical_reality: a "love this" on the work
      
    - event: client call moved up
      time: morning of
      context: after presenting concepts
      typical_reality: scheduling conflict
      
    - event: Slack from account management
      time: mid-afternoon
      context: waiting on feedback
      typical_reality: timeline update
      
    - event: "Can we look at this together?"
      time: end of day
      context: before the deadline
      typical_reality: minor amends
      
    - event: studio-wide meeting announced
      time: Monday morning
      context: pitch result pending
      typical_reality: new business win
      
    - event: creative director walking the floor
      time: during crunch
      context: everyone heads down
      typical_reality: checking in, being supportive
```

```yaml
# variables/gen_z_professional/london_agency/industry_terms.yaml

industry_terms:
  stressors:
    - "pitch"
    - "client amends"
    - "the deck"
    - "creative review"
    - "creds presentation"
    - "chemistry meeting"
    
  agency_life:
    - "the studio"
    - "creative floor"
    - "account side"
    - "the CD"
    - "the ECD"
    - "new business"
    
  feedback_culture:
    - "amends"
    - "tweaks"
    - "a few thoughts"
    - "another direction"
    - "back to the drawing board"
    
  locations:
    - "Shoreditch"
    - "Soho"
    - "Clerkenwell"
    - "Southbank"
    - "the West End"
```

---

# PART 2: SYDNEY

## Sydney Tech

```yaml
# variables/gen_z_professional/sydney_tech/characters.yaml

characters:
  - name: Liam
    age: 26
    role: software engineer
    years_in_workforce: 3
    company_type: fintech
    team: payments
    
  - name: Sophie
    age: 25
    role: product manager
    years_in_workforce: 2
    company_type: scale-up
    team: marketplace
    
  - name: Josh
    age: 27
    role: senior developer
    years_in_workforce: 4
    company_type: tech company
    team: platform
    
  - name: Priya
    age: 24
    role: data analyst
    years_in_workforce: 2
    company_type: startup
    team: growth
    
  - name: Matt
    age: 28
    role: engineering lead
    years_in_workforce: 5
    company_type: SaaS company
    team: core product
```

```yaml
# variables/gen_z_professional/sydney_tech/locations.yaml

locations:
  - workspace: open office
    detail: the standing desk with the harbour glimpse
    building: tech hub in Surry Hills
    commute: the light rail from Randwick
    
  - workspace: apartment desk
    detail: the corner of the living room
    building: flat in Newtown
    commute: none—WFH day
    
  - workspace: WeWork
    detail: the hot desk on the quiet floor
    building: coworking in Pyrmont
    commute: the ferry from Manly
    
  - workspace: café
    detail: the outdoor table
    building: somewhere in Surry Hills
    commute: a short walk
    
  - workspace: rooftop
    detail: the outdoor workspace
    building: their office building
    commute: elevator from the fourth floor
```

```yaml
# variables/gen_z_professional/sydney_tech/triggers.yaml

triggers:
  false_alarm:
    - event: Slack from the CEO
      time: 7 AM
      context: before the morning standup
      typical_reality: sharing an article
      
    - event: calendar invite from HR
      time: mid-week
      context: during restructure rumours
      typical_reality: benefits update
      
    - event: message from their skip-level
      time: end of day
      context: after a product launch
      typical_reality: congrats message
      
    - event: all-hands moved up
      time: Friday morning
      context: competitor news
      typical_reality: product announcement
      
    - event: "Quick sync?" from manager
      time: Monday morning
      context: after a tough sprint
      typical_reality: priorities chat
      
    - event: LinkedIn message from recruiter
      time: during work hours
      context: market uncertainty
      typical_reality: routine poaching
```

```yaml
# variables/gen_z_professional/sydney_tech/industry_terms.yaml

industry_terms:
  stressors:
    - "runway"
    - "burn rate"
    - "investor update"
    - "board meeting"
    - "restructure"
    - "hiring freeze"
    
  australian_workplace:
    - "a quick chat"
    - "a catch-up"
    - "popping in"
    - "having a yarn"
    - "checking in"
    
  hierarchy:
    - "CEO"
    - "CTO"
    - "head of"
    - "lead"
    - "senior"
    - "mid"
    
  locations:
    - "Surry Hills"
    - "Pyrmont"
    - "the CBD"
    - "North Sydney"
    - "Circular Quay"
```

---

## Sydney Finance

```yaml
# variables/gen_z_professional/sydney_finance/characters.yaml

characters:
  - name: Jack
    age: 26
    role: analyst
    years_in_workforce: 3
    company_type: investment bank
    team: M&A
    
  - name: Emma
    age: 25
    role: associate
    years_in_workforce: 2
    company_type: Big Four
    team: deals
    
  - name: Daniel
    age: 27
    role: senior analyst
    years_in_workforce: 4
    company_type: asset management
    team: equities
    
  - name: Mia
    age: 24
    role: graduate
    years_in_workforce: 1
    company_type: consulting firm
    team: strategy
    
  - name: Tom
    age: 28
    role: associate director
    years_in_workforce: 5
    company_type: private equity
    team: portfolio
```

```yaml
# variables/gen_z_professional/sydney_finance/locations.yaml

locations:
  - workspace: open office
    detail: the desk on the dealing floor
    building: tower in the CBD
    commute: the train from Bondi Junction
    
  - workspace: client site
    detail: borrowed meeting room
    building: client HQ in North Sydney
    commute: the ferry across the harbour
    
  - workspace: apartment desk
    detail: the study nook
    building: flat in Darlinghurst
    commute: none—WFH day
    
  - workspace: coffee shop
    detail: the back table
    building: near Martin Place
    commute: between meetings
    
  - workspace: airport lounge
    detail: the quiet corner
    building: Qantas Club
    commute: heading to Melbourne
```

```yaml
# variables/gen_z_professional/sydney_finance/triggers.yaml

triggers:
  false_alarm:
    - event: email from the MD
      time: 6 AM
      context: deal week
      typical_reality: scheduling request
      
    - event: Teams message from the partner
      time: Sunday evening
      context: before Monday's client meeting
      typical_reality: deck comment
      
    - event: calendar invite from HR
      time: during review season
      context: bonus cycle
      typical_reality: benefits update
      
    - event: "Got a minute?" from senior
      time: mid-afternoon
      context: after submitting work
      typical_reality: minor feedback
      
    - event: client call moved up
      time: day of
      context: waiting on sign-off
      typical_reality: scheduling conflict
      
    - event: missed call from the director
      time: during lunch
      context: on a live deal
      typical_reality: quick question
```

---

## Sydney Creative (Agency)

```yaml
# variables/gen_z_professional/sydney_creative/characters.yaml

characters:
  - name: Chloe
    age: 26
    role: senior designer
    years_in_workforce: 3
    company_type: creative agency
    team: brand
    
  - name: Ryan
    age: 25
    role: copywriter
    years_in_workforce: 2
    company_type: advertising agency
    team: creative
    
  - name: Jess
    age: 27
    role: art director
    years_in_workforce: 4
    company_type: design studio
    team: campaigns
    
  - name: Sam
    age: 24
    role: junior creative
    years_in_workforce: 2
    company_type: digital agency
    team: content
    
  - name: Tash
    age: 28
    role: creative lead
    years_in_workforce: 5
    company_type: integrated agency
    team: brand experience
```

```yaml
# variables/gen_z_professional/sydney_creative/locations.yaml

locations:
  - workspace: studio
    detail: the desk by the mood wall
    building: agency in Surry Hills
    commute: walking from Redfern
    
  - workspace: apartment desk
    detail: kitchen table with the good light
    building: flat in Marrickville
    commute: none—concept day
    
  - workspace: client office
    detail: borrowed meeting room
    building: client HQ in the CBD
    commute: the bus from the studio
    
  - workspace: café
    detail: outdoor table
    building: somewhere in Chippendale
    commute: a short walk
    
  - workspace: rooftop bar
    detail: after-work creative review
    building: near the studio
    commute: post-pitch drinks
```

```yaml
# variables/gen_z_professional/sydney_creative/triggers.yaml

triggers:
  false_alarm:
    - event: email from the ECD
      time: 10 PM
      context: pitch night
      typical_reality: "this is great"
      
    - event: client call brought forward
      time: morning of
      context: waiting on feedback
      typical_reality: they're keen to discuss
      
    - event: Slack from account management
      time: mid-afternoon
      context: post-presentation
      typical_reality: logistics update
      
    - event: "Let's look at this together"
      time: end of day
      context: deadline looming
      typical_reality: collaborative refinement
      
    - event: agency-wide meeting
      time: unusual time
      context: pitch result pending
      typical_reality: we won the pitch
      
    - event: CD walking through
      time: during crunch
      context: heads down working
      typical_reality: checking everyone's okay
```

---

# PART 3: CREATIVE FREELANCER / INDEPENDENT

## NEW TEMPLATE SET

### Persona Profile

**Role:** Freelance designer, writer, photographer, illustrator, creative consultant  
**Work Style:** Project-to-project, portfolio-based, client-dependent  
**Age Range:** 24-35

**Core Context:**
- No stable income — feast or famine cycle
- YOU are the product — rejection is personal
- No employer buffer between you and the market
- Every project could be the last one for a while
- Self-worth tied to creative output and client approval

**Core Anxiety Pattern:**
- Every email could be work (hope) or rejection (fear)
- Quiet inbox = existential dread
- Client silence = catastrophic thinking
- Saying no to work feels impossible even when burnt out
- Never fully "off" because off means not earning

**Unique Tension:**
- Chose this life — can't complain about instability they signed up for
- Success on social media makes everyone look booked and busy
- Struggling feels like proof they're not talented enough
- Rest feels like falling behind
- Every quiet period feels like the career might be over

---

## Variable Files

```yaml
# variables/creative_freelancer/characters.yaml

characters:
  - name: Maya
    age: 28
    discipline: graphic designer
    years_freelance: 4
    specialty: brand identity
    income_stability: variable
    
  - name: Jordan
    age: 26
    discipline: copywriter
    years_freelance: 3
    specialty: brand voice
    income_stability: project-to-project
    
  - name: Alex
    age: 30
    discipline: photographer
    years_freelance: 5
    specialty: commercial
    income_stability: seasonal
    
  - name: Sam
    age: 27
    discipline: illustrator
    years_freelance: 3
    specialty: editorial
    income_stability: feast or famine
    
  - name: Riley
    age: 29
    discipline: creative consultant
    years_freelance: 4
    specialty: brand strategy
    income_stability: retainer + projects
```

```yaml
# variables/creative_freelancer/locations.yaml

locations:
  - workspace: home desk
    detail: the corner of the flat that's become an office
    building: rental apartment
    commute: ten steps from the bedroom
    
  - workspace: coworking space
    detail: the day pass desk
    building: local coworking
    commute: a fifteen-minute bike ride
    
  - workspace: coffee shop
    detail: the regular table by the outlet
    building: the café that tolerates laptops
    commute: around the corner
    
  - workspace: client's office
    detail: borrowed desk for the day
    building: client HQ
    commute: across town
    
  - workspace: kitchen table
    detail: laptop between breakfast dishes
    building: home
    commute: none—deadline day
```

```yaml
# variables/creative_freelancer/triggers.yaml

triggers:
  false_alarm:
    - event: email notification
      time: any time
      context: waiting to hear back from a pitch
      typical_reality: newsletter they subscribed to
      hope: new project inquiry
      fear: rejection
      
    - event: client going quiet
      time: mid-project
      context: after sending work for review
      typical_reality: they're busy, will respond tomorrow
      fear: they hate it, project's dead
      
    - event: Instagram DM
      time: evening
      context: posted new work recently
      typical_reality: a friend saying nice things
      hope: someone wanting to hire them
      fear: someone calling out a mistake
      
    - event: calendar reminder
      time: end of month
      context: invoice due
      typical_reality: routine accounting
      fear: realising how little came in
      
    - event: "Can we hop on a call?"
      time: from a current client
      context: mid-project
      typical_reality: scope discussion
      fear: they're killing the project
      
    - event: quiet inbox
      time: Monday morning
      context: no active projects
      typical_reality: normal slow period
      fear: career is over
```

```yaml
# variables/creative_freelancer/stakes.yaml

stakes:
  financial:
    - "rent due in two weeks"
    - "three months of runway if nothing comes in"
    - "credit card balance climbing"
    - "tax bill coming up"
    
  identity:
    - "years of building this practice"
    - "the thing they tell everyone they do"
    - "what they left the agency job for"
    - "the portfolio they've been building"
    
  reputation:
    - "one bad project and word spreads"
    - "clients talk to each other"
    - "too small to have a bad quarter"
    - "referrals are everything"
    
  comparison:
    - "everyone on Instagram looks booked"
    - "peers announcing big projects"
    - "friends with stable jobs and benefits"
    - "the algorithm showing only success stories"
```

```yaml
# variables/creative_freelancer/body_sensations.yaml

sensations:
  - primary: stomach flip
    secondary: that mix of hope and dread
    context: email notification sound
    
  - primary: chest tighten
    secondary: mind racing through scenarios
    context: client going quiet
    
  - primary: that sinking feeling
    secondary: scrolling for reassurance
    context: slow inbox week
    
  - primary: jaw clench
    secondary: shoulders up
    context: waiting on payment
    
  - primary: low-grade dread
    secondary: hard to focus on anything else
    context: between projects
```

---

## Template: Recognition

```markdown
# Recognition Template
## Persona: Creative Freelancer
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.discipline}}
- {{character.years_freelance}}
- {{trigger.event}}
- {{trigger.time}}
- {{trigger.context}}
- {{trigger.typical_reality}}
- {{trigger.hope}}
- {{trigger.fear}}
- {{body.primary}}
- {{body.secondary}}
- {{stakes.identity}}
- {{location.workspace}}

### Template

{{character.name}} had been freelancing for {{character.years_freelance}} years.

Long enough to know the rhythm.
Long enough to trust that work comes and goes.

Not long enough to stop the {{body.primary}} every time the inbox pinged.

The {{trigger.event}} came through {{trigger.time}}.
{{trigger.context}}.

Their {{body.primary}}.
Then {{body.secondary}}.

Before they even looked, their brain was running two tracks:
{{trigger.hope}}.
Or: {{trigger.fear}}.

They checked.

{{trigger.typical_reality}}.

Nothing exciting.
Nothing devastating.
Nothing that should have made their body react like their career was on the line.

But it did.

And it wasn't just that notification.
It was every email.
Every DM.
Every client silence that stretched past 24 hours.

{{stakes.identity}}.
And their nervous system treating every ping—or absence of ping—
like proof of whether they were going to make it.

Sitting at {{location.workspace}},
they looked calm.
Did the work.
Sent the invoices.

And underneath, something was always scanning.
Always calculating runway.
Always bracing for the thing that would prove
this whole freelance experiment was a mistake.

The worst part was the performance.

On social media, they posted wins.
In conversations, they said "busy, but good."
Nobody could know that their nervous system
was treating every quiet Monday like evidence
that the work had dried up forever.

They couldn't exactly tweet:
"I refresh my inbox forty times a day
and feel sick every time it's not a new project."

So they didn't.
```

---

## Template: Mechanism Proof

```markdown
# Mechanism Proof Template
## Persona: Creative Freelancer
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.discipline}}
- {{body.primary}}
- {{body.secondary}}
- {{stakes.financial}}
- {{stakes.comparison}}

### Template

{{character.name}} had tried to manage the anxiety.

Batching email checks.
Turning off notifications.
The "abundance mindset" everyone talked about.

None of it stopped the {{body.primary}} when a client went quiet.
None of it kept their {{body.secondary}} when the inbox stayed empty.

They'd tried staying busier—
saying yes to everything,
filling every gap in the calendar—
thinking that being busy would make the fear go away.

It made it worse.
Burnout plus anxiety was not an improvement.

They'd tried the opposite—
taking breaks, trusting the process,
"leaning into the slow periods."

But rest felt like falling behind.
{{stakes.comparison}}.
And here they were, refreshing their inbox on a Tuesday afternoon.

They'd tried logic.

*Work is cyclical.*
*Slow weeks don't mean slow forever.*
*{{stakes.financial}}—you're fine for now.*

The numbers made sense.
Their body didn't care about numbers.

Every strategy they tried
became another thing to manage.

And underneath all the mindset work,
all the boundary-setting,
all the "this is just how freelance works,"
the alarm kept firing.

Every time.
Right on cue.

Like their nervous system had decided
that not having a salary
meant permanent threat assessment.

And maybe it was right.
Maybe things really could dry up.

But living like they were about to
was becoming its own kind of unsustainable.
```

---

## Template: Turning Point

```markdown
# Turning Point Template
## Persona: Creative Freelancer
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.discipline}}
- {{location.workspace}}
- {{location.detail}}
- {{body.primary}}
- {{body.secondary}}
- {{character.years_freelance}}

### Template

{{character.name}} was at {{location.workspace}}—
{{location.detail}}—
when the notification came through.

Their {{body.primary}}.
Their {{body.secondary}}.
The whole familiar sequence.

But this time, instead of immediately checking,
they paused.

Not to suppress it.
Not to breathe through it.
Just to notice.

*There it is.*
*The spike.*
*Same as always.*

And something shifted.

Not the situation.
Their relationship to it.

Of course their body was on high alert.
They'd built a career with no safety net.
No guaranteed paycheck.
No HR department between them and the market.

Their nervous system was doing exactly what a nervous system does
when survival depends on things you can't control.

It was scanning.
Protecting.
Treating every signal like it might be the difference
between rent paid and rent missed.

That wasn't a malfunction.
That was a system calibrated for real stakes.

{{character.years_freelance}} years of this.
Of course their body had learned to stay alert.

The spike wasn't proof they couldn't handle freelancing.
It was proof they were paying attention
to something that actually mattered.

The notification turned out to be nothing.
Their body didn't know that yet.
But they did.

And for the first time,
the gap between what their body felt and what they knew
didn't feel like failure.

It felt like being human
in a situation with real uncertainty.

They could feel the spike
and still check the email calmly.

They could notice the dread
and still keep working.

The alarm didn't have to run the show.
It just had to be there.
```

---

## Template: Embodiment

```markdown
# Embodiment Template
## Persona: Creative Freelancer
## Mechanism: Autonomic Regulation
## Engine: False Alarm

### Variables
- {{character.name}}
- {{character.discipline}}
- {{trigger.event}}
- {{body.primary}}
- {{stakes.identity}}

### Template

The spikes didn't stop.

{{character.name}} wasn't pretending they did.

Every {{trigger.event}} still made their {{body.primary}}.
That was probably permanent.
That was probably what building a practice without a safety net did to a person.

But something had changed in what happened next.

Before, it was:
notification → spike → check frantically → catastrophize → spiral → struggle to work

Now it was:
notification → spike → *there it is* → check normally → move on

One layer instead of five.

They stopped expecting to be a freelancer who didn't feel this.
They started being a freelancer who felt it and worked anyway.

Last week, a client went quiet for three days.
Their body did the thing.
{{body.primary}}.
Mind racing through "they hate it" scenarios.

They noticed it.
Didn't chase it.
Sent a gentle follow-up.

Client was just busy.
Loved the work.
Project continued.

And even if they hadn't—
even if the project was dead—
they realised they would have handled it.
Not happily.
But capably.

The alarm wasn't a prediction.
It was just an alarm.

{{stakes.identity}}.
The stakes were still real.
The uncertainty wasn't going anywhere.

But the nervous system running threat assessment on every notification
didn't mean every notification was a threat.

They were still a {{character.discipline}} whose body ran hot.
They just weren't at war with it anymore.

Some weeks were still hard.
Some slow periods still felt like the end.

But they'd stopped adding the second layer—
the shame about being anxious,
the fear that feeling this meant they weren't cut out for this.

They could feel it and be cut out for it.

That turned out to be the whole job.
```

---

# SUMMARY

## Template Sets (Total: 6)

| Template Set | Voice | Use Case |
|--------------|-------|----------|
| Gen Z Professional | Employed, internet-literate, therapy-adjacent | Corporate roles (tech, finance, agency creative) |
| SF/SV Founder | Existential stakes, responsible for others | Startup founders |
| Healthcare RN | Clinical knowledge doesn't help | Nurses across settings |
| Gen Alpha Student | Teen, social stakes, less articulate | Students 12-17 |
| **Creative Freelancer** | **No safety net, you ARE the product** | **Independent creatives** |

## Variable Sets Created This Document

| Region | Variable Sets |
|--------|---------------|
| **London** | Tech, Agency/Creative |
| **Sydney** | Tech, Finance, Creative |
| **Creative Freelancer** | Universal (location-agnostic) |

## Key Architecture Insight

**Agency creatives** use Gen Z Professional templates — they have employers, salaries, performance reviews. The anxiety is about career success.

**Freelance creatives** need their own templates — there's no buffer between them and rejection. The anxiety is about survival and identity.

Same industry. Different voice. That's why the system separates templates (voice) from variables (details).

---

## Total Asset Count

| Asset Type | Count |
|------------|-------|
| Template Sets | 6 |
| Variable Sets | 30+ |
| Unique Books Possible | 1,200+ |

---

*End of London, Sydney & Creative Coverage*
