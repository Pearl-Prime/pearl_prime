# Overwhelm: A Guide for Nurses and Healthcare Workers
## Complete Canonical Book — Phase-Correct Structure

**Word Count Target:** ~5,500 words
**Phase Structure:** Introduce (Ch 1-2) → Deepen (Ch 3-5) → Test (Ch 6-8) → Complicate (Ch 9) → Integrate (Ch 10-12)
**Core Sentence:** "I don't know where to start, so I can't start."
**Demographic Adaptation:** Nurses and healthcare workers — patient load paralysis, competing urgent priorities, charting mountain, task saturation, system chaos
**Phenomenology:** Frozen despite urgency, can't prioritize when everything's critical, scattered attention, mental fog mid-shift, shutdown when drowning

---

## Pre-Introduction

Welcome to Overwhelm: A Guide for Nurses and Healthcare Workers.

This is a 360-minute audiobook about that frozen feeling when everything needs you at once.

Listen however works for you. Between shifts. On your days off. In pieces when you can.

12 chapters. No charting required. Nobody's auditing your progress.

Just listen. Process however you process.

Ready when you are.

[Pause 3s]

---

## Introduction

I remember standing at the nurses' station, completely frozen.

I had six patients. Two were declining. One needed pain meds twenty minutes ago. Another's family was at the desk asking questions. The charge nurse needed me for something. My phone was buzzing with lab results. And I had four hours of charting I hadn't started.

I knew I needed to move. I knew people were waiting. But I couldn't figure out what to do first. Everything was urgent. Everything needed me now. And I just stood there, paralyzed, while the list grew longer.

I thought something was wrong with me. Real nurses could handle this. Real nurses could triage, prioritize, move. I was just... stuck.

I didn't understand what was actually happening. My brain had hit a processing limit. Too many inputs, too many competing priorities, too many things marked "urgent"—and instead of sorting them, my system just stopped.

That's overwhelm. Not laziness. Not incompetence. Overwhelm.

That's what this book is about. Understanding why your brain freezes when everything needs you at once, and what actually helps you start moving again.

You found this because something feels off. Maybe you're drowning every shift. Maybe you stare at the task list and can't figure out where to begin. Maybe you go home and can't do anything because everything feels like too much.

Whatever brought you here matters. You found this for a reason.

This isn't about time management or working smarter. This is about your brain—the actual system that's supposed to sort and prioritize—and what happens when it gets overloaded.

What's happening: overwhelm isn't happening because you're bad at your job. It's happening because the inputs exceed what any brain can process.

Nothing is fundamentally wrong with you.

The paralysis isn't weakness. The scattered attention isn't a flaw. The inability to start isn't incompetence. These are your brain's responses to being asked to process more than brains can process.

This book helps you understand what's happening and what actually helps. Not more efficiency tips. What helps YOUR brain find a way through when everything is screaming for attention.

You don't have to believe this will work. You just have to be willing to be here.

You're here. That's enough.

---

## CHAPTER 1: The Freeze
### Phase: INTRODUCE — Hook + Recognition

You're not a bad nurse.

I need you to hear that first, because the freeze looks like incompetence. When everyone around you is moving and you're standing still, it's easy to think you're the problem.

You're not. Your brain just hit a wall.

Here's what healthcare overwhelm actually feels like:

**Everything is urgent but you can't move.** You know patients are waiting. You know things need to happen. But you can't figure out what to do first, so you do nothing. Or you do something random that isn't the priority.

**Your brain is foggy mid-shift.** You walk into a room and forget why you're there. You look at the patient and can't remember what you were going to assess. The mental clarity that used to be automatic is gone.

**You start things and don't finish them.** You begin one task, get interrupted, start another, get pulled away, and end up with five half-done things and nothing complete.

**The charting mountain paralyzes you.** You look at how much documentation is waiting and you can't even start. So you put it off, which makes it worse, which makes it harder to start.

**Small decisions feel impossible.** Which patient first? What order for the meds? When to take a break? Decisions that should be automatic take enormous effort—or don't get made at all.

**You want to hide.** In the supply closet. In the bathroom. Anywhere you can escape the wall of demands, even for a minute.

If this sounds familiar, you're not failing. You're overwhelmed.

And overwhelm in healthcare isn't about not being good enough. It's about being asked to process more simultaneous demands than any human brain can handle. Six patients who all need you. Competing priorities that are all marked urgent. A constant stream of interruptions that fragment your attention.

Your brain is designed to handle a certain amount of input. Healthcare regularly exceeds that amount. When it does, your brain doesn't struggle through—it freezes.

This is actually protective. If your brain tried to handle everything at once, you'd make dangerous mistakes. The freeze is your system saying: too much, can't sort, need to pause.

The problem is, you can't pause. Patients need you. The work keeps coming. So you're stuck—frozen but expected to perform.

You didn't choose this. You're not bad at prioritizing. You're working in conditions that overwhelm the prioritization system.

Let's figure out what to do about it.

---

## CHAPTER 2: How You Got Here
### Phase: INTRODUCE — Validation + Origin Story

The freeze didn't come out of nowhere. It built up.

Let me walk you through how it probably went:

**You started capable.** You could handle a patient load. You could triage, prioritize, move efficiently. The work was hard but your brain could sort it.

**Then the loads got heavier.** More patients per nurse. Higher acuity. Sicker people needing more complex care. The same brain, more inputs.

**The interruptions multiplied.** Call lights. Phones. Pages. Families. Doctors. Each interruption fragments your attention. Your brain has to restart whatever it was doing. The cognitive cost adds up.

**The charting requirements grew.** More documentation. More boxes to check. More things that have to be recorded for legal, billing, regulatory reasons. Hours of charting that doesn't feel like nursing.

**The support got thinner.** Fewer CNAs. Fewer resources. More responsibility shifted to nurses. You're doing tasks that aren't nursing because there's no one else to do them.

**You started compensating.** Skipping breaks. Staying late. Holding more in your head because you didn't have time to write it down. Your brain became the backup system for an understaffed unit.

**The pile got too big.** At some point, the accumulated inputs exceeded your processing capacity. Your brain looked at everything that needed attention and said: I can't sort this. Too much.

That's the freeze. That's where you are.

Here's what I want you to understand: **this isn't your fault.**

The conditions causing overwhelm are systemic. The staffing ratios. The documentation burden. The constant interruptions. The acuity levels. These aren't personal failures—they're system failures that land on individual nurses.

Your brain is responding rationally to irrational conditions.

The question isn't "why can't I handle this?"—nobody could handle what you're being asked to handle.

The question is: how do I get my brain working again when the inputs keep coming?

---

## CHAPTER 3: What Overwhelm Actually Is
### Phase: DEEPEN — Full Pattern Exposure

Let's get specific about what's happening in your brain.

Overwhelm isn't just stress. It's a specific cognitive state where your brain's sorting system has exceeded capacity.

Here's the neuroscience:

Your prefrontal cortex handles executive function—prioritizing, sequencing, deciding, planning. It's what lets you look at six patients and figure out who needs you first.

But the prefrontal cortex has limits. It can hold and process a certain amount of information. Add too much, and it doesn't slow down—it stops working.

Think of it like a computer. Normal use, it runs fine. Too many programs open, it slows down. Too many more, it freezes completely. Not slow—frozen.

That's what happens to your brain when you're overwhelmed. The prioritization system goes offline. You literally cannot sort the inputs because the sorter isn't working.

This triggers a stress response, which makes it worse. Stress hormones impair prefrontal function further. You need clear thinking to get out of overwhelm, but overwhelm is preventing clear thinking.

Here's what this looks like in healthcare specifically:

**Everything feels equally urgent.** The declining patient and the call light feel like they have the same weight. You can't distinguish levels of priority because the system that does that is offline.

**Decision fatigue compounds.** Every decision you make—even small ones—costs cognitive resources. By mid-shift, you've made hundreds of decisions. The capacity is depleted.

**The charting looms impossibly.** The documentation isn't just one task—it's dozens. Your brain sees the whole pile and freezes because it can't break it into manageable pieces.

**Interruptions shatter focus.** Every interruption costs more than the time it takes. Your brain has to reload context. When interruptions are constant, you never get deep enough into any task to complete it.

**The mental fog rolls in.** Thinking feels hard. Memory is unreliable. You forget things you just heard. This is your prefrontal cortex operating at reduced capacity.

**You default to reactive.** Instead of working a plan, you're just responding to whoever's loudest. The call light. The family at the desk. The newest crisis. You're not prioritizing—you're just reacting.

This is overwhelm. It's not weakness or incompetence. It's a brain that's been asked to process more than brains can process, doing exactly what brains do under those conditions.

---

## CHAPTER 4: What Staying Frozen Costs
### Phase: DEEPEN — Cost Accounting

Let's talk about what happens if the overwhelm continues without intervention.

I'm not saying this to add more pressure—you have enough. I'm saying it because overwhelm normalizes. You get used to being frozen. You forget that working differently is possible.

But the costs are real.

**Patient safety.** This is the one that matters most. Overwhelmed nurses make errors. Not because they're bad nurses—because overwhelm impairs the cognitive functions that prevent errors. Forgetting a med. Missing a sign. Not catching something you would have caught with a clear head.

You know this. You've probably already caught yourself almost making mistakes you wouldn't have made on a better day.

**Your health.** Chronic overwhelm is chronic stress. The physical toll—sleep disruption, headaches, digestive issues, immune suppression—is real. Your body is keeping score.

**Your charting.** Ironically, being too overwhelmed to chart creates more charting. The pile grows. Late documentation is harder to do accurately. The problem compounds.

**Your sense of competence.** Every shift you spend frozen erodes your belief in yourself. You start to think: maybe I'm not good enough for this. The overwhelm becomes identity.

**Your career.** If the overwhelm continues, one of two things happens: you make a serious error, or you leave. Neither is what you want.

Here's what I've watched happen to nurses who stay in chronic overwhelm:

They make an error that haunts them. The impaired cognition catches up in a way that has consequences. For a patient. For their license. For their ability to keep doing this work.

Or they leave. Sometimes this is the right choice. But often it's a reactive escape from conditions that felt unbearable, not a considered decision about what they actually want.

Or they check out. They stay but stop caring. They do the minimum. They become the disengaged nurse they never wanted to become. Survival, but not practice.

You've probably seen these outcomes in colleagues. Maybe you've already started down one of these paths.

There's another option. It starts with understanding how to get your brain working again.

---

## CHAPTER 5: The Core Truth About Overwhelm
### Phase: DEEPEN — Core Thesis + Reframe

Here's what nobody tells you in nursing school:

**You can't think your way out of overwhelm by thinking harder.**

When your brain is frozen, trying to see the whole picture—all six patients, all the tasks, all the priorities—makes it worse. That's what froze you in the first place.

The solution isn't better prioritization of everything. It's not seeing everything at once.

Here's the shift: **narrow the field until your brain can process it.**

You can't handle six patients simultaneously. But you can handle one patient. One task. One next thing.

When you try to hold everything, you hold nothing. When you focus on one thing, you can actually think about it.

This sounds too simple. It's not simple—it's hard. Because healthcare keeps demanding you see everything. And your training tells you to stay aware of the whole picture.

But the whole picture is what's freezing you. You need to look at a smaller picture. One you can actually process.

Here's what this looks like:

**Not:** What do all six patients need?
**Instead:** What does this one patient need right now?

**Not:** How do I get through all this charting?
**Instead:** What's one chart I can complete?

**Not:** What should I do first?
**Instead:** What's one thing I can do?

The shift from "everything at once" to "one thing now" is the difference between frozen and moving.

Your brain can handle one thing. That's all you need to start.

Starting anywhere is better than optimizing the start into paralysis.

---

## CHAPTER 6: Breaking the Freeze
### Phase: TEST — First Practices

Let's make this practical. Here are three ways to get your brain moving again when you're frozen:

**Practice 1: The One-Patient Focus**

When you're drowning, pick one patient. Just one.

Not the sickest necessarily—just one. Go to that patient. Do what they need. Complete something for them.

While you're with that patient, the other patients still exist. But you're not trying to process all of them. You're just processing one.

After you complete something for that patient, you can pick the next one. But only after. One at a time.

This feels wrong. It feels like you're ignoring the others. You're not—you're making it possible to actually help any of them by narrowing to one.

**Practice 2: The Next Physical Action**

When a task feels overwhelming, it's usually because it's not actually a task. It's a project with many steps.

"Chart on Mr. Johnson" isn't a task. It's dozens of tasks: open the chart, find the assessment section, document vitals, document findings, etc.

When you're frozen, identify the next physical action. What would you literally do with your hands right now?

Not "catch up on charting." But: "Click on Room 302's chart."

That's doable. That's one thing. Do that, then identify the next physical action.

**Practice 3: The Two-Minute Unstick**

When you're completely frozen—standing at the station unable to move—commit to two minutes.

Pick anything. Any task, any patient, any action. Set a mental two-minute timer. Do that thing for two minutes.

Two minutes is nothing. Your brain can't argue that two minutes is too much.

What happens: starting is the hardest part. Once you start, continuing is easier. The two minutes breaks the freeze. You probably won't stop at two minutes—but even if you do, you've moved.

These practices share a principle: make the field of focus small enough that your brain can engage.

---

## CHAPTER 7: Protecting Your Bandwidth
### Phase: TEST — Deeper Practice

You can't stay unfrozen if the inputs keep overwhelming you. Here's how to protect your processing capacity:

**Batch similar tasks.**

Every time you switch between different types of tasks, your brain has to reload. The more switching, the more cognitive cost.

When possible, batch: do all your med passes in a row, then all your assessments, then charting. Less switching, less cost.

I know healthcare constantly interrupts this. But to whatever extent you can batch, it helps.

**Write it down immediately.**

Your brain is trying to hold too much. Every piece of information you hold in your head costs processing power.

Get it out. Write it on your brain sheet. The moment you learn something, capture it externally. Don't trust your memory—your memory is overloaded.

**Identify your highest-drain moments.**

Not all parts of the shift are equally overwhelming. Maybe it's the first hour when you're getting report and assessing everyone. Maybe it's the chaos of shift change. Maybe it's when you're behind on charting.

Know when you're most likely to freeze. Prepare for those moments. Have a plan for narrowing the field when they hit.

**Create a capture system.**

When new information comes in—a lab result, a family question, an order change—it needs somewhere to go that isn't your head.

Your brain sheet, a notes app, a system that works for you. The tool doesn't matter. What matters is: inputs go into the system immediately, not into your overtaxed brain.

**Protect transition moments.**

The handoff. The break. The moment between patients. These are when your brain could reset—but often they get filled with more inputs.

When possible, take transitions as actual transitions. Don't immediately fill them with the next thing. Let your brain complete what it was doing before starting fresh.

---

## CHAPTER 8: When You're Drowning Mid-Shift
### Phase: TEST — High Intensity Moments

Some shifts are worse than others. Here's how to survive when you're actively drowning:

**When all call lights are going:**

You can only answer one at a time. Pick one—probably the most acute or the one you're closest to. Answer it. Then pick the next one.

You cannot answer all of them simultaneously. Trying to figure out the perfect order takes longer than just starting somewhere.

**When a patient is declining while everything else burns:**

The declining patient takes priority. Everything else waits.

This feels terrible. Other patients still need things. But acuity wins. You can explain late meds. You can't explain missing a code.

Let the other stuff wait. Be with the patient who needs you most.

**When the charting is so far behind it feels impossible:**

Pick one chart. The oldest one or the simplest one—whatever feels most possible.

Do that one chart. Just that one. Complete it.

Then pick the next one. One at a time. The pile is too big to see all at once. But you can do one chart.

**When your brain has fully frozen:**

Physical movement helps. Go to the bathroom. Walk to the supply room. Get water. Move your body.

Sometimes the freeze is broken by physical movement when thinking can't break it. Get your body moving and your brain may follow.

**When you're about to lose it:**

Find two minutes of privacy. Bathroom. Supply closet. Wherever.

Let the overwhelm be there without trying to fix it. Just feel how overwhelmed you are. Sometimes acknowledging it lets it move through instead of staying stuck.

Then: one thing. Pick one thing you can do. Do that thing. Then pick the next one.

---

## CHAPTER 9: What Getting Unstuck Actually Looks Like
### Phase: COMPLICATE — Paradox + Non-Linear Progress

Here's where I have to complicate things.

Getting unstuck isn't a permanent fix. It's something you'll have to do over and over.

**You'll unfreeze, then freeze again.**

Some shifts you'll handle beautifully. One patient at a time. Next physical action. Batching tasks.

Other shifts, the inputs will spike—multiple patients declining, admissions stacking up, chaos—and you'll freeze again. Just as stuck as before.

This isn't failure. This is the nature of overwhelm. Your capacity fluctuates. The inputs vary. Some days the math works; some days it doesn't.

**The conditions probably won't change.**

The staffing ratio isn't going to improve because you learned to narrow your focus. The charting burden won't decrease. The interruptions won't stop.

You have to work within conditions that will keep pushing you toward overwhelm. The practices help, but they're not a cure for a sick system.

**You can't always catch it early.**

Sometimes you'll feel the freeze coming and intervene. Sometimes you'll be deep in it before you realize what's happening.

Both will happen. Catching it early is great. Catching it late is still catching it.

**The freeze protects you, sometimes.**

Here's a hard truth: sometimes the freeze is information.

Maybe the load is genuinely unsafe. Maybe what's being asked is beyond what any nurse could do. Maybe the freeze is your system saying: this isn't okay.

Listen to that. Don't just override it every time. Sometimes the answer isn't "break through the freeze" but "acknowledge that these conditions are unsustainable."

**AND this is still worth doing.**

All of that—the recurring freezes, the unchanged conditions, the ongoing struggle—and it's still worth learning to work with overwhelm.

Because frozen doesn't help anyone. Not you, not your patients. Learning to narrow the field, to start somewhere, to move one thing at a time—that's better than paralysis.

Imperfect progress is better than staying stuck.

---

## CHAPTER 10: When You Freeze Again
### Phase: INTEGRATE — Handling Setbacks

You will freeze again. Here's how to handle it.

A freeze looks like this: you were moving, managing, getting through the shift. Then the inputs spiked—two admits at once, a patient crashing, the charge nurse out sick—and suddenly you're stuck. Staring at the list. Unable to start.

And you think: I thought I knew how to handle this.

You do. The freeze doesn't erase it.

**Recognize it faster.**

You know what the freeze feels like now. The fog. The paralysis. The everything-at-once that goes nowhere.

When you recognize it, you can intervene sooner. Not perfectly—but sooner than before.

**Get curious, not critical.**

What triggered this freeze? Was it a spike in inputs? A specific type of situation? Accumulation over the shift?

Not to blame yourself—to learn. Understanding your freeze patterns helps you anticipate and prepare.

**Return to the basics.**

When you're frozen, don't try to implement everything. Pick one practice.

One-patient focus. Next physical action. Two-minute unstick.

Just one. Use it to break the freeze.

**Expect recovery time to improve.**

Early in learning these practices, a freeze might last an hour—or a whole shift. Later, it might last twenty minutes. Eventually, you might feel it coming and intervene in five.

That shortening time is progress. The freezes don't stop, but they resolve faster.

---

## CHAPTER 11: Who You're Becoming
### Phase: INTEGRATE — Identity Shift

Something is shifting.

You're not the same nurse who started this book.

**You understand the freeze now.**

Before, you thought it was incompetence. Now you know: it's your brain hitting processing capacity. That's not a character flaw—it's neuroscience.

That understanding changes how you relate to yourself when it happens.

**You have tools.**

Narrow the field. One patient. Next physical action. Two minutes.

These aren't magic—but they're something. More than you had before.

**You see the system more clearly.**

You know now that overwhelm isn't just personal. The conditions create it. The staffing, the documentation, the constant interruptions—the system is designed in ways that overwhelm nurses.

That clarity is protection. It's harder to blame yourself when you can see the system's role.

**You're building a different pattern.**

The old pattern: freeze, panic, criticize yourself, struggle.

The new pattern: freeze, recognize it, narrow the field, start somewhere.

It's not automatic yet. But it's forming.

**You're still a good nurse.**

The freeze didn't mean you were bad at this. The overwhelm didn't mean you didn't belong.

You're a nurse working in overwhelming conditions, learning to work with your brain instead of against it. That's growth, not failure.

---

## CHAPTER 12: What Comes Next
### Phase: INTEGRATE — Continuation + Closing

This isn't an ending. It's a checkpoint.

You've learned what overwhelm is and why the freeze happens. You have tools. You know what to do when your brain hits the wall.

But the shifts keep coming. The inputs don't stop. The conditions remain what they are.

What's different is you.

Here's what you carry forward:

**Understanding.** You know what's happening in your brain when you freeze. That knowledge helps.

**Practices.** One-patient focus. Next physical action. Two-minute unstick. Batching. Capturing externally. Ways to narrow the field.

**Self-compassion.** You know the freeze isn't weakness. It's a brain doing what brains do when overloaded.

**Realism.** You know the conditions aren't going to change. You have to work within them. The practices help, but they're not a cure.

There will be hard shifts ahead. Shifts where everything spikes and you freeze despite everything you've learned. Shifts that make you wonder if you can keep doing this.

On those shifts, remember: you've been here before. You got through it before. The practices are still there.

And remember this:

**Your brain is doing its best.**

The freeze isn't failure. It's your brain saying "too much, need to pause." That's protective. That's your system trying to keep you from making dangerous mistakes when overloaded.

Thank your brain for that. Even when it's inconvenient. The freeze is trying to help.

**You can handle one thing.**

Not everything. Not all six patients. Not the whole charting pile.

One thing. You can always handle one thing.

That's all you need to start moving.

Whatever comes next—whether you stay in this role, change units, find a different path—you're learning to work with your brain instead of against it. That skill transfers. That skill helps.

Take care of yourself. Actually take care of yourself. Your brain is a tool. It needs maintenance. Rest. Recovery. Inputs that don't overwhelm.

You deserve that care.

You're a good nurse. The freeze doesn't change that.

You're enough. You've always been enough.

---

## Conclusion

You made it here. That matters.

Not because you're fixed. Because you showed up. Through every chapter. Through the parts that felt too true. That's the work.

By now, you understand that overwhelm isn't a personal failure. It's a brain hitting processing limits in conditions designed to exceed them.

The freeze is protective. The paralysis is your system saying "too much." That's not weakness—that's neuroscience.

Recovery means narrowing the field. One patient. One task. One next thing.

You don't have to see the whole picture. You just have to see enough to take one step.

When the freeze comes again—and it will—you know what to do. Recognize it. Pick one thing. Start.

The conditions won't change. The staffing won't improve. The inputs will keep coming.

But you'll be different. You'll have tools. You'll have understanding. You'll have the ability to narrow when everything screams for attention at once.

That's what sustainable nursing looks like. Not never freezing—knowing how to unfreeze.

Take care of yourself. Your brain is doing hard work in hard conditions.

You deserve care. You deserve rest. You deserve conditions that don't overwhelm you—and while you're working to change those conditions or working within them, you deserve compassion for yourself.

You're a good nurse. The freeze doesn't change that.

One thing at a time. That's all it takes.

You've got this.

---

**END OF RN/HEALTHCARE WORKER OVERWHELM BOOK**

**Word Count:** ~5,400 words
**Phase Structure Verification:**
- Ch 1-2: INTRODUCE (hook, recognition, validation, origin story) ✓
- Ch 3-5: DEEPEN (pattern exposure, cost, core thesis) ✓
- Ch 6-8: TEST (practices, protection, drowning mid-shift) ✓
- Ch 9: COMPLICATE (paradox, non-linear, freeze protects sometimes) ✓
- Ch 10-12: INTEGRATE (setbacks, identity shift, continuation) ✓

**Demographic Adaptations from Gen Z Overwhelm:**
- Healthcare-specific freeze triggers (patient loads, competing urgent priorities)
- Charting as specific overwhelm driver
- Patient safety stakes (errors from overwhelm)
- Shift-based structure (mid-shift freeze, drowning moments)
- Healthcare practices (one-patient focus, brain sheets, batching tasks)
- Interruption reality (call lights, phones, constant fragmentation)
- Nursing identity connection ("you're still a good nurse")
- System critique (staffing ratios, documentation burden)
- Acuity triage in emergencies (declining patient takes priority)
