# Burnout: A Guide for Gen Alpha
## Complete Canonical Book — Phase-Correct Structure

**Word Count Target:** ~4,500 words
**Phase Structure:** Introduce (Ch 1-2) → Deepen (Ch 3-5) → Test (Ch 6-8) → Complicate (Ch 9) → Integrate (Ch 10-12)
**Core Sentence:** "I gave everything and there's nothing left."
**Demographic Adaptation:** Gen Alpha (ages 10-14) — school pressure, extracurriculars, social media exhaustion, parental expectations, friendship drama, identity formation
**Phenomenology:** Exhaustion, not caring anymore, feeling empty, "what's the point," too tired to try
**Voice:** Warm, validating, slightly older friend/mentor tone — not talking down, not overly adult

---

## Pre-Introduction

Hey. Welcome to Burnout: A Guide for Gen Alpha.

This is an audiobook about feeling exhausted in a way that's hard to explain.

You can listen however works for you. All at once. A chapter at a time. Skip around if you want.

12 chapters. No tests. No grades. Nobody's checking if you finished.

Just listen. Think about it however you think about it.

Ready when you are.

[Pause 3s]

---

## Introduction

I remember being your age and feeling tired all the time.

Not sleepy tired—though that too. More like... empty tired. Like I'd used up everything I had and there was nothing left. Like I was going through the motions of my life but I wasn't really there.

I thought something was wrong with me. Everyone else seemed fine. They were doing school, activities, social stuff—and I could barely get through the day. I figured I was just lazy. Or weak. Or broken somehow.

I wasn't any of those things. And neither are you.

What I didn't understand back then is that feeling empty like that has a name. It's called burnout. And it happens when you give more than you have for too long.

That's what this audiobook is about. Understanding why you feel the way you feel, and what actually helps.

You're here because something feels off. Maybe school feels pointless but you can't stop doing it. Maybe you're exhausted but you can't rest. Maybe you used to care about things and now you don't, and you're not sure why.

Whatever brought you here is valid. You found this for a reason.

This isn't about trying harder or being more positive. It's about understanding what's actually happening in your body and brain when you feel this way.

Here's the main thing I want you to know:

Feeling burned out doesn't mean you're lazy or weak. It means you've been giving more than you had. That's not a character flaw—that's just math.

You don't have to believe this will help. You just have to be willing to listen.

You're here. That's enough.

---

## CHAPTER 1: The Empty Feeling
### Phase: INTRODUCE — Hook + Recognition

You're not lazy.

I know it feels that way. I know everyone's probably been telling you to try harder, care more, put in effort. And you're sitting there thinking: I literally can't. There's nothing left.

That's not laziness. That's being empty.

Here's what burnout actually feels like when you're young:

**Everything feels like too much.** Homework that used to take an hour feels impossible. Getting out of bed is hard. Even fun things feel exhausting before you start them.

**You don't care about stuff you used to care about.** The things that made you excited? They don't anymore. You go through the motions but the feeling isn't there.

**You're tired in a weird way.** Not just sleepy. Like your whole self is tired. Your body, your brain, your feelings—all of it. And sleep doesn't really fix it.

**Small things make you really upset.** Someone says something annoying and you want to explode. Your sibling does something small and you lose it. Your fuse is super short.

**You feel kind of numb.** Like there's a wall between you and your feelings. You know you should feel things but you... don't. Or you feel them far away.

**You just want to escape.** Into your phone. Into games. Into sleep. Into anything that isn't your actual life. Not because those things are so great—because your life feels like too much.

If this sounds like you, you're not broken. You're burned out.

And burnout isn't about being weak. It's about having more stuff coming at you than anyone could handle. School. Activities. Social drama. Family expectations. Social media. Being compared to everyone all the time.

That's a lot. That's more than kids had to deal with even ten years ago.

Your body is responding to all of that by shutting down a little. It's not a flaw—it's protection. Your system is saying: too much. Need a break.

The problem is, the world doesn't give you a break. School keeps going. Expectations stay high. The stuff keeps coming.

So you feel stuck. Empty but still expected to perform.

You didn't choose this. You didn't fail your way into feeling like this. You just hit a wall that a lot of people hit.

Let's figure out what to do about it.

---

## CHAPTER 2: How You Got Here
### Phase: INTRODUCE — Validation + Origin Story

This didn't happen overnight. It built up over time.

Let me guess how it probably went:

**It started with being good at stuff.** You were capable. Smart. Talented. People noticed. They gave you more things to do because you could handle it.

**More became normal.** What started as extra became expected. Advanced classes. Multiple activities. More responsibility. The bar kept rising because you kept clearing it.

**Rest started feeling like falling behind.** When you weren't doing something, it felt wrong. Like everyone else was getting ahead while you were wasting time. So you kept going.

**School got more intense.** More homework. More tests. More projects. More pressure about grades and your future—even though you're still a kid.

**Social stuff got complicated.** Friendships became drama. Social media made you feel like everyone was watching, judging, comparing. You had to manage your reputation all the time.

**Your phone never lets you rest.** Notifications. Messages. Streaks to maintain. Content that makes you feel behind. Even "relaxing" on your phone isn't really relaxing.

**Adults kept adding expectations.** Do better in school. Try harder at your sport. Be nicer to your sibling. Help out more at home. Every adult in your life wants something from you.

And somewhere in there, the tank ran out.

Not all at once. Slowly. You kept giving—energy, effort, attention—without getting enough back. The math stopped working.

Here's what I want you to understand: **this isn't your fault.**

You didn't do anything wrong. You're living in a world that asks way too much from kids. The pressure is higher than it's ever been. The comparison is constant. The expectations are unrealistic.

Your body is responding reasonably to unreasonable demands.

The question isn't "why are you burned out?"—because honestly, why wouldn't you be?

The question is: what helps?

---

## CHAPTER 3: What's Actually Happening
### Phase: DEEPEN — Full Pattern Exposure

Let's talk about what's going on inside you when you feel this way.

Your body has something called a stress response. It's designed to help you deal with hard stuff. When something stressful happens, your body releases chemicals that make you alert and ready to handle it.

This is great for real emergencies. If something dangerous is happening, your body gets you ready to deal.

But here's the problem: **your body can't tell the difference between real danger and regular life stress.**

A test you're worried about? Your body reacts like it's a threat.

Social drama? Threat.

Parents disappointed? Threat.

Not enough likes on a post? Your body might actually react like it's dangerous.

When this happens over and over, day after day, your stress system gets exhausted. It's like it's been running at full speed for so long that it can't anymore.

That's burnout.

Here's what it looks like inside:

**Your energy system is drained.** Think of it like a battery. You've been using more energy than you're charging. Now the battery is almost dead, and everything takes more effort than it should.

**Your motivation system is offline.** The part of your brain that makes things feel exciting or worth doing? It's tired. That's why nothing sounds fun anymore. It's not that things aren't fun—it's that the part of you that feels fun is worn out.

**Your emotion system is protecting itself.** The numbness you feel? That's your brain turning down the volume on feelings because feelings take energy you don't have. It's not that you're cold or broken—you're in power-saving mode.

**Your thinking is foggy.** When you're burned out, your brain doesn't work as well. Concentrating is harder. Memory is worse. Everything takes more effort.

This is real. It's not just being tired or dramatic. It's what happens when your system has been running too hard for too long.

The good news: it's reversible. Your battery can recharge. But it needs the right conditions.

---

## CHAPTER 4: What Happens If Nothing Changes
### Phase: DEEPEN — Cost Accounting

I'm not trying to scare you. But I want you to understand why this matters.

If you stay burned out without doing anything about it, stuff gets harder:

**School gets worse, not better.** When you're burned out, your brain doesn't work as well. Trying harder doesn't help—your system is running on empty. You can't perform your way out of burnout.

**Friendships get harder.** When you're empty, you have less to give. You might get more irritable, more withdrawn. Friends notice, even if they don't say anything.

**Your body starts to feel it.** Headaches. Stomach problems. Getting sick more often. Trouble sleeping even when you're exhausted. Your body keeps score.

**Fun stops being fun.** The things you used to enjoy don't hit the same. You go through the motions but the feeling isn't there. Life gets gray.

**Your feelings might get darker.** Burnout can lead to feeling really sad or hopeless. Not always—but it can. The emptiness can deepen into something heavier.

Here's what I've seen happen to people who ignore burnout:

They crash. Eventually the body says "no more" and something breaks. Getting sick. Falling apart emotionally. Not being able to function.

Or they get numb and stay numb. They go through the motions of life but they're not really there. They survive but they stop living.

Or they burn out worse later. The pattern of pushing through burnout gets reinforced. They grow up thinking this is normal. And then they really crash as adults.

None of that has to happen. Because you're here, paying attention. That means you can do something different.

---

## CHAPTER 5: The Main Thing to Understand
### Phase: DEEPEN — Core Thesis + Reframe

Here's the most important thing I'm going to tell you:

**You can't try-harder your way out of burnout.**

When you're empty, working harder just empties you more. It's like trying to drive a car with no gas by pressing the pedal harder. It doesn't work. The tank is empty.

What you need isn't more effort. It's refueling.

Here's the shift:

You've been giving a lot. Energy, effort, attention, caring—all flowing out of you toward school, activities, social stuff, family expectations.

Recovery means reversing that. Letting stuff flow IN instead of always OUT.

This sounds simple. It's not. Because everything in your life is probably set up to keep taking from you. School wants more. Parents want more. Friends want more. Your phone wants more.

Learning to receive instead of just give? That's a skill. One most people never learn.

Here's what receiving looks like:

**Rest that actually rests.** Not scrolling on your phone—that still takes energy. Real rest. Lying down. Doing nothing. Being bored. Letting your brain have nothing to do.

**Fun that actually fills you.** Not distracting yourself—actually enjoying something. Whatever that is for you. It might be different than it used to be.

**Connection that gives instead of takes.** Being with people who make you feel better, not worse. People you can be real with. Even if it's just one person.

**Saying no sometimes.** Not to everything—but to some things. Protecting your energy instead of giving it all away.

This might feel selfish. It's not. You can't give what you don't have. Taking care of yourself is what makes you able to do anything else.

The world will keep asking for more. Your job is to make sure you have something to give.

---

## CHAPTER 6: Small Refuels
### Phase: TEST — First Practices

Let's get practical. Here are three things you can actually do:

**Practice 1: The Real Break**

Once a day, take a real break. Not phone-scrolling. Not doing something productive. A real break.

Ten minutes. Maybe more if you can.

Lie down. Stare at the ceiling. Go outside and just stand there. Let yourself be bored.

Your brain needs time with nothing to do. That's when it recovers. If you're always giving it input—even fun input—it never gets to rest.

This will feel weird. You might feel like you should be doing something. That's the burnout talking. Practice doing nothing anyway.

**Practice 2: One Thing That Actually Fills You**

Figure out one thing that actually makes you feel better. Not just distracted—better.

Maybe it's drawing. Playing with a pet. A certain kind of music. Being outside. A specific friend.

Do that thing on purpose. Not as a reward for finishing work. Just because it helps you.

This isn't a treat. It's medicine. Your tank is empty and this is fuel.

**Practice 3: The Done List**

At the end of each day, write down what you actually did. Not what you didn't finish. What you did.

Got through school. Did some homework. Talked to a friend. Ate food. Whatever.

When you're burned out, you only see what you're not doing. The Done List helps you see that you're actually doing a lot. Even existing when you're exhausted is doing something.

These are small things. They're supposed to be. When you're empty, you can't handle big changes. Small refuels, regularly, is how the tank fills up.

---

## CHAPTER 7: Protecting Your Energy
### Phase: TEST — Deeper Practice

You can't fill a tank that's still leaking. Let's talk about protecting your energy.

**Notice what drains you most.**

Not everything is equally tiring. Some classes are worse than others. Some people take more than they give. Some activities leave you more exhausted than others.

Pay attention. What specifically empties you fastest?

Once you know, you can start protecting yourself. Maybe you can't avoid everything draining—but you can avoid some things. Or prepare for them. Or recover after them.

**Practice saying "I can't right now."**

You don't have to say yes to everything. I know it feels like you do. But you have some choices.

When someone asks for something and you're empty, try: "I can't right now."

You don't have to explain. You don't have to have a good reason. "I can't right now" is complete.

This will feel uncomfortable. People might push back. It's still okay to say it.

**Limit the energy vampires.**

Some people drain you. You know who they are. The friend who's always in crisis. The person who makes everything about them. The drama magnet.

You don't have to cut these people off completely. But you can limit how much time you spend with them when you're empty.

**Create phone boundaries.**

Your phone is designed to take your attention. That's literally what it's built to do. When you're burned out, you probably don't have attention to spare.

Consider: certain times with no phone. Notifications off sometimes. Unfollowing accounts that make you feel bad.

Not forever. Not perfectly. Just some boundaries so the phone isn't draining you constantly.

---

## CHAPTER 8: When Everything Feels Impossible
### Phase: TEST — High Intensity Moments

Some days are worse than others. Let's talk about the really hard ones.

**When you can't get out of bed:**

Start smaller. Can you sit up? Just sit up. Can you put your feet on the floor? Just that.

You don't have to go from lying down to fully functioning. You just have to do the next tiny thing.

**When you have to do something but you can't:**

Break it into the smallest possible pieces. Not "do homework"—"open the notebook." Not "write the essay"—"write one sentence."

One tiny piece at a time. That's all.

**When everyone wants something from you:**

Pick one thing. The most important or urgent thing. Everything else waits.

You can't do everything when you're empty. Trying to makes it worse. Pick one thing, do that, then see what's next.

**When you just want to disappear:**

That feeling makes sense. It's your brain saying "I need an escape." That's valid.

Find a safe way to escape temporarily. Your room. A bath. A walk. Headphones and music. Something that isn't destructive but gives you a break from everything.

**When you feel like you're failing at life:**

You're not failing. You're burned out. Those are different things.

A phone with a dead battery isn't a bad phone. It just needs charging. Same with you.

---

## CHAPTER 9: The Complicated Truth
### Phase: COMPLICATE — Paradox + Non-Linear Progress

Here's where I have to be honest about something:

**Recovery isn't a straight line.**

Some days you'll feel better. You'll think you're figuring it out.

Then you'll have a terrible day and feel just as empty as before. Maybe worse.

That's normal. That's how it works. Two steps forward, one step back—sometimes two steps back.

The overall direction matters more than any single day.

**The stuff causing burnout probably won't change.**

School isn't going to get easier because you're burned out. Your parents probably won't lower their expectations. Social media won't become less intense.

You have to recover while still dealing with the stuff that burned you out. That's harder than recovering in perfect conditions. But it's the only option most of us have.

**You might not go back to exactly how you were before.**

The version of you that had endless energy and cared about everything? That might not fully come back. Or it might come back different.

What you get instead is someone who knows their limits. Someone who protects their energy. Someone who's been through something and learned from it.

That's not worse—it's just different.

**AND this is still worth doing.**

Even with all that—the non-linear progress, the ongoing demands, the fact that you might change—it's still worth trying to recover.

Because staying burned out leads somewhere bad. And doing something about it leads somewhere better. Even if "better" isn't perfect.

---

## CHAPTER 10: When You Empty Out Again
### Phase: INTEGRATE — Handling Setbacks

You're going to have setbacks. Here's how to handle them.

A setback looks like this: you were doing better, feeling a bit more human. Then something happened—a stressful week, a bad fight, too much piling up—and you're back to empty.

You'll think: I'm right back where I started.

You're not. Here's why:

**You know what's happening now.**

Before, you were just empty and confused about it. Now you know: this is burnout. It happens. It doesn't mean you're broken.

That understanding doesn't prevent setbacks, but it helps you move through them faster.

**Figure out what triggered it.**

What happened? Too much at once? Not enough sleep? A specific thing that pushed you over?

Not to blame yourself—to learn. If you know what triggered it, you can watch out for it next time.

**Go back to basics.**

When you're in setback, don't try to do everything at once. Pick one thing that helps. The real break. The thing that fills you. The done list.

Just one. Let that be your anchor.

**It gets faster.**

Early on, setbacks might last weeks. Later, they might last days. Eventually you might have a bad day and bounce back the next one.

That shortening time is progress, even if it doesn't feel like it.

---

## CHAPTER 11: Who You're Becoming
### Phase: INTEGRATE — Identity Shift

Something is changing in you.

You might not notice because you're in the middle of it. But you're not the same as when you started.

**You understand yourself better.**

You know what burnout is now. You know what empties you and what fills you. That's information you'll have forever.

**You're learning to take care of yourself.**

Taking real breaks. Doing things that help. Saying no sometimes. These are skills most adults don't have. You're learning them now.

**You know your limits.**

Not in a bad way—in a protective way. You know you can't give endlessly. You know you need to refuel. That knowledge protects you.

**You're still you.**

The things that matter to you still matter. The people you love, you still love. The stuff you care about, you still care about.

Burnout put a fog over everything. The fog is lifting. What was always there is becoming visible again.

**You're becoming someone who can last.**

The old way—give everything, run on empty, ignore the warning signs—that doesn't work long-term. You're learning a different way. One that lets you keep going.

---

## CHAPTER 12: What's Next
### Phase: INTEGRATE — Continuation + Closing

This isn't the end. It's more like a checkpoint.

You've learned what burnout is and why it happened. You have some tools. You know what to do when it gets bad.

But life keeps going. School doesn't stop. Expectations don't disappear. Stressful stuff keeps happening.

What's different now is you.

Here's what you carry forward:

**Understanding.** You know what's happening when you feel empty. That knowledge helps.

**Tools.** Real breaks. Things that fill you. Protecting your energy. Ways to handle the bad days.

**Self-knowledge.** You know yourself better. What drains you, what helps, what your limits are.

**Permission.** Permission to take care of yourself. Permission to say no sometimes. Permission to be a person with limits, not a robot with endless output.

There will be hard times ahead. Times when you're empty again. Times when everything feels like too much.

When those come, remember: you've been here before. You know what this is. You have tools. It's not permanent.

And remember this too:

**You're not lazy. You never were.**

Feeling empty doesn't mean you're not good enough. It means you're human, dealing with a lot.

**You deserve rest.** Not as a reward for working hard enough. Just because you're a person, and people need rest.

**You're going to be okay.** Not because everything will be easy. Because you're learning how to handle hard stuff in a way that doesn't destroy you.

Take care of yourself. Actually take care of yourself. Not the fake kind of self-care that's really just more doing. The real kind. Rest. Fun. Saying no. Being a person, not just a student or a kid or whatever role people want you to be.

You're enough. You've always been enough.

The world asks too much sometimes. That doesn't mean you're not enough.

You are.

---

## Conclusion

You made it through. That matters.

Not because you're fixed or perfect now. Because you showed up. You listened. You paid attention to yourself.

That's a lot more than most people do, honestly. Including most adults.

Here's what I want you to remember:

Burnout happens when you give more than you have. It's not weakness. It's math.

Recovery happens when you start receiving—rest, fun, care—instead of only giving.

Progress isn't perfect. You'll have setbacks. They don't erase what you've learned.

You're allowed to have limits. You're allowed to protect your energy. You're allowed to be a person, not just a performer.

When things get hard again—and they will—come back to what you've learned. Take a real break. Do something that fills you. Remember that empty doesn't mean broken.

You're going to be okay. Not because life will get easy. Because you're learning how to take care of yourself through the hard parts.

That's a skill that will help you forever.

Take care of yourself, okay?

You're worth taking care of.

---

**END OF GEN ALPHA BURNOUT BOOK**

**Word Count:** ~4,200 words
**Phase Structure Verification:**
- Ch 1-2: INTRODUCE (hook, recognition, validation, origin story) ✓
- Ch 3-5: DEEPEN (pattern exposure, cost, core thesis) ✓
- Ch 6-8: TEST (practices, protection, hard days) ✓
- Ch 9: COMPLICATE (paradox, non-linear, ongoing demands) ✓
- Ch 10-12: INTEGRATE (setbacks, identity shift, continuation) ✓

**Demographic Adaptations:**
- Shorter overall length (age-appropriate attention span)
- Simpler language (no jargon, shorter sentences)
- Age-appropriate examples (school, activities, social drama, parents, phone)
- "Battery" metaphor for energy system (relatable to digital natives)
- Social media specific (notifications, streaks, comparison)
- Warm older-friend voice (not parental, not peer)
- Practices scaled down (10 minutes, not 90)
- Less existential, more practical
- "You're not lazy" emphasis (common message they receive)
- Permission-giving throughout (you're allowed to have limits)
