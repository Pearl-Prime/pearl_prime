# Burnout: A Guide for Nurses and Healthcare Workers
## Complete Canonical Book — Phase-Correct Structure

**Word Count Target:** ~5,500 words
**Phase Structure:** Introduce (Ch 1-2) → Deepen (Ch 3-5) → Test (Ch 6-8) → Complicate (Ch 9) → Integrate (Ch 10-12)
**Core Sentence:** "I gave everything and there's nothing left."
**Demographic Adaptation:** Nurses and healthcare workers — compassion fatigue, patient care burden, shift work, systemic understaffing, moral injury
**Phenomenology:** Depletion, emotional exhaustion, numbness to suffering, loss of purpose, running on empty while others depend on you

---

## Pre-Introduction

Welcome to Burnout: A Guide for Nurses and Healthcare Workers.

This is a 360-minute audiobook about burnout.

Listen however makes sense for you. On the drive home after a shift. On your days off. In small pieces between everything else.

12 chapters. You control how you move through them.

No charting required. No one's tracking your compliance.

Just listen. Process however you process.

Ready when you are.

[Pause 3s]

---

## Introduction

I became a nurse because I wanted to help people.

That's probably why you did too. There was something in you that said: I want to be there when it matters. I want to make a difference. I want to care for people when they're at their most vulnerable.

And you did. You showed up. Shift after shift. Patient after patient. You gave everything you had—your skill, your time, your emotional presence—to people who needed you.

And somewhere along the way, the tank emptied.

Not all at once. Gradually. Until one day you realized you were going through the motions. Doing the tasks, hitting the metrics, keeping patients alive—but something essential was gone. The caring that brought you here had been replaced by numbness. Or worse, by resentment.

I thought something was wrong with me. I thought real nurses could handle this. I thought if I just tried harder, cared more, pushed through, I'd find my way back to why I started.

I didn't understand that the problem wasn't me. The problem was a system that extracts everything caregivers have to give and calls it "passion for the work."

The breakthrough came when I finally understood: burnout in healthcare isn't a personal failure. It's an occupational injury. You got hurt doing a job that asks the impossible. The wound is real, and it needs real healing.

That's what this book is. What I learned when I stopped blaming myself and started understanding what actually happened—and what actually helps.

You found this because something feels off. Maybe you dread going in. Maybe you've lost the ability to feel what you used to feel. Maybe you look at patients and feel nothing, and the guilt of that nothing is crushing.

Whatever brought you here matters. You found this for a reason.

This isn't about self-care tips or resilience training. This is about your nervous system—the actual system in your body that's been absorbing trauma, grief, and impossible demands for too long.

What's happening: burnout isn't happening because you don't care enough. It's happening because you cared too much, for too long, with too little support.

Nothing is fundamentally wrong with you.

The numbness isn't coldness. The exhaustion isn't weakness. The desire to leave isn't betrayal. These are your body's honest responses to an unsustainable situation.

This book helps you understand what's happening and what actually helps. Not another wellness module. What helps YOUR nervous system begin to recover while you figure out what comes next.

You don't have to believe this will work. You just have to be willing to be here.

You're here. That's enough.

---

## CHAPTER 1: The Empty Caregiver
### Phase: INTRODUCE — Hook + Recognition

You're not a bad nurse.

I need you to hear that first, because everything in your world has probably been telling you the opposite. The staffing ratios that make safe care impossible. The metrics that measure everything except what matters. The voice in your head that says: a real nurse could handle this.

A real nurse couldn't handle this. Nobody could. What's being asked is beyond human capacity.

Here's what healthcare burnout actually feels like:

You're physically present but emotionally gone. You do the assessments, give the meds, chart the notes. But you're not really there. The part of you that used to connect with patients has retreated somewhere you can't reach.

You feel guilty about the numbness. You remember when you used to feel things. When a patient's story moved you. When you cried in the supply closet after a death. Now you feel nothing, and you wonder what's wrong with you that death and suffering don't touch you anymore.

Compassion has become a performance. You say the right words. Make the appropriate face. Go through the motions of caring. But inside, you're calculating how long until the end of the shift.

You're exhausted in a way that days off don't fix. You sleep and wake up tired. Your days off are spent recovering enough to go back. The fatigue is bone-deep, and it doesn't respond to rest.

Small irritations have become unbearable. The call light that goes off again. The family member who wants an update. The coworker who doesn't pull their weight. Things you used to handle now push you to the edge.

You fantasize about escape. Calling in sick. Leaving the profession. Getting into your car and just driving somewhere else. Anywhere else.

You've thought about quitting more than once. Maybe you've even started looking. Or maybe you feel trapped—by loans, by the economy, by not knowing what else you would do.

If any of this sounds familiar, you're not failing. You're burned out.

And burnout in healthcare isn't about not being tough enough. It's about absorbing more trauma, death, suffering, and impossible demands than any nervous system can process. It's about giving care without receiving it. It's about a system that treats your compassion as an unlimited resource.

You didn't choose to feel this way. You got worn down by a job that grinds people down. You kept showing up until there was nothing left to show up with.

That's not weakness. That's depletion.

You're here now. That's the beginning.

---

## CHAPTER 2: How You Got Here
### Phase: INTRODUCE — Validation + Origin Story

Burnout didn't happen overnight. It accumulated.

Let me walk you through how it probably went:

It started with calling. You felt drawn to this work. Something about caring for people, being there when it mattered, making a difference. That wasn't naive—it was real. The calling was genuine.

And the work was hard, but it was meaningful. You could handle hard when it meant something. The exhaustion was worth it when you could see the impact.

But the system started extracting more. Staffing got tighter. Ratios got worse. Documentation requirements grew. More was expected with less support. The gap between what was needed and what was possible widened.

You filled the gap. That's what nurses do. You stayed late. You skipped lunches. You took on extra patients because someone had to. You absorbed the impossible because the alternative was patients going without care.

And nobody thanked you. Or they thanked you in ways that cost nothing—pizza parties, hero signs, appreciation weeks. While the ratios stayed dangerous and the support stayed absent.

You started absorbing trauma without processing it. Death became routine. Suffering became background noise. You didn't have time to process—there was always another patient, another crisis, another shift. So the trauma accumulated, unmetabolized, in your nervous system.

The pandemic broke something. Or maybe it just revealed what was already broken. You gave everything during the crisis. You risked your health, your family's health. You watched people die in ways that will stay with you forever. And then you were expected to just... keep going. Like it was normal.

You learned to suppress the caring. Because caring hurt too much. Every time you let yourself feel something for a patient, it cost you. And you didn't have enough left to pay that cost. So you numbed. It was protective. It was necessary. And it changed you.

Here's the thing: you didn't do anything wrong. You responded to impossible circumstances by doing the impossible. You adapted to a broken system by breaking yourself to fill the gaps.

The problem isn't you. The problem is a healthcare system that depends on burning out its workforce and calling it dedication.

The question now isn't: why am I burned out?

The question is: how do I recover when the system that depleted me is still demanding more?

---

## CHAPTER 3: What Healthcare Burnout Actually Is
### Phase: DEEPEN — Full Pattern Exposure

Let's get specific about what's happening in your body.

Healthcare burnout isn't just feeling tired. It's a combination of physical exhaustion, emotional depletion, and something called moral injury. Understanding all three matters.

**The physical exhaustion:**

Shift work destroys circadian rhythms. Your body never fully knows when to sleep and when to be alert. The night shifts, the rotating schedules, the 12-hour days—they create a chronic sleep debt that regular rest can't repay.

You're on your feet for hours. You're lifting patients, responding to emergencies, moving constantly. The physical demands alone would be depleting. Combined with everything else, they're crushing.

Your stress response never turns off. In healthcare, there's always a potential emergency. Your nervous system stays activated, ready for the code, the rapid response, the sudden deterioration. This chronic activation exhausts the system that's supposed to protect you.

**The emotional depletion:**

Compassion fatigue is real. It's the cost of caring for suffering people. Every patient's pain leaves a residue. Every death takes something. Over time, without replenishment, the capacity to feel empathy gets depleted.

You've absorbed more trauma than you realize. The deaths you've witnessed. The suffering you've tried to ease. The families you've held together. Each one left a mark. Accumulated, they've changed your nervous system.

The emotional labor is constant and invisible. You manage your own reactions while managing patients' and families' emotions. You stay calm when you're scared. You project confidence when you're uncertain. This performance costs energy that never gets counted.

**The moral injury:**

This might be the deepest wound. Moral injury happens when you're forced to act against your values—or prevented from acting according to them.

Every time you couldn't give a patient the care they needed because of staffing. Every time you had to rush through something that should have been done slowly. Every time you saw what should happen and couldn't make it happen.

These violations accumulate. They create a kind of soul wound—a betrayal of the reason you became a nurse in the first place.

Here's what this combination looks like:

**Depersonalization:** Patients become room numbers. You refer to "the hip in 302" instead of Mrs. Johnson who's scared about her surgery. This isn't cruelty—it's protection. But it signals deep burnout.

**Cynicism:** You used to believe the work mattered. Now you're not sure. The idealism that brought you here has been ground down by reality.

**Reduced accomplishment:** Nothing feels like enough. You could work a perfect shift and still feel like you failed someone. The gap between what you want to give and what you can give has become unbearable.

**Intrusive symptoms:** Flashbacks to bad outcomes. Dreams about work. Startling easily. These are signs that trauma has accumulated faster than you've been able to process it.

This is healthcare burnout. It's not a personal failure. It's an occupational injury inflicted by a system that demands too much while giving too little.

---

## CHAPTER 4: What Staying Depleted Costs
### Phase: DEEPEN — Cost Accounting

Let's talk about what happens if nothing changes.

I'm not saying this to guilt you. You've had enough guilt. I'm saying it because healthcare workers are trained to put themselves last, to minimize their own needs, to keep going regardless of cost.

But the costs are real. They're accumulating.

**Your health.** The research is clear: burned-out healthcare workers have higher rates of cardiovascular disease, depression, anxiety, substance use, and suicide. The job that was supposed to let you help with health is destroying yours.

**Your safety.** Fatigue causes errors. Cognitive impairment from burnout causes errors. You know this—you've probably caught yourself making mistakes you wouldn't have made when you were fully present. The next mistake might be one you don't catch.

**Your patients.** This is hard to hear, but it's true. Burned-out nurses provide different care than healthy ones. Not because you're a bad nurse—because burnout impairs the cognitive and emotional capacities that good care requires. Your patients deserve you at your best. They're not getting it.

**Your relationships.** The people you love get what's left after work takes its share. You're irritable at home. Distant. You don't have the energy for the connection you need. Your family has learned not to expect emotional availability from you.

**Your sense of self.** You became a nurse because of who you are. The caring, the desire to help, the ability to be present with suffering—these were core to your identity. Burnout erodes them. You're becoming someone you don't recognize.

**Your career.** You might leave. Many do—the turnover rates in nursing are evidence of systemic failure. But if you leave burned out, you take the burnout with you. It follows you into whatever comes next.

Here's what I've watched happen to healthcare workers who don't address burnout:

They make a serious error. The impairment catches up with them in a way that can't be ignored. The consequences are devastating—for the patient, for the nurse, for everyone.

Or they leave the profession. Sometimes this is the right choice. But often it's a reactive escape rather than a considered decision. They leave wounded, carrying the trauma into whatever comes next.

Or they stay and hollow out. They become the cynical, checked-out nurses they swore they'd never become. They do the minimum. They count the years until retirement. They survive, but they stopped being the nurse they wanted to be.

Or they have a breakdown. The accumulated trauma and exhaustion finally break through. A crisis. A collapse. Something that forces a reckoning that could have been gentler if it had come sooner.

You've probably seen these outcomes in colleagues. Maybe you've already started down one of these paths.

There's another option. It starts with acknowledging where you are.

---

## CHAPTER 5: The Core Truth About Recovery
### Phase: DEEPEN — Core Thesis + Reframe

Here's what the hospital's wellness program won't tell you:

You can't yoga your way out of this.

Resilience training doesn't fix dangerous staffing ratios. Mindfulness apps don't process accumulated trauma. Self-care doesn't compensate for a system designed to deplete you.

The wellness industry wants you to believe burnout is a personal problem with personal solutions. It's not. Burnout in healthcare is a systemic problem that happens to individual people.

And yet—you're the one living with it. The system should change, and also you can't wait for it to change. You need to recover while working within a system that's still trying to deplete you.

This is the bind: the burnout isn't your fault, but the recovery is your responsibility. Not because that's fair—it's not. But because you're the only one who can do it.

Here's what recovery actually requires:

**Acknowledging the injury.** Burnout isn't tiredness. It's injury. You got hurt doing this job. The wound is real. Treating it like something you should just push through makes it worse.

**Receiving care, not just giving it.** You've been outputting constantly. Care flowing out to patients, families, coworkers. Recovery requires reversing the flow. Letting care come in. Letting yourself receive.

**Processing what you've absorbed.** The trauma doesn't go away by itself. It's stored in your nervous system, waiting. Recovery means finding ways to let it move through—therapy, body work, grief rituals, whatever helps you actually process instead of just suppress.

**Protecting yourself from further injury.** You can't heal a wound while it's still being inflicted. Recovery requires boundaries—limits on what you give, what you absorb, what you take on. The system will resist these boundaries. Hold them anyway.

**Finding meaning again—or accepting it's changed.** The calling that brought you here might still be there, buried. Or it might have transformed into something different. Recovery includes figuring out what you're doing this for now.

Here's the hard truth: you might not be able to fully recover while staying in your current situation. The demands might be too high. The support might be too low. Full recovery might require changing something—your unit, your role, your relationship with this career.

That's not failure. That's information.

For now, you can start where you are. Small deposits. Small protections. Small recoveries. They add up.

---

## CHAPTER 6: Small Recoveries
### Phase: TEST — First Practices

Let's make this practical.

You don't have time for elaborate self-care routines. Your days off are for recovering enough to go back. Here are three practices designed for healthcare worker reality:

**Practice 1: The Shift Transition**

Before you go home, take five minutes to consciously leave work at work.

This might be in your car before you start driving. Or in the locker room. Or somewhere else that can become a threshold.

During these five minutes: acknowledge what happened this shift. Not analyze—acknowledge. Say to yourself (out loud if you can): "That was hard. I did what I could. I'm leaving it here."

Then imagine putting down a heavy bag. The patients, the problems, the system—put them down. You'll pick it back up next shift. But right now, you're not carrying it.

This creates separation. Without it, the shift bleeds into everything. The transition practice builds a boundary between work and not-work.

**Practice 2: The Receiving Practice**

Once a day, receive something. Not earn it. Not deserve it. Just receive it.

A cup of tea that someone else makes. A moment of kindness you let land. A compliment you don't deflect.

Healthcare workers are trained to give. Receiving feels selfish, indulgent, wrong. But your tank is empty because the flow only went one direction.

Practice receiving. One small thing a day. It doesn't have to be big—it has to be received. Let it in. Let it fill something.

**Practice 3: The Trauma Inventory**

Once a week, write down what you witnessed. Not a chart note—a human record.

"I was with Mr. Johnson when he died. His daughter wasn't there in time."

"I couldn't get to the call light for ten minutes because I was drowning."

"The admit from the ED was sicker than anyone told us. We almost lost them."

Just name what happened. You're not processing it yet—you're acknowledging it. Getting it out of your body and onto paper.

This prevents the accumulation from becoming invisible. It makes the weight real. And it's the first step toward actually processing what you've been carrying.

These practices are small. They're supposed to be. You're depleted—you can't handle big interventions right now. Small deposits, consistently, is how the tank starts to fill.

---

## CHAPTER 7: Protecting What's Left
### Phase: TEST — Deeper Practice

You can't fully recover while staying in situations that keep injuring you. But you can reduce the injury while you figure out your options.

**Identify your specific depletion patterns.**

Not all shifts are equally depleting. Not all patients, not all coworkers, not all situations.

What specifically empties you fastest? Is it certain types of patients? Is it being charge? Is it specific coworkers who take more than they give? Is it the documentation that feels pointless?

Get specific. The clearer you are about what depletes you, the more strategically you can protect yourself.

**Build micro-boundaries.**

You might not be able to change the staffing ratio. But you can change small things.

Can you take your break? Not "if things are slow"—actually take it. Sit down. Eat. Let your nervous system downregulate for fifteen minutes.

Can you stop volunteering for extra? The impulse to help is strong. But every extra shift, every picked-up patient, every "I'll handle it"—they're withdrawals from an empty account.

Can you limit emotional labor with certain people? The coworker who vents constantly. The family member who needs more than you have. You can be kind and also boundaried.

**Find the hidden restoratives.**

Some parts of the job might still fill you. A particular type of patient interaction. A coworker who supports instead of drains. A skill you still enjoy using.

Notice these. They're not just pleasant—they're survival. Lean into the parts of the job that restore when you can.

**Process incrementally.**

You have years of accumulated trauma. You can't process it all at once. But you can process some.

Therapy helps if you can access it. Specifically, trauma-informed therapy. Not just talking about work—actually processing the experiences stored in your body.

If therapy isn't available, find other outlets. Physical movement helps trauma move through. Crying helps—if you can still cry. Talking to someone who understands, not to vent, but to be witnessed.

**Consider what might need to change.**

While you're doing the daily survival work, also let yourself think about the bigger picture.

Is this unit sustainable? Is this hospital? Is bedside nursing?

You're not betraying the profession by asking these questions. You're being honest about what's working and what isn't.

Change is always an option. It's not always the right one, and it's not always available. But keeping it on the table makes the current situation a choice, not a trap.

---

## CHAPTER 8: When the Shift from Hell Happens
### Phase: TEST — High Intensity Moments

Some shifts are worse than others. Here's how to survive the bad ones without losing more of yourself.

**When you're drowning in the moment:**

The call lights are all going. You're behind on everything. Someone is declining and you can't get to them fast enough.

In that moment, you can only do one thing at a time. Pick the most critical. Do that. Then pick the next one.

You cannot do everything. You're not supposed to be able to. The staffing made this situation, not you. Do what you can. Let go of what you can't.

**When a patient outcome goes bad:**

You're going to lose patients. Some deaths will feel like failures—maybe they were preventable, maybe you missed something, maybe you'll never know.

After a bad outcome: don't immediately jump to self-blame. First, just sit with what happened. "That happened. It's terrible."

Later, you can review what was in your control and what wasn't. But in the immediate aftermath, just let it be terrible without deciding it was your fault.

**When the moral injury is acute:**

Sometimes you'll have to do something—or not do something—that violates your sense of what's right. You can't give the patient the time they need. You have to discharge someone who isn't ready. You can't advocate the way you want because you'll lose your job.

These moments wound. There's no way to make them not wound.

What helps: naming it. "This is wrong. I'm being forced to do something wrong because of circumstances beyond my control. It's not okay, and it's not my fault."

The naming doesn't fix it. But it keeps you from absorbing the guilt for a system's failure.

**When you're going to break down:**

Sometimes the wave comes up and you know you're going to lose it.

Find somewhere private. The bathroom. The supply closet. Somewhere.

Let it happen. The body needs to release what it's holding. Fighting it takes more energy than letting it move through.

Two minutes. Three minutes. Let it happen. Then wash your face, take a breath, and go back.

The breakdown doesn't mean you can't do this. It means you're human, carrying more than humans should carry. Let the pressure release when you can.

---

## CHAPTER 9: What Recovery Actually Looks Like
### Phase: COMPLICATE — Paradox + Non-Linear Progress

Here's where I need to complicate everything I've told you.

Recovery from healthcare burnout isn't linear. It's not a program you complete. It's messier and longer than you want it to be.

**You'll feel better, then a bad shift will wreck you.**

Some weeks you'll think: I'm coming back. I can feel things again.

Then you'll have a shift that destroys you. A death you couldn't prevent. A staffing situation that was dangerous. And you'll be back in the fog, wondering if you made any progress at all.

This is normal. Progress in burnout recovery is two steps forward, one step back—sometimes three steps back. The overall direction matters more than any single shift.

**The system isn't going to accommodate your recovery.**

The staffing ratios aren't going to improve because you're burned out. The demands aren't going to decrease. The trauma is going to keep happening.

You have to recover while still being exposed to the conditions that injured you. That's harder than recovering in a safe environment. But it's the only option most healthcare workers have.

**You can't process trauma you're still accumulating.**

Here's a cruel truth: you can do all the right things—therapy, practices, boundaries—and still be accumulating new trauma faster than you're processing old trauma.

If the exposure is too high, recovery isn't possible without changing the exposure. That might mean a different unit. A different role. A break from bedside care.

This isn't failure. It's math. If the inputs are still toxic, recovery has a ceiling.

**You might not get back to who you were.**

The nurse who started this career—idealistic, full of compassion, able to feel—might not be who you become.

What you might get instead is someone wiser. Someone with boundaries. Someone who can still care, but differently. Someone who's been through something and come out changed.

That's not loss—that's transformation. The new version might actually be more sustainable than the old one.

**AND this is still worth doing.**

All of that—the non-linear progress, the ongoing exposure, the transformation instead of restoration—and it's still worth doing.

Because the alternative is staying where you are. And you know where that leads. You've seen it in colleagues who gave up on recovery.

Imperfect recovery is better than no recovery. Changed is better than hollowed out.

---

## CHAPTER 10: When You Deplete Again
### Phase: INTEGRATE — Handling Setbacks

You will hit empty again. Here's how to handle it.

A setback looks like this: you were doing better. The fog was lifting. Then something happened—a terrible shift, a stretch of short-staffing, a patient that got to you—and you're back in the depletion.

And you think: I haven't learned anything. I'm just going to keep cycling through this.

Maybe. But probably not. Here's why:

**The depletion isn't the same as before.**

You have understanding now. You know what's happening, why it's happening, what helps. You're not confused about being a bad nurse—you know it's burnout.

That understanding doesn't prevent setbacks, but it changes how you move through them.

**Get curious about what happened.**

What triggered this setback? Was it a specific event? An accumulation? A boundary you dropped?

Not to blame yourself—to learn. If you can identify what pushed you back into depletion, you can protect against it next time.

**Return to one practice.**

When you're depleted again, don't try to do everything. Pick one practice. The shift transition. The receiving practice. Something.

Do that one thing. Let it be your anchor while you stabilize.

**Remember: recovery time shortens.**

Early in burnout recovery, setbacks might knock you down for weeks. Later, they might last days. Eventually, you might have a bad shift and recover by the next one.

That shortening recovery time is progress. Not perfect immunity—but faster bounce-back.

---

## CHAPTER 11: Who You're Becoming
### Phase: INTEGRATE — Identity Shift

Something is shifting.

It's hard to see when you're in the middle of it. But you're not the same nurse who started this book.

**You're practicing receiving.**

You used to only give. Care flowed out, never in. Now you're learning to let things in. Small things. Kindness. Rest. Help.

This is huge. It changes the entire equation of your life.

**You have boundaries now.**

Maybe they're not perfect. Maybe you still overextend sometimes. But you're more aware of your limits than you were. You protect yourself more than you did.

The nurse who said yes to everything is becoming the nurse who says yes to what she can actually do.

**You're processing instead of just suppressing.**

The trauma inventory. The therapy if you're doing it. The crying in the supply closet. These aren't breakdowns—they're processing.

You're not just accumulating anymore. You're starting to move things through.

**You see the system more clearly.**

You used to think burnout was your failure. Now you see it's a system designed to extract everything caregivers have.

That clarity is protection. It's harder to blame yourself when you can see what's actually happening.

**You're making more conscious choices.**

Whether to stay. Whether to change units. Whether this career is sustainable for you.

You're not trapped—even if options are limited. You're choosing, day by day, with more information than you had before.

**The caring is still there.**

Buried, maybe. Different than before. But still there.

You haven't become the cold nurse you were afraid of becoming. You've become a nurse who protects herself so she can keep caring. That's different.

---

## CHAPTER 12: What Comes Next
### Phase: INTEGRATE — Continuation + Closing

This isn't an ending. It's a checkpoint.

You've traveled through something. Through understanding what burnout is, why it happened, how the injury works. Through practices that help you survive and start to recover. Through the hard truth that the system isn't going to save you.

You're not done. The job keeps demanding. The trauma keeps happening.

But you're different now. You carry something you didn't have before.

Here's what you carry:

**Understanding.** You know what burnout is—not weakness, not failure, but occupational injury. You know the biology of it, the morality injury, the compassion fatigue. That understanding protects you from shame.

**Practices.** You have tools. The shift transition. The receiving practice. The trauma inventory. Small deposits that add up.

**Boundaries.** You're learning to protect yourself. Not perfectly—but more than before. The boundaries are forming.

**Community.** You're not alone in this. Other nurses are struggling. Some are in recovery. Some have found ways to stay and stay human. You're part of something.

**Options.** You might stay. You might change units. You might leave bedside care. You might leave nursing. All of these are legitimate choices. You get to make them.

There will be hard shifts. Shifts that deplete everything you've rebuilt. Shifts that make you wonder why you do this.

On those days, remember: you've been here before. You got through it before. The practices are still there. The understanding doesn't disappear.

And remember this:

You became a nurse because something in you wanted to help people.

That something is still there. Wounded, maybe. Changed, certainly. But still there.

The system tried to use that caring against you—extracting it until you were empty. But the caring itself wasn't the problem. The problem was a system that takes without giving back.

You're learning to give AND receive now. To care for others AND care for yourself. To be a nurse AND be a human with limits.

That's the sustainable path. The one that lets you keep going—if you choose to keep going—without destroying yourself.

Whatever you decide about your future in healthcare, you get to make that decision from recovery instead of collapse. From clarity instead of desperation. From something closer to fullness instead of complete depletion.

Take care of yourself. Actually take care of yourself. Not the way you take care of others—the way you need to be taken care of.

You deserve it. Not because you've earned it through suffering. Because you're a person, and people need care.

That includes you.

You're enough. You've always been enough.

The system asked for too much. That doesn't mean you weren't enough.

You were always enough.

---

## Conclusion

You made it here. That matters.

Not because you're healed or fixed. Because you showed up. Through every chapter. Through the parts that described your life too accurately. That's the work.

By now, you understand that healthcare burnout isn't a personal failure. It's an occupational injury inflicted by a system designed to extract everything caregivers have.

Your nervous system was telling you the truth. The numbness was protection. The exhaustion was information. The desire to escape was rational.

Recovery isn't about becoming the nurse you were before. That nurse didn't know what you know now. Recovery is about becoming a nurse—or a person—who can sustain. Who can care without being destroyed by caring.

That person is available. Not easily. Not quickly. But available.

When the depletion returns—and it will—you'll know what you're dealing with. You'll have practices. You'll have understanding. You'll have the ability to name what's happening instead of just drowning in it.

Remember:

The system wants to keep extracting. That's what systems do.

But you're not an infinite resource. You're a person. And people need to receive, not just give.

Practice receiving. Process what you've absorbed. Protect what's left.

And give yourself permission to make whatever choice you need to make about your future—staying, changing, leaving. All of them are legitimate. All of them can be right.

Take care of yourself. The way you'd take care of a patient who was burned out. With compassion. With appropriate interventions. With realistic expectations.

You deserve that care.

You've always deserved it.

---

**END OF RN/HEALTHCARE WORKER BURNOUT BOOK**

**Word Count:** ~5,600 words
**Phase Structure Verification:**
- Ch 1-2: INTRODUCE (hook, recognition, validation, origin story) ✓
- Ch 3-5: DEEPEN (pattern exposure, cost, core thesis) ✓
- Ch 6-8: TEST (practices, protection, bad shifts) ✓
- Ch 9: COMPLICATE (paradox, non-linear, accumulating faster than processing) ✓
- Ch 10-12: INTEGRATE (setbacks, identity shift, continuation) ✓

**Demographic Adaptations from Gen Z version:**
- Compassion fatigue and moral injury framing
- Patient care burden and "giving care without receiving" language
- Shift work reality (12-hour shifts, rotating schedules, breaks that don't happen)
- Systemic issues (staffing ratios, understaffing, dangerous conditions)
- Healthcare-specific practices (shift transition, trauma inventory)
- Depersonalization and numbness as protective mechanisms
- Career decision framing (stay, change units, leave bedside, leave nursing)
- Pandemic trauma acknowledgment
- Patient safety connection (burnout affects care quality)
