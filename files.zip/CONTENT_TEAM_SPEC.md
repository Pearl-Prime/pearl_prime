# CONTENT TEAM SPEC — "600 Therapeutic Seeds, Full Coverage" (FINAL)
## LA Gen Alpha Therapeutic Audiobook System

**Project:** SOURCE_OF_TRUTH Therapeutic Audiobook Platform  
**Phase 1 Goal:** 600 base seeds → 1,200,000+ unique personalized audiobooks via variable hydration

---

## Purpose (why this exists)

The goal is to ensure **every LA Gen Alpha teen can receive a fully personalized therapeutic audiobook with zero generic fallback**.

When content work is complete:
* Any region can be selected (SGV/626, Westside/Beach, Valley)
* Any pain point can be addressed
* Any writing style can be applied
* **No generic or system content is ever substituted**
* If content is missing, the system blocks the build

This spec defines **exactly what content must exist**, **where it lives**, and **how to produce it**.

---

## 1. Canonical writing style definition (MANDATORY)

### 1.1 Style Registry Entry

**File**
```
SOURCE_OF_TRUTH/data/styles/registry.yaml
```

**Content team responsibility**
* Add a registry entry for every writing style
* This is the style's "license to generate content"

**Required fields**
```yaml
style_id: phoenix_foundation
display_name: "Phoenix Foundation"
pack: phoenix_rising
status: active
supported_regions:
  - sgv_626
  - westside_beach
  - valley
supported_personas:
  - gen_alpha_10_12
  - gen_alpha_13_15
supported_pain_categories:
  - social_rejection
  - academic_pressure
  - family_conflict
  - digital_shame
therapeutic_framework:
  primary: trauma_informed
  approaches: [somatic, narrative, compassion_focused]
tone: gentle_building
voice_characteristics:
  - hope_focused
  - rising_from_ashes
  - strength_through_struggle
```

**Rule**
> If a style is missing from the registry, it does not exist to the system.

---

## 2. Style doctrine authoring (MANDATORY, PER PAIN CATEGORY)

Doctrine defines **style uniqueness and therapeutic approach**.  
Without doctrine, seeds cannot exist.

### 2.1 File location
```
SOURCE_OF_TRUTH/data/styles/<style_id>/doctrine/<pain_category>.yaml
```

### 2.2 Required doctrine fields
```yaml
style_id: phoenix_foundation
pain_category: social_rejection
signature_approach:
  name: "Rising Through Connection Loss"
  description: "Gentle acknowledgment that rejection is a form of death, and you are already beginning to rise from it."
  
therapeutic_reframe: "Social rejection is not evidence of your unworthiness—it's a painful experience you're surviving right now."

identity_shift:
  from: "I'm broken and everyone can see it."
  to: "I'm hurt, and I'm learning to rebuild in ways that honor what I've been through."

core_metaphor: "phoenix_rising_from_ashes"

language_preferences:
  preferred:
    - rising
    - rebuilding
    - strength_in_your_bones
    - survived_this_before
  forbidden:
    - everything_happens_for_a_reason
    - just_stay_positive
    - it_could_be_worse
    - they_weren't_real_friends

validation_approach: "Name the pain, acknowledge the survival, point toward rebuilding without rushing"

hope_mechanism: "You have risen before, even if you don't remember. Your body knows how."

therapeutic_framework:
  primary: trauma_informed
  secondary: somatic_awareness
  avoids: toxic_positivity
```

### 2.3 Content rules
* Third-person narrative only (not instructional)
* No minimizing language
* No toxic positivity
* Must clearly distinguish this style from others addressing same pain
* Must validate pain before offering hope
* Must be age-appropriate for 10-15 year olds

**Checklist per pain category**
* [ ] signature_approach defined
* [ ] therapeutic_reframe stated
* [ ] identity_shift clear
* [ ] language preferences documented
* [ ] validation approach explicit
* [ ] hope mechanism defined

---

## 3. Therapeutic story seeds (MANDATORY, CORE WORK)

Story seeds are the **largest content workload**.

### 3.1 File location
```
SOURCE_OF_TRUTH/data/seed_banks/<style_id>/seeds/*.json
```

### 3.2 Minimum seed coverage (per pain category)

For **full coverage system**, content team must deliver:

| Pain Category       | Seeds per Region | Total Seeds |
|---------------------|------------------|-------------|
| social_rejection    | 15 per region    | 45          |
| academic_pressure   | 15 per region    | 45          |
| family_conflict     | 15 per region    | 45          |
| digital_shame       | 12 per region    | 36          |
| autonomy_lack       | 12 per region    | 36          |
| body_image          | 10 per region    | 30          |
| overwhelm           | 10 per region    | 30          |
| loneliness          | 10 per region    | 30          |

**Region-specific additions:**
- SGV/626: boba_social_failure (15), academic_sgv (15), cultural_identity_conflict (15)
- Westside/Beach: beach_culture_failure (12), tourist_adjacent_shame (10), affluence_pressure (10)
- Valley: heat_isolation (10), car_dependency_failure (10), in_n_out_culture (8)

👉 **Phase 1 Target: 600 seeds total**  
👉 **Each seed generates 2000+ unique variants via variable hydration**

---

### 3.3 Seed JSON schema (authoring contract)

```json
{
  "seed_id": "phoenix_foundation_sgv_social_rejection_001",
  "style_id": "phoenix_foundation",
  "region": "sgv_626",
  "pain_category": "social_rejection",
  "specific_pain_point": "boba_shop_rejected_by_group",
  "title": "When the Group Chat Goes Silent",
  "intensity": "medium",
  "persona_tags": ["gen_alpha_13_15", "sgv_626", "boba_culture"],
  
  "base_narrative": {
    "word_count": 147,
    "text": "You check your phone for the third time. The group chat that was exploding with boba plans an hour ago has gone completely silent. Then you see it—the Instagram story. {friend_group} is already at {boba_shop}, drinks in hand, someone's doing the {signature_drink} reveal. Nobody told you the plans changed.\n\nYour stomach drops. This isn't the first time. Last week it was the {event_location}. Before that, the study session at {secondary_location}. Each time, you found out through someone's story, watching your friends live a life that somehow doesn't include you anymore.\n\nHere's what nobody tells you about being left out: your body remembers every single time. The tightness in your chest right now? That's not weakness. That's your system trying to protect you from a pain it recognizes.\n\nBut here's something else your body knows—you've survived being left out before. When you were {age_younger}, when {past_exclusion_memory}. You rebuilt then. Different friends, different places, but you rebuilt.\n\nThe group chat might stay silent tonight. That's their choice. But tomorrow, you get to choose too. You get to decide if you keep waiting for people who don't show up, or if you start building something different.\n\nYou're not broken because they forgot you. You're just learning who actually remembers."
  },
  
  "variable_points": [
    {
      "variable": "friend_group",
      "type": "persona_extraction",
      "source": "persona.friend_group_names",
      "fallback": "your friend group"
    },
    {
      "variable": "boba_shop",
      "type": "location_library",
      "source": "region.sgv_626.boba_shops",
      "filter": "persona.favorite_boba_shop != value",
      "example": "Half & Half"
    },
    {
      "variable": "signature_drink",
      "type": "cultural_detail",
      "source": "region.sgv_626.boba_culture.signature_drinks",
      "example": "hot honey boba torch"
    },
    {
      "variable": "event_location",
      "type": "location_library",
      "source": "region.sgv_626.social_hubs",
      "example": "626 Night Market"
    },
    {
      "variable": "secondary_location",
      "type": "location_library",
      "source": "region.sgv_626.study_locations",
      "example": "Factory Tea Bar"
    },
    {
      "variable": "age_younger",
      "type": "persona_calculation",
      "formula": "persona.age - 3",
      "example": "10"
    },
    {
      "variable": "past_exclusion_memory",
      "type": "generated_snippet",
      "source": "persona.early_childhood_exclusion_type",
      "example": "you weren't invited to someone's birthday party and you cried in your room for hours"
    }
  ],
  
  "therapeutic_elements": {
    "validation_present": true,
    "validation_quote": "your body remembers every single time. The tightness in your chest right now? That's not weakness.",
    "hope_present": true,
    "hope_quote": "You're not broken because they forgot you. You're just learning who actually remembers.",
    "agency_emphasized": true,
    "agency_quote": "tomorrow, you get to choose too",
    "somatic_awareness": true,
    "somatic_quote": "The tightness in your chest right now? That's your system trying to protect you",
    "no_toxic_positivity": true
  },
  
  "quality_checks": {
    "location_authenticity": true,
    "age_appropriate": true,
    "culturally_specific": true,
    "doctrine_aligned": true,
    "word_count_target": "145-150 words"
  },
  
  "audio_metadata": {
    "target_duration_seconds": "60-75",
    "voice_tone": "gentle_steady",
    "pacing": "moderate_with_pauses",
    "emphasis_points": [
      "your body remembers",
      "you've survived being left out before",
      "you're not broken"
    ]
  }
}
```

---

### 3.4 Authoring rules (VERY IMPORTANT)

* Must **explicitly reflect the doctrine signature approach**
* Must be **third-person narrative only** (not instructional "you should do X")
* Must use **real location names** from location libraries
* Must not sound generic—must be **culturally and geographically specific**
* Must validate pain before offering hope
* Must avoid toxic positivity language
* Must include somatic awareness (body sensations)
* Target 147 words (60-75 seconds audio)
* Must include 8-12 variable hydration points

**Validator will FAIL if:**
* Signature approach is not reflected
* Language contradicts doctrine
* Generic locations used instead of real places
* Toxic positivity detected
* Word count outside 140-155 range
* Fewer than 8 variable points
* No somatic reference
* Hope without validation

---

## 4. Variable hydration system (CRITICAL)

### 4.1 Variable types and sources

```yaml
variable_types:
  
  persona_extraction:
    description: "Pull directly from persona data"
    examples:
      - persona.name
      - persona.age
      - persona.friend_group_names
      - persona.primary_hangout
      - persona.favorite_boba_shop
  
  location_library:
    description: "Pull from region-specific location database"
    examples:
      - region.sgv_626.boba_shops
      - region.westside_beach.beaches
      - region.valley.malls
    filters:
      - not_equal_to_persona_favorite
      - different_from_previous
      - intensity_appropriate
  
  cultural_detail:
    description: "Region-specific cultural markers"
    examples:
      - region.sgv_626.boba_culture.signature_drinks
      - region.westside_beach.volleyball_culture.terms
      - region.valley.in_n_out.secret_menu_items
  
  persona_calculation:
    description: "Dynamic calculations from persona data"
    examples:
      - formula: "persona.age - 3"
      - formula: "persona.current_grade - 2"
  
  generated_snippet:
    description: "Mini-narratives generated from persona patterns"
    examples:
      - persona.early_childhood_exclusion_type
      - persona.family_conflict_pattern
      - persona.academic_failure_memory
  
  consequence_specific:
    description: "Pull from consequence taxonomy"
    examples:
      - consequences.social_rejection.peer_level
      - consequences.academic_pressure.psychological
```

### 4.2 Variable authoring rules

**Each variable must specify:**
* Variable name (used in {brackets})
* Type (from above taxonomy)
* Source (specific data path)
* Filters (optional, for exclusions)
* Example value (for validation)
* Fallback (if data unavailable)

**Quality standard:**
> A seed with good variable points can generate 2000+ unique variants while maintaining narrative coherence and therapeutic integrity.

---

## 5. Region-specific content requirements

### 5.1 SGV/626 seeds MUST include:
* Real boba shop names (Half & Half, Chi Cha San Chen, 7 Leaves, etc.)
* Valley Blvd traffic references when relevant
* Academic pressure cultural context (cram school, cousin comparison, A- as failure)
* Bilingual/code-switching tension where appropriate
* 626 Night Market as major social event
* Dim sum Sunday family obligation conflicts

### 5.2 Westside/Beach seeds MUST include:
* Real beach/pier names (Santa Monica Pier, Venice Boardwalk, Manhattan Beach)
* Shopping district names (Third Street Promenade, Abbot Kinney, Century City)
* Beach body/volleyball culture pressure
* Tourist-adjacent life experiences
* Economic inequality markers (can't afford Third Street stores)
* Outdoor/active lifestyle expectations

### 5.3 Valley seeds MUST include:
* Real mall names (Westfield Topanga, Sherman Oaks Galleria, Fashion Square)
* Heat isolation experiences (110+ degrees summer)
* Universal CityWalk as major destination
* In-N-Out culture (secret menu, Animal Style)
* Car dependency extremity (no walkable destinations)
* Studio City Ventura Blvd, NoHo Arts District when relevant
* Valley vs "over the hill" identity tension

### 5.4 Authenticity validator checklist:
* [ ] Location names are REAL (from location libraries)
* [ ] Cultural details match region
* [ ] Economic reality respected
* [ ] Geographic challenges accurate (heat, traffic, tourist crowds)
* [ ] No location transplanting (626 Night Market can't be in Westside seed)

---

## 6. Therapeutic framework compliance (MANDATORY)

### 6.1 Every seed must demonstrate:

**Trauma-informed approach:**
* Validate the pain before offering hope
* Acknowledge body's stress response
* No "snap out of it" language
* Respect that healing isn't linear

**Somatic awareness:**
* Reference physical sensations (chest tightness, stomach drop, etc.)
* Connect emotions to body experience
* Normalize physiological stress responses

**No toxic positivity:**
* ❌ "Everything happens for a reason"
* ❌ "Just stay positive"
* ❌ "It could be worse"
* ❌ "They weren't real friends anyway"
* ❌ "You're better off without them"

**Agency emphasis:**
* Person has choices
* Person has survived before
* Person can rebuild
* No forcing timeline or specific actions

**Hope without bypassing:**
* ✅ "You've survived this before"
* ✅ "Your body knows how to rebuild"
* ✅ "Tomorrow you get to choose"
* ✅ "You're learning who actually remembers"

### 6.2 Safety standards (NON-NEGOTIABLE)

**Content team must NEVER:**
* Include graphic self-harm descriptions
* Provide self-harm instructions
* Validate suicide ideation (acknowledge pain, redirect to support)
* Normalize abuse
* Include sexual content
* Use substance use as coping mechanism

**Age-appropriate boundaries:**
* Romance references: crush rejection, ghosting, break-ups (no sexual content)
* Family conflict: yelling, comparison, restriction (no graphic abuse)
* Academic pressure: failure, disappointment, comparison (no extreme descriptions)

---

## 7. Content production workflow

### 7.1 Pre-writing phase
1. Review doctrine for assigned style + pain category
2. Review location libraries for assigned region
3. Review persona schemas to understand variable sources
4. Review 2-3 example seeds in similar category

### 7.2 Writing phase
1. Draft 147-word base narrative
2. Identify 8-12 variable points
3. Specify variable types, sources, examples
4. Check therapeutic elements (validation, hope, agency, somatic)
5. Verify no toxic positivity language
6. Confirm all locations are REAL

### 7.3 Quality review phase
1. Run through authenticity checklist
2. Verify doctrine alignment
3. Test variable coherence (do examples fit naturally?)
4. Word count check (145-150 target)
5. Safety review (age-appropriate, no harmful content)
6. Submit for validation

### 7.4 Revision phase
1. Address validator feedback
2. Refine variable specifications if needed
3. Adjust language for doctrine alignment
4. Re-check word count
5. Re-submit

---

## 8. Content completion checklist (per style)

A writing style is **100% complete** when:

### Per style
* [ ] Registry entry exists
* [ ] Supported regions declared
* [ ] Supported personas declared
* [ ] Supported pain categories declared
* [ ] Therapeutic framework documented

### Per pain category
* [ ] Doctrine YAML exists
* [ ] Doctrine validated (signature approach, reframe, identity shift)
* [ ] Minimum seed count met (varies by category)
* [ ] Seeds validated against doctrine
* [ ] Region coverage sufficient (SGV/626, Westside/Beach, Valley)
* [ ] Variable hydration points robust

### Global
* [ ] No reliance on generic fallback content
* [ ] All location names verified real
* [ ] All therapeutic safety standards met
* [ ] Ready for production deployment

---

## 9. Phase 1 production targets

### Total seed counts by category:

**Universal pain points:** 297 seeds
- social_rejection: 45
- academic_pressure: 45
- family_conflict: 45
- digital_shame: 36
- autonomy_lack: 36
- body_image: 30
- overwhelm: 30
- loneliness: 30

**SGV/626 specific:** 101 seeds
- boba_social_failure: 15
- academic_sgv_amplified: 15
- cultural_identity_conflict: 15
- cram_school_humiliation: 12
- cousin_comparison: 10
- model_minority_burden: 10
- 626_geographic_specific: 12
- filial_piety_pressure: 12

**Westside/Beach specific:** 101 seeds
- beach_culture_failure: 12
- beach_body_pressure: 12
- volleyball_culture_exclusion: 10
- tourist_adjacent_shame: 10
- affluence_pressure: 12
- outdoor_performance_anxiety: 10
- abbot_kinney_economic_gap: 10
- third_street_promenade_isolation: 10
- santa_monica_pier_crowds: 8
- venice_boardwalk_chaos: 7

**Valley specific:** 101 seeds
- heat_isolation: 10
- car_dependency_failure: 10
- mall_fatigue: 10
- in_n_out_culture_exclusion: 8
- universal_citywalk_economic_gap: 10
- valley_traffic_stress: 8
- sherman_oaks_galleria_nostalgia: 8
- noho_arts_district_trying: 8
- ventura_blvd_social_pressure: 8
- 818_identity_tension: 8
- entertainment_industry_proximity: 8
- valley_vs_westside_rivalry: 5

**TOTAL PHASE 1: 600 seeds**

**Multiplied by variable hydration:** 1,200,000+ unique therapeutic audiobooks possible

---

## 10. How content team knows they're "done"

Run validation tool:
```bash
python3 tools/content_validation/validate_seed_pack.py \
  --style phoenix_foundation \
  --region sgv_626 \
  --pain_category social_rejection \
  --check_completeness
```

**PASS means:**
* All seeds validated for doctrine alignment
* All location names verified real
* All therapeutic safety checks passed
* Variable hydration robust (2000+ variants possible)
* No toxic positivity detected
* Age-appropriate content confirmed
* Ready for TTS production

---

## 11. What the system is waiting on (content side)

**System cannot go to production until:**

* ❌ All writing styles have complete doctrine (Phoenix Rising, Warrior Path, Sage Journey packs)
* ❌ All 600 seeds written, validated, and variable-specified
* ❌ All location libraries verified accurate
* ❌ All persona schemas complete
* ❌ Registry + therapeutic framework mapping complete
* ❌ Safety review completed across all content

Once the above is done:
> **System status → PRODUCTION READY**

---

## 12. Example seed (reference quality)

See separate file: `EXAMPLE_SEED_PHOENIX_SGV_SOCIAL_REJECTION.json`

This example demonstrates:
* Proper variable hydration (10 points)
* Real location usage (Half & Half, 626 Night Market, Factory Tea Bar)
* SGV cultural specificity (boba culture, Instagram stories)
* Therapeutic framework (validation + hope + agency + somatic)
* No toxic positivity
* 147 words exactly
* Third-person narrative voice
* Phoenix Foundation doctrine alignment

**Content team should study this example before beginning production.**

---

## Final one-line truth for the team

> **The therapeutic framework is ready. The variable system is ready. The location libraries are ready. What's missing is 600 complete, culturally authentic, therapeutically sound story seeds — with robust variable hydration — for every pain point across all LA regions.**

---

## Next steps options:

1. **Production schedule:** Day-by-day content creation timeline for 600 seeds
2. **Example seed pack:** Complete Phoenix Foundation SGV social_rejection pack (15 seeds) as starter
3. **Doctrine templates:** Pre-filled doctrine YAML for all 3 style packs
4. **Writer training:** Quick-start guide for content team onboarding
5. **Validation workflow:** Step-by-step QA process

**Ready to begin production when you are.**

---

**Document Status:** FINAL  
**Last Updated:** 2024-12-26  
**Author:** Nihala (Ma'at)  
**Project:** SOURCE_OF_TRUTH LA Gen Alpha Therapeutic Audiobook Platform  
**Version:** V4 Content Spec
