# Book Plan Schema Specification

## Overview

A Book Plan is a frozen, explicit contract that specifies **every decision** for a single book. The assembler reads this plan and executes it without interpretation.

---

## Schema Version

```yaml
schema_version: "3.0"
```

---

## Complete Schema (YAML)

```yaml
# ═══════════════════════════════════════════════════════════════
# BOOK PLAN - Complete Specification
# ═══════════════════════════════════════════════════════════════

schema_version: "3.0"

# ───────────────────────────────────────────────────────────────
# BOOK IDENTITY
# ───────────────────────────────────────────────────────────────

book_id: "anxiety_genz_001"          # Unique identifier
topic: "anxiety"                      # anxiety | depression | grief
persona: "gen_z"                      # gen_z | millennial | gen_x | boomer
variant: "base"                       # base | faith | secular | clinical

# ───────────────────────────────────────────────────────────────
# CHARACTER DEFINITION
# ───────────────────────────────────────────────────────────────

character:
  id: "sam"                           # Reference to characters/sam.yaml
  # All character details come from the library file
  # Name, pronouns, traits are NOT specified here
  # This is a reference, not a definition

# ───────────────────────────────────────────────────────────────
# BOOK METADATA
# ───────────────────────────────────────────────────────────────

metadata:
  title: "Phoenix Raising"
  subtitle: "Moving Through Anxiety Without Waiting for Calm"
  generated_at: "2026-01-19T14:30:00Z"
  generator_version: "3.0.0"

# ───────────────────────────────────────────────────────────────
# GLOBAL SETTINGS
# ───────────────────────────────────────────────────────────────

settings:
  voice: "phoenix_protocol"           # Voice/tone identifier
  pov: "second_person"                # second_person | first_person
  tense: "present"                    # present | past
  reading_level: "accessible"         # accessible | clinical | academic

# ───────────────────────────────────────────────────────────────
# CHAPTER DEFINITIONS
# ───────────────────────────────────────────────────────────────

chapters:

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 1: Recognition
  # ─────────────────────────────────────────────────────────────
  - chapter: 1
    title: "The Sentence"
    
    # Core content (REQUIRED)
    experience_id: "exp_01_recognition"
    
    # Scene injection (null = no scene)
    scene:
      id: null
      position: null
    
    # Exercises (empty array = no exercises)
    exercises: []
    
    # Reflection block (null = no reflection)
    reflection_id: null
    
    # Chapter-end integration (null = no integration block)
    integration_id: null
    
    # Persona-specific closing (null = no closing)
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 2: Origin
  # ─────────────────────────────────────────────────────────────
  - chapter: 2
    title: "Where It Came From"
    experience_id: "exp_02_origin"
    scene:
      id: "scene_02_classroom_memory"
      position: "after_para_3"         # Injection point
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 3: Cost to Self
  # ─────────────────────────────────────────────────────────────
  - chapter: 3
    title: "What It's Done to You"
    experience_id: "exp_03_cost_self"
    scene:
      id: null
      position: null
    exercises: []
    reflection_id: "refl_03_notice"
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 4: Reframe
  # ─────────────────────────────────────────────────────────────
  - chapter: 4
    title: "Anxiety as Information"
    experience_id: "exp_04_reframe"
    scene:
      id: "scene_04_text_send"
      position: "after_section_2"
    exercises:
      - id: "breath_box_4444"
        position: "end"
        intro_text: "box_breath_intro"
    reflection_id: null
    integration_id: null
    closing_id: "close_04_genz"

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 5: Cost of Waiting
  # ─────────────────────────────────────────────────────────────
  - chapter: 5
    title: "What Waiting Costs"
    experience_id: "exp_05_cost_waiting"
    scene:
      id: null
      position: null
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 6: End the War
  # ─────────────────────────────────────────────────────────────
  - chapter: 6
    title: "Stop Fighting"
    experience_id: "exp_06_end_war"
    scene:
      id: "scene_06_ramen_text"
      position: "mid_chapter"
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 7: Small Moves
  # ─────────────────────────────────────────────────────────────
  - chapter: 7
    title: "Small Moves"
    experience_id: "exp_07_small_moves"
    scene:
      id: null
      position: null
    exercises:
      - id: "check_in_3_second"
        position: "after_section_1"
        intro_text: null
      - id: "breath_box_4444"
        position: "mid_chapter"
        intro_text: null
      - id: "ground_54321"
        position: "after_section_3"
        intro_text: null
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 8: Loud Anxiety
  # ─────────────────────────────────────────────────────────────
  - chapter: 8
    title: "When It Gets Loud"
    experience_id: "exp_08_loud"
    scene:
      id: "scene_08_coffee_shop"
      position: "after_para_5"
    exercises:
      - id: "breath_46"
        position: "mid_chapter"
        intro_text: "breath_46_intro"
      - id: "ground_feet"
        position: "after_breath"
        intro_text: null
      - id: "breath_478"
        position: "end"
        intro_text: "breath_478_intro"
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 9: Automaticity
  # ─────────────────────────────────────────────────────────────
  - chapter: 9
    title: "When It Becomes Automatic"
    experience_id: "exp_09_automatic"
    scene:
      id: "scene_09_bonfire"
      position: "mid_chapter"
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 10: Slips
  # ─────────────────────────────────────────────────────────────
  - chapter: 10
    title: "When You Slip"
    experience_id: "exp_10_slips"
    scene:
      id: "scene_10_verve_freeze"
      position: "after_section_1"
    exercises: []
    reflection_id: "refl_10_slip_recovery"
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 11: Identity
  # ─────────────────────────────────────────────────────────────
  - chapter: 11
    title: "Who You're Becoming"
    experience_id: "exp_11_identity"
    scene:
      id: "scene_11_open_mic"
      position: "mid_chapter"
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null

  # ─────────────────────────────────────────────────────────────
  # CHAPTER 12: Forward
  # ─────────────────────────────────────────────────────────────
  - chapter: 12
    title: "From Here"
    experience_id: "exp_12_forward"
    scene:
      id: null
      position: null
    exercises: []
    reflection_id: null
    integration_id: "bridge_forward_open"
    closing_id: "close_12_final"

# ───────────────────────────────────────────────────────────────
# FRONT MATTER (Optional)
# ───────────────────────────────────────────────────────────────

front_matter:
  a0_pre_intro:
    id: "a0_genz_anxiety"             # null if no pre-intro
  a1_introduction:
    id: "a1_genz_anxiety"             # null if no introduction

# ───────────────────────────────────────────────────────────────
# BACK MATTER (Optional)
# ───────────────────────────────────────────────────────────────

back_matter:
  conclusion:
    id: "conclusion_genz_anxiety"     # null if no conclusion
  appendix:
    id: null                          # null if no appendix
  resources:
    id: null                          # null if no resources
```

---

## JSON Schema for Validation

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Phoenix Book Plan",
  "type": "object",
  "required": ["schema_version", "book_id", "topic", "persona", "character", "chapters"],
  "properties": {
    "schema_version": {
      "type": "string",
      "const": "3.0"
    },
    "book_id": {
      "type": "string",
      "pattern": "^[a-z_]+_[a-z0-9]+_[0-9]{3}$"
    },
    "topic": {
      "type": "string",
      "enum": ["anxiety", "depression", "grief", "trauma", "burnout"]
    },
    "persona": {
      "type": "string",
      "enum": ["gen_z", "millennial", "gen_x", "boomer", "universal"]
    },
    "variant": {
      "type": "string",
      "enum": ["base", "faith", "secular", "clinical"]
    },
    "character": {
      "type": "object",
      "required": ["id"],
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^[a-z_]+$"
        }
      }
    },
    "chapters": {
      "type": "array",
      "minItems": 12,
      "maxItems": 12,
      "items": {
        "type": "object",
        "required": ["chapter", "title", "experience_id"],
        "properties": {
          "chapter": {
            "type": "integer",
            "minimum": 1,
            "maximum": 12
          },
          "title": {
            "type": "string"
          },
          "experience_id": {
            "type": "string",
            "pattern": "^exp_[0-9]{2}_[a-z_]+$"
          },
          "scene": {
            "type": ["object", "null"],
            "properties": {
              "id": {"type": ["string", "null"]},
              "position": {"type": ["string", "null"]}
            }
          },
          "exercises": {
            "type": "array",
            "items": {
              "type": "object",
              "required": ["id", "position"],
              "properties": {
                "id": {"type": "string"},
                "position": {"type": "string"},
                "intro_text": {"type": ["string", "null"]}
              }
            }
          },
          "reflection_id": {"type": ["string", "null"]},
          "integration_id": {"type": ["string", "null"]},
          "closing_id": {"type": ["string", "null"]}
        }
      }
    }
  }
}
```

---

## Field Reference

### Book Identity Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `book_id` | string | ✓ | Unique identifier: `{topic}_{persona}_{number}` |
| `topic` | enum | ✓ | Content topic: anxiety, depression, grief, etc. |
| `persona` | enum | ✓ | Target audience: gen_z, millennial, etc. |
| `variant` | enum | ✗ | Content variant: base, faith, secular, clinical |

### Character Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `character.id` | string | ✓ | Reference to character file in library |

### Chapter Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `chapter` | integer | ✓ | Chapter number (1-12) |
| `title` | string | ✓ | Chapter title |
| `experience_id` | string | ✓ | Reference to experience content |
| `scene.id` | string/null | ✗ | Scene to inject, null = no scene |
| `scene.position` | string/null | ✗ | Where to inject scene |
| `exercises` | array | ✓ | List of exercises (can be empty) |
| `reflection_id` | string/null | ✗ | Reflection block reference |
| `integration_id` | string/null | ✗ | Integration bridge reference |
| `closing_id` | string/null | ✗ | Persona-specific closing |

### Exercise Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | ✓ | Exercise reference |
| `position` | string | ✓ | Injection point in chapter |
| `intro_text` | string/null | ✗ | Intro text reference |

---

## Position Values

Valid position values for scenes and exercises:

| Position | Description |
|----------|-------------|
| `start` | Beginning of chapter |
| `after_para_N` | After paragraph N |
| `after_section_N` | After section N |
| `mid_chapter` | Middle of chapter |
| `before_end` | Near end, before closing |
| `end` | End of chapter |

---

## Null Semantics

**CRITICAL: Null means intentionally empty, not "decide later"**

| Value | Meaning |
|-------|---------|
| `scene.id: null` | This chapter has no scene. Correct. |
| `scene.id: "scene_04_text"` | This chapter has this scene. Correct. |
| `scene.id: ""` | INVALID. Empty string not allowed. |
| Field missing | INVALID. All fields must be present. |

---

## Validation Rules

1. **All component IDs must exist in libraries**
2. **No duplicate experience_ids across chapters**
3. **Scene positions must be valid for chapter length**
4. **Exercise positions must not overlap**
5. **Character ID must exist in characters library**
6. **Chapter numbers must be sequential 1-12**
7. **No empty strings (use null instead)**

---

## Example: Minimal Valid Plan

```yaml
schema_version: "3.0"
book_id: "anxiety_genz_001"
topic: "anxiety"
persona: "gen_z"
character:
  id: "sam"
chapters:
  - chapter: 1
    title: "The Sentence"
    experience_id: "exp_01_recognition"
    scene: {id: null, position: null}
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null
  # ... chapters 2-11 ...
  - chapter: 12
    title: "From Here"
    experience_id: "exp_12_forward"
    scene: {id: null, position: null}
    exercises: []
    reflection_id: null
    integration_id: "bridge_forward_open"
    closing_id: null
```

---

## Example: Complex Plan with All Features

```yaml
schema_version: "3.0"
book_id: "anxiety_millennial_042"
topic: "anxiety"
persona: "millennial"
variant: "secular"
character:
  id: "alex"
metadata:
  title: "Phoenix Raising"
  subtitle: "Moving Through Anxiety Without Waiting for Calm"
  generated_at: "2026-01-19T14:30:00Z"
settings:
  voice: "phoenix_protocol"
  pov: "second_person"
  tense: "present"
  reading_level: "accessible"
chapters:
  - chapter: 4
    title: "Anxiety as Information"
    experience_id: "exp_04_reframe"
    scene:
      id: "scene_04_slack_message"
      position: "after_section_2"
    exercises:
      - id: "breath_box_4444"
        position: "end"
        intro_text: "box_breath_intro_millennial"
    reflection_id: "refl_04_notice_signal"
    integration_id: null
    closing_id: "close_04_millennial"
```

---

## Usage

### Reading a Plan

```python
import yaml

with open("plans/anxiety_genz_001.yaml") as f:
    plan = yaml.safe_load(f)

for chapter in plan["chapters"]:
    print(f"Chapter {chapter['chapter']}: {chapter['experience_id']}")
    if chapter["scene"]["id"]:
        print(f"  Scene: {chapter['scene']['id']}")
```

### Validating a Plan

```python
from validator import validate_plan

result = validate_plan("plans/anxiety_genz_001.yaml")
if not result.valid:
    for error in result.errors:
        print(f"ERROR: {error}")
    sys.exit(1)
```

### Assembling a Book

```python
from assembler import assemble_book

book = assemble_book("plans/anxiety_genz_001.yaml")
book.write("output/anxiety_genz_001.md")
```
