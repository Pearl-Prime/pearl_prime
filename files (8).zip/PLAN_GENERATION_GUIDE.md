# Plan Generation Guide

## Overview

This guide explains how to use an LLM to generate 1,200+ Book Plans safely and systematically. The LLM acts as a **planner/architect**, not a writer.

**Key Insight:** The LLM generates **symbolic plans** (JSON/YAML), not prose. Plans are constrained, reviewable, and testable.

---

## The Correct Mental Model

```
┌─────────────────────────────────────────────────────────────┐
│                    LLM AS PLANNER                            │
│                                                              │
│   Input:                                                     │
│   - Component Libraries (finite catalog)                     │
│   - Planning Matrix (book variants)                          │
│   - Constraints (rules)                                      │
│                                                              │
│   Output:                                                    │
│   - Book Plans (YAML files)                                  │
│   - NOT prose                                                │
│   - NOT content                                              │
│   - NOT decisions at runtime                                 │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Step 1: Define the Planning Space

Before generating plans, define the finite space of possibilities.

### Topics

```yaml
topics:
  - anxiety
  - depression
  - grief
  - trauma      # future
  - burnout     # future
```

### Personas

```yaml
personas:
  - gen_z
  - millennial
  - gen_x
  - boomer
  - universal
```

### Variants

```yaml
variants:
  - base        # Default, neutral
  - faith       # Faith-inclusive language
  - secular     # Explicitly secular
  - clinical    # Clinical/professional tone
```

### Book Count Calculation

```
Topics (3) × Personas (5) × Variants (4) = 60 base combinations

With additional variations:
- Scene combinations: ~5 per book
- Exercise combinations: ~10 per book
- Character options: 4

Total unique books: 60 × 5 × 10 / overlap ≈ 1,200
```

---

## Step 2: Create the Planning Matrix

The Planning Matrix is a spreadsheet that defines all book variants.

### Matrix Structure

| Column | Description | Example |
|--------|-------------|---------|
| book_id | Unique identifier | anxiety_genz_001 |
| topic | Content topic | anxiety |
| persona | Target audience | gen_z |
| variant | Content variant | base |
| character_id | Character to use | sam |
| ch{N}_scene | Scene for chapter N | scene_04_text_send |
| ch{N}_exercise_{M} | Exercise M for chapter N | breath_box_4444 |
| ch{N}_reflection | Reflection for chapter N | refl_10_slip |
| ch{N}_integration | Integration for chapter N | bridge_forward_open |
| ch{N}_closing | Closing for chapter N | close_12_final |

### Example Rows

```csv
book_id,topic,persona,variant,character_id,ch04_scene,ch04_exercise_1,ch08_scene,ch08_exercise_1,ch12_integration
anxiety_genz_001,anxiety,gen_z,base,sam,scene_04_text_send,breath_box_4444,scene_08_coffee_shop,breath_46,bridge_forward_open
anxiety_genz_002,anxiety,gen_z,base,sam,scene_04_email_prof,breath_box_4444,scene_08_coffee_shop,breath_478,bridge_forward_open
anxiety_millennial_001,anxiety,millennial,base,alex,scene_04_slack,breath_box_4444,scene_08_home_office,breath_46,bridge_forward_soft
```

---

## Step 3: LLM Prompt for Matrix Generation

Use this prompt to have an LLM generate the planning matrix.

### Prompt Template

```
You are a book planning assistant. Your job is to generate a Planning Matrix for therapeutic audiobooks.

## Context

I'm creating 1,200+ personalized therapeutic audiobooks using a component-based assembly system. Each book is defined by a plan that specifies which components to include.

## Available Components

### Topics
- anxiety
- depression
- grief

### Personas
- gen_z (18-26, digital native, college/early career)
- millennial (27-42, work/life balance, career established)
- gen_x (43-58, leadership roles, family responsibilities)
- boomer (59-77, life transitions, legacy)
- universal (any age, generic)

### Characters
- sam (they/them, Gen Z default)
- alex (they/them, millennial default)
- jordan (they/them, Gen X default)
- taylor (they/them, universal default)

### Scenes (by topic and persona)

For anxiety + gen_z:
- scene_02_classroom_memory
- scene_04_text_send
- scene_04_email_prof
- scene_06_ramen_text
- scene_08_coffee_shop
- scene_09_bonfire
- scene_10_verve_freeze
- scene_11_open_mic

For anxiety + millennial:
- scene_02_meeting_memory
- scene_04_slack_message
- scene_04_client_email
- scene_06_team_lunch
- scene_08_home_office
- scene_09_dinner_party
- scene_10_zoom_freeze
- scene_11_presentation

### Exercises
- breath_box_4444 (beginner, all)
- breath_46 (intermediate, all)
- breath_478 (advanced, all)
- ground_54321 (beginner, all)
- ground_feet (beginner, all)
- check_in_3_second (beginner, all)
- body_scan (intermediate, all)

### Bridges
- bridge_forward_open (open ending, default)
- bridge_forward_soft (gentle ending, sensitive)
- bridge_forward_practice (action-oriented)

## Task

Generate a Planning Matrix with 50 unique book variants for ANXIETY topic.

Requirements:
1. Each book_id must be unique: {topic}_{persona}_{number}
2. Mix personas evenly
3. Vary scene combinations
4. Vary exercise combinations
5. Match character to persona
6. Include all required columns

## Output Format

Return a CSV with these columns:
book_id,topic,persona,variant,character_id,ch02_scene,ch04_scene,ch04_exercise_1,ch06_scene,ch07_exercise_1,ch07_exercise_2,ch07_exercise_3,ch08_scene,ch08_exercise_1,ch08_exercise_2,ch09_scene,ch10_scene,ch10_reflection,ch11_scene,ch12_integration,ch12_closing

Use empty string for "no component" (not null).

Generate 50 rows.
```

---

## Step 4: LLM Prompt for Plan Generation

Once you have a matrix row, use this prompt to generate the full YAML plan.

### Prompt Template

```
You are a book plan generator. Convert this matrix row into a full Book Plan YAML.

## Matrix Row

book_id: anxiety_genz_001
topic: anxiety
persona: gen_z
variant: base
character_id: sam
ch02_scene: scene_02_classroom_memory
ch04_scene: scene_04_text_send
ch04_exercise_1: breath_box_4444
ch06_scene: scene_06_ramen_text
ch07_exercise_1: check_in_3_second
ch07_exercise_2: breath_box_4444
ch07_exercise_3: ground_54321
ch08_scene: scene_08_coffee_shop
ch08_exercise_1: breath_46
ch08_exercise_2: ground_feet
ch08_exercise_3: breath_478
ch09_scene: scene_09_bonfire
ch10_scene: scene_10_verve_freeze
ch10_reflection: refl_10_slip_recovery
ch11_scene: scene_11_open_mic
ch12_integration: bridge_forward_open
ch12_closing: close_12_final

## Schema

Use this exact structure:

```yaml
schema_version: "3.0"
book_id: "{book_id}"
topic: "{topic}"
persona: "{persona}"
variant: "{variant}"
character:
  id: "{character_id}"
metadata:
  title: "Phoenix Raising"
  subtitle: "Moving Through Anxiety Without Waiting for Calm"
  generated_at: "{timestamp}"
chapters:
  - chapter: 1
    title: "The Sentence"
    experience_id: "exp_01_recognition"
    scene: {id: null, position: null}
    exercises: []
    reflection_id: null
    integration_id: null
    closing_id: null
  # ... continue for all 12 chapters
```

## Rules

1. Experience IDs follow pattern: exp_{NN}_{slug}
2. Empty matrix cell = null in YAML
3. Scene position should be appropriate for chapter:
   - Chapter 2: "after_para_3"
   - Chapter 4: "after_section_2"
   - Chapter 6: "mid_chapter"
   - Chapter 8: "after_para_5"
   - Chapter 9: "mid_chapter"
   - Chapter 10: "after_section_1"
   - Chapter 11: "mid_chapter"
4. Exercise positions should not overlap:
   - First exercise: "after_section_1" or "mid_chapter"
   - Second exercise: "after_section_2" or "mid_chapter"
   - Third exercise: "end"

## Output

Generate the complete YAML plan file.
```

---

## Step 5: Batch Generation Script

Use this script to automate plan generation from a matrix.

```python
#!/usr/bin/env python3
"""
Generate Book Plans from Planning Matrix.

Usage:
    python generate_plans.py matrix.csv output_dir/
"""

import csv
import yaml
from datetime import datetime
from pathlib import Path

# Chapter configuration
CHAPTERS = [
    {"num": 1, "title": "The Sentence", "exp": "exp_01_recognition"},
    {"num": 2, "title": "Where It Came From", "exp": "exp_02_origin"},
    {"num": 3, "title": "What It's Done to You", "exp": "exp_03_cost_self"},
    {"num": 4, "title": "Anxiety as Information", "exp": "exp_04_reframe"},
    {"num": 5, "title": "What Waiting Costs", "exp": "exp_05_cost_waiting"},
    {"num": 6, "title": "Stop Fighting", "exp": "exp_06_end_war"},
    {"num": 7, "title": "Small Moves", "exp": "exp_07_small_moves"},
    {"num": 8, "title": "When It Gets Loud", "exp": "exp_08_loud"},
    {"num": 9, "title": "When It Becomes Automatic", "exp": "exp_09_automatic"},
    {"num": 10, "title": "When You Slip", "exp": "exp_10_slips"},
    {"num": 11, "title": "Who You're Becoming", "exp": "exp_11_identity"},
    {"num": 12, "title": "From Here", "exp": "exp_12_forward"},
]

# Default scene positions by chapter
SCENE_POSITIONS = {
    2: "after_para_3",
    4: "after_section_2",
    6: "mid_chapter",
    8: "after_para_5",
    9: "mid_chapter",
    10: "after_section_1",
    11: "mid_chapter",
}

# Default exercise positions
EXERCISE_POSITIONS = ["after_section_1", "mid_chapter", "end"]


def row_to_plan(row: dict) -> dict:
    """Convert a matrix row to a Book Plan."""
    
    plan = {
        "schema_version": "3.0",
        "book_id": row["book_id"],
        "topic": row["topic"],
        "persona": row["persona"],
        "variant": row.get("variant", "base"),
        "character": {"id": row["character_id"]},
        "metadata": {
            "title": "Phoenix Raising",
            "subtitle": get_subtitle(row["topic"]),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        },
        "chapters": [],
    }
    
    for ch_config in CHAPTERS:
        chapter = build_chapter(ch_config, row)
        plan["chapters"].append(chapter)
    
    return plan


def build_chapter(ch_config: dict, row: dict) -> dict:
    """Build a single chapter from config and row."""
    
    num = ch_config["num"]
    
    chapter = {
        "chapter": num,
        "title": ch_config["title"],
        "experience_id": ch_config["exp"],
        "scene": {"id": None, "position": None},
        "exercises": [],
        "reflection_id": None,
        "integration_id": None,
        "closing_id": None,
    }
    
    # Scene
    scene_key = f"ch{num:02d}_scene"
    if scene_key in row and row[scene_key]:
        chapter["scene"]["id"] = row[scene_key]
        chapter["scene"]["position"] = SCENE_POSITIONS.get(num, "mid_chapter")
    
    # Exercises
    for i in range(1, 4):
        ex_key = f"ch{num:02d}_exercise_{i}"
        if ex_key in row and row[ex_key]:
            chapter["exercises"].append({
                "id": row[ex_key],
                "position": EXERCISE_POSITIONS[i - 1],
                "intro_text": None,
            })
    
    # Reflection
    refl_key = f"ch{num:02d}_reflection"
    if refl_key in row and row[refl_key]:
        chapter["reflection_id"] = row[refl_key]
    
    # Integration
    int_key = f"ch{num:02d}_integration"
    if int_key in row and row[int_key]:
        chapter["integration_id"] = row[int_key]
    
    # Closing
    close_key = f"ch{num:02d}_closing"
    if close_key in row and row[close_key]:
        chapter["closing_id"] = row[close_key]
    
    return chapter


def get_subtitle(topic: str) -> str:
    """Get subtitle by topic."""
    subtitles = {
        "anxiety": "Moving Through Anxiety Without Waiting for Calm",
        "depression": "Finding Movement When Everything Feels Heavy",
        "grief": "Carrying Loss Without Losing Yourself",
    }
    return subtitles.get(topic, "A Phoenix Protocol Book")


def generate_plans(matrix_path: str, output_dir: str):
    """Generate all plans from a matrix CSV."""
    
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    with open(matrix_path) as f:
        reader = csv.DictReader(f)
        
        for row in reader:
            plan = row_to_plan(row)
            
            # Write YAML
            plan_path = output_path / f"{plan['book_id']}.yaml"
            with open(plan_path, 'w') as out:
                yaml.dump(plan, out, default_flow_style=False, sort_keys=False)
            
            print(f"Generated: {plan_path}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 3:
        print("Usage: python generate_plans.py matrix.csv output_dir/")
        sys.exit(1)
    
    generate_plans(sys.argv[1], sys.argv[2])
```

---

## Step 6: Validation and Review

After generating plans:

### Automated Validation

```bash
# Validate all plans
$ phoenix validate plans/

Validating 1200 plans...
✅ 1198 valid
❌ 2 invalid

Invalid plans:
  - anxiety_genz_042.yaml: [REFERENCE] Scene not found
  - grief_boomer_003.yaml: [CONSTRAINT] Duplicate experience
```

### Human Review (Sampling)

Review a sample of plans for correctness:

```bash
# Random sample 20 plans
$ ls plans/ | shuf | head -20 | xargs -I {} phoenix show {}
```

Check:
- Scene placement makes sense for chapter
- Exercise variety is appropriate
- Persona/character match
- Ending feels complete

---

## Step 7: Generate Books

Once plans are validated:

```bash
# Generate all books
$ phoenix assemble plans/ -o output/

Assembling 1200 books...
✅ 1200 books assembled
```

---

## Summary: The Safe Way to Use LLMs

| Use LLM For | Don't Use LLM For |
|-------------|-------------------|
| Planning (offline) | Runtime decisions |
| Matrix generation | Content generation |
| Symbolic output (YAML) | Prose output |
| Constrained choices | Open-ended generation |
| Reviewable artifacts | Hidden decisions |

**The LLM plans. The system prints.**

That's the separation that makes 1,200 books safe.
