# Phoenix Book Assembly Architecture V3

## The Core Principle

**LLM = Planner (offline, once)**
**System = Assembler (deterministic, no decisions)**

These two layers must never cross. Ever.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    PLANNING LAYER                        │
│              (LLM-assisted, offline, frozen)             │
│                                                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │
│  │ Component   │  │ Book Plan   │  │ Plan        │     │
│  │ Libraries   │  │ Generator   │  │ Validator   │     │
│  └─────────────┘  └─────────────┘  └─────────────┘     │
│         │                │                │             │
│         ▼                ▼                ▼             │
│  ┌─────────────────────────────────────────────────┐   │
│  │           FROZEN BOOK PLANS (JSON/YAML)          │   │
│  │          One per book. No ambiguity.             │   │
│  └─────────────────────────────────────────────────┘   │
│                          │                              │
└──────────────────────────┼──────────────────────────────┘
                           │
         ══════════════════╪══════════════════════════════
                    BRIGHT RED LINE
              (No decisions cross this line)
         ══════════════════╪══════════════════════════════
                           │
┌──────────────────────────┼──────────────────────────────┐
│                          ▼                              │
│                   ASSEMBLY LAYER                        │
│           (Dumb, deterministic, lookup-only)            │
│                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │
│  │ Plan        │  │ Component   │  │ Book        │    │
│  │ Reader      │  │ Fetcher     │  │ Renderer    │    │
│  └─────────────┘  └─────────────┘  └─────────────┘    │
│         │                │                │            │
│         ▼                ▼                ▼            │
│  ┌─────────────────────────────────────────────────┐  │
│  │              RENDERED BOOK (Markdown)            │  │
│  │           Deterministic. Reproducible.           │  │
│  └─────────────────────────────────────────────────┘  │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

## What Changes

| Before (V2) | After (V3) |
|-------------|------------|
| Runtime decides if scene needed | Plan says scene or null |
| Assembler has fallback logic | Assembler has lookup only |
| Missing = inject something | Missing = hard fail |
| Persona selected at render | Persona frozen in plan |
| Variables resolved late | Variables resolved at planning |
| Emergent bugs | Binary bugs |
| "Why did this happen?" | "Plan says X, got X" |

---

## The Five Components

### 1. Component Libraries (Finite Catalogs)

Everything that can appear in a book must exist in a library first.

- `experiences/` - 12 experience archetypes × topic
- `scenes/` - 6 scene slots × topic × persona
- `exercises/` - 8 exercise families
- `reflections/` - 4 reflection styles
- `bridges/` - 3 integration endings
- `characters/` - Character definitions (name, pronouns, traits)

**Rule: If it's not in a library, it cannot appear in a book.**

### 2. Book Plan Schema

A JSON/YAML file that specifies **every decision** for one book.

```yaml
book_id: "anxiety_genz_001"
topic: "anxiety"
persona: "gen_z"
character: "sam"
chapters:
  - chapter: 1
    experience_id: "exp_01_recognition"
    scene_id: null
    exercise_ids: []
    reflection_id: null
  - chapter: 4
    experience_id: "exp_04_reframe"
    scene_id: "scene_04_text_send"
    exercise_ids: ["breath_box_4444"]
    reflection_id: "refl_notice"
```

**Rule: No nulls that require decision. Explicit null = intentionally empty.**

### 3. Plan Validator

Runs before assembly. Catches:

- Missing component references
- Invalid chapter configurations
- Duplicate content assignments
- Constraint violations
- Schema errors

**Rule: Invalid plan = build fails. No exceptions.**

### 4. Assembler

Reads plan. Fetches components. Renders book.

```python
def assemble(plan):
    book = []
    for chapter in plan.chapters:
        content = fetch_experience(chapter.experience_id)
        if chapter.scene_id:
            scene = fetch_scene(chapter.scene_id)
            content = inject_scene(content, scene)
        if chapter.exercise_ids:
            exercises = [fetch_exercise(e) for e in chapter.exercise_ids]
            content = inject_exercises(content, exercises)
        book.append(content)
    return render(book)
```

**Rule: Assembler makes ZERO decisions. Lookup only.**

### 5. Book Planning Matrix

Spreadsheet that defines all 1,200 books.

| book_id | topic | persona | ch1_scene | ch4_exercise | ch12_bridge |
|---------|-------|---------|-----------|--------------|-------------|
| 001 | anxiety | gen_z | null | box_breath | forward_open |
| 002 | anxiety | millennial | null | body_scan | forward_soft |

**Rule: LLM generates matrix once. Human reviews. System executes.**

---

## Migration Path

### Phase 1: Extract Libraries (Week 1)
- Audit existing content
- Extract unique experiences, scenes, exercises
- Create canonical component files
- Assign stable IDs

### Phase 2: Design Plan Schema (Week 1)
- Define JSON/YAML structure
- Document all fields
- Create validation rules
- Build validator

### Phase 3: Generate Test Plans (Week 2)
- Create 10 test book plans manually
- Validate plans
- Assemble books
- Compare to current output

### Phase 4: Build Planning Matrix (Week 2-3)
- Define all book variants
- Use LLM to generate 1,200 plans
- Validate all plans
- Human review sample

### Phase 5: Replace Assembler (Week 3)
- Build new lookup-only assembler
- Remove all fallback logic
- Remove all decision points
- Hard fail on missing

### Phase 6: Full Generation (Week 4)
- Generate all 1,200 books
- Automated QA
- Human spot-check
- Production release

---

## Success Criteria

After V3:

1. **Any book can be regenerated identically** from its plan
2. **Build failures are binary** - plan invalid or plan valid
3. **No emergent bugs** - output matches plan exactly
4. **QA is automated** - validator catches issues before build
5. **Scale is trivial** - 1,200 books = 1,200 plan executions

---

## Anti-Patterns to Eliminate

### ❌ Never Again

```python
# BAD: Decision at runtime
if chapter.scene is None:
    chapter.scene = find_fallback_scene()

# BAD: Smart defaults
scene = scene_id or DEFAULT_SCENES[topic]

# BAD: Conditional injection
if needs_exercise(chapter):
    inject_exercise(chapter)

# BAD: Late resolution
character_name = resolve_character(persona)
```

### ✅ Always

```python
# GOOD: Lookup only
scene = fetch_component(plan.scene_id)
if scene is None:
    raise BuildError(f"Missing scene: {plan.scene_id}")

# GOOD: Explicit null
if plan.scene_id is None:
    # Intentionally no scene - this is correct
    pass

# GOOD: Plan is source of truth
character_name = plan.character.name  # Already resolved
```

---

## File Structure

```
phoenix_v3/
├── libraries/
│   ├── experiences/
│   │   ├── anxiety/
│   │   │   ├── exp_01_recognition.md
│   │   │   ├── exp_02_origin.md
│   │   │   └── ...
│   │   ├── depression/
│   │   └── grief/
│   ├── scenes/
│   │   ├── anxiety/
│   │   │   ├── gen_z/
│   │   │   │   ├── scene_04_text_send.yaml
│   │   │   │   └── ...
│   │   │   └── millennial/
│   │   └── ...
│   ├── exercises/
│   │   ├── breath_box_4444.yaml
│   │   ├── breath_478.yaml
│   │   └── ...
│   ├── reflections/
│   │   ├── refl_notice.md
│   │   └── ...
│   ├── bridges/
│   │   ├── bridge_forward_open.md
│   │   └── ...
│   └── characters/
│       ├── sam.yaml
│       └── ...
├── plans/
│   ├── anxiety_genz_001.yaml
│   ├── anxiety_genz_002.yaml
│   └── ...
├── validator/
│   ├── validate_plan.py
│   └── rules/
├── assembler/
│   ├── assemble.py
│   └── render.py
├── output/
│   └── books/
└── planning/
    ├── BOOK_PLANNING_MATRIX.csv
    └── generate_plans.py
```

---

## Next Steps

1. Review this architecture
2. Approve or modify the plan schema
3. Begin library extraction
4. Build validator
5. Test with 10 books
6. Scale to 1,200

The problem is solvable. The path is clear. Let's build it.
