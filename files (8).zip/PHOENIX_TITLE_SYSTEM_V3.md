# Phoenix Protocol Title System V3
## Location-Based, Hook-Driven, SEO-Optimized

---

## Series Naming Convention

### Formula
```
[Location] [Topic] Series
```

### Examples
| Location | Topic | Series Name |
|----------|-------|-------------|
| Santa Cruz | Anxiety | **Santa Cruz Anxiety Series** |
| Brooklyn | Depression | **Brooklyn Depression Series** |
| New York | Burnout | **New York Burnout Series** |
| San Francisco | Overthinking | **San Francisco Overthinking Series** |
| Nationwide | Healthcare | **Healthcare Heroes Anxiety Series** |

### Location Strategy by Persona

| Persona | Location Type | Examples |
|---------|---------------|----------|
| Gen Z | Hip urban areas | Santa Cruz, Brooklyn, Austin, Portland, Denver |
| Millennial | Major metros | New York, Los Angeles, San Francisco, Boston, DC |
| Healthcare | Nationwide | "Healthcare Heroes" (profession = location) |
| Parents | Suburban | "Modern Parent" / "Family" |
| College | Campus | "College" / "Campus" |
| Faith | Nationwide | "Faith &" prefix |
| Couples | Nationwide | "Couples" / "Partner" |

---

## Title Formula

### Main Title: The Hook

**Pattern:** [Provocative Statement About the Topic]

| Topic | Hook Examples |
|-------|---------------|
| **Anxiety** | "Your Anxiety Is Lying to You" / "Stop Waiting for Calm" / "Anxious but Moving" |
| **Depression** | "Getting Out of Bed Is a Win" / "Depression Lies About Tomorrow" |
| **Grief** | "Loss Doesn't Follow a Timeline" / "Grief Is Love with Nowhere to Go" |
| **Burnout** | "Hustle Culture Almost Killed Me" / "You're Not Lazy You're Depleted" |
| **Overthinking** | "Your Brain Won't Shut Up" / "3 AM Thoughts Are Lying to You" |
| **People-Pleasing** | "Stop Shrinking for Other People" / "Your No Is Not Negotiable" |
| **Perfectionism** | "Done Is Better Than Perfect" / "Your Worth Isn't Your Output" |
| **Digital** | "Your Phone Is Not Your Friend" / "Scroll Hole to Whole Self" |
| **Rejection** | "Rejection Isn't the End of the Story" / "The No That Didn't Kill You" |

### Hook Characteristics

✅ **What Makes a Good Hook:**
- Speaks directly to the pain
- Counterintuitive or surprising
- Sounds like something a friend would say
- Under 8 words
- Uses "You" or "Your"

❌ **What to Avoid:**
- Generic ("A Guide to...")
- Clinical ("Managing Symptoms of...")
- Abstract ("Finding Inner Peace...")
- Long (10+ words)

---

## Subtitle Formula

### Pattern
```
The Phoenix Protocol: A [Location] Guide to [Specific Outcome for Topic]
```

### Components

| Component | Purpose | Example |
|-----------|---------|---------|
| "The Phoenix Protocol:" | Brand anchor | Always included |
| "A [Location] Guide" | Personalization + SEO | "A Santa Cruz Guide" |
| "to [Outcome]" | Promise + topic clarity | "to Acting While Anxious" |

### Outcome Phrases by Topic

| Topic | Outcome Phrases |
|-------|-----------------|
| **Anxiety** | "Acting While Anxious" / "Moving Through Anxiety" / "Breaking the Hesitation Loop" |
| **Depression** | "Moving Through Depression" / "Finding Motion When Everything Feels Heavy" |
| **Grief** | "Carrying Grief Forward" / "Living with Loss" |
| **Burnout** | "Burnout Recovery" / "Sustainable Success" |
| **Overthinking** | "Breaking the Thought Loop" / "Quieting Overthinking" |
| **People-Pleasing** | "Breaking People-Pleasing" / "Authentic Self-Expression" |
| **Perfectionism** | "Releasing Perfectionism" / "Good Enough" |
| **Digital** | "Digital Balance" / "Social Media Anxiety Recovery" |
| **Rejection** | "Rejection Resilience" / "Social Resilience" |

---

## Complete Title Examples

### Anxiety × Gen Z × Santa Cruz
```
Series: Santa Cruz Anxiety Series

Title: Your Anxiety Is Lying to You
Subtitle: The Phoenix Protocol: A Santa Cruz Guide to Acting Before You Feel Ready

Keywords: santa cruz anxiety, gen z anxiety help, california mental health, young adult anxiety relief
```

### Depression × Millennial × New York
```
Series: New York Depression Series

Title: Success and Sadness Can Coexist
Subtitle: The Phoenix Protocol: A New York Guide to High Function Depression

Keywords: new york depression, nyc depression, millennial depression, professional depression
```

### Burnout × Healthcare × Nationwide
```
Series: Healthcare Heroes Burnout Series

Title: Running on Empty Saving Lives
Subtitle: The Phoenix Protocol: Burnout Recovery for Healthcare Workers

Keywords: healthcare burnout, nurse burnout, physician burnout, medical exhaustion
```

### Overthinking × Millennial × San Francisco
```
Series: San Francisco Overthinking Series

Title: The Founder's Mind Won't Rest
Subtitle: The Phoenix Protocol: A Bay Area Guide to Entrepreneurial Overthinking

Keywords: san francisco overthinking, tech overthinking, startup anxiety, founder mental health
```

---

## Location Expansion Strategy

### Phase 1: Major Markets (10 Locations)
1. Santa Cruz (Gen Z coastal)
2. Brooklyn (Gen Z urban)
3. Austin (Gen Z creative)
4. New York (Millennial professional)
5. Los Angeles (Millennial entertainment)
6. San Francisco (Millennial tech)
7. Boston (Millennial academic)
8. Washington DC (Millennial political)
9. Chicago (Midwest metro)
10. Denver (Mountain West)

### Phase 2: Secondary Markets (10 More)
11. Seattle
12. Portland
13. Nashville
14. Atlanta
15. Miami
16. Phoenix
17. Philadelphia
18. Minneapolis
19. San Diego
20. Dallas

### Phase 3: Hyper-Local (Neighborhoods)
- Brooklyn → Williamsburg, Park Slope, DUMBO
- San Francisco → Mission, Castro, Marina
- Los Angeles → Silver Lake, Venice, West Hollywood

---

## SEO Keyword Pattern

### Formula
```
[location] [topic], [persona] [topic], [related terms]
```

### Example
```
santa cruz anxiety, gen z anxiety help, california mental health, young adult anxiety relief, social anxiety, panic attacks
```

### Keyword Clusters by Topic

| Topic | Primary | Secondary | Long-tail |
|-------|---------|-----------|-----------|
| Anxiety | anxiety relief, anxiety help | panic attacks, social anxiety | how to stop anxiety naturally |
| Depression | depression help, depression recovery | low mood, getting unstuck | how to function with depression |
| Burnout | burnout recovery, exhaustion | work stress, tired all the time | how to recover from burnout |
| Overthinking | stop overthinking, rumination | mental loops, racing thoughts | how to quiet your mind |

---

## Full Title Architecture

```
SERIES NAME:          [Location] [Topic] Series
                      ↓
MAIN TITLE:           [Hook Statement About Topic]
                      ↓
SUBTITLE:             The Phoenix Protocol: A [Location] Guide to [Outcome]
                      ↓
KEYWORDS:             [location topic], [persona topic], [related terms]
```

### Real Example:

```
SERIES NAME:          Santa Cruz Anxiety Series
                      ↓
MAIN TITLE:           Your Anxiety Is Lying to You
                      ↓
SUBTITLE:             The Phoenix Protocol: A Santa Cruz Guide to Acting Before You Feel Ready
                      ↓
KEYWORDS:             santa cruz anxiety, gen z anxiety help, california mental health, young adult anxiety relief
```

---

## Hook Bank (Ready to Use)

### Anxiety Hooks
- "Your Anxiety Is Lying to You"
- "Stop Waiting for Calm"
- "Anxious but Moving"
- "Send the Text While Shaking"
- "Your Nervous System Isn't Broken"
- "Confidence Doesn't Come First"
- "Your Fear Is Not a Stop Sign"
- "Brave Isn't Fearless"
- "The 3-Second Rule for Anxiety"
- "Anxious and Ambitious"
- "Success Doesn't Wait for Calm"
- "The Imposter Syndrome Antidote"
- "Your Anxiety Isn't Laziness"
- "High Stakes Low Calm"

### Depression Hooks
- "Getting Out of Bed Is a Win"
- "Depression Lies About Tomorrow"
- "One Small Move Changes Everything"
- "Success and Sadness Can Coexist"
- "The Weight You Carry Isn't Weakness"
- "Your Career Didn't Break You"
- "Empty Cup Empty Heart"
- "Depressed Parents Raise Strong Kids"
- "Your Brain Chemistry Isn't Destiny"

### Burnout Hooks
- "Hustle Culture Almost Killed Me"
- "You're Not Lazy You're Depleted"
- "The Promotion That Cost Everything"
- "Silicon Valley Stole Your Soul"
- "Running on Empty Saving Lives"
- "The Parent Who Has Nothing Left to Give"
- "Too Tired to Love"
- "Straight A's Aren't Worth Your Sanity"
- "Ministry Shouldn't Kill You"
- "Burnout Isn't a Badge of Honor"

### Overthinking Hooks
- "Your Brain Won't Shut Up"
- "3 AM Thoughts Are Lying to You"
- "Analysis Paralysis Is Killing Your Career"
- "The Founder's Mind Won't Rest"
- "Did I Miss Something"
- "Am I Ruining My Kids"
- "Stop Reading Between the Lines"
- "The Test You Already Passed"
- "Thoughts Are Not Facts"

### People-Pleasing Hooks
- "Stop Shrinking for Other People"
- "Your No Is Not Negotiable"
- "The Yes That's Destroying You"
- "You Can't Save Everyone"
- "Your Kids Need to See You Say No"
- "Love Yourself First"
- "People-Pleasing Is Self-Abandonment"

### Perfectionism Hooks
- "Done Is Better Than Perfect"
- "Your Worth Isn't Your Output"
- "The Perfect Trap Is Killing Your Career"
- "Perfect Care Doesn't Exist"
- "There Is No Perfect Parent"
- "The 4.0 Isn't Worth Your Mental Health"
- "Perfect Is the Enemy of Done"

### Digital Overwhelm Hooks
- "Your Phone Is Not Your Friend"
- "Scroll Hole to Whole Self"
- "Always Connected Never Present"
- "Beyond the EHR"
- "Put the Phone Down First"
- "Your Feed Is Curated to Make You Feel Bad"
- "Unplug Before You Unravel"

### Rejection Sensitivity Hooks
- "Rejection Isn't the End of the Story"
- "The No That Didn't Kill You"
- "Career Rejection Won't Break You"
- "When Patients Push You Away"
- "Your Teen's Rejection Isn't Personal"
- "Fear of Abandonment Doesn't Have to Run Your Relationship"
- "The Rejection Letter Isn't Your Future"
- "Rejection Is Redirection"

### Grief Hooks
- "Loss Doesn't Follow a Timeline"
- "Grief Doesn't Mean Goodbye"
- "Success Doesn't Pause for Grief"
- "The Life That Continues After Loss"
- "When Patients Become Ghosts"
- "The Worst Club No One Wants to Join"
- "Grieving Together Without Growing Apart"
- "Tears and Trust"
- "Grief Is Love with Nowhere to Go"

---

## Quick Reference Card

| Element | Formula | Example |
|---------|---------|---------|
| **Series** | [Location] [Topic] Series | Santa Cruz Anxiety Series |
| **Title** | [Hook < 8 words] | Your Anxiety Is Lying to You |
| **Subtitle** | The Phoenix Protocol: A [Location] Guide to [Outcome] | The Phoenix Protocol: A Santa Cruz Guide to Acting Before You Feel Ready |
| **Keywords** | [location topic], [persona topic], [related] | santa cruz anxiety, gen z anxiety help, california mental health |

---

## Implementation

This system produces:
- **100 unique series** (10 topics × 10 persona/location combos)
- **Clear brand architecture** (Phoenix Protocol umbrella)
- **SEO optimization** (topic + location keywords)
- **Emotional hooks** (memorable, shareable titles)
- **Scalable** (add new locations without restructuring)
