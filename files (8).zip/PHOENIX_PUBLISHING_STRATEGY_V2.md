# Phoenix Protocol Publishing Strategy V2
## Enhanced 1,200-Book Plan Based on Market Research

---

## Part 1: What the Data Shows

### Current Bestseller Title Patterns (2025)

| Pattern | Example | Why It Works |
|---------|---------|--------------|
| **The [Adjective] [Noun]** | The Subtle Art, The Anxious Generation | Pattern interruption, memorable |
| **[Verb] Like a [Expert]** | Think Like a Monk, Steal Like an Artist | Authority transfer |
| **The [Number] [Things]** | The 7 Habits, 12 Rules for Life | Concrete, actionable promise |
| **How to [Action] Without [Obstacle]** | How to Win Friends... | Problem-solution framing |
| **[Outcome]: [Subtitle]** | Atomic Habits: Tiny Changes... | SEO + promise combo |
| **Don't [Common Behavior]** | Don't Believe Everything You Think | Counterintuitive hook |

### Top Mental Health Bestsellers 2025

| Title | Author | Key Selling Point |
|-------|--------|-------------------|
| The Anxious Generation | Jonathan Haidt | Youth + social media angle |
| Beyond Anxiety | Martha Beck | "Creativity spiral" framework |
| The Body Keeps the Score | Van der Kolk | Trauma + neuroscience |
| The Happiness Trap | Russ Harris | ACT therapy framework |
| Notes on a Nervous Planet | Matt Haig | Modern life + anxiety |
| How to Be Enough | Ellen Hendriksen | Perfectionism + adequacy |

### What These Bestsellers Have in Common

1. **Named framework** (not just advice)
2. **Neuroscience/evidence backing** (credibility)
3. **Specific audience** (not "everyone")
4. **Action-oriented subtitle** (what you'll DO)
5. **2-4 word main title** (memorable)

---

## Part 2: Series Strategy Enhancement

### Current Plan Issues

Your current 150-series × 8-book model is **too fragmented** for discoverability.

**Problem:** 150 series means 150 brand-building efforts.

### Recommended: Umbrella Brand + Sub-Series

```
PHOENIX PROTOCOL (Master Brand)
├── PHOENIX RISING (Anxiety - 4 sub-series)
│   ├── For Gen Z (12 books)
│   ├── For Millennials (12 books)
│   ├── For Parents (12 books)
│   └── Workbook Companions (12 books)
├── PHOENIX REBUILDING (Depression - 4 sub-series)
├── PHOENIX CARRYING (Grief - 4 sub-series)
├── PHOENIX HEALING (Trauma - 4 sub-series)
└── PHOENIX THRIVING (Burnout - 4 sub-series)
```

**Benefit:** 5 master series × 4 sub-series × 12 books = 240 core books, each reinforcing the Phoenix Protocol brand.

### Box Set Strategy (Critical for Revenue)

<cite>Research shows readers are 25% more likely to purchase a series in bulk when offered as a set.</cite>

**Create box sets at multiple levels:**

| Level | Contents | Price Point |
|-------|----------|-------------|
| Mini Set | Books 1-3 of a sub-series | $14.99 |
| Complete Sub-Series | All 12 books of one persona | $29.99 |
| Master Collection | All 48 anxiety books | $79.99 |

---

## Part 3: Title Formula for Phoenix

### Current Title
> "Phoenix Raising: Moving Through Anxiety Without Waiting for Calm"

**Analysis:**
- ✅ Good subtitle (action + obstacle framing)
- ⚠️ "Phoenix Raising" doesn't signal the book's topic
- ❌ No persona indicator
- ❌ No named method/framework

### Recommended Title Formula

```
[Action Verb] While Anxious: The Phoenix Protocol for [Persona]
```

Or:

```
The [Number]-[Unit] [Method]: [Promise] ([Persona] Edition)
```

### Enhanced Title Examples by Persona

| Persona | Original | Enhanced Title |
|---------|----------|----------------|
| Gen Z | Phoenix Raising | **Act While Anxious: The Phoenix Protocol for Gen Z** |
| Millennial | Phoenix Raising | **The 3-Second Shift: Stop Waiting for Calm and Start Living (Millennial Edition)** |
| Parents | - | **Raising Unstoppable Kids: The Phoenix Protocol for Anxious Parents** |
| Couples | - | **Love Through the Loop: A Couples Guide to Acting While Anxious** |

### Subtitle Patterns That Convert

Based on bestseller data:

| Pattern | Example |
|---------|---------|
| **How to [Action] Without [Waiting/Struggle]** | How to Move Forward Without Waiting for Calm |
| **A [Number]-[Time] Guide to [Outcome]** | A 12-Week Guide to Acting Through Anxiety |
| **Stop [Pain], Start [Action]** | Stop Waiting, Start Living |
| **The [Unexpected] Path to [Desired Outcome]** | The Counterintuitive Path to Confidence |
| **[Action] Your Way to [State]** | Breathe Your Way to Action |

---

## Part 4: Topic Expansion Based on Market Data

### High-Demand Mental Health Topics (2025)

| Topic | Search Volume | Competition | Recommendation |
|-------|---------------|-------------|----------------|
| Anxiety | Very High | High | ✅ Already covered - good |
| Depression | Very High | High | ✅ Already covered - good |
| Grief | High | Medium | ✅ Already covered - good |
| Burnout | Very High | Medium | ⬆️ Add - underserved |
| Overthinking | Very High | Medium | ⬆️ Add - hot topic |
| People-Pleasing | High | Low | ⬆️ Add - gap in market |
| Perfectionism | High | Medium | ⬆️ Add - Gen Z resonance |
| Digital Wellness | High | Low | ⬆️ Add - youth market |
| Rejection Sensitivity | Medium | Very Low | ⬆️ Add - underserved niche |
| Emotional Dysregulation | Medium | Low | ⬆️ Add - clinician crossover |

### Recommended Topic Matrix (10 Topics)

| Topic | Phoenix Name | Core Message |
|-------|--------------|--------------|
| Anxiety | Phoenix Rising | Act while anxious |
| Depression | Phoenix Moving | Move while heavy |
| Grief | Phoenix Carrying | Carry while grieving |
| Trauma | Phoenix Healing | Heal while remembering |
| Burnout | Phoenix Resting | Rest while responsible |
| Overthinking | Phoenix Quieting | Quiet while thinking |
| People-Pleasing | Phoenix Choosing | Choose while caring |
| Perfectionism | Phoenix Releasing | Release while striving |
| Digital Overwhelm | Phoenix Unplugging | Unplug while connected |
| Rejection Sensitivity | Phoenix Belonging | Belong while vulnerable |

---

## Part 5: Persona Refinement

### Current Personas
- Gen Z
- Millennial
- Gen X
- Boomer
- Universal

### Enhanced Persona Matrix

| Persona | Age Range | Core Pain | Platform | Purchase Behavior |
|---------|-----------|-----------|----------|-------------------|
| **Gen Z** | 18-28 | Identity anxiety, social comparison | TikTok, BookTok | Digital-first, binge readers |
| **Gen Alpha Parents** | 28-45 | Parenting anxious kids | Instagram, podcasts | Buy for kids + self |
| **Millennial Professionals** | 30-42 | Work-life burnout | LinkedIn, podcasts | Career advancement framing |
| **Healthcare Workers** | 25-55 | Compassion fatigue | Professional networks | Evidence-based preference |
| **Couples** | 25-55 | Relationship anxiety | Relationship apps | Joint purchase |
| **College Students** | 18-24 | Academic + social anxiety | TikTok, campus | Semester-based buying |
| **New Parents** | 25-40 | Postpartum, sleep deprivation | Parenting apps | Gift purchases |
| **Caregivers** | 35-65 | Caregiver burnout | Support groups | High intent, underserved |
| **Faith-Based** | All ages | Faith + mental health integration | Church networks | Community purchase |
| **Secular/Scientific** | All ages | Evidence-based only | Science podcasts | Credentialed preference |

### New Book Count: 10 Topics × 10 Personas × 1 Book = 100 Core Books

With 12 chapter variations per book = **1,200 unique audiobook paths**

This is **much more manageable** than 1,200 separate book plans.

---

## Part 6: SEO-Optimized Title Templates

### For Amazon Discovery

```
Main Title: 4-6 words, memorable, brandable
Subtitle: 12-20 words, keyword-rich, benefit-focused
```

### Keyword Clusters to Include in Subtitles

| Topic | Primary Keywords | Secondary Keywords |
|-------|------------------|-------------------|
| Anxiety | anxiety relief, calm, nervous system | panic, worry, stress, overthinking |
| Depression | depression, low mood, energy | motivation, getting unstuck, heavy |
| Grief | grief, loss, healing | mourning, letting go, remembrance |
| Burnout | burnout, exhaustion, recovery | rest, boundaries, sustainable |
| Overthinking | overthinking, rumination, mental loops | quiet mind, peace, clarity |

### Complete Title Templates

**Template 1: Action + Framework**
```
[Verb] While [State]: The Phoenix Protocol for [Persona]
A [Number]-Step Guide to [Outcome] Without [Obstacle]
```

Example:
> **Act While Anxious: The Phoenix Protocol for Gen Z**
> *A 12-Step Guide to Moving Forward Without Waiting for Calm*

**Template 2: Problem + Promise**
```
The [Problem] [Solution]: [Named Method]
How to [Outcome] When [Obstacle] Won't Stop
```

Example:
> **The Anxiety Paradox: The Phoenix Protocol**
> *How to Build Confidence When Your Mind Won't Quiet*

**Template 3: Counterintuitive Hook**
```
Stop [Expected Action]: [Unexpected Truth]
The [Adjective] Guide to [Outcome] for [Persona]
```

Example:
> **Stop Fighting Anxiety: Your Nervous System Isn't the Enemy**
> *The Compassionate Guide to Acting Through Fear for Millennials*

---

## Part 7: Companion Product Strategy

### What's Selling Beyond Books

| Product Type | Amazon Demand | Recommendation |
|--------------|---------------|----------------|
| Workbooks/Journals | Very High | ✅ Create companion workbooks |
| Vision Board Kits | High | Consider branded versions |
| Card Decks | Medium | 52-card anxiety tools deck |
| Audio Programs | Very High | ✅ Already doing - expand |
| Coloring Books | High | Mindfulness coloring companion |

### Workbook Companion Strategy

For each core book, create:

1. **12-Week Workbook** - Exercises from each chapter
2. **Quick Reference Card** - Laminated 3×5 breathing/grounding
3. **Audio Companion** - Guided exercises only (no narration)

### Pricing Strategy

| Product | Format | Price | Bundle Price |
|---------|--------|-------|--------------|
| Core Book | Audiobook | $14.99 | - |
| Core Book | eBook | $9.99 | - |
| Workbook | Print | $12.99 | - |
| Book + Workbook | Bundle | - | $19.99 |
| Complete Protocol | All formats | - | $39.99 |

---

## Part 8: Release Strategy

### Rapid Release (Recommended)

<cite>Authors with rapid release strategies see up to 40% higher series completion rates.</cite>

**Phase 1: Launch Wave (Month 1)**
- Release 3 core books simultaneously (Anxiety × Gen Z, Millennial, Universal)
- Book 1 priced at $2.99 or free for 5 days
- Books 2-3 at full price

**Phase 2: Momentum (Months 2-3)**
- Release 1 book per week
- Alternate between topics and personas
- Create "new release" visibility algorithm boost

**Phase 3: Box Sets (Month 4)**
- Bundle Phase 1 books into box sets
- Price at 40% discount vs. individual
- Use box sets for advertising

**Phase 4: Workbook Wave (Month 5-6)**
- Release workbook companions
- Cross-promote with existing buyers
- Email sequence: "You bought the book, now do the work"

---

## Part 9: Revised 1,200-Book Matrix

### New Structure

| Layer | Count | Example |
|-------|-------|---------|
| Topics | 10 | Anxiety, Depression, Grief, etc. |
| Personas | 10 | Gen Z, Millennial, Healthcare, etc. |
| Core Books | 100 | One per topic × persona |
| Chapter Variations | 12 | Personalized chapter content |
| Total Unique Paths | 1,200 | Different audiobook experiences |

### This Approach Advantages

1. **100 plans, not 1,200** - More manageable
2. **Clear brand architecture** - Phoenix Protocol → Topic → Persona
3. **Box set friendly** - Natural bundling opportunities
4. **Discoverability** - Series pages on Amazon
5. **Cross-promotion** - Buy one, see all

---

## Part 10: Revised Title Matrix (Sample)

### Anxiety Series

| Persona | Main Title | Subtitle |
|---------|------------|----------|
| Gen Z | **Act While Anxious** | The Phoenix Protocol: A Gen Z Guide to Moving Forward Without Waiting for Calm |
| Millennial | **The 3-Second Shift** | The Phoenix Protocol: How Busy Professionals Break the Anxiety Loop |
| Healthcare | **Steady Hands, Racing Mind** | The Phoenix Protocol for Healthcare Workers Living with Anxiety |
| Parents | **Raising Brave Kids** | The Phoenix Protocol: A Parent's Guide to Modeling Calm in Chaos |
| Couples | **Love Through the Loop** | The Phoenix Protocol: Acting Together When Anxiety Pulls Apart |
| College | **Campus Calm** | The Phoenix Protocol: A Student's Guide to Thriving While Anxious |
| Faith-Based | **Peace Beyond Understanding** | The Phoenix Protocol: Faith-Centered Strategies for Anxious Believers |
| Secular | **The Neuroscience of Now** | The Phoenix Protocol: Evidence-Based Tools for Acting Through Anxiety |
| Caregivers | **Steady as You Go** | The Phoenix Protocol: Managing Anxiety While Caring for Others |
| Universal | **Phoenix Rising** | The Phoenix Protocol: A Complete Guide to Acting While Anxious |

### Depression Series

| Persona | Main Title | Subtitle |
|---------|------------|----------|
| Gen Z | **Move While Heavy** | The Phoenix Protocol: A Gen Z Guide to Action When Everything Feels Hard |
| Millennial | **The Weight You Carry** | The Phoenix Protocol: Moving Forward When Motivation Won't Come |
| Healthcare | **When the Helper Needs Help** | The Phoenix Protocol for Healthcare Workers Facing Depression |
| Universal | **Phoenix Moving** | The Phoenix Protocol: A Complete Guide to Action Through Depression |

---

## Part 11: Implementation Roadmap

### Week 1-2: Foundation
- Finalize 10 topics × 10 personas matrix
- Create title style guide
- Design cover template system
- Build Book Plan schema (already done)

### Week 3-4: Content Architecture
- Extract 12 core experiences per topic
- Build persona-specific scene libraries
- Create exercise library (universal)
- Document voice guidelines per persona

### Month 2: Core Production
- Generate 100 Book Plans
- Validate all plans
- Assemble 100 core books
- QA pass

### Month 3: Audio Production
- Record/generate all audiobooks
- Create chapter variations
- Build 1,200 unique audio paths
- QA audio

### Month 4: Launch
- Phase 1 release (3 books)
- Gather reviews
- Optimize listings
- Begin advertising

### Month 5-6: Scale
- Weekly releases
- Box set creation
- Workbook development
- Cross-promotion campaigns

---

## Summary: Key Changes

| Before | After |
|--------|-------|
| 150 series × 8 books | 10 topics × 10 personas × 1 core book |
| Generic titles | SEO-optimized, persona-specific titles |
| Single product | Core book + workbook + audio companions |
| All-at-once release | Rapid release strategy with box sets |
| Flat structure | Umbrella brand + sub-series hierarchy |

**Same 1,200 unique experiences. Better discoverability. Stronger brand.**
