# Plan Validator Specification

## Overview

The Plan Validator runs **before assembly**. It catches errors at the planning stage, not the rendering stage. If a plan fails validation, no book is generated.

**Rule: Invalid plan = build fails. No exceptions. No fallbacks.**

---

## Validation Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    PLAN VALIDATION FLOW                      │
└─────────────────────────────────────────────────────────────┘

                    ┌──────────────┐
                    │  Book Plan   │
                    │    (YAML)    │
                    └──────┬───────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   Schema     │
                    │  Validation  │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
              ▼            ▼            ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │ Required │ │  Type    │ │  Format  │
        │  Fields  │ │  Check   │ │  Check   │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
              │            │            │
              └────────────┼────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │  Reference   │
                    │  Validation  │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
              ▼            ▼            ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │Experience│ │  Scene   │ │ Exercise │
        │  Exists  │ │  Exists  │ │  Exists  │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
              │            │            │
              └────────────┼────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │  Constraint  │
                    │  Validation  │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
              ▼            ▼            ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │   No     │ │ Position │ │ Safety   │
        │  Dupes   │ │  Valid   │ │  Rules   │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
              │            │            │
              └────────────┼────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   Result     │
                    └──────┬───────┘
                           │
              ┌────────────┴────────────┐
              │                         │
              ▼                         ▼
        ┌──────────┐            ┌──────────────┐
        │  VALID   │            │   INVALID    │
        │          │            │              │
        │ → Build  │            │ → Error List │
        └──────────┘            └──────────────┘
```

---

## Validation Levels

### Level 1: Schema Validation

Checks structural correctness of the plan file.

```python
def validate_schema(plan: dict) -> ValidationResult:
    errors = []
    
    # Required top-level fields
    required = ["schema_version", "book_id", "topic", "persona", "character", "chapters"]
    for field in required:
        if field not in plan:
            errors.append(SchemaError(f"Missing required field: {field}"))
    
    # Schema version check
    if plan.get("schema_version") != "3.0":
        errors.append(SchemaError(f"Invalid schema version: {plan.get('schema_version')}"))
    
    # Type checks
    if not isinstance(plan.get("chapters"), list):
        errors.append(SchemaError("'chapters' must be a list"))
    
    if len(plan.get("chapters", [])) != 12:
        errors.append(SchemaError(f"Must have exactly 12 chapters, got {len(plan.get('chapters', []))}"))
    
    # Chapter validation
    for i, chapter in enumerate(plan.get("chapters", [])):
        chapter_errors = validate_chapter_schema(chapter, i + 1)
        errors.extend(chapter_errors)
    
    return ValidationResult(valid=len(errors) == 0, errors=errors)
```

### Level 2: Reference Validation

Checks that all referenced components exist in libraries.

```python
def validate_references(plan: dict, libraries: Libraries) -> ValidationResult:
    errors = []
    
    # Character reference
    if not libraries.characters.exists(plan["character"]["id"]):
        errors.append(ReferenceError(
            f"Character not found: {plan['character']['id']}"
        ))
    
    # Chapter references
    for chapter in plan["chapters"]:
        # Experience reference
        if not libraries.experiences.exists(plan["topic"], chapter["experience_id"]):
            errors.append(ReferenceError(
                f"Chapter {chapter['chapter']}: Experience not found: {chapter['experience_id']}"
            ))
        
        # Scene reference (if not null)
        if chapter["scene"]["id"] is not None:
            if not libraries.scenes.exists(plan["topic"], plan["persona"], chapter["scene"]["id"]):
                errors.append(ReferenceError(
                    f"Chapter {chapter['chapter']}: Scene not found: {chapter['scene']['id']}"
                ))
        
        # Exercise references
        for exercise in chapter.get("exercises", []):
            if not libraries.exercises.exists(exercise["id"]):
                errors.append(ReferenceError(
                    f"Chapter {chapter['chapter']}: Exercise not found: {exercise['id']}"
                ))
        
        # Reflection reference
        if chapter.get("reflection_id") is not None:
            if not libraries.reflections.exists(chapter["reflection_id"]):
                errors.append(ReferenceError(
                    f"Chapter {chapter['chapter']}: Reflection not found: {chapter['reflection_id']}"
                ))
        
        # Integration reference
        if chapter.get("integration_id") is not None:
            if not libraries.bridges.exists(chapter["integration_id"]):
                errors.append(ReferenceError(
                    f"Chapter {chapter['chapter']}: Bridge not found: {chapter['integration_id']}"
                ))
        
        # Closing reference
        if chapter.get("closing_id") is not None:
            if not libraries.closings.exists(plan["topic"], plan["persona"], chapter["closing_id"]):
                errors.append(ReferenceError(
                    f"Chapter {chapter['chapter']}: Closing not found: {chapter['closing_id']}"
                ))
    
    return ValidationResult(valid=len(errors) == 0, errors=errors)
```

### Level 3: Constraint Validation

Checks logical rules and constraints.

```python
def validate_constraints(plan: dict) -> ValidationResult:
    errors = []
    
    # Rule 1: No duplicate experience IDs
    experience_ids = [ch["experience_id"] for ch in plan["chapters"]]
    if len(experience_ids) != len(set(experience_ids)):
        dupes = [x for x in experience_ids if experience_ids.count(x) > 1]
        errors.append(ConstraintError(
            f"Duplicate experience IDs: {set(dupes)}"
        ))
    
    # Rule 2: Chapter numbers must be sequential 1-12
    chapter_nums = [ch["chapter"] for ch in plan["chapters"]]
    if chapter_nums != list(range(1, 13)):
        errors.append(ConstraintError(
            f"Chapter numbers must be 1-12 in sequence, got: {chapter_nums}"
        ))
    
    # Rule 3: Experience IDs must match chapter numbers
    for chapter in plan["chapters"]:
        expected_prefix = f"exp_{chapter['chapter']:02d}_"
        if not chapter["experience_id"].startswith(expected_prefix):
            errors.append(ConstraintError(
                f"Chapter {chapter['chapter']}: experience_id should start with '{expected_prefix}'"
            ))
    
    # Rule 4: Scene positions must be valid
    for chapter in plan["chapters"]:
        if chapter["scene"]["id"] is not None:
            if chapter["scene"]["position"] is None:
                errors.append(ConstraintError(
                    f"Chapter {chapter['chapter']}: scene.id is set but scene.position is null"
                ))
    
    # Rule 5: If scene.position is set, scene.id must be set
    for chapter in plan["chapters"]:
        if chapter["scene"]["position"] is not None:
            if chapter["scene"]["id"] is None:
                errors.append(ConstraintError(
                    f"Chapter {chapter['chapter']}: scene.position is set but scene.id is null"
                ))
    
    # Rule 6: Exercise positions must be unique within chapter
    for chapter in plan["chapters"]:
        positions = [ex["position"] for ex in chapter.get("exercises", [])]
        if len(positions) != len(set(positions)):
            errors.append(ConstraintError(
                f"Chapter {chapter['chapter']}: Duplicate exercise positions"
            ))
    
    # Rule 7: Topic/persona consistency
    valid_combos = {
        "anxiety": ["gen_z", "millennial", "gen_x", "boomer", "universal"],
        "depression": ["gen_z", "millennial", "gen_x", "boomer", "universal"],
        "grief": ["gen_z", "millennial", "gen_x", "boomer", "universal"],
    }
    if plan["persona"] not in valid_combos.get(plan["topic"], []):
        errors.append(ConstraintError(
            f"Invalid topic/persona combination: {plan['topic']}/{plan['persona']}"
        ))
    
    # Rule 8: No empty strings (use null instead)
    for chapter in plan["chapters"]:
        if chapter["scene"]["id"] == "":
            errors.append(ConstraintError(
                f"Chapter {chapter['chapter']}: scene.id cannot be empty string, use null"
            ))
        if chapter["scene"]["position"] == "":
            errors.append(ConstraintError(
                f"Chapter {chapter['chapter']}: scene.position cannot be empty string, use null"
            ))
    
    return ValidationResult(valid=len(errors) == 0, errors=errors)
```

### Level 4: Safety Validation

Checks content safety rules specific to therapeutic material.

```python
def validate_safety(plan: dict, libraries: Libraries) -> ValidationResult:
    errors = []
    warnings = []
    
    # Rule 1: Chapter 12 should have an integration bridge
    ch12 = plan["chapters"][11]  # 0-indexed
    if ch12.get("integration_id") is None:
        warnings.append(SafetyWarning(
            "Chapter 12 has no integration bridge - ending may feel abrupt"
        ))
    
    # Rule 2: Practice chapters (4, 7, 8) should have exercises
    practice_chapters = [4, 7, 8]
    for ch_num in practice_chapters:
        ch = plan["chapters"][ch_num - 1]
        if len(ch.get("exercises", [])) == 0:
            warnings.append(SafetyWarning(
                f"Chapter {ch_num} is a practice chapter but has no exercises"
            ))
    
    # Rule 3: Slip chapter (10) should have recovery reflection
    ch10 = plan["chapters"][9]
    if ch10.get("reflection_id") is None:
        warnings.append(SafetyWarning(
            "Chapter 10 (slips) should have recovery reflection"
        ))
    
    # Rule 4: Check for cure language in referenced content
    for chapter in plan["chapters"]:
        experience = libraries.experiences.get(plan["topic"], chapter["experience_id"])
        if experience and contains_cure_language(experience.content):
            errors.append(SafetyError(
                f"Chapter {chapter['chapter']}: Experience contains cure language"
            ))
    
    # Rule 5: Validate exercise safety claims
    for chapter in plan["chapters"]:
        for exercise in chapter.get("exercises", []):
            ex = libraries.exercises.get(exercise["id"])
            if ex and contains_cure_promise(ex.purpose):
                errors.append(SafetyError(
                    f"Chapter {chapter['chapter']}: Exercise {exercise['id']} contains cure promise"
                ))
    
    return ValidationResult(
        valid=len(errors) == 0, 
        errors=errors, 
        warnings=warnings
    )

def contains_cure_language(content: str) -> bool:
    """Check for language that promises cure or elimination of anxiety."""
    cure_phrases = [
        "will eliminate",
        "will cure",
        "will fix",
        "will make anxiety go away",
        "will stop anxiety",
        "you'll never feel anxious again",
        "permanent solution",
        "complete recovery",
    ]
    content_lower = content.lower()
    return any(phrase in content_lower for phrase in cure_phrases)

def contains_cure_promise(content: str) -> bool:
    """Check for exercise purposes that promise outcomes."""
    promise_phrases = [
        "this will help you",
        "you will feel calm",
        "this fixes",
        "this eliminates",
    ]
    content_lower = content.lower()
    return any(phrase in content_lower for phrase in promise_phrases)
```

---

## Error Types

```python
class ValidationError:
    """Base class for validation errors."""
    level: str  # "schema", "reference", "constraint", "safety"
    message: str
    location: str  # Where in the plan
    severity: str  # "error" or "warning"

class SchemaError(ValidationError):
    """Plan structure is invalid."""
    level = "schema"
    severity = "error"

class ReferenceError(ValidationError):
    """Referenced component doesn't exist."""
    level = "reference"
    severity = "error"

class ConstraintError(ValidationError):
    """Logical rule violated."""
    level = "constraint"
    severity = "error"

class SafetyError(ValidationError):
    """Content safety rule violated."""
    level = "safety"
    severity = "error"

class SafetyWarning(ValidationError):
    """Content safety recommendation not followed."""
    level = "safety"
    severity = "warning"
```

---

## Validation Result

```python
@dataclass
class ValidationResult:
    valid: bool
    errors: List[ValidationError]
    warnings: List[ValidationError] = field(default_factory=list)
    
    def to_report(self) -> str:
        """Generate human-readable validation report."""
        lines = []
        
        if self.valid:
            lines.append("✅ PLAN VALID")
        else:
            lines.append("❌ PLAN INVALID")
        
        if self.errors:
            lines.append(f"\n{len(self.errors)} Error(s):")
            for error in self.errors:
                lines.append(f"  [{error.level.upper()}] {error.message}")
        
        if self.warnings:
            lines.append(f"\n{len(self.warnings)} Warning(s):")
            for warning in self.warnings:
                lines.append(f"  [{warning.level.upper()}] {warning.message}")
        
        return "\n".join(lines)
```

---

## CLI Usage

```bash
# Validate a single plan
$ phoenix validate plans/anxiety_genz_001.yaml

✅ PLAN VALID
2 Warning(s):
  [SAFETY] Chapter 4 has no closing_id - consider adding persona-specific closing

# Validate all plans
$ phoenix validate plans/

Validating 1200 plans...
✅ 1198 valid
❌ 2 invalid

Invalid plans:
  - anxiety_genz_042.yaml: [REFERENCE] Scene not found: scene_04_typo
  - grief_boomer_003.yaml: [CONSTRAINT] Duplicate experience IDs: {exp_05_cost}

# Validate with strict mode (warnings are errors)
$ phoenix validate --strict plans/anxiety_genz_001.yaml

❌ PLAN INVALID
1 Error(s):
  [SAFETY] Chapter 4 has no closing_id - consider adding persona-specific closing
```

---

## Integration with Build

```python
def build_book(plan_path: str) -> Book:
    """Build a book from a plan. Fails on invalid plan."""
    
    # Load plan
    plan = load_plan(plan_path)
    
    # Validate (all levels)
    result = validate_plan(plan)
    
    if not result.valid:
        # Hard fail - no book generated
        raise BuildError(
            f"Plan validation failed:\n{result.to_report()}"
        )
    
    # Log warnings but continue
    if result.warnings:
        logger.warning(f"Plan has warnings:\n{result.to_report()}")
    
    # Proceed to assembly
    return assemble(plan)
```

---

## Summary: What Validation Catches

| Level | Catches | Example |
|-------|---------|---------|
| Schema | Structure errors | Missing `chapters` field |
| Reference | Missing components | Scene ID doesn't exist in library |
| Constraint | Logic violations | Duplicate experience IDs |
| Safety | Content issues | Cure language in experience |

**If validation passes, assembly cannot fail due to missing or invalid content.**

That's the guarantee.
