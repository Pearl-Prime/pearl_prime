# Component Libraries Specification

## Overview

Component Libraries are **finite, bounded catalogs** of content that can appear in books. Every piece of content must exist in a library before it can be referenced in a Book Plan.

**Rule: If it's not in a library, it cannot appear in a book.**

---

## Library Structure

```
libraries/
├── experiences/
│   ├── anxiety/
│   │   ├── exp_01_recognition.md
│   │   ├── exp_02_origin.md
│   │   ├── exp_03_cost_self.md
│   │   ├── exp_04_reframe.md
│   │   ├── exp_05_cost_waiting.md
│   │   ├── exp_06_end_war.md
│   │   ├── exp_07_small_moves.md
│   │   ├── exp_08_loud.md
│   │   ├── exp_09_automatic.md
│   │   ├── exp_10_slips.md
│   │   ├── exp_11_identity.md
│   │   └── exp_12_forward.md
│   ├── depression/
│   │   └── [same 12 files]
│   └── grief/
│       └── [same 12 files]
├── scenes/
│   ├── anxiety/
│   │   ├── gen_z/
│   │   │   ├── scene_02_classroom_memory.yaml
│   │   │   ├── scene_04_text_send.yaml
│   │   │   ├── scene_06_ramen_text.yaml
│   │   │   ├── scene_08_coffee_shop.yaml
│   │   │   ├── scene_09_bonfire.yaml
│   │   │   ├── scene_10_verve_freeze.yaml
│   │   │   └── scene_11_open_mic.yaml
│   │   └── millennial/
│   │       ├── scene_02_meeting_memory.yaml
│   │       ├── scene_04_slack_message.yaml
│   │       └── ...
│   └── [other topics]
├── exercises/
│   ├── breathing/
│   │   ├── breath_box_4444.yaml
│   │   ├── breath_46.yaml
│   │   └── breath_478.yaml
│   ├── grounding/
│   │   ├── ground_54321.yaml
│   │   ├── ground_feet.yaml
│   │   └── ground_object.yaml
│   └── awareness/
│       ├── check_in_3_second.yaml
│       └── body_scan.yaml
├── reflections/
│   ├── refl_03_notice.md
│   ├── refl_04_notice_signal.md
│   └── refl_10_slip_recovery.md
├── bridges/
│   ├── bridge_forward_open.md
│   ├── bridge_forward_soft.md
│   └── bridge_forward_practice.md
├── closings/
│   ├── anxiety/
│   │   ├── gen_z/
│   │   │   ├── close_04_genz.md
│   │   │   └── close_12_final.md
│   │   └── millennial/
│   └── [other topics]
├── intros/
│   ├── box_breath_intro.md
│   ├── box_breath_intro_millennial.md
│   ├── breath_46_intro.md
│   └── breath_478_intro.md
├── front_matter/
│   ├── a0/
│   │   ├── a0_genz_anxiety.md
│   │   └── a0_millennial_anxiety.md
│   └── a1/
│       ├── a1_genz_anxiety.md
│       └── a1_millennial_anxiety.md
├── back_matter/
│   └── conclusions/
│       ├── conclusion_genz_anxiety.md
│       └── conclusion_millennial_anxiety.md
└── characters/
    ├── sam.yaml
    ├── alex.yaml
    ├── jordan.yaml
    └── taylor.yaml
```

---

## Component Types

### 1. Experiences (12 per topic)

Core chapter content. Topic-specific, persona-agnostic.

**Naming Convention:** `exp_{NN}_{slug}.md`

**File Format:** Markdown with section markers

```markdown
# Experience: Recognition

<!-- SECTION: opening -->
You're sitting in the library, third floor, the quiet section.

The post is written. A real one. About the thing you've been thinking about for weeks.
<!-- /SECTION: opening -->

<!-- SECTION: core_insight -->
There's a sentence that's been running your decisions for years.

The sentence is:

*"Once I'm not anxious, then I'll do it."*
<!-- /SECTION: core_insight -->

<!-- SECTION: examples -->
Maybe you say it differently:

*"Once I stop overthinking, I'll post."*
*"Once I feel calm, I'll send the message."*
<!-- /SECTION: examples -->

<!-- SCENE_SOCKET: after_section_1 -->

<!-- SECTION: body_teaching -->
The body learns through repetition.

Each time you feel the tightening—and then stop—you're teaching it something.
<!-- /SECTION: body_teaching -->

<!-- EXERCISE_SOCKET: end -->

<!-- REFLECTION_SOCKET -->

<!-- CLOSING_SOCKET -->
```

**Section Markers:**
- `<!-- SECTION: name -->` - Named content section
- `<!-- SCENE_SOCKET: position -->` - Where scenes can be injected
- `<!-- EXERCISE_SOCKET: position -->` - Where exercises can be injected
- `<!-- REFLECTION_SOCKET -->` - Where reflection goes (if any)
- `<!-- CLOSING_SOCKET -->` - Where persona closing goes (if any)

### Complete Experience List (Anxiety)

| ID | Title | Purpose |
|----|-------|---------|
| exp_01_recognition | The Sentence | Name the trap |
| exp_02_origin | Where It Came From | Understand the source |
| exp_03_cost_self | What It's Done to You | See impact on identity |
| exp_04_reframe | Anxiety as Information | Shift perspective |
| exp_05_cost_waiting | What Waiting Costs | See time cost |
| exp_06_end_war | Stop Fighting | End internal conflict |
| exp_07_small_moves | Small Moves | Begin action |
| exp_08_loud | When It Gets Loud | Handle high volume |
| exp_09_automatic | When It Becomes Automatic | Recognize progress |
| exp_10_slips | When You Slip | Handle setbacks |
| exp_11_identity | Who You're Becoming | Identity shift |
| exp_12_forward | From Here | Open ending |

---

### 2. Scenes (6-8 per topic × persona)

Narrative vignettes that make content concrete. Topic AND persona specific.

**Naming Convention:** `scene_{NN}_{slug}.yaml`

**File Format:** YAML with content and metadata

```yaml
# Scene: Text Send
id: "scene_04_text_send"
topic: "anxiety"
persona: "gen_z"
chapter_target: 4
position_default: "after_section_2"

character_slot: true  # Will use plan's character

content: |
  ---
  
  Last Tuesday. The group chat deciding on weekend plans.
  
  You had an idea — that new ramen place on Pacific.
  
  Chest tight. Thumbs hovering.
  
  *What if they think it's basic. What if someone already suggested it. What if they just... don't respond.*
  
  You typed it anyway: "what about that ramen spot by the boardwalk?"
  
  Sent.
  
  Heart pounding. Watching for the typing dots.
  
  Then: "ooh yes" "I've been wanting to try that" "down"
  
  The anxiety didn't leave before you sent it.
  
  You just stopped waiting for it to.
  
  ---

# Alternate content for different emotional contexts
variants:
  high_stakes:
    content: |
      ---
      The email to your professor. Office hours request.
      ...
      ---
```

### Complete Scene List (Anxiety × Gen Z)

| ID | Chapter | Description |
|----|---------|-------------|
| scene_02_classroom_memory | 2 | 8th grade hand-down moment |
| scene_04_text_send | 4 | Group chat ramen suggestion |
| scene_06_ramen_text | 6 | Same scene, different framing |
| scene_08_coffee_shop | 8 | Pacific Ave coffee shop typing |
| scene_09_bonfire | 9 | Beach bonfire typing confidence |
| scene_10_verve_freeze | 10 | Verve laptop freeze moment |
| scene_11_open_mic | 11 | Lulu Carpenter's open mic |

---

### 3. Exercises (8 families)

Somatic practices with detailed instructions. Universal across topics/personas.

**Naming Convention:** `{category}_{slug}.yaml`

**File Format:** YAML with structured exercise content

```yaml
# Exercise: Box Breathing
id: "breath_box_4444"
category: "breathing"
name: "Box Breathing (4-4-4-4)"
duration_seconds: 60
difficulty: "beginner"

# Purpose statement (not a cure promise)
purpose: |
  Proof the body can breathe, be present, attend — **while the sensation remains**.

# Pre-exercise framing
framing: |
  But first — what this practice **is not**:
  
  Not a fix.
  Not a cure.
  Not designed to make the sensation leave.
  
  This is **proof**.

# Exercise instructions
instructions: |
  The body breathes in a square.
  
  **Inhale for 4.**
  **Hold for 4.**
  **Exhale for 4.**
  **Hold for 4.**
  
  For one minute. Maybe two.
  
  Not to fix.
  
  To **observe**.

# Guided version with counts
guided: |
  **Begin.**
  
  Find comfort. Eyes open or closed.
  
  **Inhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**
  **Exhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**
  
  **Again.**
  
  **Inhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**
  **Exhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**
  
  **Once more.**
  
  **Inhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**
  **Exhale... 2, 3, 4.**
  **Hold... 2, 3, 4.**

# Post-exercise debrief
debrief: |
  Now notice:
  
  **Was the sensation present while breathing?**
  
  Perhaps.
  
  But see:
  
  **The body just moved through a pattern while the sensation was there.**
  
  It didn't wait for it to leave.
  It didn't need calm first.
  It simply... breathed.
  
  The body acted while anxious.
  
  **That's proof.**

# Audio cues (for TTS)
audio_cues:
  pre_pause: 2
  between_rounds: 1
  post_pause: 4
```

### Complete Exercise List

| ID | Category | Name | Duration |
|----|----------|------|----------|
| breath_box_4444 | breathing | Box Breathing (4-4-4-4) | 60s |
| breath_46 | breathing | Extended Exhale (4-6) | 45s |
| breath_478 | breathing | 4-7-8 Breath | 90s |
| ground_54321 | grounding | 5-4-3-2-1 Grounding | 120s |
| ground_feet | grounding | Feet Grounding | 30s |
| ground_object | grounding | Object Focus | 60s |
| check_in_3_second | awareness | 3-Second Check-In | 15s |
| body_scan | awareness | Body Scan | 180s |

---

### 4. Reflections (4 styles)

Brief reflection prompts. Positioned after key content.

**Naming Convention:** `refl_{NN}_{slug}.md`

**File Format:** Markdown

```markdown
# Reflection: Notice

---

Then they choose a gentler next move instead of bracing. A small shift arrives, almost quiet, but real, they press their feet into the floor until contact feels certain. They note what helped, a thread to pick up next time.

---
```

### Complete Reflection List

| ID | Chapter | Focus |
|----|---------|-------|
| refl_03_notice | 3 | Notice without fixing |
| refl_04_notice_signal | 4 | Notice anxiety as signal |
| refl_10_slip_recovery | 10 | Recovery from slip |
| refl_12_forward | 12 | Looking forward |

---

### 5. Bridges (3 types)

Integration content for chapter endings.

**Naming Convention:** `bridge_{slug}.md`

**File Format:** Markdown

```markdown
# Bridge: Forward Open

This isn't the end.

**It's the beginning.**

You've learned how to act while anxious.
You've built the new pattern.
You've shifted your identity.

And now —

**You get to live.**

Not perfectly.
Not without anxiety.
But... **fully.**

While anxious.
```

### Complete Bridge List

| ID | Tone | Use Case |
|----|------|----------|
| bridge_forward_open | Open, non-conclusive | Default ending |
| bridge_forward_soft | Gentle, supportive | Sensitive personas |
| bridge_forward_practice | Action-oriented | Practice-heavy variants |

---

### 6. Characters (4 base characters)

Character definitions for scene injection.

**Naming Convention:** `{name}.yaml`

**File Format:** YAML

```yaml
# Character: Sam
id: "sam"
name: "Sam"
pronouns:
  subject: "they"
  object: "them"
  possessive: "their"
  reflexive: "themselves"

# Character traits for scene consistency
traits:
  - gender_neutral
  - young_adult
  - relatable
  - everyname

# Usage notes
notes: |
  Sam is the default character for Gen Z content.
  Gender-neutral, short name, universally relatable.
  Use for scenes where specific identity isn't important.
```

### Complete Character List

| ID | Name | Pronouns | Primary Use |
|----|------|----------|-------------|
| sam | Sam | they/them | Gen Z default |
| alex | Alex | they/them | Millennial default |
| jordan | Jordan | they/them | Gen X default |
| taylor | Taylor | they/them | Universal default |

---

### 7. Closings (persona-specific)

Chapter-end content tailored to persona.

**Naming Convention:** `close_{NN}_{persona}.md`

**File Format:** Markdown

```markdown
# Closing: Chapter 4 Gen Z

---

Three weeks of this.

You asked that question in the UCSC lecture hall while your voice shook.

You posted that photo of your pottery project while your stomach churned.

You showed up to the beach bonfire while your mind listed everything that could go wrong.

Small things. None of them heroic.

But something shifted.

---
```

---

### 8. Front Matter

Pre-chapter content (A0, A1).

**Naming Convention:** `a{N}_{persona}_{topic}.md`

### 9. Back Matter

Post-chapter content (conclusions, appendices).

**Naming Convention:** `conclusion_{persona}_{topic}.md`

---

## Adding New Components

### Process

1. **Create file in correct location**
2. **Follow naming convention exactly**
3. **Include all required fields**
4. **Run validator**
5. **Add to component registry**

### Component Registry

Every library maintains a `_registry.yaml`:

```yaml
# libraries/exercises/_registry.yaml
version: "3.0"
last_updated: "2026-01-19"

components:
  - id: "breath_box_4444"
    file: "breathing/breath_box_4444.yaml"
    status: "active"
    
  - id: "breath_46"
    file: "breathing/breath_46.yaml"
    status: "active"
    
  - id: "breath_old_version"
    file: "breathing/breath_old.yaml"
    status: "deprecated"
    replaced_by: "breath_box_4444"
```

---

## Validation Rules

1. **All IDs must be unique across their library**
2. **All files must follow naming conventions**
3. **All required fields must be present**
4. **No orphan files** (must be in registry)
5. **No broken references** (all IDs must resolve)
6. **Content must pass safety checks**

---

## Summary: The Finite Catalog

| Library | Count | Pattern |
|---------|-------|---------|
| Experiences | 12 × topics | One per chapter per topic |
| Scenes | ~8 × topics × personas | Narrative vignettes |
| Exercises | 8 | Universal somatic practices |
| Reflections | 4 | Brief prompts |
| Bridges | 3 | Integration endings |
| Characters | 4 | Named characters |
| Closings | varies | Persona-specific |
| Front Matter | varies | Per book type |
| Back Matter | varies | Per book type |

**Total for one topic × one persona:** ~30 unique components
**Total for full system:** ~500 canonical components

That's it. No more. No less. No runtime generation.
