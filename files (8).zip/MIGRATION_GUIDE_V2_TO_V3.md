# Migration Guide: V2 → V3

## Overview

This guide walks through migrating from the current assembly system (V2, broken) to the new architecture (V3, deterministic).

---

## Current State (V2) Problems

| Problem | Root Cause | V3 Solution |
|---------|------------|-------------|
| Placeholder text in output | Runtime generation falling back | Pre-validated plans |
| Scene injection chaos | Conditional logic at assembly | Explicit scene IDs in plan |
| Character name drift | Late resolution | Character frozen in plan |
| Persona bleed | Layer mixing | Single persona per plan |
| Empty Practice blocks | Missing content + no fail | Hard fail on missing |
| Duplicate content | Smart fallbacks | Lookup only |

---

## Migration Timeline

```
Week 1: Library Extraction + Schema Design
Week 2: Validator + Test Plans
Week 3: New Assembler + Full Generation
Week 4: QA + Production
```

---

## Phase 1: Library Extraction (Week 1, Days 1-3)

### Task 1.1: Audit Current Content

Identify all unique content pieces in the current system.

```bash
# Find all source files
find . -name "*.md" -path "*/chapters/*" | head -20

# Count unique experiences
grep -l "CHAPTER" chapters/*.md | wc -l

# Find all scenes
grep -r "scene" --include="*.yaml" | cut -d: -f1 | sort -u

# Find all exercises
grep -r "breath\|ground\|scan" --include="*.md" chapters/
```

### Task 1.2: Extract Experiences

For each chapter, extract the core experience content:

```bash
# Create experience library structure
mkdir -p libraries/experiences/anxiety
mkdir -p libraries/experiences/depression
mkdir -p libraries/experiences/grief
```

For each source chapter file (e.g., `gen_z_chapter_1_anxiety.md`):

1. Copy to `libraries/experiences/anxiety/exp_01_recognition.md`
2. Remove persona-specific content
3. Add section markers
4. Add socket markers

**Before (V2):**
```markdown
# Chapter 1

You're sitting in the library...

Three weeks in. You're at the coffee shop on Pacific Ave.
Your phone buzzes. Group chat making plans.
[persona-specific content mixed in]
```

**After (V3):**
```markdown
# Experience: Recognition

<!-- SECTION: opening -->
You're sitting in the library, third floor, the quiet section.
<!-- /SECTION: opening -->

<!-- SCENE_SOCKET: after_section_1 -->

<!-- SECTION: core_insight -->
There's a sentence that's been running your decisions for years.
<!-- /SECTION: core_insight -->

<!-- CLOSING_SOCKET -->
```

### Task 1.3: Extract Scenes

For each persona-specific scene:

1. Identify all unique scenes in current content
2. Create scene files in `libraries/scenes/{topic}/{persona}/`
3. Use YAML format with content field

```yaml
# libraries/scenes/anxiety/gen_z/scene_04_text_send.yaml
id: "scene_04_text_send"
topic: "anxiety"
persona: "gen_z"
chapter_target: 4

content: |
  ---
  
  Last Tuesday. The group chat deciding on weekend plans.
  
  You had an idea — that new ramen place on Pacific.
  
  Chest tight. Thumbs hovering.
  
  *What if they think it's basic.*
  
  You typed it anyway: "what about that ramen spot by the boardwalk?"
  
  Sent.
  
  ---
```

### Task 1.4: Extract Exercises

For each unique exercise:

1. Identify all breathing/grounding exercises
2. Create exercise files in `libraries/exercises/`
3. Include purpose, instructions, guided version, debrief

### Task 1.5: Create Component Registry

For each library, create a `_registry.yaml`:

```yaml
# libraries/experiences/anxiety/_registry.yaml
version: "3.0"
components:
  - id: "exp_01_recognition"
    file: "exp_01_recognition.md"
    status: "active"
  - id: "exp_02_origin"
    file: "exp_02_origin.md"
    status: "active"
```

---

## Phase 2: Schema Design + Validator (Week 1, Days 4-5)

### Task 2.1: Finalize Plan Schema

Review and approve the schema in `BOOK_PLAN_SCHEMA.md`.

Key decisions:
- [ ] Confirm all required fields
- [ ] Confirm position values
- [ ] Confirm null semantics
- [ ] Confirm validation rules

### Task 2.2: Build Validator

Implement the validator from `PLAN_VALIDATOR_SPEC.md`:

```python
# validator/validate_plan.py

def validate_plan(plan_path: str) -> ValidationResult:
    plan = load_plan(plan_path)
    
    # Level 1: Schema
    result = validate_schema(plan)
    if not result.valid:
        return result
    
    # Level 2: References
    result = validate_references(plan, libraries)
    if not result.valid:
        return result
    
    # Level 3: Constraints
    result = validate_constraints(plan)
    if not result.valid:
        return result
    
    # Level 4: Safety
    result = validate_safety(plan, libraries)
    
    return result
```

### Task 2.3: Test Validator

Create test plans that should fail:

```yaml
# test_plans/invalid_missing_scene.yaml
# Should fail: scene_id references non-existent scene
chapters:
  - chapter: 4
    scene:
      id: "scene_does_not_exist"
      position: "mid_chapter"
```

```yaml
# test_plans/invalid_duplicate_exp.yaml
# Should fail: duplicate experience IDs
chapters:
  - chapter: 1
    experience_id: "exp_01_recognition"
  - chapter: 2
    experience_id: "exp_01_recognition"  # Duplicate!
```

---

## Phase 3: Create Test Plans (Week 2, Days 1-2)

### Task 3.1: Create 10 Manual Plans

Create 10 plans by hand to validate the full workflow:

```bash
# Create plan directory
mkdir -p plans/test

# Create plans
# - anxiety_genz_001.yaml (full features)
# - anxiety_genz_002.yaml (minimal)
# - anxiety_millennial_001.yaml (different persona)
# - depression_genz_001.yaml (different topic)
# - etc.
```

### Task 3.2: Validate Test Plans

```bash
phoenix validate plans/test/

Validating 10 plans...
✅ 10 valid
```

---

## Phase 4: Build New Assembler (Week 2, Days 3-5)

### Task 4.1: Implement Assembler

Build the assembler from `ASSEMBLER_SPEC.md`:

```python
# assembler/assemble.py

class Assembler:
    def __init__(self, libraries: Libraries):
        self.libraries = libraries
    
    def assemble(self, plan_path: str) -> Book:
        plan = self._load_plan(plan_path)
        character = self._fetch_character(plan.character.id)
        
        chapters = []
        for chapter_plan in plan.chapters:
            chapter = self._assemble_chapter(plan, chapter_plan, character)
            chapters.append(chapter)
        
        return Book(
            id=plan.book_id,
            chapters=chapters
        )
```

### Task 4.2: Remove All Fallback Logic

Audit the assembler for any decision-making:

```python
# ❌ REMOVE: Any fallback logic
if scene is None:
    scene = default_scene  # DELETE THIS

# ❌ REMOVE: Any conditional injection
if needs_exercise(chapter):
    inject_exercise()  # DELETE THIS

# ❌ REMOVE: Any late resolution
character = resolve_character(persona)  # DELETE THIS
```

### Task 4.3: Test Assembler

```bash
# Assemble test plans
phoenix assemble plans/test/ -o output/test/

Assembling 10 books...
✅ 10 books assembled

# Compare to expected output
diff output/test/anxiety_genz_001.md expected/anxiety_genz_001.md
```

---

## Phase 5: Generate Planning Matrix (Week 3, Days 1-2)

### Task 5.1: Define All Book Variants

Create the complete planning matrix:

```bash
# Use LLM to generate matrix
python generate_matrix.py > planning/BOOK_PLANNING_MATRIX.csv
```

### Task 5.2: Human Review Matrix

Review the matrix for:
- [ ] Appropriate scene distribution
- [ ] Exercise variety
- [ ] Persona/character alignment
- [ ] No missing combinations

### Task 5.3: Generate All Plans

```bash
# Generate plans from matrix
python generate_plans.py planning/BOOK_PLANNING_MATRIX.csv plans/

Generated 1200 plans in plans/
```

### Task 5.4: Validate All Plans

```bash
phoenix validate plans/

Validating 1200 plans...
✅ 1200 valid
```

---

## Phase 6: Full Generation (Week 3, Days 3-5)

### Task 6.1: Assemble All Books

```bash
phoenix assemble plans/ -o output/

Assembling 1200 books...
✅ 1200 books assembled
```

### Task 6.2: Automated QA

```bash
# Run QA checks
phoenix qa output/

Running QA on 1200 books...

Checks:
✅ No placeholder text
✅ No unresolved variables
✅ Character names consistent
✅ No duplicate content blocks
✅ All chapters present
✅ Word count in range

1200/1200 passed
```

### Task 6.3: Human Spot-Check

Sample 20 books for manual review:

```bash
ls output/ | shuf | head -20
```

For each book, verify:
- [ ] Reads naturally
- [ ] No weird jumps
- [ ] Scenes fit context
- [ ] Exercises feel earned
- [ ] Ending is appropriate

---

## Phase 7: Production (Week 4)

### Task 7.1: Archive V2 System

```bash
# Move old system to archive
mv v2_assembler/ archive/v2_assembler_deprecated/
```

### Task 7.2: Deploy V3 System

```bash
# Deploy new system
cp -r v3_assembler/ production/
```

### Task 7.3: Document V3

Ensure all documentation is complete:
- [ ] PHOENIX_BOOK_ARCHITECTURE_V3.md
- [ ] BOOK_PLAN_SCHEMA.md
- [ ] COMPONENT_LIBRARIES_SPEC.md
- [ ] PLAN_VALIDATOR_SPEC.md
- [ ] ASSEMBLER_SPEC.md
- [ ] PLAN_GENERATION_GUIDE.md

### Task 7.4: Train Team

Brief team on new system:
- How to add new components
- How to create new plans
- How to run validation
- How to debug failures

---

## Rollback Plan

If V3 fails:

1. Stop V3 deployment
2. Restore V2 from archive
3. Document failure reason
4. Fix and retry

---

## Success Criteria

V3 migration is complete when:

1. ✅ All 1,200 books generate without error
2. ✅ All books pass automated QA
3. ✅ Sample books pass human review
4. ✅ No runtime decisions in assembler
5. ✅ Any plan change produces predictable output change
6. ✅ Team can add new components independently

---

## Anti-Patterns to Avoid During Migration

### ❌ "Just fix the current system"

The current system's problems are architectural. Patches will not work.

### ❌ "Add more fallbacks"

More fallbacks = more emergent bugs. Remove all fallbacks.

### ❌ "Make it smarter"

The assembler should be dumber, not smarter. Intelligence belongs in planning.

### ❌ "We'll fix it later"

Validation must be complete before assembly. No "fix in post."

---

## FAQ

### Q: Can we keep some V2 logic?

A: No. V3 is a clean break. V2 logic has proven unreliable.

### Q: What if we need a new component?

A: Add to library → Add to registry → Reference in plan → Validate → Assemble.

### Q: What if assembly fails?

A: Fix the plan. The assembler is correct if it fails on missing content.

### Q: How do we handle persona-specific content?

A: Separate plans per persona. Each plan references persona-specific components.

### Q: What if we need 10,000 books?

A: Same process. Plans scale linearly. Generation is O(n).

---

## Summary

| Before (V2) | After (V3) |
|-------------|------------|
| Runtime decisions | Pre-planned decisions |
| Smart fallbacks | Hard failures |
| Emergent bugs | Predictable output |
| "Why did this happen?" | "Plan says X, got X" |
| Debugging is archaeology | Debugging is diff |

The migration is not about fixing bugs. It's about changing the architecture so bugs become impossible.
