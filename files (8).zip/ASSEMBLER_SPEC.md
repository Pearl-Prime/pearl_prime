# Assembler Specification

## Overview

The Assembler is a **dumb, deterministic, lookup-only** system that reads a validated Book Plan and produces a rendered book. It makes **zero decisions**.

**Rule: The Assembler does not think. It executes.**

---

## Core Principle

```
IF it's in the plan → include it
IF it's not in the plan → don't include it
IF something is missing → FAIL
```

No fallbacks. No defaults. No intelligence.

---

## Assembler Flow

```
┌─────────────────────────────────────────────────────────────┐
│                     ASSEMBLER FLOW                          │
└─────────────────────────────────────────────────────────────┘

        ┌──────────────┐
        │ Validated    │
        │ Book Plan    │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Load Plan    │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Load         │
        │ Character    │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ For Each     │◄────────────┐
        │ Chapter      │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Fetch        │             │
        │ Experience   │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Inject Scene │             │
        │ (if present) │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Inject       │             │
        │ Exercises    │             │
        │ (if present) │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Inject       │             │
        │ Reflection   │             │
        │ (if present) │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Inject       │             │
        │ Integration  │             │
        │ (if present) │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Inject       │             │
        │ Closing      │             │
        │ (if present) │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Apply        │             │
        │ Character    │             │
        └──────┬───────┘             │
               │                     │
               ▼                     │
        ┌──────────────┐             │
        │ Add to Book  │─────────────┘
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Add Front    │
        │ Matter       │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Add Back     │
        │ Matter       │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Render       │
        │ Markdown     │
        └──────┬───────┘
               │
               ▼
        ┌──────────────┐
        │ Output       │
        │ Book File    │
        └──────────────┘
```

---

## Assembler Implementation

```python
"""
Phoenix Book Assembler V3

Dumb. Deterministic. Lookup-only.
"""

from dataclasses import dataclass
from typing import List, Optional
import yaml

from libraries import Libraries
from models import BookPlan, Chapter, Book, ChapterContent


class AssemblerError(Exception):
    """Raised when assembly fails. Should never happen if plan is validated."""
    pass


class Assembler:
    """
    Assembles a book from a validated plan.
    
    This class makes ZERO decisions. It only:
    - Reads the plan
    - Fetches components
    - Assembles in order
    - Outputs result
    
    If anything is missing, it fails hard.
    """
    
    def __init__(self, libraries: Libraries):
        self.libraries = libraries
    
    def assemble(self, plan_path: str) -> Book:
        """
        Assemble a book from a plan file.
        
        Args:
            plan_path: Path to validated YAML plan
            
        Returns:
            Assembled Book object
            
        Raises:
            AssemblerError: If any component is missing
        """
        # Load plan
        plan = self._load_plan(plan_path)
        
        # Load character
        character = self._fetch_character(plan.character.id)
        
        # Assemble chapters
        chapters = []
        for chapter_plan in plan.chapters:
            chapter_content = self._assemble_chapter(plan, chapter_plan, character)
            chapters.append(chapter_content)
        
        # Assemble front matter
        front_matter = self._assemble_front_matter(plan)
        
        # Assemble back matter
        back_matter = self._assemble_back_matter(plan)
        
        # Create book
        book = Book(
            id=plan.book_id,
            metadata=plan.metadata,
            front_matter=front_matter,
            chapters=chapters,
            back_matter=back_matter
        )
        
        return book
    
    def _load_plan(self, plan_path: str) -> BookPlan:
        """Load and parse plan file."""
        with open(plan_path) as f:
            data = yaml.safe_load(f)
        return BookPlan.from_dict(data)
    
    def _fetch_character(self, character_id: str) -> Character:
        """Fetch character from library. Fail if missing."""
        character = self.libraries.characters.get(character_id)
        if character is None:
            raise AssemblerError(f"Character not found: {character_id}")
        return character
    
    def _assemble_chapter(
        self, 
        plan: BookPlan, 
        chapter_plan: Chapter,
        character: Character
    ) -> ChapterContent:
        """
        Assemble a single chapter.
        
        Steps:
        1. Fetch experience (required)
        2. Inject scene (if present in plan)
        3. Inject exercises (if present in plan)
        4. Inject reflection (if present in plan)
        5. Inject integration (if present in plan)
        6. Inject closing (if present in plan)
        7. Apply character substitution
        """
        
        # Step 1: Fetch experience (REQUIRED)
        content = self._fetch_experience(plan.topic, chapter_plan.experience_id)
        
        # Step 2: Inject scene (IF PRESENT)
        if chapter_plan.scene.id is not None:
            scene = self._fetch_scene(
                plan.topic, 
                plan.persona, 
                chapter_plan.scene.id
            )
            content = self._inject_at_position(
                content, 
                scene, 
                chapter_plan.scene.position,
                "SCENE_SOCKET"
            )
        
        # Step 3: Inject exercises (IF PRESENT)
        for exercise_plan in chapter_plan.exercises:
            exercise = self._fetch_exercise(exercise_plan.id)
            
            # Add intro if specified
            if exercise_plan.intro_text is not None:
                intro = self._fetch_intro(exercise_plan.intro_text)
                exercise = intro + "\n\n" + exercise
            
            content = self._inject_at_position(
                content,
                exercise,
                exercise_plan.position,
                "EXERCISE_SOCKET"
            )
        
        # Step 4: Inject reflection (IF PRESENT)
        if chapter_plan.reflection_id is not None:
            reflection = self._fetch_reflection(chapter_plan.reflection_id)
            content = self._inject_at_socket(content, reflection, "REFLECTION_SOCKET")
        
        # Step 5: Inject integration (IF PRESENT)
        if chapter_plan.integration_id is not None:
            integration = self._fetch_bridge(chapter_plan.integration_id)
            content = self._inject_at_socket(content, integration, "INTEGRATION_SOCKET")
        
        # Step 6: Inject closing (IF PRESENT)
        if chapter_plan.closing_id is not None:
            closing = self._fetch_closing(
                plan.topic,
                plan.persona,
                chapter_plan.closing_id
            )
            content = self._inject_at_socket(content, closing, "CLOSING_SOCKET")
        
        # Step 7: Apply character substitution
        content = self._apply_character(content, character)
        
        # Step 8: Clean up unused sockets
        content = self._remove_empty_sockets(content)
        
        return ChapterContent(
            number=chapter_plan.chapter,
            title=chapter_plan.title,
            content=content
        )
    
    # ─────────────────────────────────────────────────────────────
    # FETCH METHODS - Pure lookup, no decisions
    # ─────────────────────────────────────────────────────────────
    
    def _fetch_experience(self, topic: str, experience_id: str) -> str:
        """Fetch experience content. Fail if missing."""
        content = self.libraries.experiences.get(topic, experience_id)
        if content is None:
            raise AssemblerError(f"Experience not found: {topic}/{experience_id}")
        return content
    
    def _fetch_scene(self, topic: str, persona: str, scene_id: str) -> str:
        """Fetch scene content. Fail if missing."""
        content = self.libraries.scenes.get(topic, persona, scene_id)
        if content is None:
            raise AssemblerError(f"Scene not found: {topic}/{persona}/{scene_id}")
        return content
    
    def _fetch_exercise(self, exercise_id: str) -> str:
        """Fetch exercise content. Fail if missing."""
        content = self.libraries.exercises.get(exercise_id)
        if content is None:
            raise AssemblerError(f"Exercise not found: {exercise_id}")
        return content
    
    def _fetch_reflection(self, reflection_id: str) -> str:
        """Fetch reflection content. Fail if missing."""
        content = self.libraries.reflections.get(reflection_id)
        if content is None:
            raise AssemblerError(f"Reflection not found: {reflection_id}")
        return content
    
    def _fetch_bridge(self, bridge_id: str) -> str:
        """Fetch bridge content. Fail if missing."""
        content = self.libraries.bridges.get(bridge_id)
        if content is None:
            raise AssemblerError(f"Bridge not found: {bridge_id}")
        return content
    
    def _fetch_closing(self, topic: str, persona: str, closing_id: str) -> str:
        """Fetch closing content. Fail if missing."""
        content = self.libraries.closings.get(topic, persona, closing_id)
        if content is None:
            raise AssemblerError(f"Closing not found: {topic}/{persona}/{closing_id}")
        return content
    
    def _fetch_intro(self, intro_id: str) -> str:
        """Fetch intro text. Fail if missing."""
        content = self.libraries.intros.get(intro_id)
        if content is None:
            raise AssemblerError(f"Intro not found: {intro_id}")
        return content
    
    # ─────────────────────────────────────────────────────────────
    # INJECTION METHODS - Pure string manipulation, no decisions
    # ─────────────────────────────────────────────────────────────
    
    def _inject_at_position(
        self, 
        content: str, 
        injection: str, 
        position: str,
        socket_type: str
    ) -> str:
        """
        Inject content at specified position.
        
        Positions:
        - "start": Beginning of content
        - "end": End of content
        - "after_para_N": After paragraph N
        - "after_section_N": After section N
        - "mid_chapter": Middle of content
        - Socket marker: <!-- SOCKET_TYPE: position -->
        """
        
        # Check for socket marker first
        socket_marker = f"<!-- {socket_type}: {position} -->"
        if socket_marker in content:
            return content.replace(socket_marker, injection + "\n")
        
        # Position-based injection
        if position == "start":
            return injection + "\n\n" + content
        
        if position == "end":
            return content + "\n\n" + injection
        
        if position.startswith("after_para_"):
            para_num = int(position.replace("after_para_", ""))
            return self._inject_after_paragraph(content, injection, para_num)
        
        if position.startswith("after_section_"):
            section_num = int(position.replace("after_section_", ""))
            return self._inject_after_section(content, injection, section_num)
        
        if position == "mid_chapter":
            return self._inject_at_middle(content, injection)
        
        # If position doesn't match anything, fail
        raise AssemblerError(f"Invalid position: {position}")
    
    def _inject_at_socket(self, content: str, injection: str, socket_name: str) -> str:
        """Inject content at named socket marker."""
        socket_marker = f"<!-- {socket_name} -->"
        if socket_marker not in content:
            # Socket not found - append at end
            return content + "\n\n" + injection
        return content.replace(socket_marker, injection)
    
    def _inject_after_paragraph(self, content: str, injection: str, para_num: int) -> str:
        """Inject after the Nth paragraph."""
        paragraphs = content.split("\n\n")
        if para_num >= len(paragraphs):
            # If paragraph doesn't exist, append at end
            return content + "\n\n" + injection
        paragraphs.insert(para_num, injection)
        return "\n\n".join(paragraphs)
    
    def _inject_after_section(self, content: str, injection: str, section_num: int) -> str:
        """Inject after the Nth section marker."""
        section_marker = f"<!-- /SECTION:"
        parts = content.split(section_marker)
        if section_num >= len(parts):
            return content + "\n\n" + injection
        # Reconstruct with injection after section
        result = section_marker.join(parts[:section_num + 1])
        result += "\n\n" + injection
        if section_num + 1 < len(parts):
            result += section_marker + section_marker.join(parts[section_num + 1:])
        return result
    
    def _inject_at_middle(self, content: str, injection: str) -> str:
        """Inject at approximate middle of content."""
        paragraphs = content.split("\n\n")
        mid = len(paragraphs) // 2
        paragraphs.insert(mid, injection)
        return "\n\n".join(paragraphs)
    
    def _remove_empty_sockets(self, content: str) -> str:
        """Remove any socket markers that weren't filled."""
        import re
        # Remove all socket markers
        content = re.sub(r'<!-- [A-Z_]+_SOCKET[^>]* -->\n?', '', content)
        content = re.sub(r'<!-- [A-Z_]+_SOCKET -->\n?', '', content)
        return content
    
    # ─────────────────────────────────────────────────────────────
    # CHARACTER SUBSTITUTION - Pure string replacement
    # ─────────────────────────────────────────────────────────────
    
    def _apply_character(self, content: str, character: Character) -> str:
        """Replace character placeholders with actual character."""
        # Replace name
        content = content.replace("{character_name}", character.name)
        content = content.replace("{CHARACTER_NAME}", character.name)
        
        # Replace pronouns
        content = content.replace("{they}", character.pronouns.subject)
        content = content.replace("{them}", character.pronouns.object)
        content = content.replace("{their}", character.pronouns.possessive)
        content = content.replace("{themselves}", character.pronouns.reflexive)
        
        # Capitalized versions
        content = content.replace("{They}", character.pronouns.subject.capitalize())
        content = content.replace("{Them}", character.pronouns.object.capitalize())
        content = content.replace("{Their}", character.pronouns.possessive.capitalize())
        
        return content
    
    # ─────────────────────────────────────────────────────────────
    # FRONT/BACK MATTER
    # ─────────────────────────────────────────────────────────────
    
    def _assemble_front_matter(self, plan: BookPlan) -> Optional[str]:
        """Assemble front matter if present in plan."""
        if plan.front_matter is None:
            return None
        
        parts = []
        
        if plan.front_matter.a0_pre_intro.id is not None:
            a0 = self.libraries.front_matter.get("a0", plan.front_matter.a0_pre_intro.id)
            if a0 is None:
                raise AssemblerError(f"A0 not found: {plan.front_matter.a0_pre_intro.id}")
            parts.append(a0)
        
        if plan.front_matter.a1_introduction.id is not None:
            a1 = self.libraries.front_matter.get("a1", plan.front_matter.a1_introduction.id)
            if a1 is None:
                raise AssemblerError(f"A1 not found: {plan.front_matter.a1_introduction.id}")
            parts.append(a1)
        
        return "\n\n".join(parts) if parts else None
    
    def _assemble_back_matter(self, plan: BookPlan) -> Optional[str]:
        """Assemble back matter if present in plan."""
        if plan.back_matter is None:
            return None
        
        parts = []
        
        if plan.back_matter.conclusion.id is not None:
            conclusion = self.libraries.back_matter.get("conclusion", plan.back_matter.conclusion.id)
            if conclusion is None:
                raise AssemblerError(f"Conclusion not found: {plan.back_matter.conclusion.id}")
            parts.append(conclusion)
        
        return "\n\n".join(parts) if parts else None
```

---

## What the Assembler Does NOT Do

```python
# ❌ NEVER: Make decisions about content
if chapter.scene is None:
    chapter.scene = find_fallback_scene()  # NO!

# ❌ NEVER: Apply defaults
scene = scene_id or DEFAULT_SCENE  # NO!

# ❌ NEVER: Conditional logic based on content
if needs_exercise(chapter):
    inject_exercise()  # NO!

# ❌ NEVER: Smart fallbacks
try:
    scene = fetch_scene(id)
except NotFound:
    scene = GENERIC_SCENE  # NO!

# ❌ NEVER: Late resolution
character = resolve_character(persona)  # NO!

# ❌ NEVER: Content generation
if missing_content:
    content = generate_content()  # NO!
```

---

## Error Handling

The Assembler has exactly two modes:

### Mode 1: Success

```
Plan valid → All components found → Book assembled → Output
```

### Mode 2: Failure

```
Component missing → AssemblerError → Build fails → No output
```

There is no middle ground. No partial success. No degraded output.

```python
def assemble(self, plan_path: str) -> Book:
    """
    Returns a Book or raises AssemblerError.
    Never returns a partial or degraded book.
    """
```

---

## Output Format

```python
@dataclass
class Book:
    id: str
    metadata: BookMetadata
    front_matter: Optional[str]
    chapters: List[ChapterContent]
    back_matter: Optional[str]
    
    def to_markdown(self) -> str:
        """Render book as markdown."""
        parts = []
        
        # Title
        parts.append(f"# {self.metadata.title}")
        if self.metadata.subtitle:
            parts.append(f"*{self.metadata.subtitle}*")
        
        # Front matter
        if self.front_matter:
            parts.append(self.front_matter)
        
        # Chapters
        for chapter in self.chapters:
            parts.append(f"\n\n## CHAPTER {chapter.number}\n")
            parts.append(chapter.content)
        
        # Back matter
        if self.back_matter:
            parts.append(self.back_matter)
        
        return "\n\n".join(parts)
    
    def write(self, path: str):
        """Write book to file."""
        with open(path, 'w') as f:
            f.write(self.to_markdown())
```

---

## CLI Usage

```bash
# Assemble a single book
$ phoenix assemble plans/anxiety_genz_001.yaml -o output/anxiety_genz_001.md

✅ Book assembled: output/anxiety_genz_001.md

# Assemble all books
$ phoenix assemble plans/ -o output/

Assembling 1200 books...
✅ 1200 books assembled

# Assemble with verbose output
$ phoenix assemble -v plans/anxiety_genz_001.yaml

Loading plan: anxiety_genz_001.yaml
Loading character: sam
Assembling chapter 1...
  - Experience: exp_01_recognition ✓
  - Scene: (none)
  - Exercises: (none)
Assembling chapter 2...
  - Experience: exp_02_origin ✓
  - Scene: scene_02_classroom_memory ✓
  - Exercises: (none)
...
✅ Book assembled: output/anxiety_genz_001.md
```

---

## Guarantees

After the Assembler runs:

1. **Output matches plan exactly** - Every component in the plan is in the book
2. **No extra content** - Nothing in the book that isn't in the plan
3. **Reproducible** - Same plan → same book, every time
4. **No decisions made** - Assembler is stateless and deterministic
5. **Failure is clean** - Either complete success or complete failure

---

## Summary

| The Assembler... | Does | Does NOT |
|------------------|------|----------|
| Read plans | ✓ | |
| Fetch components | ✓ | |
| Inject at positions | ✓ | |
| Apply character | ✓ | |
| Output markdown | ✓ | |
| Make decisions | | ✗ |
| Apply defaults | | ✗ |
| Use fallbacks | | ✗ |
| Generate content | | ✗ |
| Resolve ambiguity | | ✗ |

**The Assembler is a printer, not a thinker.**
