# Anxiety: A Guide for Gen Alpha

**Complete Canonical Book — Phase-Correct Structure**

**Word Count Target:** ~4,200 words
**Phase Structure:** Introduce (Ch 1-2) → Deepen (Ch 3-5) → Test (Ch 6-8) → Complicate (Ch 9) → Integrate (Ch 10-12)
**Core Sentence:** "Once I'm not anxious, then I'll do it."
**Demographic Adaptation:** Gen Alpha (ages 10-14) — school stress, social anxiety, performance fears, social media pressure, family worries, identity formation
**Phenomenology:** Worry, fear, avoidance, "what if" thinking, waiting to feel ready, physical tension
**Voice:** Warm, validating, slightly older friend/mentor tone — not talking down, not overly adult

---

## Pre-Introduction

Hey. Welcome to Anxiety: A Guide for Gen Alpha.

This is an audiobook about that worried feeling that won't go away.

You can listen however works for you. All at once. A chapter at a time. Skip around if you want.

12 chapters. No tests. No grades. Nobody's checking if you finished.

Just listen. Think about it however you think about it.

Ready when you are.

[Pause 3s]

---

## Introduction

I remember being your age and feeling worried all the time.

Not regular worried—like before a test. More like worried about everything. Worried something bad was going to happen. Worried I'd mess up. Worried people were judging me. Worried about things that hadn't even happened yet.

I thought I just needed to calm down first. I kept waiting to feel ready. I thought once the worry went away, then I could do stuff.

But the worry never went away. So I kept waiting. And waiting.

I was doing it backwards. I didn't know that then.

That's what this audiobook is about. Understanding why you feel worried all the time, and what actually helps—which is probably different from what you'd expect.

You're here because worry feels like it's running your life. Maybe you avoid stuff because it feels scary. Maybe you can't stop thinking about what might go wrong. Maybe your body feels tight and nervous even when nothing bad is happening.

Whatever brought you here is valid. You found this for a reason.

This isn't about getting rid of anxiety. That's not actually possible—and it's not even the goal. It's about learning how to do your life even when anxiety is there.

Here's the main thing I want you to know:

You don't have to wait until you're not anxious to do things. You can do them while anxious. That's the whole secret.

You don't have to believe this will help. You just have to be willing to listen.

You're here. That's enough.

---

## CHAPTER 1: The Waiting Game

**Phase: INTRODUCE — Hook + Recognition**

You're not a scaredy-cat.

I know it feels that way sometimes. You see other people doing stuff that seems easy for them—raising their hand, talking to new people, trying new things—and you think: why can't I just do that?

Here's the thing: those people aren't braver than you. They just don't wait to feel ready.

What anxiety actually feels like when you're young:

**You avoid stuff.** Not because you don't want to do it—because the worry feels too big. So you skip the party, don't raise your hand, pretend you don't care.

**Your body feels weird.** Stomach hurts before school. Can't sleep because your brain won't stop. Heart beats fast for no reason. Muscles are tight. Feel like you might throw up.

**You think about "what if" constantly.** What if I mess up? What if they laugh? What if something bad happens? What if I'm not good enough? Your brain plays scary movies of everything that could go wrong.

**You wait to feel ready.** You tell yourself: once I feel less nervous, then I'll do it. But you never feel less nervous. So you never do it.

**Small things feel huge.** A text someone didn't answer. A look someone gave you. Being called on in class. Things that are probably fine feel terrifying.

**You feel different from everyone else.** Like other people have some calm that you don't have. Like there's something wrong with you that nobody else deals with.

If this sounds like you, you're not broken. You're anxious.

And anxiety doesn't mean you're weak. It means your brain is really good at predicting danger—maybe too good. It sees threats everywhere, even when things are actually okay.

Your brain is trying to protect you. It's just doing it too much.

The problem is, you've been playing by anxiety's rules. Waiting until you feel ready. Avoiding things that feel scary.

That strategy doesn't work. Let me show you what does.

---

## CHAPTER 2: How You Got Here

**Phase: INTRODUCE — Validation + Origin Story**

This didn't start yesterday. It built up over time.

Let me guess how it probably went:

**Something felt scary.** Maybe it was small—a bad day at school, a friendship that went weird, getting yelled at. Maybe it was bigger. Something happened, and your brain said: that was dangerous.

**Your brain started watching for danger.** After that thing happened, your brain got protective. It started looking for anything that might hurt you again.

**Avoiding felt like relief.** When something felt scary, you avoided it. And the relief felt amazing. Your brain learned: avoiding = safety.

**The avoidance grew.** One thing led to another. If talking to new kids is scary, maybe all social stuff is scary. If one test went bad, maybe all tests are dangerous.

**Your world got smaller.** More and more things felt like threats. So more and more things got avoided. The safe zone kept shrinking.

**Now everything feels overwhelming.** School, social stuff, new experiences—all of it feels like too much. And you don't know how you got here.

Here's what I want you to understand: this isn't your fault.

Your brain was trying to protect you. It just learned the wrong lesson.

The lesson it learned: avoid scary things = stay safe.

The actual truth: avoiding scary things = makes them scarier.

Every time you avoid something because it feels scary, your brain goes: "Good call. That was clearly dangerous." The thing becomes more scary, not less.

It's a trap. And you walked into it without knowing.

The good news: you can walk out of it too.

---

## CHAPTER 3: What's Actually Happening

**Phase: DEEPEN — Full Pattern Exposure**

Let's talk about what's going on inside you when you feel anxious.

Your brain has an alarm system. It's called the "fight or flight" response. When it detects danger, it sounds an alarm and gets your body ready to deal with a threat.

Heart beats faster. Muscles tense up. Stomach gets weird. Breathing gets shallow. All of that is your body preparing to fight or run.

This is great if there's an actual emergency. If a bear is chasing you, you want your body ready to run.

Here's the problem: your alarm system can't tell the difference between a bear and a spelling test.

Your brain treats social stuff like physical danger. Raising your hand in class? Alarm. New people? Alarm. Someone looking at you weird? Alarm.

The alarm isn't broken. It's just too sensitive.

Here's what happens in the anxiety loop:

**Something triggers worry.** Maybe someone's going to judge you. Maybe something could go wrong. Your brain says: possible danger.

**Your body reacts.** Alarm bells. Heart racing. Stomach churning. All the physical stuff.

**You interpret that as proof.** You feel terrible, so something must be wrong. Your body is basically saying "danger!"—so you believe it.

**You avoid or escape.** You don't raise your hand. You skip the party. You don't send the text.

**Relief floods in.** The anxiety goes down. Your brain says: "See? Avoiding was the right call."

**The cycle repeats.** Next time, the same thing feels even scarier. Your world gets smaller.

Here's what your brain doesn't learn: if you had done the thing, you probably would have been fine.

The alarm was a false alarm. But you never found out, because you ran away.

---

## CHAPTER 4: Why This Matters

**Phase: DEEPEN — Cost Accounting**

I'm not trying to scare you. But I want you to understand why this matters.

If you keep letting anxiety run your life, stuff gets harder:

**You miss out.** The party you didn't go to. The friend you didn't make. The team you didn't try out for. The fun you didn't have. Anxiety takes those away.

**Your world keeps shrinking.** What's scary today becomes more scary tomorrow. The safe zone gets smaller and smaller. Eventually you're afraid of everything.

**You don't learn you can handle stuff.** The only way to learn you can do hard things is to do hard things. If you always avoid, you never build confidence.

**School gets worse.** Not raising your hand means not participating. Not asking questions means not understanding. Anxiety makes learning harder.

**Friendships suffer.** It's hard to make friends when you're avoiding social stuff. It's hard to keep friends when anxiety makes you cancel plans.

**You feel more alone.** Nobody knows what you're dealing with. You feel like something's wrong with you that nobody else understands.

Here's what I've seen happen to people who let anxiety win:

They end up living really small lives. Not because they're not capable—because they're too afraid to try.

Or they seem okay on the outside but they're miserable inside. Always scared. Never at peace.

None of that has to happen. Because you're here, learning this stuff now. That means you can do something different.

---

## CHAPTER 5: The Main Thing to Understand

**Phase: DEEPEN — Core Thesis + Reframe**

Here's the most important thing I'm going to tell you:

**You don't have to wait until you're not anxious to do things.**

This is the whole secret. This changes everything.

You've been operating on a lie. The lie says: first I need to feel ready, then I can act.

The truth: you act while anxious, and then the anxiety decreases.

It's backwards from what you'd expect. But it's how anxiety works.

Here's the real equation:

**Avoid = anxiety gets worse**
**Do it while anxious = anxiety gets better**

Every time you avoid something, you teach your brain that thing is dangerous. The next time, it's scarier.

Every time you do something while anxious, you teach your brain you can handle it. The next time, it's less scary.

This is called exposure. It's the only thing that actually works for anxiety.

Not relaxation techniques. Not positive thinking. Not waiting until you feel better.

Doing the scary thing. While scared.

I know this sounds impossible. If you could do the scary thing, you would, right?

But here's what changes: you stop waiting to feel ready. You do it scared.

Raise your hand while your heart is pounding. Go to the party while your stomach hurts. Send the text while you're worried about the response.

Your anxiety will scream that you can't. You do it anyway.

And then something amazing happens: you survive. And your brain learns.

---

## CHAPTER 6: Small Brave Things

**Phase: TEST — First Practices**

Let's get practical. Here are three things you can actually do:

**Practice 1: The Ten-Second Window**

When anxiety tells you not to do something, you have about ten seconds before your brain starts making excuses.

Use those ten seconds. Act before your brain talks you out of it.

Hand goes up before you think about it. Text gets sent before you rewrite it fifty times. Decision made before the "what ifs" kick in.

Just ten seconds. Move before anxiety catches up.

**Practice 2: Tiny Brave Things**

You don't have to start with the scariest thing. Start small.

Make eye contact with one person. Say hi to someone you don't usually talk to. Raise your hand once in an easy class.

Tiny brave things. Things that make your heart beat a little faster but won't destroy you if they go wrong.

Each tiny brave thing teaches your brain: I can do hard things.

Do one tiny brave thing per day. That's it.

**Practice 3: The "And" Trick**

When you're anxious, don't fight it. Just add "and" to it.

"I'm anxious AND I'm going to do it anyway."
"My stomach hurts AND I'm walking into class."
"I'm worried AND I'm sending the text."

You don't have to feel good first. You just have to act at the same time as the anxiety.

The anxiety doesn't have to leave for you to move.

---

## CHAPTER 7: When Anxiety Gets Loud

**Phase: TEST — Deeper Practice**

Sometimes anxiety isn't a whisper. It's a scream.

Here's how to handle the really loud moments:

**Name it.** When anxiety is screaming, pause and say (in your head): "Anxiety is happening." Just naming it creates a tiny bit of distance.

**Remember: the feeling is lying.** Your body is sending alarm signals, but there's no actual emergency. The feeling of danger isn't the same as actual danger.

**Breathe weird.** When you're really anxious, your breathing goes fast and shallow. Do this: breathe in for 4 counts, out for 6 counts. The longer exhale tells your body to calm down.

**Go physical.** When anxiety is stuck in your head, get in your body. Push against a wall as hard as you can. Run in place. Do jumping jacks. Physical movement burns off the stress chemicals.

**Find one grounding thing.** Look around. Find one thing you can see. One thing you can hear. One thing you can touch. Just one of each. It brings you back to right now.

The goal isn't to make anxiety disappear. It's to keep moving even when it's screaming.

Because anxiety is loud, but it's not the boss. You are.

---

## CHAPTER 8: Hard Anxiety Days

**Phase: TEST — High Intensity Moments**

Some days are worse than others. Let's talk about those.

**When you can't do the thing:**

Do a smaller version. Can't raise your hand in class? Write your thought down instead. Can't go to the party? Just go for twenty minutes. Can't do the whole thing? Do a piece of it.

Progress, not perfection.

**When everyone seems fine except you:**

They're not fine. They're just not showing it. Lots of people are anxious. They're just hiding it like you are.

You're not the only one. You're just honest with yourself.

**When you really want to cancel:**

Ask yourself: Am I canceling because it's actually a bad idea, or because anxiety is telling me to?

If it's anxiety, try this: "I'll go for fifteen minutes. I can leave after that."

Usually, once you're there, it's not as bad as you thought.

**When you avoided something and feel terrible:**

It's okay. You're going to avoid sometimes. That doesn't mean you failed.

Notice what happened. Notice how avoiding felt in the moment versus how it feels now. Learn from it. Try again tomorrow.

One avoided thing doesn't erase your progress.

---

## CHAPTER 9: The Complicated Truth

**Phase: COMPLICATE — Paradox + Non-Linear Progress**

Here's where I have to be honest about something:

**Anxiety doesn't go away forever.**

Some people will tell you that if you do enough work, you'll be anxiety-free. That's not true.

What actually happens is this: anxiety still shows up, but it's quieter. You still feel it, but it doesn't control you as much. It goes from being the boss to being more like a nervous friend who worries too much.

**Progress isn't a straight line.**

Some days you'll feel brave. You'll do things that used to terrify you, no problem.

Then you'll have a day where something easy feels impossible again. You'll think: I'm back to square one.

You're not. Setbacks are part of the process. Two steps forward, one step back—that's normal.

**The goal isn't fearlessness.**

Brave people aren't people who don't feel fear. They're people who act even though they're afraid.

You might always have some anxiety. The question is whether you let it run your life or not.

**AND this is still worth doing.**

Even with all that—the anxiety that stays, the progress that isn't perfect—this is still worth it.

Because right now, anxiety is controlling everything. And it doesn't have to be that way.

You can have anxiety AND a life. That's the goal.

---

## CHAPTER 10: When You Fall Back

**Phase: INTEGRATE — Handling Setbacks**

You're going to have setbacks. Here's how to handle them.

A setback looks like this: you were doing better, being braver. Then something happened and suddenly you're avoiding everything again.

You'll think: I'm back where I started.

You're not. Here's why:

**You know more now.**

Before, you didn't understand what was happening. Now you do. You know it's anxiety. You know avoiding makes it worse. That knowledge doesn't go away.

**Figure out what triggered it.**

What happened? Something stressful? Something embarrassing? A big change? Not to blame yourself—to understand. If you know your triggers, you can watch out for them.

**Go back to basics.**

When you're in setback, pick one small brave thing. Just one. The ten-second window. A tiny brave thing.

Don't try to fix everything at once. Just do one thing.

**Be kind to yourself.**

You're learning something hard. Of course you're going to mess up sometimes. That's not failure. That's practice.

---

## CHAPTER 11: Who You're Becoming

**Phase: INTEGRATE — Identity Shift**

Something is changing in you.

You might not notice because you're in the middle of it. But you're not the same as when you started.

**You understand yourself better.**

You know what anxiety is. You know it's not dangerous, even when it feels that way. You know your brain is trying to protect you, even when it's wrong.

**You're building courage.**

Every tiny brave thing adds up. Every time you do something while anxious, you're building a muscle. The courage muscle.

**You're not your anxiety.**

Anxiety is something that happens to you. It's not who you are. You're the person who has anxiety AND does stuff anyway.

**You're learning young.**

Most people don't learn this stuff until they're adults—if ever. You're figuring it out now. That means your whole life can be different.

**You're becoming someone who doesn't let fear decide.**

Not someone fearless—that doesn't exist. Someone who feels fear and acts anyway. That's real bravery.

---

## CHAPTER 12: What's Next

**Phase: INTEGRATE — Continuation + Closing**

This isn't the end. It's more like a checkpoint.

You've learned what anxiety is and why it works the way it does. You have tools. You know that you don't have to wait until you feel ready.

But life keeps going. Scary stuff keeps happening. Anxiety will still show up.

What's different now is you.

Here's what you carry forward:

**Understanding.** You know what's happening when you feel anxious. That knowledge helps.

**Tools.** The ten-second window. Tiny brave things. The "and" trick. Ways to handle the hard days.

**A new equation.** Avoid = worse. Act while anxious = better.

**Permission.** Permission to feel anxious and still do things. Permission to not be perfect. Permission to have setbacks and keep going.

There will be scary things ahead. Things that make your heart pound and your stomach hurt.

When those come, remember: you've been here before. You know what this is. You can do scary things scared.

And remember this too:

**You're not a scaredy-cat.** You never were. You're a person with anxiety who is learning to do things anyway.

**Feeling anxious doesn't mean you can't.** It just means it's harder. Harder doesn't mean impossible.

**You're going to be okay.** Not because everything will be easy. Because you're learning how to handle hard things.

Take care of yourself. Be kind to yourself. And keep doing tiny brave things.

You've got this.

---

## Conclusion

You made it through. That matters.

Not because you're fixed or perfect now. Because you showed up. You listened. You paid attention.

Here's what I want you to remember:

**Anxiety isn't danger.** It feels like danger, but it's not. It's your brain being overprotective.

**You don't have to wait to feel ready.** That's the big lie. Act while anxious, and the anxiety decreases.

**Tiny brave things add up.** You don't have to be fearless. You just have to keep doing small hard things.

**Progress isn't perfect.** You'll have setbacks. They don't erase what you've learned.

When things get scary again—and they will—come back to what you've learned. Ten seconds. One tiny brave thing. "I'm anxious AND I'm doing it anyway."

You're going to be okay. Not because life will get easy. Because you're learning how to be brave.

That's a skill that will help you forever.

Take care of yourself, okay?

You're worth taking care of.

---

## END OF GEN ALPHA ANXIETY BOOK

**Word Count:** ~4,200 words

**Phase Structure Verification:**
- Ch 1-2: INTRODUCE (hook, recognition, validation, origin story) ✓
- Ch 3-5: DEEPEN (pattern exposure, cost, core thesis) ✓
- Ch 6-8: TEST (practices, deeper tools, hard days) ✓
- Ch 9: COMPLICATE (paradox, non-linear progress, anxiety doesn't disappear) ✓
- Ch 10-12: INTEGRATE (setbacks, identity shift, continuation) ✓

**Demographic Adaptations:**
- Shorter overall length (age-appropriate attention span)
- Simpler language (no jargon, shorter sentences)
- Age-appropriate examples (school, social stuff, raising hand, parties, friends)
- "Alarm system" metaphor for nervous system (relatable)
- Social media/comparison acknowledged but not central
- Warm older-friend voice (not parental, not peer)
- Practices scaled down (ten seconds, one tiny thing)
- Less existential, more practical
- "You're not a scaredy-cat" emphasis (addresses common message/fear)
- Permission-giving throughout

**Key Differences from Adult Anxiety Book:**
- Core sentence same: "Once I'm not anxious, then I'll do it"
- Practices simplified: "tiny brave things" instead of complex frameworks
- Examples: school, friends, raising hand vs. work, relationships, big decisions
- Length: ~4,200 vs. ~5,500 words
- Voice: Mentor tone vs. peer-professional tone
- Complexity: Single concepts vs. layered insights
